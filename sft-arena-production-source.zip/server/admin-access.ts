const ADMIN_ID = 'usr_fd7c9e87878841af';
export const ADMIN_USERNAME = 'ivvylol';

export function isArenaAdmin(user: {id:string;username:string;is_demo:number;status:string}|null|undefined) {
  return Boolean(user && user.id===ADMIN_ID && user.username.toLowerCase()===ADMIN_USERNAME && !user.is_demo && user.status==='active');
}
