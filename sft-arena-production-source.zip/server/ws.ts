import { isArenaAdmin } from './admin-access.ts';
import { WebSocketServer, WebSocket } from 'ws';
import type { Server as HttpServer } from 'http';
import crypto from 'crypto';
import { db } from './db.ts';

interface ClientMeta {
  ws: WebSocket;
  userId: string | null;
  matchRooms: Set<string>;
}

const clients = new Set<ClientMeta>();

function parseCookies(cookieHeader: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  if (!cookieHeader) return out;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx > 0) {
      const k = part.slice(0, idx).trim();
      const v = part.slice(idx + 1).trim();
      out[k] = decodeURIComponent(v);
    }
  }
  return out;
}

function resolveUserIdFromToken(rawToken: string | undefined): string | null {
  if (!rawToken) return null;
  const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
  const row = db
    .prepare("SELECT user_id FROM user_sessions WHERE token_hash = ? AND revoked_at IS NULL AND expires_at > strftime('%Y-%m-%dT%H:%M:%fZ', 'now')")
    .get(tokenHash) as { user_id: string } | undefined;
  return row?.user_id ?? null;
}

export function attachWebSocketServer(server: HttpServer): void {
  const wss = new WebSocketServer({ server, path: '/ws' });

  wss.on('connection', (ws, req) => {
    const url = new URL(req.url || '/ws', 'http://localhost');
    const cookies = parseCookies(req.headers.cookie);
    const token = cookies['sft_session'] || url.searchParams.get('token') || undefined;
    const userId = resolveUserIdFromToken(token);

    const meta: ClientMeta = {
      ws,
      userId,
      matchRooms: new Set(),
    };
    clients.add(meta);

    ws.send(JSON.stringify({ type: 'connected', authenticated: Boolean(userId), userId }));

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString()) as { type: string; matchId?: string; token?: string };
        if (msg.type === 'auth' && msg.token) {
          meta.userId = resolveUserIdFromToken(msg.token);
          ws.send(JSON.stringify({ type: 'auth_ok', authenticated: Boolean(meta.userId) }));
        } else if (msg.type === 'subscribe_match' && msg.matchId) {
          // Verify private match access if match is private
          const match = db.prepare('SELECT id, is_private FROM matches WHERE id = ?').get(msg.matchId) as { id: string; is_private: number } | undefined;
          if (!match) return;
          if (match.is_private === 1) {
            if (!meta.userId) return;
            const user = db.prepare('SELECT id,username,is_demo,status FROM users WHERE id = ?').get(meta.userId) as Parameters<typeof isArenaAdmin>[0];
            const isStaff = isArenaAdmin(user);
            const isPart = db.prepare('SELECT 1 FROM match_participants WHERE match_id = ? AND user_id = ?').get(msg.matchId, meta.userId);
            const invited = db.prepare('SELECT 1 FROM match_invites WHERE match_id=? AND user_id=?').get(msg.matchId,meta.userId);
            if (!isStaff && !isPart && !invited) return;
          }
          meta.matchRooms.add(msg.matchId);
          ws.send(JSON.stringify({ type: 'subscribed', matchId: msg.matchId }));
        } else if (msg.type === 'unsubscribe_match' && msg.matchId) {
          meta.matchRooms.delete(msg.matchId);
        } else if (msg.type === 'ping') {
          ws.send(JSON.stringify({ type: 'pong', ts: Date.now() }));
        }
      } catch {
        // Ignore malformed WS payloads
      }
    });

    ws.on('close', () => {
      clients.delete(meta);
    });
  });
}

export function broadcastToMatch(matchId: string, payload: Record<string, unknown>): void {
  // Fetch the room under each viewer’s own session instead of broadcasting an actor-specific response.
  const data = JSON.stringify({ type: payload.type, matchId });
  for (const c of clients) {
    if (c.ws.readyState === WebSocket.OPEN && c.matchRooms.has(matchId)) {
      c.ws.send(data);
    }
  }
}

export function broadcastToUser(userId: string, payload: Record<string, unknown>): void {
  const data = JSON.stringify(payload);
  for (const c of clients) {
    if (c.ws.readyState === WebSocket.OPEN && c.userId === userId) {
      c.ws.send(data);
    }
  }
}

export function broadcastGlobal(payload: Record<string, unknown>): void {
  const data = JSON.stringify(payload);
  for (const c of clients) {
    if (c.ws.readyState === WebSocket.OPEN) {
      c.ws.send(data);
    }
  }
}
