import { db, newId } from './db.ts';

export type BalanceBucket = 'available' | 'reserved' | 'frozen';
export type LedgerEntryType =
  | 'deposit_credit'
  | 'withdrawal_reserve'
  | 'withdrawal_confirm'
  | 'withdrawal_refund'
  | 'match_stake_reserve'
  | 'match_stake_release'
  | 'match_win_payout'
  | 'match_fee'
  | 'match_refund'
  | 'match_override_adjustment'
  | 'tournament_entry'
  | 'tournament_refund'
  | 'tournament_payout'
  | 'shop_purchase'
  | 'reward_bonus'
  | 'referral_bonus'
  | 'staff_freeze'
  | 'staff_unfreeze'
  | 'admin_adjustment';

export interface LedgerMutation {
  idempotencyKey: string;
  userId: string;
  entryType: LedgerEntryType;
  bucket: BalanceBucket;
  deltaLamports: number; // integer lamports (+ or -)
  referenceType: string;
  referenceId: string;
  network?: string;
  description: string;
  actorUserId?: string | null;
}

export interface UserBalanceRow {
  user_id: string;
  available_lamports: number;
  reserved_lamports: number;
  frozen_lamports: number;
  updated_at: string;
}

export function getUserBalance(userId: string): UserBalanceRow {
  const row = db
    .prepare('SELECT user_id, available_lamports, reserved_lamports, frozen_lamports, updated_at FROM user_balances WHERE user_id = ?')
    .get(userId) as UserBalanceRow | undefined;
  if (!row) {
    db.prepare('INSERT OR IGNORE INTO user_balances (user_id, available_lamports, reserved_lamports, frozen_lamports) VALUES (?, 0, 0, 0)').run(userId);
    return {
      user_id: userId,
      available_lamports: 0,
      reserved_lamports: 0,
      frozen_lamports: 0,
      updated_at: new Date().toISOString(),
    };
  }
  return row;
}

/**
 * Applies a group of ledger mutations atomically. Must be called inside a SQLite transaction
 * (`db.transaction(...)` or immediate transaction) or it opens one safely.
 */
export function applyLedgerGroup(mutations: LedgerMutation[], txGroupId = newId('txg')): { skipped: boolean; txGroupId: string } {
  for (const m of mutations) {
    if (!Number.isInteger(m.deltaLamports)) {
      throw new Error(`Ledger delta must be integer lamports, received: ${m.deltaLamports}`);
    }
  }

  // Check idempotency across the group first
  for (const m of mutations) {
    const exists = db.prepare('SELECT id FROM ledger_entries WHERE idempotency_key = ?').get(m.idempotencyKey);
    if (exists) {
      return { skipped: true, txGroupId };
    }
  }

  for (const m of mutations) {
    db.prepare('INSERT OR IGNORE INTO user_balances (user_id, available_lamports, reserved_lamports, frozen_lamports) VALUES (?, 0, 0, 0)').run(m.userId);
    const bal = db
      .prepare('SELECT available_lamports, reserved_lamports, frozen_lamports FROM user_balances WHERE user_id = ?')
      .get(m.userId) as { available_lamports: number; reserved_lamports: number; frozen_lamports: number };

    let nextVal = 0;
    if (m.bucket === 'available') {
      nextVal = bal.available_lamports + m.deltaLamports;
      if (nextVal < 0) throw new Error('Insufficient available SOL balance');
      db.prepare("UPDATE user_balances SET available_lamports = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE user_id = ?").run(nextVal, m.userId);
    } else if (m.bucket === 'reserved') {
      nextVal = bal.reserved_lamports + m.deltaLamports;
      if (nextVal < 0) throw new Error('Insufficient reserved SOL balance');
      db.prepare("UPDATE user_balances SET reserved_lamports = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE user_id = ?").run(nextVal, m.userId);
    } else {
      nextVal = bal.frozen_lamports + m.deltaLamports;
      if (nextVal < 0) throw new Error('Insufficient frozen SOL balance');
      db.prepare("UPDATE user_balances SET frozen_lamports = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE user_id = ?").run(nextVal, m.userId);
    }

    db.prepare(`
      INSERT INTO ledger_entries (
        id, tx_group_id, idempotency_key, user_id, entry_type, bucket, delta_lamports, balance_after_lamports,
        reference_type, reference_id, network, description, actor_user_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      newId('led'),
      txGroupId,
      m.idempotencyKey,
      m.userId,
      m.entryType,
      m.bucket,
      m.deltaLamports,
      nextVal,
      m.referenceType,
      m.referenceId,
      m.network ?? 'devnet',
      m.description,
      m.actorUserId ?? null
    );
  }

  return { skipped: false, txGroupId };
}

export function runImmediateTransaction<T>(fn: () => T): T {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    try {
      db.exec('ROLLBACK');
    } catch {
      // ignore rollback errors if connection already rolled back
    }
    throw err;
  }
}
