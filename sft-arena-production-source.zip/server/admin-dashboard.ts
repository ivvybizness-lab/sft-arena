import type { Express } from 'express';
import { requireRole } from './auth.ts';
import { db, newId, writeAuditLog } from './db.ts';
import { runImmediateTransaction } from './ledger.ts';

const staff = requireRole(['moderator', 'finance', 'owner']);
const finance = requireRole(['finance', 'owner']);
const owner = requireRole(['owner']);
const catalogCategories = ['Title', 'Avatar Border', 'Profile Banner', 'Badge'];
const catalogRarities = ['Common', 'Rare', 'Epic', 'Mythic'];

export function registerAdminDashboard(app: Express) {
  app.get('/api/admin/dashboard', staff, (req, res) => {
    const counts = db.prepare(`
      SELECT (SELECT COUNT(DISTINCT user_id) FROM user_sessions WHERE revoked_at IS NULL
        AND expires_at>strftime('%Y-%m-%dT%H:%M:%fZ','now')
        AND last_seen_at>=strftime('%Y-%m-%dT%H:%M:%fZ','now','-90 seconds')) AS online,
      (SELECT COUNT(*) FROM users) AS users,
      (SELECT COUNT(*) FROM users WHERE created_at>=strftime('%Y-%m-%dT%H:%M:%fZ','now','-7 days')) AS signups,
      (SELECT COUNT(*) FROM matches WHERE status IN ('Waiting','Ready','In Progress')) AS open_matches,
      (SELECT COUNT(*) FROM disputes WHERE status IN ('Open','Under Review')) AS disputes
    `).get();
    const sessions = db.prepare(`
      WITH days(day, offset) AS (SELECT date('now','-6 days'),0 UNION ALL
        SELECT date(day,'+1 day'),offset+1 FROM days WHERE offset<6)
      SELECT day, (SELECT COUNT(*) FROM analytics_sessions WHERE started_at>=day AND started_at<date(day,'+1 day')) AS count FROM days
    `).all();
    const financial = req.authUser?.role === 'moderator' ? null : db.prepare(`
      SELECT (SELECT COUNT(*) FROM withdrawal_requests WHERE status IN ('Queued','Needs Review')) AS pending,
             (SELECT COALESCE(SUM(platform_fee_lamports),0) FROM matches WHERE status='Complete') AS fees
    `).get();
    res.json({ counts, sessions, financial });
  });

  app.get('/api/admin/directory/:view', staff, (req, res) => {
    const view = req.params.view;
    const scope = req.query.scope === 'staff';
    const search = String(req.query.q || '').trim().slice(0, 100);
    const q = '%' + search + '%';
    const rawPage = Number(req.query.page || 0);
    const page = Number.isSafeInteger(rawPage) ? Math.max(0, Math.min(rawPage, 20000)) : 0;
    const limit = 50;
    if (view === 'balances' && req.authUser?.role === 'moderator') return res.sendStatus(403);

    const playerSearch = '(u.username LIKE @q OR u.email LIKE @q OR u.epic_display_name LIKE @q OR u.role LIKE @q OR u.id=@search)';
    const queries: Record<string, { from:string; fields:string; order:string }> = {
      users: {
        from: 'FROM users u LEFT JOIN user_balances b ON b.user_id=u.id WHERE '+playerSearch+(scope ? " AND u.role<>'player'" : ''),
        fields: "u.id,u.username,u.email,u.role,u.status,u.wins,u.losses,u.created_at,u.profile_portrait,b.available_lamports",
        order: 'u.created_at DESC,u.id',
      },
      referrals: {
        from: 'FROM users u LEFT JOIN users r ON r.id=u.referred_by_user_id WHERE (u.username LIKE @q OR u.referral_code LIKE @q)'+
          (req.query.referrer ? ' AND u.referred_by_user_id=@referrer' : ''),
        fields: 'u.id,u.username,u.profile_portrait,u.referral_code,r.username AS referrer,(SELECT COUNT(*) FROM users invited WHERE invited.referred_by_user_id=u.id) AS referrals',
        order: 'referrals DESC,u.created_at DESC,u.id',
      },
      signups: {
        from: 'FROM users u WHERE (u.username LIKE @q OR u.email LIKE @q)',
        fields: 'u.id,u.username,u.profile_portrait,u.created_at,u.acquisition_source',
        order: 'u.created_at DESC,u.id',
      },
      balances: {
        from: 'FROM users u JOIN user_balances b ON b.user_id=u.id WHERE '+playerSearch,
        fields: `u.id,u.username,u.email,u.profile_portrait,b.available_lamports,b.reserved_lamports,b.frozen_lamports,
          (SELECT COALESCE(SUM(l.delta_lamports),0) FROM ledger_entries l WHERE l.user_id=u.id AND l.bucket='available'
            AND l.entry_type IN ('match_win_payout','match_override_adjustment','tournament_payout')) AS earnings`,
        order: 'b.available_lamports DESC,u.id',
      },
      matches: {
        from: `FROM matches m WHERE m.id=@search OR m.title LIKE @q OR EXISTS(
          SELECT 1 FROM match_participants p WHERE p.match_id=m.id AND p.username_snapshot LIKE @q)`,
        fields: `m.id,m.title,m.status,m.mode,m.format,m.first_to,m.entry_lamports,m.total_prize_lamports,m.created_at,
          (SELECT group_concat(p.username_snapshot, ', ') FROM match_participants p WHERE p.match_id=m.id) AS players,
          (SELECT group_concat(p.username_snapshot, ', ') FROM match_participants p WHERE p.match_id=m.id AND p.team_side=m.winner_side) AS winner`,
        order: 'm.created_at DESC,m.id',
      },
      bans: {
        from: `FROM users u LEFT JOIN account_status_history h ON h.id=(
          SELECT bh.id FROM account_status_history bh WHERE bh.user_id=u.id AND bh.new_status='banned'
          ORDER BY bh.created_at DESC,bh.rowid DESC LIMIT 1) LEFT JOIN users actor ON actor.id=h.actor_user_id
          WHERE u.status='banned' AND ${playerSearch}`,
        fields: 'u.id,u.username,u.profile_portrait,u.role,h.reason,h.created_at,actor.username AS banned_by',
        order: 'h.created_at DESC,u.id',
      },
    };
    if (!Object.hasOwn(queries,view)) return res.sendStatus(404);
    const query = queries[view];
    const params = { q, search, limit, offset:page*limit, referrer:String(req.query.referrer || '') };
    const rows = db.prepare(`SELECT ${query.fields} ${query.from} ORDER BY ${query.order} LIMIT @limit OFFSET @offset`).all(params);
    const count = db.prepare(`SELECT COUNT(*) AS total ${query.from}`).get(params) as {total:number};
    res.json({ rows, total:count.total, limit });
  });

  app.get('/api/admin/money/:view', finance, (req, res) => {
    const q = '%' + String(req.query.q || '').trim().slice(0,100) + '%';
    if (req.params.view === 'deposits') {
      const rows = db.prepare(`SELECT d.id,d.network,d.base_lamports,d.expected_lamports,d.received_lamports,d.status,
        d.matched_signature,d.created_at,d.matched_at,u.id AS user_id,u.username,u.email
        FROM deposit_invoices d JOIN users u ON u.id=d.user_id
        WHERE u.username LIKE @q OR u.email LIKE @q OR d.id LIKE @q OR d.matched_signature LIKE @q
        ORDER BY d.status='Needs Review' DESC,d.created_at DESC LIMIT 100`).all({q});
      return res.json({rows});
    }
    if (req.params.view === 'withdrawals') {
      const rows = db.prepare(`SELECT w.id,w.network,w.amount_lamports,w.fee_lamports,w.status,w.tx_signature,w.destination_address,
        w.created_at,w.confirmed_at,u.id AS user_id,u.username,u.email,r.username AS reviewer
        FROM withdrawal_requests w JOIN users u ON u.id=w.user_id LEFT JOIN users r ON r.id=w.reviewed_by_user_id
        WHERE u.username LIKE @q OR u.email LIKE @q OR w.id LIKE @q OR w.destination_address LIKE @q
        ORDER BY w.status='Needs Review' DESC,w.status='Queued' DESC,w.created_at DESC LIMIT 100`).all({q});
      return res.json({rows});
    }
    if (req.params.view === 'audit') {
      const rows = db.prepare(`SELECT l.id,l.entry_type,l.description,l.delta_lamports,l.bucket,l.created_at,
        l.reference_id,u.username,actor.username AS actor
        FROM ledger_entries l JOIN users u ON u.id=l.user_id LEFT JOIN users actor ON actor.id=l.actor_user_id
        WHERE u.username LIKE @q OR l.entry_type LIKE @q OR l.reference_id LIKE @q OR l.description LIKE @q
        ORDER BY l.created_at DESC LIMIT 100`).all({q});
      const totals = db.prepare(`SELECT COALESCE(SUM(available_lamports),0) AS available,
        COALESCE(SUM(reserved_lamports),0) AS reserved,COALESCE(SUM(frozen_lamports),0) AS frozen FROM user_balances`).get();
      return res.json({rows,totals});
    }
    res.sendStatus(404);
  });

  app.patch('/api/admin/referrals/:id', owner, (req,res) => {
    const code = String(req.body?.code || '').trim();
    if (!/^[a-z0-9_-]{3,24}$/i.test(code)) return res.status(400).json({error:'Use 3–24 letters, digits, hyphens, or underscores.'});
    const staffUser = req.authUser!;
    const result = runImmediateTransaction(() => {
      if (!db.prepare('SELECT id FROM users WHERE id=?').get(req.params.id)) return 404;
      if (db.prepare('SELECT id FROM users WHERE referral_code=? COLLATE NOCASE AND id<>?').get(code,req.params.id)) return 409;
      db.prepare('UPDATE users SET referral_code=? WHERE id=?').run(code,req.params.id);
      writeAuditLog({actorUserId:staffUser.id,actorRole:staffUser.role,action:'referral_code_updated',entityType:'user',entityId:req.params.id,summary:'Updated referral code'});
      return 200;
    });
    res.status(result).json(result === 200 ? {ok:true} : {error:result===404?'Player not found.':'That referral code is already in use.'});
  });

  app.get('/api/admin/rewards', staff, (_req,res) => {
    const rows = db.prepare(`SELECT c.id,c.reward_label,c.amount_lamports,c.created_at,u.username,u.profile_portrait
      FROM rewards_claims c JOIN users u ON u.id=c.user_id ORDER BY c.created_at DESC LIMIT 100`).all();
    res.json({rows});
  });

  app.get('/api/admin/catalog', staff, (_req,res) => {
    res.json({rows:db.prepare('SELECT * FROM shop_items ORDER BY is_active DESC,is_featured DESC,created_at DESC').all()});
  });

  app.put('/api/admin/catalog/:id', owner, (req,res) => {
    const staffUser = req.authUser!;
    const id = req.params.id === 'new' ? newId('shop') : req.params.id;
    const {category,rarity,price_lamports,featured,active} = req.body || {};
    const name = String(req.body?.name || '').trim().slice(0,80);
    const description = String(req.body?.description || '').trim().slice(0,250);
    const preview = String(req.body?.preview_value || '').trim().slice(0,80);
    if (!name || !catalogCategories.includes(category) || !catalogRarities.includes(rarity)
      || !Number.isSafeInteger(price_lamports) || price_lamports < 0 || typeof featured !== 'boolean' || typeof active !== 'boolean') {
      return res.status(400).json({error:'Enter a valid item name, category, rarity, and SOL price.'});
    }
    const isNew = req.params.id === 'new';
    const changed = runImmediateTransaction(() => {
      if (isNew) {
        db.prepare(`INSERT INTO shop_items(id,name,description,category,rarity,price_lamports,preview_value,is_featured,is_active)
          VALUES(?,?,?,?,?,?,?,?,?)`).run(id,name,description,category,rarity,price_lamports,preview,+featured,+active);
      } else {
        if (!db.prepare('UPDATE shop_items SET name=?,description=?,category=?,rarity=?,price_lamports=?,preview_value=?,is_featured=?,is_active=? WHERE id=?')
          .run(name,description,category,rarity,price_lamports,preview,+featured,+active,id).changes) return false;
      }
      writeAuditLog({actorUserId:staffUser.id,actorRole:staffUser.role,action:isNew?'shop_item_created':'shop_item_updated',entityType:'shop_item',entityId:id,summary:name});
      return true;
    });
    res.status(changed ? 200 : 404).json(changed ? {id} : {error:'Item not found.'});
  });

  app.post('/api/admin/catalog/:id/gift', owner, (req,res) => {
    const staffUser = req.authUser!;
    const userId = typeof req.body?.userId==='string' ? req.body.userId : '';
    const result = runImmediateTransaction(() => {
      const item = db.prepare('SELECT name FROM shop_items WHERE id=? AND is_active=1').get(req.params.id) as {name:string}|undefined;
      if (!item || !db.prepare('SELECT id FROM users WHERE id=?').get(userId)) return 404;
      const inserted = db.prepare(`INSERT INTO user_inventory(id,user_id,item_id,purchased_lamports) VALUES(?,?,?,0)
        ON CONFLICT(user_id,item_id) DO NOTHING`).run(newId('inv'),userId,req.params.id);
      if (!inserted.changes) return 409;
      writeAuditLog({actorUserId:staffUser.id,actorRole:staffUser.role,action:'shop_item_gifted',entityType:'user',entityId:userId,summary:'Gifted '+item.name});
      return 201;
    });
    res.status(result).json(result===201 ? {ok:true} : {error:result===409?'This player already owns the item.':'Player or active item not found.'});
  });
}
