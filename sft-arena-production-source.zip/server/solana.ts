import { hostedDemo } from './hosting.ts';
import type { Express } from 'express';
import crypto from 'crypto';
import {
  Connection,
  PublicKey,
  SystemProgram,
  Transaction,
  sendAndConfirmTransaction,
} from '@solana/web3.js';
import { db, newId, writeAuditLog, notifyUser } from './db.ts';
import { applyLedgerGroup, getUserBalance, runImmediateTransaction } from './ledger.ts';
import { getServerTreasuryKeypair, getServerTreasuryPublicAddress, LAMPORTS_PER_SOL } from './seed.ts';
import { requireAuth, requireRole } from './auth.ts';

function getRpcConnection(): Connection {
  const rpcUrl = process.env.SOLANA_RPC_URL || 'https://api.devnet.solana.com';
  return new Connection(rpcUrl, 'confirmed');
}

function getWalletConfig() {
  return db.prepare('SELECT * FROM wallet_config WHERE id = 1').get() as {
    id: number;
    network_mode: 'demo' | 'devnet' | 'mainnet';
    mainnet_enabled: number;
    paid_matches_enabled: number;
    fee_bps: number;
    min_withdrawal_lamports: number;
    treasury_address: string;
  };
}

/**
 * Generates a unique 9-decimal suffix (between 1001 and 99999 lamports) not currently active
 * so each Waiting deposit invoice has a globally unique exact lamport amount.
 */
function allocateUniqueSuffix(): number {
  for (let i = 0; i < 40; i++) {
    const candidate = crypto.randomInt(1001, 99999);
    const clash = db
      .prepare("SELECT id FROM deposit_invoices WHERE status = 'Waiting' AND unique_suffix_lamports = ?")
      .get(candidate);
    if (!clash) return candidate;
  }
  return crypto.randomInt(100000, 999999);
}

/**
 * Core idempotent deposit processor shared by the live Solana Devnet RPC watcher and test verification harness.
 */
export function processIncomingSolanaTransfer(params: {
  network: string;
  txSignature: string;
  instructionIndex: number;
  fromAddress: string;
  toAddress: string;
  lamports: number;
  receivedAtIso?: string;
}): {
  outcome: 'Matched' | 'Wrong Amount' | 'Late' | 'Unmatched' | 'Duplicate Ignored';
  invoiceId?: string;
  transferId?: string;
} {
  const cfg = getWalletConfig();
  if (params.toAddress !== cfg.treasury_address) {
    return { outcome: 'Unmatched' };
  }

  let result: {
    outcome: 'Matched' | 'Wrong Amount' | 'Late' | 'Unmatched' | 'Duplicate Ignored';
    invoiceId?: string;
    transferId?: string;
  } = { outcome: 'Unmatched' };

  runImmediateTransaction(() => {
    // 1. Strict unique check on (network, tx_signature, instruction_index)
    const dup = db
      .prepare('SELECT id FROM processed_chain_transfers WHERE network = ? AND tx_signature = ? AND instruction_index = ?')
      .get(params.network, params.txSignature, params.instructionIndex) as { id: string } | undefined;

    if (dup) {
      result = { outcome: 'Duplicate Ignored', transferId: dup.id };
      return;
    }

    // Expire old invoices past expires_at using server time
    db.prepare(`
      UPDATE deposit_invoices
      SET status = 'Expired'
      WHERE status = 'Waiting' AND expires_at < strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
    `).run();

    // 2. Look for active Waiting invoice with exact expected_lamports
    const exactWaiting = db
      .prepare("SELECT * FROM deposit_invoices WHERE status = 'Waiting' AND expected_lamports = ? ORDER BY created_at DESC LIMIT 1")
      .get(params.lamports) as {
      id: string;
      user_id: string;
      base_lamports: number;
      expected_lamports: number;
    } | undefined;

    const transferId = newId('txf');

    if (exactWaiting) {
      // Exact match -> credit user available balance atomically with idempotency
      applyLedgerGroup([
        {
          idempotencyKey: `dep_${params.network}_${params.txSignature}_${params.instructionIndex}`,
          userId: exactWaiting.user_id,
          entryType: 'deposit_credit',
          bucket: 'available',
          deltaLamports: params.lamports,
          referenceType: 'deposit_invoice',
          referenceId: exactWaiting.id,
          network: params.network,
          description: `SOL deposit confirmed (${(params.lamports / LAMPORTS_PER_SOL).toFixed(9)} SOL)`,
        },
      ]);

      db.prepare(`
        UPDATE deposit_invoices
        SET status = 'Matched', matched_signature = ?, matched_instruction_index = ?,
            received_lamports = ?, matched_sender_address = ?,
            matched_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
        WHERE id = ?
      `).run(params.txSignature, params.instructionIndex, params.lamports, params.fromAddress, exactWaiting.id);

      db.prepare(`
        INSERT INTO processed_chain_transfers (
          id, network, tx_signature, instruction_index, from_address, to_address, lamports, status, matched_invoice_id, note
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Matched', ?, 'Exact Waiting invoice matched and credited')
      `).run(transferId, params.network, params.txSignature, params.instructionIndex, params.fromAddress, params.toAddress, params.lamports, exactWaiting.id);

      notifyUser({
        userId: exactWaiting.user_id,
        category: 'wallet',
        title: 'SOL Deposit Credited',
        body: `${(params.lamports / LAMPORTS_PER_SOL).toFixed(9)} SOL credited to your wallet.`,
        linkUrl: '/profile/' + encodeURIComponent((db.prepare('SELECT username FROM users WHERE id = ?').get(exactWaiting.user_id) as { username: string }).username) + '?tab=deposits',
      });

      result = { outcome: 'Matched', invoiceId: exactWaiting.id, transferId };
      return;
    }

    // 3. Check if it matched an Expired invoice (Late transfer -> Needs Review, never auto-credit)
    const lateExpired = db
      .prepare("SELECT * FROM deposit_invoices WHERE status = 'Expired' AND expected_lamports = ? ORDER BY created_at DESC LIMIT 1")
      .get(params.lamports) as { id: string; user_id: string } | undefined;

    if (lateExpired) {
      db.prepare(`
        UPDATE deposit_invoices
        SET status = 'Needs Review', matched_signature = ?, matched_instruction_index = ?,
            received_lamports = ?, matched_sender_address = ?,
            review_note = 'Late transfer received after invoice expiry — requires finance approval'
        WHERE id = ?
      `).run(params.txSignature, params.instructionIndex, params.lamports, params.fromAddress, lateExpired.id);

      db.prepare(`
        INSERT INTO processed_chain_transfers (
          id, network, tx_signature, instruction_index, from_address, to_address, lamports, status, matched_invoice_id, note
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Late', ?, 'Arrived after invoice expiry; queued for finance review')
      `).run(transferId, params.network, params.txSignature, params.instructionIndex, params.fromAddress, params.toAddress, params.lamports, lateExpired.id);

      result = { outcome: 'Late', invoiceId: lateExpired.id, transferId };
      return;
    }

    // 4. Check if amount is close to an active Waiting invoice (e.g. sender sent base amount without unique suffix or wrong lamports)
    const possibleWrongAmt = db
      .prepare("SELECT * FROM deposit_invoices WHERE status = 'Waiting' AND ABS(expected_lamports - ?) <= 5000000 ORDER BY created_at DESC LIMIT 1")
      .get(params.lamports) as { id: string; user_id: string } | undefined;

    if (possibleWrongAmt) {
      db.prepare(`
        UPDATE deposit_invoices
        SET status = 'Needs Review', matched_signature = ?, matched_instruction_index = ?,
            received_lamports = ?, matched_sender_address = ?,
            review_note = 'Wrong SOL amount transferred vs unique invoice suffix — queued for finance review'
        WHERE id = ?
      `).run(params.txSignature, params.instructionIndex, params.lamports, params.fromAddress, possibleWrongAmt.id);

      db.prepare(`
        INSERT INTO processed_chain_transfers (
          id, network, tx_signature, instruction_index, from_address, to_address, lamports, status, matched_invoice_id, note
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Wrong Amount', ?, 'Transfer amount differed from expected 9-decimal invoice')
      `).run(transferId, params.network, params.txSignature, params.instructionIndex, params.fromAddress, params.toAddress, params.lamports, possibleWrongAmt.id);

      result = { outcome: 'Wrong Amount', invoiceId: possibleWrongAmt.id, transferId };
      return;
    }

    // 5. Completely Unmatched transfer -> store cleanly for manual finance inspection
    db.prepare(`
      INSERT INTO processed_chain_transfers (
        id, network, tx_signature, instruction_index, from_address, to_address, lamports, status, matched_invoice_id, note
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Unmatched', NULL, 'No matching deposit invoice found')
    `).run(transferId, params.network, params.txSignature, params.instructionIndex, params.fromAddress, params.toAddress, params.lamports);

    result = { outcome: 'Unmatched', transferId };
  });

  return result;
}

/**
 * Polls configured Solana RPC treasury address and updates persistent cursor cleanly.
 */
export async function syncSolanaDevnetDeposits(): Promise<{ scanned: number; network: string }> {
  const cfg = getWalletConfig();
  if (!cfg.treasury_address) return { scanned: 0, network: cfg.network_mode };
  if (cfg.network_mode === 'demo') return { scanned: 0, network: 'demo' };

  const conn = getRpcConnection();
  let pubkey: PublicKey;
  try {
    pubkey = new PublicKey(cfg.treasury_address);
  } catch {
    return { scanned: 0, network: cfg.network_mode };
  }

  const cursor = db.prepare('SELECT * FROM solana_watcher_cursor WHERE network = ?').get(cfg.network_mode) as
    | { last_signature: string | null; last_slot: number }
    | undefined;

  let scanned = 0;
  try {
    const sigs = await conn.getSignaturesForAddress(pubkey, {
      limit: 20,
      ...(cursor?.last_signature ? { until: cursor.last_signature } : {}),
    });

    if (sigs.length > 0) {
      // Process oldest-to-newest
      const ordered = [...sigs].reverse();
      for (const s of ordered) {
        if (s.err) continue;
        const parsed = await conn.getParsedTransaction(s.signature, { maxSupportedTransactionVersion: 0 });
        if (!parsed?.transaction?.message?.instructions) continue;

        parsed.transaction.message.instructions.forEach((ix, idx) => {
          if ('parsed' in ix && ix.program === 'system' && ix.parsed?.type === 'transfer') {
            const info = ix.parsed.info as { source: string; destination: string; lamports: number };
            if (info.destination === cfg.treasury_address && Number(info.lamports) > 0) {
              processIncomingSolanaTransfer({
                network: cfg.network_mode,
                txSignature: s.signature,
                instructionIndex: idx,
                fromAddress: info.source,
                toAddress: info.destination,
                lamports: Number(info.lamports),
              });
              scanned++;
            }
          }
        });
      }

      const newest = sigs[0];
      db.prepare(`
        UPDATE solana_watcher_cursor
        SET last_signature = ?, last_slot = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
        WHERE network = ?
      `).run(newest.signature, newest.slot, cfg.network_mode);
    }
  } catch {
    // RPC network hiccups don't crash the app; durable cursor retries cleanly on next tick
  }

  return { scanned, network: cfg.network_mode };
}

let watcherTimer: NodeJS.Timeout | null = null;
export function startSolanaWatcherLoop() {
  if (watcherTimer) return;
  watcherTimer = setInterval(() => {
    syncSolanaDevnetDeposits().catch(() => {});
  }, 30_000);
}

/**
 * Safely processes or retries a queued withdrawal.
 * Persists signed tx / tx_signature BEFORE or DURING broadcast so retries never double-send.
 */
export async function executeOrRetryWithdrawal(withdrawalId: string, options?: { simulateUncertainTimeout?: boolean }) {
  const w = db.prepare('SELECT * FROM withdrawal_requests WHERE id = ?').get(withdrawalId) as {
    id: string;
    user_id: string;
    network: string;
    destination_address: string;
    amount_lamports: number;
    fee_lamports: number;
    status: string;
    tx_signature: string | null;
    signed_tx_base64: string | null;
    attempt_count: number;
  } | undefined;

  if (!w) throw new Error('Withdrawal request not found');
  if (w.status === 'Confirmed') return { status: 'Confirmed', txSignature: w.tx_signature };
  if (w.status === 'Failed') return { status: 'Failed' };

  // Validate Solana address
  let destPubkey: PublicKey;
  try {
    destPubkey = new PublicKey(w.destination_address);
  } catch {
    runImmediateTransaction(() => {
      applyLedgerGroup([
        {
          idempotencyKey: `wd_refund_${w.id}`,
          userId: w.user_id,
          entryType: 'withdrawal_refund',
          bucket: 'reserved',
          deltaLamports: -w.amount_lamports,
          referenceType: 'withdrawal',
          referenceId: w.id,
          network: w.network,
          description: 'Invalid Solana destination address — refunding reserved SOL',
        },
        {
          idempotencyKey: `wd_refund_av_${w.id}`,
          userId: w.user_id,
          entryType: 'withdrawal_refund',
          bucket: 'available',
          deltaLamports: w.amount_lamports,
          referenceType: 'withdrawal',
          referenceId: w.id,
          network: w.network,
          description: 'Refunded failed withdrawal back to available balance',
        },
      ]);
      db.prepare("UPDATE withdrawal_requests SET status = 'Failed', last_error = 'Invalid Solana public key', updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(w.id);
    });
    return { status: 'Failed' };
  }

  // If we already have a tx_signature from an earlier uncertain attempt, verify it FIRST on-chain before rebroadcasting!
  const conn = getRpcConnection();
  if (w.tx_signature && w.network !== 'demo' && !w.tx_signature.startsWith('demo_wd_')) {
    try {
      const st = await conn.getSignatureStatus(w.tx_signature);
      if (st.value?.confirmationStatus === 'confirmed' || st.value?.confirmationStatus === 'finalized') {
        runImmediateTransaction(() => {
          applyLedgerGroup([
            {
              idempotencyKey: `wd_conf_${w.id}`,
              userId: w.user_id,
              entryType: 'withdrawal_confirm',
              bucket: 'reserved',
              deltaLamports: -w.amount_lamports,
              referenceType: 'withdrawal',
              referenceId: w.id,
              network: w.network,
              description: `Withdrawal confirmed on ${w.network}: ${w.tx_signature}`,
            },
          ]);
          db.prepare("UPDATE withdrawal_requests SET status = 'Confirmed', confirmed_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now'), updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(w.id);
        });
        return { status: 'Confirmed', txSignature: w.tx_signature, reconciledExisting: true };
      }
    } catch {
      // Keep status Needs Review / Processing safely
    }
  }

  // Build & persist signed transaction BEFORE broadcast if not already persisted
  let signedB64 = w.signed_tx_base64;
  let precomputedSig = w.tx_signature;
  const kp = await getServerTreasuryKeypair();

  if (!signedB64 && kp) {
    const netAmount = Math.max(1, w.amount_lamports - w.fee_lamports);
    const tx = new Transaction().add(
      SystemProgram.transfer({
        fromPubkey: kp.publicKey,
        toPubkey: destPubkey,
        lamports: netAmount,
      })
    );

    if (w.network === 'demo' || options?.simulateUncertainTimeout) {
      // Deterministic signed payload persisted prior to broadcast
      tx.recentBlockhash = '11111111111111111111111111111111' as never;
      tx.feePayer = kp.publicKey;
      await tx.sign(kp);
      signedB64 = Buffer.from(await tx.serialize({ requireAllSignatures: false })).toString('base64');
      precomputedSig = `demo_wd_${crypto.createHash('sha256').update(w.id).digest('hex').slice(0, 32)}`;
    } else {
      try {
        const latest = await conn.getLatestBlockhash('confirmed');
        tx.recentBlockhash = latest.blockhash;
        tx.feePayer = kp.publicKey;
        await tx.sign(kp);
        signedB64 = Buffer.from(await tx.serialize()).toString('base64');
      } catch {
        // Fallback if RPC unreachable during sandbox dev
      }
    }

    db.prepare(`
      UPDATE withdrawal_requests
      SET status = 'Processing', signed_tx_base64 = ?, tx_signature = COALESCE(tx_signature, ?),
          attempt_count = attempt_count + 1, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
      WHERE id = ?
    `).run(signedB64, precomputedSig, w.id);
  }

  // Simulate uncertain RPC timeout scenario for E2E retry verification
  if (options?.simulateUncertainTimeout) {
    db.prepare(`
      UPDATE withdrawal_requests
      SET status = 'Needs Review', last_error = 'RPC confirmation timeout — signed tx persisted, safe reconciliation required',
          updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
      WHERE id = ?
    `).run(w.id);
    return { status: 'Needs Review', txSignature: precomputedSig };
  }

  // In demo mode or retry reconciliation on persisted demo tx, finalize cleanly ONCE via ledger idempotency!
  if (w.network === 'demo' || (precomputedSig && precomputedSig.startsWith('demo_wd_'))) {
    const finalSig = precomputedSig || `demo_wd_${crypto.createHash('sha256').update(w.id).digest('hex').slice(0, 32)}`;
    runImmediateTransaction(() => {
      applyLedgerGroup([
        {
          idempotencyKey: `wd_conf_${w.id}`,
          userId: w.user_id,
          entryType: 'withdrawal_confirm',
          bucket: 'reserved',
          deltaLamports: -w.amount_lamports,
          referenceType: 'withdrawal',
          referenceId: w.id,
          network: w.network,
          description: `Withdrawal confirmed (${w.network}): ${finalSig}`,
        },
      ]);
      db.prepare("UPDATE withdrawal_requests SET status = 'Confirmed', tx_signature = ?, confirmed_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now'), updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(finalSig, w.id);
    });
    return { status: 'Confirmed', txSignature: finalSig };
  }

  // Real Solana Devnet broadcast if treasury is funded
  if (kp && signedB64) {
    try {
      const tx = Transaction.from(Buffer.from(signedB64, 'base64'));
      const sig = await sendAndConfirmTransaction(conn, tx, [kp], { commitment: 'confirmed' });
      runImmediateTransaction(() => {
        applyLedgerGroup([
          {
            idempotencyKey: `wd_conf_${w.id}`,
            userId: w.user_id,
            entryType: 'withdrawal_confirm',
            bucket: 'reserved',
            deltaLamports: -w.amount_lamports,
            referenceType: 'withdrawal',
            referenceId: w.id,
            network: w.network,
            description: `Solana ${w.network} withdrawal confirmed: ${sig}`,
          },
        ]);
        db.prepare("UPDATE withdrawal_requests SET status = 'Confirmed', tx_signature = ?, confirmed_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now'), updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(sig, w.id);
      });
      return { status: 'Confirmed', txSignature: sig };
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Solana broadcast error';
      db.prepare("UPDATE withdrawal_requests SET status = 'Needs Review', last_error = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(msg.slice(0, 240), w.id);
      return { status: 'Needs Review', error: msg };
    }
  }

  return { status: w.status };
}

export function registerWalletRoutes(app: Express) {
  // Wallet summary for authenticated user
  app.get('/api/wallet', requireAuth, async (req, res) => {
    const user = req.authUser!;
    const cfg = getWalletConfig();
    const balance = getUserBalance(user.id);

    // Expire overdue waiting invoices first
    db.prepare("UPDATE deposit_invoices SET status = 'Expired' WHERE status = 'Waiting' AND expires_at < strftime('%Y-%m-%dT%H:%M:%fZ', 'now')").run();

    const invoices = db
      .prepare('SELECT * FROM deposit_invoices WHERE user_id = ? ORDER BY created_at DESC LIMIT 20')
      .all(user.id);
    const withdrawals = db
      .prepare('SELECT id, network, destination_address, amount_lamports, fee_lamports, status, tx_signature, attempt_count, last_error, created_at, confirmed_at FROM withdrawal_requests WHERE user_id = ? ORDER BY created_at DESC LIMIT 20')
      .all(user.id);
    const ledger = db
      .prepare('SELECT * FROM ledger_entries WHERE user_id = ? ORDER BY created_at DESC LIMIT 50')
      .all(user.id);

    const treasuryAddr = cfg.treasury_address || (await getServerTreasuryPublicAddress());

    res.json({
      config: {
        networkMode: cfg.network_mode,
        mainnetEnabled: Boolean(cfg.mainnet_enabled),
        paidMatchesEnabled: Boolean(cfg.paid_matches_enabled),
        feeBps: cfg.fee_bps,
        minWithdrawalLamports: cfg.min_withdrawal_lamports,
        treasuryAddress: treasuryAddr,
      },
      balance,
      invoices,
      withdrawals,
      ledger,
    });
  });

  // Create SOL Deposit Invoice with unique 9-decimal lamport suffix
  app.post('/api/wallet/deposit-invoice', requireAuth, async (req, res) => {
    if (req.body?.asset !== undefined && req.body.asset !== 'SOL') return res.status(400).json({error:'This wallet accepts only native SOL.'});
    const user = req.authUser!;
    const cfg = getWalletConfig();
    const solAmount = Number(req.body?.amountSol || 0);
    if (!Number.isFinite(solAmount) || solAmount <= 0 || solAmount > 500) {
      return res.status(400).json({ error: 'Enter a deposit amount between 0.001 and 500 SOL' });
    }

    const baseLamports = Math.round(solAmount * LAMPORTS_PER_SOL);
    const uniqueSuffix = allocateUniqueSuffix();
    const expectedLamports = baseLamports + uniqueSuffix;
    const invoiceId = newId('inv');
    const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();
    const treasuryAddr = cfg.treasury_address || (await getServerTreasuryPublicAddress());

    db.prepare(`
      INSERT INTO deposit_invoices (
        id, user_id, network, treasury_address, base_lamports, unique_suffix_lamports, expected_lamports, status, expires_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Waiting', ?)
    `).run(invoiceId, user.id, cfg.network_mode, treasuryAddr, baseLamports, uniqueSuffix, expectedLamports, expiresAt);

    const invoice = db.prepare('SELECT * FROM deposit_invoices WHERE id = ?').get(invoiceId);
    res.status(201).json({ invoice });
  });

  app.post('/api/wallet/tip', requireAuth, (req, res) => {
    if (req.body?.asset !== undefined && req.body.asset !== 'SOL') return res.status(400).json({error:'This wallet accepts only native SOL.'});
    const sender = req.authUser!;
    const { username, amountSol, requestId } = req.body ?? {};
    const amount = Math.round(Number(amountSol) * LAMPORTS_PER_SOL);
    if (typeof username !== 'string' || typeof requestId !== 'string' || !/^[a-f0-9-]{36}$/i.test(requestId)
      || !Number.isSafeInteger(amount) || amount < 1 || amount > 500 * LAMPORTS_PER_SOL) {
      return res.status(400).json({error:'Enter a player username and a valid tip amount.'});
    }
    try {
      runImmediateTransaction(() => {
        if (getWalletConfig().network_mode !== 'demo') throw Error('Player tips are available with simulated SOL only.');
        const recipient = db.prepare("SELECT id,username FROM users WHERE username=? AND status='active'").get(username.trim()) as {id:string;username:string}|undefined;
        if (!recipient || recipient.id === sender.id) throw Error('Choose another active SFT player.');
        if (sender.status !== 'active' || db.prepare('SELECT 1 FROM player_moderation WHERE lock_tipping=1 AND user_id IN (?,?)').get(sender.id,recipient.id)) {
          throw Error('Tipping is unavailable for this account.');
        }
        const referenceId = sender.id+':'+requestId;
        const entry = db.prepare("SELECT tx_group_id, delta_lamports FROM ledger_entries WHERE idempotency_key=?").get(referenceId+':send') as {tx_group_id:string;delta_lamports:number}|undefined;
        if (entry) {
          const identical = entry.delta_lamports === -amount && db.prepare("SELECT 1 FROM ledger_entries WHERE tx_group_id=? AND idempotency_key=? AND user_id=?").get(entry.tx_group_id,referenceId+':receive',recipient.id);
          if (!identical) throw Error('This tip request was already used.');
          return;
        }
        applyLedgerGroup([
          {idempotencyKey:referenceId+':send',userId:sender.id,entryType:'admin_adjustment',bucket:'available',deltaLamports:-amount,
            referenceType:'demo_tip',referenceId,network:'demo',description:'Simulated SOL tip to '+recipient.username,actorUserId:sender.id},
          {idempotencyKey:referenceId+':receive',userId:recipient.id,entryType:'admin_adjustment',bucket:'available',deltaLamports:amount,
            referenceType:'demo_tip',referenceId,network:'demo',description:'Simulated SOL tip from '+sender.username,actorUserId:sender.id},
        ]);
      });
      res.json({ok:true});
    } catch (error) {res.status(400).json({error:(error as Error).message});}
  });

  // Trigger manual Solana RPC sync
  app.post('/api/wallet/sync', requireAuth, async (_req, res) => {
    const result = await syncSolanaDevnetDeposits();
    res.json(result);
  });

  // Request SOL Withdrawal (atomic reserve + execution pipeline)
  app.post('/api/wallet/withdraw', requireAuth, async (req, res) => {
    if (req.body?.asset !== undefined && req.body.asset !== 'SOL') return res.status(400).json({error:'This wallet accepts only native SOL.'});
    const user = req.authUser!;
    const cfg = getWalletConfig();
    const { destinationAddress, amountSol, idempotencyKey, simulateUncertainTimeout } = req.body || {};

    if (user.status === 'restricted') {
      return res.status(403).json({ error: 'Restricted accounts cannot withdraw SOL' });
    }

    const dest = String(destinationAddress || user.payout_address || '').trim();
    if (!dest) return res.status(400).json({ error: 'Valid Solana destination wallet address is required' });

    try {
      new PublicKey(dest);
    } catch {
      return res.status(400).json({ error: 'Invalid Solana wallet address format' });
    }

    const amountLamports = Math.round(Number(amountSol || 0) * LAMPORTS_PER_SOL);
    if (!Number.isInteger(amountLamports) || amountLamports < cfg.min_withdrawal_lamports) {
      return res.status(400).json({
        error: `Minimum withdrawal is ${(cfg.min_withdrawal_lamports / LAMPORTS_PER_SOL).toFixed(4)} SOL`,
      });
    }

    const wdId = newId('wd');
    const idem = String(idempotencyKey || newId('wdidem'));

    try {
      runImmediateTransaction(() => {
        const existing = db.prepare('SELECT id FROM withdrawal_requests WHERE idempotency_key = ?').get(idem);
        if (existing) throw new Error('Duplicate withdrawal request ignored');

        applyLedgerGroup([
          {
            idempotencyKey: `wd_res_av_${wdId}`,
            userId: user.id,
            entryType: 'withdrawal_reserve',
            bucket: 'available',
            deltaLamports: -amountLamports,
            referenceType: 'withdrawal',
            referenceId: wdId,
            network: cfg.network_mode,
            description: `Reserved ${(amountLamports / LAMPORTS_PER_SOL).toFixed(4)} SOL for withdrawal to ${dest.slice(0, 8)}...`,
            actorUserId: user.id,
          },
          {
            idempotencyKey: `wd_res_lock_${wdId}`,
            userId: user.id,
            entryType: 'withdrawal_reserve',
            bucket: 'reserved',
            deltaLamports: amountLamports,
            referenceType: 'withdrawal',
            referenceId: wdId,
            network: cfg.network_mode,
            description: `Locked SOL pending broadcast`,
            actorUserId: user.id,
          },
        ]);

        // Rapid deposit->withdraw risk check (flagged if deposited < 1h ago with 0 matches)
        const recentDep = db
          .prepare("SELECT id FROM deposit_invoices WHERE user_id = ? AND status = 'Matched' AND matched_at >= datetime('now', '-1 hour')")
          .get(user.id);
        const recentMatch = db
          .prepare("SELECT id FROM match_participants WHERE user_id = ? AND joined_at >= datetime('now', '-2 hours')")
          .get(user.id);
        if (recentDep && !recentMatch) {
          db.prepare(`
            INSERT INTO risk_flags (id, user_id, flag_type, severity, details_json)
            VALUES (?, ?, 'rapid_deposit_withdraw', 'high', ?)
          `).run(newId('rf'), user.id, JSON.stringify({ withdrawalId: wdId, amountLamports }));
        }

        db.prepare(`
          INSERT INTO withdrawal_requests (id, user_id, network, destination_address, amount_lamports, fee_lamports, status, idempotency_key)
          VALUES (?, ?, ?, ?, ?, 5000, 'Queued', ?)
        `).run(wdId, user.id, cfg.network_mode, dest, amountLamports, idem);
      });

      const execResult = await executeOrRetryWithdrawal(wdId, {
        simulateUncertainTimeout: Boolean(simulateUncertainTimeout) && cfg.network_mode !== 'mainnet',
      });

      const updated = db.prepare('SELECT * FROM withdrawal_requests WHERE id = ?').get(wdId);
      res.status(201).json({ withdrawal: updated, execution: execResult });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to process withdrawal';
      res.status(400).json({ error: msg });
    }
  });

  // Devnet / Demo Deposit Simulation Helper (strictly gated out of mainnet, Finance/Owner/Tester verified)
  app.post('/api/wallet/devnet-simulate-transfer', requireAuth, (req, res) => {
    const cfg = getWalletConfig();
    if (cfg.network_mode === 'mainnet') {
      return res.status(403).json({ error: 'Simulation disabled in mainnet mode' });
    }
    const user = req.authUser!;
    const { invoiceId, overrideLamports, forceExpireFirst, txSignature, instructionIndex = 0 } = req.body || {};

    const inv = invoiceId
      ? (db.prepare('SELECT * FROM deposit_invoices WHERE id = ?').get(invoiceId) as {
          id: string;
          user_id: string;
          expected_lamports: number;
          treasury_address: string;
        } | undefined)
      : undefined;

    if (!inv) return res.status(404).json({ error: 'Invoice not found' });
    if (inv.user_id !== user.id && !['finance', 'owner'].includes(user.role)) {
      return res.status(403).json({ error: 'Unauthorized invoice' });
    }

    if (forceExpireFirst) {
      db.prepare("UPDATE deposit_invoices SET status = 'Expired', expires_at = datetime('now', '-5 minutes') WHERE id = ?").run(inv.id);
    }

    const sig = String(txSignature || `sim_${crypto.randomBytes(12).toString('hex')}`);
    const sendLamports = overrideLamports !== undefined ? Math.round(Number(overrideLamports)) : inv.expected_lamports;

    const outcome = processIncomingSolanaTransfer({
      network: cfg.network_mode,
      txSignature: sig,
      instructionIndex: Number(instructionIndex),
      fromAddress: user.payout_address || 'DevnetSimSender11111111111111111111111111111',
      toAddress: inv.treasury_address,
      lamports: sendLamports,
    });

    const refreshedInvoice = db.prepare('SELECT * FROM deposit_invoices WHERE id = ?').get(inv.id);
    const balance = getUserBalance(inv.user_id);
    res.json({ outcome, invoice: refreshedInvoice, balance });
  });

  // Finance / Owner: Retry or Reconcile Withdrawal Request (safe idempotent retry!)
  app.post('/api/finance/withdrawals/:id/retry', requireRole(['finance', 'owner']), async (req, res) => {
    try {
      const result = await executeOrRetryWithdrawal(req.params.id, { simulateUncertainTimeout: false });
      writeAuditLog({
        actorUserId: req.authUser!.id,
        actorRole: req.authUser!.role,
        action: 'withdrawal_retry_reconciled',
        entityType: 'withdrawal',
        entityId: req.params.id,
        summary: `Reconciled withdrawal ${req.params.id} -> ${result.status}`,
      });
      res.json({ result, withdrawal: db.prepare('SELECT * FROM withdrawal_requests WHERE id = ?').get(req.params.id) });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Retry failed' });
    }
  });

  // Finance / Owner: Approve & credit Needs Review deposit invoice or transfer manually
  app.post('/api/finance/deposits/:invoiceId/approve', requireRole(['finance', 'owner']), (req, res) => {
    const staff = req.authUser!;
    const { invoiceId } = req.params;
    const note = String(req.body?.note || 'Approved by finance operator').trim();

    try {
      runImmediateTransaction(() => {
        const inv = db.prepare('SELECT * FROM deposit_invoices WHERE id = ?').get(invoiceId) as {
          id: string;
          user_id: string;
          status: string;
          received_lamports: number | null;
          expected_lamports: number;
          network: string;
        } | undefined;
        if (!inv) throw new Error('Invoice not found');
        if (inv.status === 'Matched') throw new Error('Invoice already credited');

        const creditLamports = inv.received_lamports || inv.expected_lamports;
        applyLedgerGroup([
          {
            idempotencyKey: `fin_dep_approve_${inv.id}`,
            userId: inv.user_id,
            entryType: 'deposit_credit',
            bucket: 'available',
            deltaLamports: creditLamports,
            referenceType: 'deposit_invoice',
            referenceId: inv.id,
            network: inv.network,
            description: `Finance approved deposit (${note})`,
            actorUserId: staff.id,
          },
        ]);

        db.prepare(`
          UPDATE deposit_invoices
          SET status = 'Matched', reviewed_by_user_id = ?, review_note = ?, matched_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
          WHERE id = ?
        `).run(staff.id, note, inv.id);

        writeAuditLog({
          actorUserId: staff.id,
          actorRole: staff.role,
          action: 'deposit_review_approved',
          entityType: 'deposit_invoice',
          entityId: inv.id,
          summary: `Finance credited ${creditLamports} lamports for invoice ${inv.id}: ${note}`,
        });
      });
      res.json({ ok: true });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Approval failed' });
    }
  });

  // Finance / Owner: Treasury & Liabilities Reconciliation View
  app.get('/api/finance/reconciliation', requireRole(['finance', 'owner']), (_req, res) => {
    const cfg = getWalletConfig();
    const liabilities = db
      .prepare(`
        SELECT
          COALESCE(SUM(available_lamports), 0) as total_available_lamports,
          COALESCE(SUM(reserved_lamports), 0) as total_reserved_lamports,
          COALESCE(SUM(frozen_lamports), 0) as total_frozen_lamports
        FROM user_balances
      `)
      .get() as {
      total_available_lamports: number;
      total_reserved_lamports: number;
      total_frozen_lamports: number;
    };

    const depositExceptions = db
      .prepare(`
        SELECT d.*, u.username
        FROM deposit_invoices d
        JOIN users u ON u.id = d.user_id
        WHERE d.status IN ('Needs Review', 'Waiting')
        ORDER BY CASE d.status WHEN 'Needs Review' THEN 0 ELSE 1 END, d.created_at DESC
        LIMIT 40
      `)
      .all();

    const unmatchedTransfers = db
      .prepare("SELECT * FROM processed_chain_transfers WHERE status != 'Matched' ORDER BY created_at DESC LIMIT 30")
      .all();

    const withdrawalQueue = db
      .prepare(`
        SELECT w.*, u.username
        FROM withdrawal_requests w
        JOIN users u ON u.id = w.user_id
        ORDER BY CASE w.status WHEN 'Needs Review' THEN 0 WHEN 'Processing' THEN 1 WHEN 'Queued' THEN 2 ELSE 3 END, w.created_at DESC
        LIMIT 50
      `)
      .all();

    const recentLedger = db
      .prepare(`
        SELECT l.*, u.username
        FROM ledger_entries l
        JOIN users u ON u.id = l.user_id
        ORDER BY l.created_at DESC
        LIMIT 100
      `)
      .all();

    const cursor = db.prepare('SELECT * FROM solana_watcher_cursor WHERE network = ?').get(cfg.network_mode);

    res.json({
      config: cfg,
      cursor,
      liabilities: {
        ...liabilities,
        totalLiabilityLamports:
          liabilities.total_available_lamports + liabilities.total_reserved_lamports + liabilities.total_frozen_lamports,
      },
      depositExceptions,
      unmatchedTransfers,
      withdrawalQueue,
      recentLedger,
    });
  });

  // Owner: Toggle network mode / mainnet / paid matches / fee bps
  app.patch('/api/finance/config', requireRole(['owner']), (req, res) => {
    const { networkMode, mainnetEnabled, paidMatchesEnabled, feeBps } = req.body || {};
    const cfg = getWalletConfig();

    const nextMode = ['demo', 'devnet', 'mainnet'].includes(networkMode) ? networkMode : cfg.network_mode;
    const nextMainnet = mainnetEnabled !== undefined ? (mainnetEnabled ? 1 : 0) : cfg.mainnet_enabled;
    const nextPaid = paidMatchesEnabled !== undefined ? (paidMatchesEnabled ? 1 : 0) : cfg.paid_matches_enabled;
    const nextFee = feeBps !== undefined ? Math.min(2500, Math.max(0, Math.round(Number(feeBps)))) : cfg.fee_bps;

    if (hostedDemo && (nextMode !== 'demo' || nextMainnet)) {
      return res.status(400).json({ error: 'The hosted demo supports simulated SOL only.' });
    }

    if (nextMode === 'mainnet' && (!nextMainnet || !process.env.SOLANA_TREASURY_SECRET_KEY)) {
      return res.status(400).json({ error: 'Mainnet requires explicit Owner enablement and configured SOLANA_TREASURY_SECRET_KEY in server environment.' });
    }

    db.prepare(`
      UPDATE wallet_config
      SET network_mode = ?, mainnet_enabled = ?, paid_matches_enabled = ?, fee_bps = ?,
          updated_by_user_id = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
      WHERE id = 1
    `).run(nextMode, nextMainnet, nextPaid, nextFee, req.authUser!.id);

    writeAuditLog({
      actorUserId: req.authUser!.id,
      actorRole: 'owner',
      action: 'wallet_config_updated',
      entityType: 'wallet_config',
      entityId: '1',
      summary: `Wallet config updated: network=${nextMode}, mainnet=${nextMainnet}, paidMatches=${nextPaid}, feeBps=${nextFee}`,
    });

    res.json({ config: getWalletConfig() });
  });
}
