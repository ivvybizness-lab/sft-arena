import type { Express } from 'express';
import { db, newId, writeAuditLog, notifyUser } from './db.ts';
import { applyLedgerGroup, runImmediateTransaction } from './ledger.ts';
import { requireAuth, requireRole } from './auth.ts';

interface TournamentRow {
  id: string;
  title: string;
  subtitle: string;
  is_demo: number;
  mode: string;
  format: string;
  region: string;
  platform: string;
  entry_lamports: number;
  prize_pool_lamports: number;
  max_teams: number;
  accent_color: string;
  registration_opens_at: string;
  registration_closes_at: string;
  checkin_opens_at: string;
  starts_at: string;
  ends_at: string | null;
  status: string;
  rules_json: string;
  created_by_user_id: string | null;
  created_at: string;
}

export function registerTournamentRoutes(app: Express) {
  // List tournaments with filter & server clock timestamp
  app.get('/api/tournaments', (req, res) => {
    const view = String(req.query.view || 'all'); // upcoming | live | past | all
    const region = String(req.query.region || 'ALL');
    const search = String(req.query.search || '').trim();

    const where: string[] = [];
    const params: unknown[] = [];

    if (view === 'upcoming') {
      where.push("t.status IN ('Upcoming', 'Registration Open', 'Check-In')");
    } else if (view === 'live') {
      where.push("t.status = 'Live'");
    } else if (view === 'past') {
      where.push("t.status IN ('Completed', 'Cancelled')");
    }

    if (region !== 'ALL') {
      where.push('t.region = ?');
      params.push(region);
    }
    if (search) {
      where.push('(t.title LIKE ? OR t.mode LIKE ?)');
      params.push(`%${search}%`, `%${search}%`);
    }

    const rows = db
      .prepare(`
        SELECT t.*,
          (SELECT COUNT(*) FROM tournament_registrations tr WHERE tr.tournament_id = t.id AND tr.status IN ('Registered', 'Checked In')) as registered_teams
        FROM tournaments t
        ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
        ORDER BY CASE t.status WHEN 'Live' THEN 0 WHEN 'Registration Open' THEN 1 WHEN 'Check-In' THEN 2 WHEN 'Upcoming' THEN 3 ELSE 4 END, t.starts_at ASC
      `)
      .all(...params);

    res.json({
      tournaments: rows,
      serverTimeUtc: new Date().toISOString(),
    });
  });

  // Get single tournament with registrations, bracket, payouts
  app.get('/api/tournaments/:id', (req, res) => {
    const t = db.prepare('SELECT * FROM tournaments WHERE id = ?').get(req.params.id) as TournamentRow | undefined;
    if (!t) return res.status(404).json({ error: 'Tournament not found' });

    const registrations = db
      .prepare(`
        SELECT tr.*, u.username as captain_username, u.epic_display_name as captain_epic
        FROM tournament_registrations tr
        JOIN users u ON u.id = tr.captain_user_id
        WHERE tr.tournament_id = ? AND tr.status != 'Withdrawn'
        ORDER BY COALESCE(tr.seed, 9999) ASC, tr.created_at ASC
      `)
      .all(t.id);

    const bracket = db
      .prepare(`
        SELECT tm.*,
               ra.team_name as team_a_name,
               rb.team_name as team_b_name,
               rw.team_name as winner_team_name
        FROM tournament_matches tm
        LEFT JOIN tournament_registrations ra ON ra.id = tm.reg_a_id
        LEFT JOIN tournament_registrations rb ON rb.id = tm.reg_b_id
        LEFT JOIN tournament_registrations rw ON rw.id = tm.winner_reg_id
        WHERE tm.tournament_id = ?
        ORDER BY tm.round_number ASC, tm.match_slot ASC
      `)
      .all(t.id);

    const payouts = db
      .prepare(`
        SELECT tp.*, u.username, tr.team_name
        FROM tournament_payouts tp
        JOIN users u ON u.id = tp.user_id
        JOIN tournament_registrations tr ON tr.id = tp.registration_id
        WHERE tp.tournament_id = ?
        ORDER BY tp.rank_position ASC
      `)
      .all(t.id);

    res.json({
      tournament: t,
      registrations,
      bracket,
      payouts,
      serverTimeUtc: new Date().toISOString(),
    });
  });

  // Create tournament (Owner / Moderator)
  app.post('/api/tournaments', requireRole(['moderator', 'owner']), (req, res) => {
    const user = req.authUser!;
    const {
      title,
      subtitle = '',
      mode = 'Zone Wars',
      format = '2v2',
      region = 'NAC',
      platform = 'All',
      entryLamports = 0,
      prizePoolLamports = 5_000_000_000,
      maxTeams = 32,
      accentColor = '#6d4aff',
      registrationOpensAt,
      registrationClosesAt,
      checkinOpensAt,
      startsAt,
      rules = [],
    } = req.body || {};

    if (!title) return res.status(400).json({ error: 'Tournament title is required' });
    const entryInt = Math.max(0, Math.round(Number(entryLamports || 0)));
    const prizeInt = Math.max(0, Math.round(Number(prizePoolLamports || 0)));
    const cap = Math.max(2, Math.min(512, Math.round(Number(maxTeams || 32))));

    const now = Date.now();
    const rOpens = registrationOpensAt || new Date(now).toISOString();
    const rCloses = registrationClosesAt || new Date(now + 24 * 3600 * 1000).toISOString();
    const cOpens = checkinOpensAt || new Date(now + 23 * 3600 * 1000).toISOString();
    const sAt = startsAt || new Date(now + 25 * 3600 * 1000).toISOString();

    const tid = newId('trn');
    db.prepare(`
      INSERT INTO tournaments (
        id, title, subtitle, is_demo, mode, format, region, platform, entry_lamports, prize_pool_lamports,
        max_teams, accent_color, registration_opens_at, registration_closes_at, checkin_opens_at, starts_at,
        status, rules_json, created_by_user_id
      ) VALUES (?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Registration Open', ?, ?)
    `).run(
      tid,
      String(title).trim(),
      String(subtitle).trim(),
      mode,
      format,
      region,
      platform,
      entryInt,
      prizeInt,
      cap,
      accentColor,
      rOpens,
      rCloses,
      cOpens,
      sAt,
      JSON.stringify(Array.isArray(rules) ? rules : []),
      user.id
    );

    writeAuditLog({
      actorUserId: user.id,
      actorRole: user.role,
      action: 'tournament_created',
      entityType: 'tournament',
      entityId: tid,
      summary: `Created tournament ${title} (${format} ${mode}, maxTeams=${cap}, entry=${entryInt})`,
    });

    const created = db.prepare('SELECT * FROM tournaments WHERE id = ?').get(tid);
    res.status(201).json({ tournament: created });
  });

  // Register team / solo entry (checks server-time deadline, capacity, balance)
  app.post('/api/tournaments/:id/register', requireAuth, (req, res) => {
    const user = req.authUser!;
    const tid = req.params.id;
    const { teamName, teamId = null } = req.body || {};

    try {
      let regRow: unknown = null;
      runImmediateTransaction(() => {
        const t = db.prepare('SELECT * FROM tournaments WHERE id = ?').get(tid) as TournamentRow | undefined;
        if (!t) throw new Error('Tournament not found');

        const nowMs = Date.now();
        if (!['Registration Open', 'Check-In'].includes(t.status)) {
          throw new Error('Tournament registration is not currently open');
        }
        if (nowMs > new Date(t.registration_closes_at).getTime()) {
          throw new Error('Registration deadline has passed');
        }

        const existing = db
          .prepare("SELECT id, status FROM tournament_registrations WHERE tournament_id = ? AND captain_user_id = ? AND status != 'Withdrawn'")
          .get(tid, user.id);
        if (existing) throw new Error('You are already registered in this tournament');

        const activeCount = (
          db
            .prepare("SELECT COUNT(*) as c FROM tournament_registrations WHERE tournament_id = ? AND status IN ('Registered', 'Checked In')")
            .get(tid) as { c: number }
        ).c;
        if (activeCount >= t.max_teams) {
          throw new Error('Tournament capacity reached');
        }

        const teamSize = parseInt(t.format[0] || '1', 10) || 1;
        let snapshots = [{ userId: user.id, username: user.username, epic: user.epic_display_name || user.username }];
        let finalTeamName = String(teamName || `${user.username} Squad`).trim();

        if (teamId) {
          const team = db.prepare('SELECT * FROM teams WHERE id = ?').get(teamId) as { id: string; name: string } | undefined;
          if (!team) throw new Error('Team roster not found');
          const members = db
            .prepare(`
              SELECT u.id as userId, u.username, u.epic_display_name as epic
              FROM team_members tm JOIN users u ON u.id = tm.user_id
              WHERE tm.team_id = ? AND tm.status = 'active'
            `)
            .all(teamId) as typeof snapshots;
          if (members.length < teamSize) throw new Error(`Roster requires at least ${teamSize} members for ${t.format}`);
          snapshots = members.slice(0, teamSize);
          finalTeamName = team.name;
        }

        if (t.entry_lamports > 0) {
          applyLedgerGroup([
            {
              idempotencyKey: `trn_entry_${tid}_${user.id}`,
              userId: user.id,
              entryType: 'tournament_entry',
              bucket: 'available',
              deltaLamports: -t.entry_lamports,
              referenceType: 'tournament',
              referenceId: tid,
              description: `Tournament entry fee (${t.title})`,
              actorUserId: user.id,
            },
          ]);
        }

        const regId = newId('treg');
        db.prepare(`
          INSERT INTO tournament_registrations (
            id, tournament_id, team_name, captain_user_id, team_id, member_snapshots_json, seed, checked_in, status, entry_paid_lamports
          ) VALUES (?, ?, ?, ?, ?, ?, ?, 0, 'Registered', ?)
        `).run(regId, tid, finalTeamName, user.id, teamId || null, JSON.stringify(snapshots), activeCount + 1, t.entry_lamports);

        regRow = db.prepare('SELECT * FROM tournament_registrations WHERE id = ?').get(regId);
      });

      res.status(201).json({ registration: regRow });
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to register';
      res.status(msg.includes('capacity') || msg.includes('already') ? 409 : 400).json({ error: msg });
    }
  });

  // Check-in
  app.post('/api/tournaments/:id/checkin', requireAuth, (req, res) => {
    const user = req.authUser!;
    const tid = req.params.id;
    const reg = db
      .prepare("SELECT * FROM tournament_registrations WHERE tournament_id = ? AND captain_user_id = ? AND status IN ('Registered', 'Checked In')")
      .get(tid, user.id) as { id: string } | undefined;
    if (!reg) return res.status(404).json({ error: 'Registration not found for your account' });

    db.prepare(`
      UPDATE tournament_registrations
      SET checked_in = 1, status = 'Checked In', checked_in_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
      WHERE id = ?
    `).run(reg.id);
    res.json({ ok: true });
  });

  // Withdraw (refunds entry fee if not started yet)
  app.post('/api/tournaments/:id/withdraw', requireAuth, (req, res) => {
    const user = req.authUser!;
    const tid = req.params.id;
    try {
      runImmediateTransaction(() => {
        const t = db.prepare('SELECT * FROM tournaments WHERE id = ?').get(tid) as TournamentRow | undefined;
        if (!t) throw new Error('Tournament not found');
        if (['Live', 'Completed'].includes(t.status)) throw new Error('Cannot withdraw after tournament has started');

        const reg = db
          .prepare("SELECT * FROM tournament_registrations WHERE tournament_id = ? AND captain_user_id = ? AND status != 'Withdrawn'")
          .get(tid, user.id) as { id: string; entry_paid_lamports: number } | undefined;
        if (!reg) throw new Error('Active registration not found');

        if (reg.entry_paid_lamports > 0) {
          applyLedgerGroup([
            {
              idempotencyKey: `trn_refund_${tid}_${reg.id}`,
              userId: user.id,
              entryType: 'tournament_refund',
              bucket: 'available',
              deltaLamports: reg.entry_paid_lamports,
              referenceType: 'tournament',
              referenceId: tid,
              description: `Tournament withdrawal refund (${t.title})`,
              actorUserId: user.id,
            },
          ]);
        }

        db.prepare("UPDATE tournament_registrations SET status = 'Withdrawn' WHERE id = ?").run(reg.id);
      });
      res.json({ ok: true });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to withdraw' });
    }
  });

  // Generate Single-Elimination Bracket & Start Tournament (Staff)
  app.post('/api/tournaments/:id/generate-bracket', requireRole(['moderator', 'owner']), (req, res) => {
    const staff = req.authUser!;
    const tid = req.params.id;
    try {
      let matchCount = 0;
      runImmediateTransaction(() => {
        const t = db.prepare('SELECT * FROM tournaments WHERE id = ?').get(tid) as TournamentRow | undefined;
        if (!t) throw new Error('Tournament not found');

        const regs = db
          .prepare("SELECT * FROM tournament_registrations WHERE tournament_id = ? AND status IN ('Checked In', 'Registered') ORDER BY checked_in DESC, seed ASC, created_at ASC")
          .all(tid) as Array<{ id: string; team_name: string }>;

        if (regs.length < 2) throw new Error('At least 2 registered teams are required to generate a bracket');

        db.prepare('DELETE FROM tournament_matches WHERE tournament_id = ?').run(tid);

        let slot = 1;
        for (let i = 0; i < regs.length; i += 2) {
          const a = regs[i];
          const b = regs[i + 1] ?? null;
          db.prepare(`
            INSERT INTO tournament_matches (id, tournament_id, round_number, match_slot, reg_a_id, reg_b_id, winner_reg_id, status)
            VALUES (?, ?, 1, ?, ?, ?, ?, ?)
          `).run(
            newId('tm'),
            tid,
            slot++,
            a.id,
            b ? b.id : null,
            b ? null : a.id,
            b ? 'Ready' : 'Bye'
          );
          matchCount++;
        }

        db.prepare("UPDATE tournaments SET status = 'Live', updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(tid);
        writeAuditLog({
          actorUserId: staff.id,
          actorRole: staff.role,
          action: 'tournament_bracket_generated',
          entityType: 'tournament',
          entityId: tid,
          summary: `Generated round 1 bracket (${regs.length} teams, ${matchCount} pairings)`,
        });
      });

      res.json({ ok: true, matchCount });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to generate bracket' });
    }
  });

  // Record Bracket Match Result + Advance Round / Settle Tournament Prize Payouts (Staff)
  app.post('/api/tournaments/:id/bracket/:bracketMatchId/result', requireRole(['moderator', 'owner']), (req, res) => {
    const staff = req.authUser!;
    const { id: tid, bracketMatchId } = req.params;
    const { winnerRegId, scoreA = 1, scoreB = 0 } = req.body || {};

    try {
      let settledTournament = false;
      runImmediateTransaction(() => {
        const t = db.prepare('SELECT * FROM tournaments WHERE id = ?').get(tid) as TournamentRow | undefined;
        if (!t) throw new Error('Tournament not found');

        const bm = db.prepare('SELECT * FROM tournament_matches WHERE id = ? AND tournament_id = ?').get(bracketMatchId, tid) as {
          id: string;
          round_number: number;
          match_slot: number;
          reg_a_id: string | null;
          reg_b_id: string | null;
          status: string;
        } | undefined;
        if (!bm) throw new Error('Bracket match not found');
        if (![bm.reg_a_id, bm.reg_b_id].includes(winnerRegId)) {
          throw new Error('Winner must be one of the pairing teams');
        }

        const loserRegId = winnerRegId === bm.reg_a_id ? bm.reg_b_id : bm.reg_a_id;
        db.prepare(`
          UPDATE tournament_matches
          SET winner_reg_id = ?, score_a = ?, score_b = ?, status = 'Complete',
              completed_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
          WHERE id = ?
        `).run(winnerRegId, Math.round(Number(scoreA)), Math.round(Number(scoreB)), bm.id);

        if (loserRegId) {
          db.prepare('UPDATE tournament_registrations SET eliminated_round = ? WHERE id = ?').run(bm.round_number, loserRegId);
        }

        // Check if current round is completely done
        const pendingInRound = (
          db
            .prepare("SELECT COUNT(*) as c FROM tournament_matches WHERE tournament_id = ? AND round_number = ? AND status NOT IN ('Complete', 'Bye')")
            .get(tid, bm.round_number) as { c: number }
        ).c;

        if (pendingInRound === 0) {
          const roundWinners = db
            .prepare('SELECT winner_reg_id FROM tournament_matches WHERE tournament_id = ? AND round_number = ? ORDER BY match_slot ASC')
            .all(tid, bm.round_number) as Array<{ winner_reg_id: string }>;

          if (roundWinners.length === 1) {
            // Final champion crowned! Settle prize pool (100% or 70/30 if runner-up exists)
            const champReg = db
              .prepare('SELECT * FROM tournament_registrations WHERE id = ?')
              .get(roundWinners[0].winner_reg_id) as { id: string; captain_user_id: string; team_name: string };

            db.prepare('UPDATE tournament_registrations SET final_rank = 1 WHERE id = ?').run(champReg.id);
            if (loserRegId) {
              db.prepare('UPDATE tournament_registrations SET final_rank = 2 WHERE id = ?').run(loserRegId);
            }

            if (t.prize_pool_lamports > 0) {
              const firstPrize = loserRegId ? Math.floor(t.prize_pool_lamports * 0.7) : t.prize_pool_lamports;
              const secondPrize = t.prize_pool_lamports - firstPrize;

              const mutations = [
                {
                  idempotencyKey: `trn_pay_1_${tid}_${champReg.id}`,
                  userId: champReg.captain_user_id,
                  entryType: 'tournament_payout' as const,
                  bucket: 'available' as const,
                  deltaLamports: firstPrize,
                  referenceType: 'tournament',
                  referenceId: tid,
                  description: `1st Place Payout — ${t.title}`,
                  actorUserId: staff.id,
                },
              ];
              db.prepare('INSERT INTO tournament_payouts (id, tournament_id, registration_id, user_id, rank_position, amount_lamports) VALUES (?, ?, ?, ?, 1, ?)').run(
                newId('tpay'),
                tid,
                champReg.id,
                champReg.captain_user_id,
                firstPrize
              );

              if (loserRegId && secondPrize > 0) {
                const runnerReg = db
                  .prepare('SELECT * FROM tournament_registrations WHERE id = ?')
                  .get(loserRegId) as { id: string; captain_user_id: string };
                mutations.push({
                  idempotencyKey: `trn_pay_2_${tid}_${runnerReg.id}`,
                  userId: runnerReg.captain_user_id,
                  entryType: 'tournament_payout' as const,
                  bucket: 'available' as const,
                  deltaLamports: secondPrize,
                  referenceType: 'tournament',
                  referenceId: tid,
                  description: `2nd Place Payout — ${t.title}`,
                  actorUserId: staff.id,
                });
                db.prepare('INSERT INTO tournament_payouts (id, tournament_id, registration_id, user_id, rank_position, amount_lamports) VALUES (?, ?, ?, ?, 2, ?)').run(
                  newId('tpay'),
                  tid,
                  runnerReg.id,
                  runnerReg.captain_user_id,
                  secondPrize
                );
              }

              applyLedgerGroup(mutations);
            }

            db.prepare("UPDATE tournaments SET status = 'Completed', ends_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now'), updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(tid);
            notifyUser({
              userId: champReg.captain_user_id,
              category: 'tournament',
              title: 'Tournament Champion!',
              body: `${champReg.team_name} won ${t.title}!`,
              linkUrl: `/tournaments`,
            });
            settledTournament = true;
          } else {
            // Pair next round
            const nextRound = bm.round_number + 1;
            let nextSlot = 1;
            for (let i = 0; i < roundWinners.length; i += 2) {
              const wa = roundWinners[i].winner_reg_id;
              const wb = roundWinners[i + 1]?.winner_reg_id ?? null;
              db.prepare(`
                INSERT INTO tournament_matches (id, tournament_id, round_number, match_slot, reg_a_id, reg_b_id, winner_reg_id, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
              `).run(newId('tm'), tid, nextRound, nextSlot++, wa, wb, wb ? null : wa, wb ? 'Ready' : 'Bye');
            }
          }
        }

        writeAuditLog({
          actorUserId: staff.id,
          actorRole: staff.role,
          action: 'tournament_match_result',
          entityType: 'tournament',
          entityId: tid,
          summary: `Recorded tournament match ${bracketMatchId} winner=${winnerRegId} (${scoreA}-${scoreB})`,
        });
      });

      res.json({ ok: true, settledTournament });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to record bracket result' });
    }
  });
}
