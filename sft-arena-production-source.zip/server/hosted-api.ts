import { AsyncLocalStorage } from 'node:async_hooks';
import type { IncomingMessage, ServerResponse } from 'node:http';
import Database from 'better-sqlite3';
import { createApp } from './http.ts';
import { db, notifyUser, runMigrations, usingDatabase, writeAuditLog } from './db.ts';
import { seedInitialData } from './seed.ts';
import { applyLedgerGroup, runImmediateTransaction } from './ledger.ts';

export interface SnapshotStore {
  load(): Promise<{ bytes: Buffer; revision: string } | null>;
  save(bytes: Buffer, previousRevision: string | null): Promise<void>;
}

export class WriteConflict extends Error {}
const MAX_STATE_BYTES = 12 * 1024 * 1024;

function captureResponse(app: ReturnType<typeof createApp>, req: IncomingMessage, res: ServerResponse) {
  const send = res.end;
  const emit = req.emit;
  req.emit = AsyncLocalStorage.bind(emit.bind(req));
  return new Promise<{ send: () => void; restore: () => void }>((resolve, reject) => {
    const restore = () => { res.end = send; req.emit = emit; };
    res.end = ((...args: Parameters<typeof send>) => {
      resolve({ send: () => { restore(); send.apply(res, args); }, restore });
      return res;
    }) as typeof res.end;
    try { app(req, res); } catch (error) { restore(); reject(error); }
  });
}

function jsonError(response: ServerResponse, status: number, message: string) {
  for (const name of response.getHeaderNames()) response.removeHeader(name);
  response.statusCode = status;
  response.setHeader('Content-Type', 'application/json');
  response.setHeader('Cache-Control', 'private, no-store');
  response.end(JSON.stringify({ error: message }));
}

function applyProductionDemoCredit() {
  if (process.env.VERCEL_ENV !== 'production') return false;
  const playerId = 'usr_fd7c9e87878841af';
  const creditId = 'demo-credit-2026-11-22-ivvylol';
  if (!db.prepare("SELECT 1 FROM users WHERE id = ? AND username = 'ivvylol' COLLATE NOCASE").get(playerId)) return false;
  return runImmediateTransaction(() => {
    const credit = applyLedgerGroup([{ idempotencyKey: creditId, userId: playerId, entryType: 'admin_adjustment',
      bucket: 'available', deltaLamports: 100_000_000_000, referenceType: 'demo_credit', referenceId: creditId,
      network: 'demo', description: 'One-time 100 simulated SOL credit' }]);
    if (credit.skipped) return false;
    writeAuditLog({action:'demo_balance_credited', entityType:'user', entityId:playerId, summary:'One-time demo wallet credit',
      metadata:{creditId, amountSol:100}});
    notifyUser({userId:playerId, category:'wallet', title:'Demo credit received', body:'100 simulated SOL was added to your SFT Arena wallet.',
      linkUrl:'/profile/ivvylol'});
    return true;
  });
}

export function createHostedApi(store: SnapshotStore) {
  const app = createApp();

  async function loadInitializedState() {
    const current = await store.load();
    if (current) return current;

    const initial = new Database(':memory:');
    try {
      await usingDatabase(initial, async () => {
        runMigrations();
        await seedInitialData();
      });
      try { await store.save(initial.serialize(), null); }
      catch (error) { if (!(error instanceof WriteConflict)) throw error; }
      const saved = await store.load();
      if (!saved) throw new Error('Unable to create demo state');
      return saved;
    } finally {
      initial.close();
    }
  }

  return async (req: IncomingMessage, res: ServerResponse) => {
    let connection: Database.Database | undefined;
    let pending: Awaited<ReturnType<typeof captureResponse>> | undefined;
    try {
      const snapshot = await loadInitializedState();
      connection = new Database(snapshot.bytes);
      await usingDatabase(connection, async () => {
        const getChangeCount = () => connection!.prepare('SELECT total_changes()').pluck().get();
        const before = getChangeCount();
        runMigrations();

        // Demo state stays isolated. Fail closed if an incompatible snapshot is attached.
        const mode = connection!.prepare('SELECT network_mode FROM wallet_config WHERE id=1').pluck().get();
        if (mode !== 'demo') throw new Error('Only a simulated wallet is supported on this deployment');
        const credited = applyProductionDemoCredit();
        res.setHeader('Cache-Control', 'private, no-store');
        pending = await captureResponse(app, req, res);
        if (getChangeCount() !== before) {
          const bytes = connection!.serialize();
          if (bytes.length > MAX_STATE_BYTES) {
            pending.restore();
            return jsonError(res, 507, 'The demo storage limit was reached.');
          }
          await store.save(bytes, snapshot.revision);
          if (credited) console.info('SFT one-time simulated SOL credit posted: demo-credit-2026-11-22-ivvylol');
        }
        pending.send();
      });
    } catch (error) {
      pending?.restore();
      if (res.headersSent) return;
      if (error instanceof WriteConflict) return jsonError(res, 409, 'The record changed while this request was running. Please retry.');
      console.error('SFT hosted request failed:', error instanceof Error ? error.name : 'unknown',
        error && typeof error === 'object' && 'code' in error ? error.code : undefined);
      jsonError(res, 503, 'The demo backend is temporarily unavailable.');
    } finally {
      connection?.close();
    }
  };
}
