import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { AsyncLocalStorage } from 'node:async_hooks';
import { hostedDemo } from './hosting.ts';

declare const __SFT_PACKAGED_MIGRATIONS__: Array<{ name: string; sql: string }>;

const DB_PATH = process.env.DATABASE_PATH
  ? path.resolve(process.cwd(), process.env.DATABASE_PATH)
  : path.resolve(process.cwd(), 'data', 'sft.db');

export const EVIDENCE_DIR = process.env.EVIDENCE_STORAGE_DIR
  ? path.resolve(process.cwd(), process.env.EVIDENCE_STORAGE_DIR)
  : path.resolve(process.cwd(), 'data', 'evidence');

const requestDatabase = new AsyncLocalStorage<Database.Database>();
let localDatabase: Database.Database | undefined;

export function usingDatabase<T>(database: Database.Database, callback: () => T): T {
  database.pragma('foreign_keys = ON');
  return requestDatabase.run(database, callback);
}

export const db = new Proxy({} as Database.Database, {
  get(_target, key) {
    let database = requestDatabase.getStore();
    if (!database) {
      if (hostedDemo) throw new Error('Hosted database access requires a request context');
      if (!localDatabase) {
        fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
        fs.mkdirSync(EVIDENCE_DIR, { recursive: true });
        localDatabase = new Database(DB_PATH);
        localDatabase.pragma('journal_mode = WAL');
        localDatabase.pragma('foreign_keys = ON');
        localDatabase.pragma('busy_timeout = 5000');
      }
      database = localDatabase;
    }
    const property = Reflect.get(database, key, database);
    return typeof property === 'function' ? property.bind(database) : property;
  },
});

export function runMigrations(): void {
  const migrationsDir = path.resolve(process.cwd(), 'migrations');
  const packaged = typeof __SFT_PACKAGED_MIGRATIONS__ === 'undefined' ? null : __SFT_PACKAGED_MIGRATIONS__;
  if (!packaged && !fs.existsSync(migrationsDir)) return;

  db.exec(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version TEXT PRIMARY KEY,
      applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
    );
  `);

  const files = packaged?.map(({ name }) => name) ?? fs
    .readdirSync(migrationsDir)
    .filter((f) => f.endsWith('.sql'))
    .sort();

  const appliedRows = db.prepare('SELECT version FROM schema_migrations').all() as Array<{ version: string }>;
  const applied = new Set(appliedRows.map((r) => r.version));

  for (const [index, file] of files.entries()) {
    if (applied.has(file)) continue;
    const sql = packaged?.[index].sql ?? fs.readFileSync(path.join(migrationsDir, file), 'utf8');
    const tx = db.transaction(() => {
      db.exec(sql);
      db.prepare('INSERT INTO schema_migrations (version) VALUES (?)').run(file);
    });
    tx();
  }
}

export function newId(prefix: string): string {
  return `${prefix}_${crypto.randomUUID().replace(/-/g, '').slice(0, 16)}`;
}

export function hashPassword(password: string, existingSalt?: string): string {
  const salt = existingSalt || crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  if (!salt || !keyHex) return false;
  const derived = crypto.scryptSync(password, salt, 64);
  const storedBuf = Buffer.from(keyHex, 'hex');
  if (derived.length !== storedBuf.length) return false;
  return crypto.timingSafeEqual(derived, storedBuf);
}

export function hashSensitive(value: string): string {
  const secret = process.env.SESSION_SECRET || 'sft-dev-hash-secret';
  return crypto.createHmac('sha256', secret).update(value).digest('hex');
}

export function writeAuditLog(params: {
  actorUserId?: string | null;
  actorRole?: string;
  action: string;
  entityType: string;
  entityId: string;
  summary: string;
  metadata?: Record<string, unknown>;
}) {
  db.prepare(`
    INSERT INTO audit_logs (id, actor_user_id, actor_role, action, entity_type, entity_id, summary, metadata_json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    newId('aud'),
    params.actorUserId ?? null,
    params.actorRole ?? 'system',
    params.action,
    params.entityType,
    params.entityId,
    params.summary,
    JSON.stringify(params.metadata ?? {})
  );
}

export function notifyUser(params: {
  userId: string;
  category: string;
  title: string;
  body: string;
  linkUrl?: string;
}) {
  db.prepare(`
    INSERT INTO notifications (id, user_id, category, title, body, link_url)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(
    newId('ntf'),
    params.userId,
    params.category,
    params.title,
    params.body,
    params.linkUrl ?? '/'
  );
}
