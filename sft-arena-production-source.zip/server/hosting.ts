// The hosted demonstration cannot accept or send real SOL.
export const hostedDemo = process.env.VERCEL === '1' || process.env.SFT_HOSTED_DEMO === '1';
