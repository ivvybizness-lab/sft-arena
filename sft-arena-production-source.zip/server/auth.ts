import { ADMIN_USERNAME, isArenaAdmin } from './admin-access.ts';
import crypto from 'crypto';
import { OAuth2Client } from 'google-auth-library';
import { hostedDemo } from './hosting.ts';
import type { Request, Response, NextFunction, Express } from 'express';
import { db, hashPassword, verifyPassword, hashSensitive, newId, writeAuditLog } from './db.ts';
import { getUserBalance, applyLedgerGroup, runImmediateTransaction } from './ledger.ts';

export type UserRole = 'player' | 'moderator' | 'finance' | 'owner';

export interface AuthUser {
  id: string;
  username: string;
  display_name: string;
  email: string;
  email_verified: number;
  phone: string | null;
  phone_verified: number;
  role: UserRole;
  country: string;
  competitive_region: 'NAE' | 'NAC' | 'NAW' | 'EU';
  age_verified: number;
  age_attested_at: string | null;
  legacy_demo_match_eligible: number;
  age_verification_ref: string | null;
  epic_display_name: string;
  epic_account_id: string;
  status: 'active' | 'restricted' | 'suspended' | 'banned';
  referral_code: string;
  referred_by_user_id: string | null;
  acquisition_source: string;
  risk_score: number;
  twitch_channel: string | null;
  twitch_authorized: number;
  avatar_url: string;
  profile_banner: string;
  profile_portrait: number | null;
  active_title: string;
  active_border: string;
  payout_address: string;
  wins: number;
  losses: number;
  elo: number;
  xp: number;
  is_demo: number;
  created_at: string;
}

declare global {
  namespace Express {
    interface Request {
      authUser?: AuthUser | null;
      sessionId?: string | null;
    }
  }
}

function parseCookies(req: Request): Record<string, string> {
  const header = req.headers.cookie;
  const out: Record<string, string> = {};
  if (!header) return out;
  for (const chunk of header.split(';')) {
    const idx = chunk.indexOf('=');
    if (idx > 0) {
      try { out[chunk.slice(0, idx).trim()] = decodeURIComponent(chunk.slice(idx + 1).trim()); }
      catch { /* Ignore malformed cookies. */ }
    }
  }
  return out;
}

function extractClientInfo(req: Request) {
  const ip = (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || req.ip || '127.0.0.1';
  const ua = (req.headers['user-agent'] || '').slice(0, 200);
  const browser = ua.includes('Chrome') ? 'Chrome' : ua.includes('Firefox') ? 'Firefox' : ua.includes('Safari') ? 'Safari' : 'API/Other';
  const os = ua.includes('Windows') ? 'Windows' : ua.includes('Mac') ? 'macOS' : ua.includes('Linux') ? 'Linux' : 'Other';
  const deviceHeader = (req.headers['x-device-id'] as string) || '';
  const deviceId = deviceHeader || hashSensitive(`${ua}:${ip}`).slice(0, 16);
  const isVpn = req.headers['x-vpn-detected'] === 'true' ? 1 : 0;
  return { ipHash: hashSensitive(ip), browser, os, deviceId, isVpn };
}

export function setSessionCookie(res: Response, rawToken: string, expiresAtIso: string) {
  const maxAgeSec = Math.max(0, Math.floor((new Date(expiresAtIso).getTime() - Date.now()) / 1000));
  // Partitioned + SameSite=None + HttpOnly + Secure works in AI Studio iframe & standard HTTPS browsers
  res.setHeader(
    'Set-Cookie',
    `sft_session=${encodeURIComponent(rawToken)}; Path=/; HttpOnly; Secure; SameSite=None; Partitioned; Max-Age=${maxAgeSec}`
  );
}

export function clearSessionCookie(res: Response) {
  res.setHeader(
    'Set-Cookie',
    'sft_session=; Path=/; HttpOnly; Secure; SameSite=None; Partitioned; Max-Age=0'
  );
}

export function originCsrfGuard(req: Request, res: Response, next: NextFunction) {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) return next();
  const origin = req.headers.origin;
  if (!origin) {
    // Allow same-origin requests without Origin header or non-browser bearer calls
    return next();
  }
  try {
    const originHost = new URL(origin).host;
    const targetHost = (req.headers['x-forwarded-host'] as string) || req.headers.host || '';
    if (originHost === targetHost) {
      return next();
    }
    return res.status(403).json({ error: 'Invalid request origin' });
  } catch {
    return res.status(403).json({ error: 'Malformed origin header' });
  }
}

export function attachAuthUser(req: Request, _res: Response, next: NextFunction) {
  req.authUser = null;
  req.sessionId = null;

  const cookies = parseCookies(req);
  const authHeader = req.headers.authorization;
  const bearer = authHeader?.startsWith('Bearer ') ? authHeader.slice(7).trim() : undefined;
  const rawToken = bearer || cookies['sft_session'];

  if (!rawToken) return next();

  const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
  const session = db
    .prepare("SELECT id, user_id FROM user_sessions WHERE token_hash = ? AND revoked_at IS NULL AND expires_at > strftime('%Y-%m-%dT%H:%M:%fZ', 'now')")
    .get(tokenHash) as { id: string; user_id: string } | undefined;

  if (!session) return next();

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(session.user_id) as AuthUser | undefined;
  if (!user || ['suspended','banned'].includes(user.status) || (hostedDemo && user.is_demo && user.role !== 'player')) return next();

  db.prepare("UPDATE user_sessions SET last_seen_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ? AND last_seen_at < strftime('%Y-%m-%dT%H:%M:%fZ', 'now', '-60 seconds')").run(session.id);
  req.authUser = { ...user, role: isArenaAdmin(user) ? 'owner' : 'player' };
  req.sessionId = session.id;
  next();
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.authUser) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  if (req.authUser.status === 'banned' || req.authUser.status === 'suspended') {
    return res.status(403).json({ error: `Account is ${req.authUser.status}. Contact SFT Support.` });
  }
  next();
}

export function requireRole(roles: UserRole[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.authUser) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    if (!roles.includes(req.authUser.role)) {
      return res.status(403).json({ error: 'Insufficient permissions for this action' });
    }
    next();
  };
}

export function serializeUserSelf(u: AuthUser) {
  const balance = getUserBalance(u.id);
  return {
    id: u.id,
    username: u.username,
    displayName: u.display_name,
    email: u.email,
    emailVerified: Boolean(u.email_verified),
    phone: u.phone,
    phoneVerified: Boolean(u.phone_verified),
    role: isArenaAdmin(u) ? 'owner' : 'player',
    country: u.country,
    competitiveRegion: u.competitive_region,
    ageVerified: Boolean(u.age_verified),
    ageAttested: Boolean(u.age_attested_at),
    epicDisplayName: u.epic_display_name,
    epicAccountId: u.epic_account_id,
    status: u.status,
    referralCode: u.referral_code,
    acquisitionSource: u.acquisition_source,
    twitchChannel: u.twitch_channel,
    twitchAuthorized: Boolean(u.twitch_authorized),
    avatarUrl: u.avatar_url,
    profileBanner: u.profile_banner,
    profilePortrait: u.profile_portrait,
    activeTitle: u.active_title,
    activeBorder: u.active_border,
    payoutAddress: u.payout_address,
    wins: u.wins,
    losses: u.losses,
    elo: u.elo,
    xp: u.xp,
    isDemo: Boolean(u.is_demo),
    createdAt: u.created_at,
    balance,
    googleConnected: Boolean(db.prepare("SELECT 1 FROM google_identities WHERE user_id = ?").get(u.id)),
  };
}

export function serializeUserPublic(u: AuthUser) {
  return {
    id: u.id,
    username: u.username,
    displayName: u.display_name,
    role: u.role,
    competitiveRegion: u.competitive_region,
    epicDisplayName: u.epic_display_name,
    status: u.status,
    twitchChannel: u.twitch_authorized ? u.twitch_channel : null,
    avatarUrl: u.avatar_url,
    profileBanner: u.profile_banner,
    profilePortrait: u.profile_portrait,
    activeTitle: u.active_title,
    activeBorder: u.active_border,
    wins: u.wins,
    losses: u.losses,
    elo: u.elo,
    xp: u.xp,
    isDemo: Boolean(u.is_demo),
    createdAt: u.created_at,
  };
}

function evaluateRiskSignals(userId: string, ipHash: string, deviceId: string, isVpn: number) {
  const sharedIpUsers = db
    .prepare('SELECT DISTINCT user_id FROM security_login_events WHERE ip_hash = ? AND user_id IS NOT NULL AND user_id != ?')
    .all(ipHash, userId) as Array<{ user_id: string }>;

  const sharedDeviceUsers = db
    .prepare('SELECT DISTINCT user_id FROM security_login_events WHERE device_id = ? AND user_id IS NOT NULL AND user_id != ?')
    .all(deviceId, userId) as Array<{ user_id: string }>;

  if (sharedIpUsers.length > 0 || sharedDeviceUsers.length > 0) {
    const existing = db
      .prepare("SELECT id FROM risk_flags WHERE user_id = ? AND flag_type = 'shared_ip_device' AND status IN ('Open','Investigating')")
      .get(userId);
    if (!existing) {
      db.prepare(`
        INSERT INTO risk_flags (id, user_id, flag_type, severity, details_json)
        VALUES (?, ?, 'shared_ip_device', 'medium', ?)
      `).run(
        newId('rf'),
        userId,
        JSON.stringify({ sharedIpCount: sharedIpUsers.length, sharedDeviceCount: sharedDeviceUsers.length })
      );
      db.prepare('UPDATE users SET risk_score = MIN(100, risk_score + 20) WHERE id = ?').run(userId);
    }
  }

  if (isVpn) {
    const existingVpn = db
      .prepare("SELECT id FROM risk_flags WHERE user_id = ? AND flag_type = 'vpn_proxy_login' AND status IN ('Open','Investigating')")
      .get(userId);
    if (!existingVpn) {
      db.prepare(`
        INSERT INTO risk_flags (id, user_id, flag_type, severity, details_json)
        VALUES (?, ?, 'vpn_proxy_login', 'low', ?)
      `).run(newId('rf'), userId, JSON.stringify({ note: 'VPN/Proxy header signal detected on login' }));
      db.prepare('UPDATE users SET risk_score = MIN(100, risk_score + 10) WHERE id = ?').run(userId);
    }
  }
}

function startLoginSession(req: Request, res: Response, user: AuthUser) {
    const info = extractClientInfo(req);
    const knownDevice = db
      .prepare('SELECT 1 FROM security_login_events WHERE user_id = ? AND device_id = ? LIMIT 1')
      .get(user.id, info.deviceId);

    const rawToken = crypto.randomBytes(32).toString('hex');
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    const sessionId = newId('ses');
    const expiresAt = new Date(Date.now() + 7 * 86400 * 1000).toISOString();

    db.prepare(`
      INSERT INTO user_sessions (id, user_id, token_hash, device_id, browser, os, ip_hash, ip_country, is_vpn_proxy, expires_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(sessionId, user.id, tokenHash, info.deviceId, info.browser, info.os, info.ipHash, user.country, info.isVpn, expiresAt);

    db.prepare(`
      INSERT INTO security_login_events (id, user_id, username_or_email, event_type, ip_hash, country, device_id, browser, os, is_vpn_proxy)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(newId('sle'), user.id, user.email, knownDevice ? 'login_success' : 'new_device', info.ipHash, user.country, info.deviceId, info.browser, info.os, info.isVpn);

    db.prepare('INSERT INTO analytics_sessions (id, user_id, duration_seconds) VALUES (?, ?, 420)').run(newId('ase'), user.id);
    evaluateRiskSignals(user.id, info.ipHash, info.deviceId, info.isVpn);

    setSessionCookie(res, rawToken, expiresAt);
    return res.json({ user: serializeUserSelf(user), token: rawToken });
}

const googleClientId = process.env.GOOGLE_CLIENT_ID || '154883863092-lv80nlrfdbpu73jt3fpm2a0vj8k94m2s.apps.googleusercontent.com';
const google = new OAuth2Client(googleClientId);
const digest = (value: string) => crypto.createHash('sha256').update(value).digest('hex');
export function registerAuthRoutes(app: Express) {
  app.get('/api/auth/google/challenge', (req, res) => {
    const nonce = crypto.randomBytes(32).toString('hex');
    db.prepare('DELETE FROM google_challenges WHERE expires_at <= ?').run(Date.now());
    db.prepare('INSERT INTO google_challenges VALUES (?, ?)').run(digest(nonce), Date.now() + 300000);
    res.cookie('sft_google_nonce', nonce, {httpOnly:true, secure:true, sameSite:'lax', maxAge:300000, path:'/api/auth/google'});
    res.set('Cache-Control','no-store').json({nonce, clientId:googleClientId});
  });
  app.post('/api/auth/google', async (req, res) => {
    const nonce = parseCookies(req).sft_google_nonce;
    const credential = req.body?.credential;
    if (!nonce || typeof credential !== 'string' || credential.length > 16000 ||
        !db.prepare('SELECT 1 FROM google_challenges WHERE digest=? AND expires_at>?').get(digest(nonce), Date.now()))
      return res.status(400).json({error:'Sign-in expired. Reopen the sign-in panel.'});
    try {
      const ticket = await google.verifyIdToken({idToken:credential, audience:googleClientId});
      const identity = ticket.getPayload() as (ReturnType<typeof ticket.getPayload> & {nonce?:string});
      if (!identity?.email_verified || !identity.email || !identity.sub || identity.nonce !== nonce)
        return res.status(401).json({error:'Google could not verify this sign-in.'});
      const email = identity.email.toLowerCase();
      let user = db.prepare('SELECT u.* FROM users u JOIN google_identities g ON g.user_id=u.id WHERE g.subject=?').get(identity.sub) as AuthUser | undefined;
      const emailAccount = db.prepare('SELECT id FROM users WHERE email=?').get(email) as {id:string}|undefined;
      if (!user && emailAccount && (req.authUser?.id !== emailAccount.id || req.authUser.is_demo))
        return res.status(409).json({error:'This email already belongs to an SFT account. Sign in with its password and connect Google from Profile → Linked Accounts.'});
      if (!user && !emailAccount && (req.body.acceptTerms !== true || req.body.ageConfirmed !== true)) return res.json({needsConsent:true});
      if (user && ['banned','suspended'].includes(user.status)) return res.status(403).json({error:'This account is '+user.status+'.'});
      if (req.authUser && ((user && req.authUser.id !== user.id) || (!user && req.authUser.id !== emailAccount?.id)))
        return res.status(409).json({error:'Select the Google account matching your signed-in SFT email.'});
      if (req.authUser && db.prepare('SELECT 1 FROM google_identities WHERE user_id=? AND subject<>?').get(req.authUser.id,identity.sub))
        return res.status(409).json({error:'A different Google account is already connected.'});
      const info = extractClientInfo(req);
      const id = user?.id || emailAccount?.id || newId('usr');
      runImmediateTransaction(() => {
        if (!db.prepare('DELETE FROM google_challenges WHERE digest=? AND expires_at>?').run(digest(nonce), Date.now()).changes) throw Error('expired');
        if (!user && !emailAccount) {
          const username = (email.split('@')[0].replace(/[^a-z0-9_]/gi,'').slice(0,14) || 'Player') + '_' + crypto.randomBytes(4).toString('hex');
          db.prepare("INSERT INTO users(id,username,display_name,email,email_verified,password_hash,referral_code,acquisition_source,age_attested_at) VALUES(?,?,?,?,1,?,?,'google',strftime('%Y-%m-%dT%H:%M:%fZ','now'))")
            .run(id,username,String(identity.name || username).slice(0,80),email,hashPassword(crypto.randomBytes(40).toString('hex')),newId('ref'));
          db.prepare('INSERT INTO user_balances(user_id) VALUES(?)').run(id);
          for (const p of db.prepare('SELECT policy_type,version FROM policy_versions WHERE is_active=1').all() as {policy_type:string;version:string}[])
            db.prepare('INSERT INTO policy_acceptances(id,user_id,policy_type,policy_version,ip_hash) VALUES(?,?,?,?,?)').run(newId('pac'),id,p.policy_type,p.version,info.ipHash);
        }
        if (!user) {
          db.prepare('INSERT INTO google_identities(subject,user_id) VALUES(?,?)').run(identity.sub,id);
          db.prepare('UPDATE users SET email_verified=1 WHERE id=?').run(id);
          writeAuditLog({actorUserId:id,actorRole:'player',action:'google_linked',entityType:'user',entityId:id,summary:'Connected verified Google identity'});
        }
      });
      user = db.prepare('SELECT * FROM users WHERE id=?').get(id) as AuthUser;
      return startLoginSession(req,res,user);
    } catch {
      return res.status(401).json({error:'Google sign-in could not be verified. Reopen the panel and try again.'});
    }
  });

  // Get current authenticated session
  app.get('/api/auth/me', (req, res) => {
    if (!req.authUser) {
      return res.json({ user: null });
    }
    const acceptances = db
      .prepare('SELECT policy_type, policy_version, accepted_at FROM policy_acceptances WHERE user_id = ?')
      .all(req.authUser.id);
    const activePolicies = db
      .prepare('SELECT policy_type, version, title FROM policy_versions WHERE is_active = 1')
      .all();
    return res.json({
      user: serializeUserSelf(req.authUser),
      policyAcceptances: acceptances,
      activePolicies,
    });
  });

  // Register new account
  app.post('/api/auth/register', (req, res) => {
    const {
      username,
      displayName,
      email,
      password,
      country = 'US',
      competitiveRegion = 'NAE',
      epicDisplayName = '',
      referralCodeUsed = '',
      acquisitionSource = 'direct',
      acceptTerms,
      ageConfirmed,
    } = req.body || {};

    if (typeof username !== 'string' || !/^[A-Za-z0-9]{3,12}$/.test(username.trim())) {
      return res.status(400).json({ error: 'Username must be 3–12 letters or numbers.' });
    }
    if (typeof email !== 'string' || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      return res.status(400).json({ error: 'Enter a valid email address.' });
    }
    if (typeof password !== 'string' || !/^(?=.*[A-Za-z])(?=.*[0-9]).{8,25}$/.test(password)) {
      return res.status(400).json({ error: 'Use an 8–25 character password with at least one letter and one number.' });
    }
    if (ageConfirmed !== true) {
      return res.status(400).json({ error: 'Confirm that you are 18 or older to create an account.' });
    }
    if (acceptTerms !== true) {
      return res.status(400).json({ error: 'You must accept the SFT Terms, Privacy Policy, and Competition Rules.' });
    }
    if (!['NAE', 'NAC', 'NAW', 'EU'].includes(competitiveRegion)) {
      return res.status(400).json({ error: 'Invalid competitive region' });
    }

    const cleanUsername = String(username).trim().replace(/[^a-zA-Z0-9_.-]/g, '');
    const cleanEmail = String(email).trim().toLowerCase();
    if (cleanUsername.length < 3 || cleanUsername.length > 24) {
      return res.status(400).json({ error: 'Username must be 3-24 alphanumeric characters.' });
    }

    if (cleanUsername.toLowerCase() === ADMIN_USERNAME) return res.status(409).json({error:'Username is reserved.'});

    const existing = db.prepare('SELECT id FROM users WHERE username = ? OR email = ?').get(cleanUsername, cleanEmail);
    if (existing) {
      return res.status(409).json({ error: 'Username or email is already registered.' });
    }

    const info = extractClientInfo(req);
    const userId = newId('usr');
    const passHash = hashPassword(String(password));
    const myRefCode = `SFT-${cleanUsername.toUpperCase().slice(0, 8)}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;

    let referredById: string | null = null;
    if (referralCodeUsed) {
      const refRow = db.prepare('SELECT id FROM users WHERE referral_code = ?').get(String(referralCodeUsed).trim()) as { id: string } | undefined;
      if (refRow) referredById = refRow.id;
    }

    const rawToken = crypto.randomBytes(32).toString('hex');
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    const sessionId = newId('ses');
    const expiresAt = new Date(Date.now() + 7 * 86400 * 1000).toISOString();

    runImmediateTransaction(() => {
      db.prepare(`
        INSERT INTO users (
          id, username, display_name, email, email_verified, phone_verified, password_hash, role,
          country, competitive_region, age_attested_at, epic_display_name, epic_account_id,
          status, referral_code, referred_by_user_id, acquisition_source, is_demo
        ) VALUES (?, ?, ?, ?, 1, 0, ?, ?, ?, ?, strftime('%Y-%m-%dT%H:%M:%fZ','now'), ?, ?, 'active', ?, ?, ?, 0)
      `).run(
        userId,
        cleanUsername,
        String(displayName || cleanUsername).trim(),
        cleanEmail,
        passHash,
        'player',
        String(country).toUpperCase().slice(0, 2) || 'US',
        competitiveRegion,
        String(epicDisplayName || cleanUsername).trim(),
        epicDisplayName ? `epic_${cleanUsername.toLowerCase()}` : '',
        myRefCode,
        referredById,
        String(acquisitionSource || 'direct').slice(0, 40)
      );

      db.prepare('INSERT INTO user_balances (user_id, available_lamports, reserved_lamports, frozen_lamports) VALUES (?, 0, 0, 0)').run(userId);

      // Record policy acceptances for active versions
      const activePolicies = db.prepare('SELECT policy_type, version FROM policy_versions WHERE is_active = 1').all() as Array<{
        policy_type: string;
        version: string;
      }>;
      for (const pol of activePolicies) {
        db.prepare(`
          INSERT INTO policy_acceptances (id, user_id, policy_type, policy_version, ip_hash)
          VALUES (?, ?, ?, ?, ?)
        `).run(newId('pac'), userId, pol.policy_type, pol.version, info.ipHash);
      }

      // Grant referral welcome credit (Demo/Devnet bonus) if referred and ledger tracked
      if (referredById) {
        applyLedgerGroup([
          {
            idempotencyKey: `ref_bonus_${userId}`,
            userId: referredById,
            entryType: 'referral_bonus',
            bucket: 'available',
            deltaLamports: 10_000_000, // 0.01 SOL referral reward
            referenceType: 'referral',
            referenceId: userId,
            network: 'devnet',
            description: `Referral bonus for inviting ${cleanUsername}`,
            actorUserId: userId,
          },
        ]);
      }

      db.prepare(`
        INSERT INTO user_sessions (id, user_id, token_hash, device_id, browser, os, ip_hash, ip_country, is_vpn_proxy, expires_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(sessionId, userId, tokenHash, info.deviceId, info.browser, info.os, info.ipHash, String(country).toUpperCase().slice(0, 2) || 'US', info.isVpn, expiresAt);

      db.prepare(`
        INSERT INTO security_login_events (id, user_id, username_or_email, event_type, ip_hash, country, device_id, browser, os, is_vpn_proxy)
        VALUES (?, ?, ?, 'login_success', ?, ?, ?, ?, ?, ?)
      `).run(newId('sle'), userId, cleanEmail, info.ipHash, String(country).toUpperCase().slice(0, 2) || 'US', info.deviceId, info.browser, info.os, info.isVpn);

      db.prepare('INSERT INTO analytics_sessions (id, user_id, duration_seconds) VALUES (?, ?, 300)').run(newId('ase'), userId);
      evaluateRiskSignals(userId, info.ipHash, info.deviceId, info.isVpn);
      writeAuditLog({
        actorUserId: userId,
        actorRole: 'player',
        action: 'user_registered',
        entityType: 'user',
        entityId: userId,
        summary: `New user ${cleanUsername} registered (${competitiveRegion})`,
      });
    });

    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId) as AuthUser;
    setSessionCookie(res, rawToken, expiresAt);
    return res.status(201).json({ user: serializeUserSelf(user), token: rawToken });
  });

  app.post('/api/auth/demo-player', (req,res) => {
    const id = String(req.body?.identifier || '');
    if (!['VortexFN','Sloocwtw07'].includes(id)) return res.status(404).json({error:'Unknown demo player.'});
    const user = db.prepare("SELECT * FROM users WHERE username=? AND is_demo=1 AND role='player' AND status='active'").get(id) as AuthUser | undefined;
    if (!user) return res.status(404).json({error:'Demo account unavailable.'});
    return startLoginSession(req,res,user);
  });

  // Login
  app.post('/api/auth/login', (req, res) => {
    const { identifier, password } = req.body || {};
    if (!identifier || !password) {
      return res.status(400).json({ error: 'Username/email and password are required.' });
    }
    const cleanId = String(identifier).trim();
    const info = extractClientInfo(req);

    const user = db
      .prepare('SELECT * FROM users WHERE username = ? OR email = ?')
      .get(cleanId, cleanId.toLowerCase()) as (AuthUser & { password_hash: string }) | undefined;

    if (hostedDemo && user?.is_demo && user.role !== "player") return res.status(403).json({error:"Staff access requires a private SFT staff account."});
    if (!user || !verifyPassword(String(password), user.password_hash)) {
      db.prepare(`
        INSERT INTO security_login_events (id, user_id, username_or_email, event_type, ip_hash, country, device_id, browser, os, is_vpn_proxy)
        VALUES (?, ?, ?, 'login_failed', ?, 'US', ?, ?, ?, ?)
      `).run(newId('sle'), user?.id ?? null, cleanId, info.ipHash, info.deviceId, info.browser, info.os, info.isVpn);
      return res.status(401).json({ error: 'Invalid credentials.' });
    }

    if (user.status === 'banned' || user.status === 'suspended') {
      return res.status(403).json({ error: `Account is currently ${user.status}.` });
    }

    return startLoginSession(req, res, user);
  });

  // Logout
  app.post('/api/auth/logout', (req, res) => {
    if (req.sessionId) {
      db.prepare("UPDATE user_sessions SET revoked_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(req.sessionId);
    }
    clearSessionCookie(res);
    return res.json({ ok: true });
  });

  app.delete('/api/account/connections/:provider', requireAuth, (req, res) => {
    const user = req.authUser!;
    const provider = req.params.provider;
    if (provider !== 'epic' && provider !== 'twitch') {
      return res.status(404).json({ error: 'This connection cannot be removed here.' });
    }
    runImmediateTransaction(() => {
      if (provider === 'epic') {
        db.prepare("UPDATE users SET epic_display_name = '', epic_account_id = '' WHERE id = ?").run(user.id);
      } else {
        db.prepare('UPDATE users SET twitch_channel = NULL, twitch_authorized = 0 WHERE id = ?').run(user.id);
        db.prepare('UPDATE twitch_streams SET is_live = 0, is_authorized = 0 WHERE user_id = ?').run(user.id);
      }
      const previous = provider === 'epic' ? user.epic_display_name : user.twitch_channel;
      if (previous) db.prepare("INSERT INTO linked_accounts_history (id,user_id,provider,previous_value,new_value) VALUES (?,?,?,?,'')")
        .run(newId('lah'), user.id, provider, previous);
    });
    res.json({ ok: true });
  });

  app.patch('/api/account/appearance', requireAuth, (req, res) => {
    const { banner, portrait } = req.body || {};
    if (banner !== undefined && !['violet', 'midnight', 'ocean', 'sunset'].includes(banner))
      return res.status(400).json({ error: 'Choose a valid banner.' });
    if (portrait !== undefined && portrait !== null && (!Number.isInteger(portrait) || portrait < 0 || portrait > 5))
      return res.status(400).json({ error: 'Choose a valid avatar.' });
    const user = req.authUser!;
    runImmediateTransaction(()=>{
      if (portrait !== undefined) {
        db.prepare(`UPDATE user_inventory SET equipped=0 WHERE user_id=?
          AND item_id IN (SELECT id FROM shop_items WHERE portrait_index IS NOT NULL)`).run(user.id);
      }
      if (banner !== undefined) db.prepare('UPDATE users SET profile_banner=? WHERE id=?').run(banner,user.id);
      if (portrait !== undefined) db.prepare('UPDATE users SET profile_portrait=? WHERE id=?').run(portrait,user.id);
    });
    res.json({ ok: true });
  });

  // Update profile / username / Epic IGN / region / payout / twitch link (tracks history cleanly without altering match snapshots!)
  app.patch('/api/account/profile', requireAuth, (req, res) => {
    const u = req.authUser!;
    const {
      username,
      displayName,
      epicDisplayName,
      epicAccountId,
      competitiveRegion,
      payoutAddress,
      twitchChannel,
      phone,
      verifyPhoneCode,
      verifyEmailCode,
      ageConfirmed,
    } = req.body || {};

    if (username && username !== u.username) {
      const normalized = String(username).trim().replace(/[^a-zA-Z0-9_.-]/g,'').toLowerCase();
      if (isArenaAdmin(u) || normalized === ADMIN_USERNAME) return res.status(400).json({error:'This username is reserved.'});
    }

    runImmediateTransaction(() => {
      if (username && username !== u.username) {
        const cleanNew = String(username).trim().replace(/[^a-zA-Z0-9_.-]/g, '');
        if (cleanNew.length < 3 || cleanNew.length > 24) {
          throw new Error('Username must be 3-24 characters');
        }
        const conflict = db.prepare('SELECT id FROM users WHERE username = ? AND id != ?').get(cleanNew, u.id);
        if (conflict) throw new Error('Username already taken');
        db.prepare(`
          INSERT INTO username_history (id, user_id, previous_username, new_username)
          VALUES (?, ?, ?, ?)
        `).run(newId('unh'), u.id, u.username, cleanNew);
        db.prepare('UPDATE users SET username = ? WHERE id = ?').run(cleanNew, u.id);
      }

      if (displayName) {
        db.prepare('UPDATE users SET display_name = ? WHERE id = ?').run(String(displayName).trim().slice(0, 32), u.id);
      }

      if (epicDisplayName !== undefined && epicDisplayName !== u.epic_display_name) {
        db.prepare(`
          INSERT INTO linked_accounts_history (id, user_id, provider, previous_value, new_value)
          VALUES (?, ?, 'epic', ?, ?)
        `).run(newId('lah'), u.id, u.epic_display_name, String(epicDisplayName).trim());
        db.prepare('UPDATE users SET epic_display_name = ?, epic_account_id = ? WHERE id = ?').run(
          String(epicDisplayName).trim().slice(0,32),
          String(epicAccountId || `epic_${String(epicDisplayName).trim().toLowerCase()}`),
          u.id
        );
      }

      if (competitiveRegion && ['NAE', 'NAC', 'NAW', 'EU'].includes(competitiveRegion)) {
        db.prepare('UPDATE users SET competitive_region = ? WHERE id = ?').run(competitiveRegion, u.id);
      }

      if (payoutAddress !== undefined && payoutAddress !== u.payout_address) {
        const addr = String(payoutAddress).trim();
        db.prepare(`
          INSERT INTO linked_accounts_history (id, user_id, provider, previous_value, new_value)
          VALUES (?, ?, 'solana_wallet', ?, ?)
        `).run(newId('lah'), u.id, u.payout_address, addr);
        db.prepare('UPDATE users SET payout_address = ? WHERE id = ?').run(addr, u.id);

        // Risk check: shared payout address across different accounts
        if (addr.length > 20) {
          const shared = db.prepare('SELECT id FROM users WHERE payout_address = ? AND id != ?').all(addr, u.id);
          if (shared.length > 0) {
            db.prepare(`
              INSERT INTO risk_flags (id, user_id, flag_type, severity, details_json)
              VALUES (?, ?, 'shared_payout_address', 'high', ?)
            `).run(newId('rf'), u.id, JSON.stringify({ payoutAddress: addr, sharedAccountCount: shared.length }));
            db.prepare('UPDATE users SET risk_score = MIN(100, risk_score + 35) WHERE id = ?').run(u.id);
          }
        }
      }

      if (twitchChannel !== undefined) {
        const ch = String(twitchChannel).trim().replace(/^@/, '');
        db.prepare(`
          INSERT INTO linked_accounts_history (id, user_id, provider, previous_value, new_value)
          VALUES (?, ?, 'twitch', ?, ?)
        `).run(newId('lah'), u.id, u.twitch_channel || '', ch);
        db.prepare('UPDATE users SET twitch_channel = ?, twitch_authorized = ? WHERE id = ?').run(ch || null, ch ? 1 : 0, u.id);
        if (ch) {
          db.prepare(`
            INSERT INTO twitch_streams (id, user_id, channel_name, stream_title, game_mode, viewer_count, is_live, is_authorized)
            VALUES (?, ?, ?, ?, 'Zone Wars', 12, 1, 1)
            ON CONFLICT(channel_name) DO UPDATE SET user_id = excluded.user_id, is_authorized = 1, is_live = 1, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
          `).run(newId('str'), u.id, ch, `${u.display_name} Competing Live on SFT`);
        }
      }

      if (phone) {
        db.prepare('UPDATE users SET phone = ?, phone_verified = ? WHERE id = ?').run(
          String(phone).trim(),
          verifyPhoneCode === '123456' ? 1 : u.phone_verified,
          u.id
        );
      } else if (verifyPhoneCode === '123456') {
        db.prepare('UPDATE users SET phone_verified = 1 WHERE id = ?').run(u.id);
      }

      if (verifyEmailCode === '123456') {
        db.prepare('UPDATE users SET email_verified = 1 WHERE id = ?').run(u.id);
      }

      if (ageConfirmed === true && !u.age_attested_at) {
        db.prepare("UPDATE users SET age_attested_at = strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id = ?").run(u.id);
      }

      db.prepare("UPDATE users SET updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(u.id);
    });

    const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(u.id) as AuthUser;
    return res.json({ user: serializeUserSelf(updated) });
  });

  // Public player search & public profile view (strictly excludes private identity/risk fields)
  app.get('/api/users/search', (req, res) => {
    const q = String(req.query.q || '').trim();
    const rows = q
      ? (db
          .prepare('SELECT * FROM users WHERE (username LIKE ? OR epic_display_name LIKE ? OR display_name LIKE ?) ORDER BY elo DESC LIMIT 20')
          .all(`%${q}%`, `%${q}%`, `%${q}%`) as AuthUser[])
      : (db.prepare('SELECT * FROM users ORDER BY elo DESC LIMIT 20').all() as AuthUser[]);
    res.json({ users: rows.map(serializeUserPublic) });
  });

  app.get('/api/users/:username', (req, res) => {
    const user = db.prepare('SELECT * FROM users WHERE username = ? OR id = ?').get(req.params.username, req.params.username) as AuthUser | undefined;
    if (!user) return res.status(404).json({ error: 'Player not found' });

    const isSelf = req.authUser?.id === user.id;
    const recentMatches = db.prepare(`
      SELECT m.id, m.title, m.mode, m.format, m.region, m.status, m.winner_side,
        m.score_a, m.score_b, m.created_at, mp.team_side,
        (SELECT json_group_array(op.username_snapshot) FROM match_participants op
          WHERE op.match_id=m.id AND op.team_side<>mp.team_side) AS opponents
        ${isSelf ? `, (SELECT SUM(l.delta_lamports) FROM ledger_entries l
          WHERE l.user_id=mp.user_id AND l.reference_type IN ('match','match_override') AND l.reference_id=m.id
            AND l.bucket='available') AS wallet_change_lamports,
          EXISTS(SELECT 1 FROM ledger_entries l WHERE l.user_id=mp.user_id AND l.reference_type='match'
            AND l.reference_id=m.id AND l.entry_type='match_refund' AND l.bucket='available' AND l.delta_lamports>0) AS refunded` : ''}
      FROM match_participants mp JOIN matches m ON m.id=mp.match_id
      WHERE mp.user_id=? AND (m.is_private=0 OR ?=1)
      ORDER BY m.created_at DESC LIMIT 100
    `).all(user.id, Number(isSelf));

    const isSelfOrStaff =
      req.authUser && (req.authUser.id === user.id || ['moderator', 'finance', 'owner'].includes(req.authUser.role));

    res.json({
      profile: isSelfOrStaff ? serializeUserSelf(user) : serializeUserPublic(user),
      recentMatches,
    });
  });

  // Leaderboard
  app.get('/api/leaderboard', (req, res) => {
    const region = String(req.query.region || 'ALL');
    const period = String(req.query.period || '');
    if (['Daily','Weekly','Monthly','All-Time'].includes(period)) {
      const now = new Date();
      const start = new Date(Date.UTC(now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate()));
      if (period === 'Weekly') start.setUTCDate(start.getUTCDate() - (start.getUTCDay()+6)%7);
      if (period === 'Monthly') start.setUTCDate(1);
      const end = new Date(start);
      if (period === 'Monthly') end.setUTCMonth(end.getUTCMonth()+1);
      else end.setUTCDate(end.getUTCDate()+(period === 'Weekly' ? 7:1));
      const since = period === 'All-Time' ? '0000' : start.toISOString();
      const rows = db.prepare(`WITH results AS (
        SELECT p.user_id,COUNT(*) AS played,SUM(CASE WHEN p.team_side=m.winner_side THEN 1 ELSE 0 END) AS wins
        FROM match_participants p JOIN matches m ON m.id=p.match_id
        WHERE m.status='Complete' AND m.completed_at>=? GROUP BY p.user_id
      ), winnings AS (
        SELECT user_id,SUM(delta_lamports) AS earned FROM ledger_entries WHERE bucket='available'
        AND entry_type IN ('match_win_payout','tournament_payout','match_override_adjustment') AND created_at>=? GROUP BY user_id
      )
      SELECT u.id,u.username,u.competitive_region AS region, COALESCE(w.earned,0) AS earnedLamports,
        CASE WHEN ?='All-Time' THEN u.wins ELSE COALESCE(r.wins,0) END AS wins,
        CASE WHEN ?='All-Time' THEN u.losses ELSE COALESCE(r.played-r.wins,0) END AS losses
      FROM users u LEFT JOIN results r ON r.user_id=u.id LEFT JOIN winnings w ON w.user_id=u.id
      WHERE u.status='active' AND (?='ALL' OR u.competitive_region=?) AND (?='All-Time' OR r.played>0 OR w.earned>0)
      ORDER BY earnedLamports DESC,wins DESC,losses ASC,u.username LIMIT 100`).all(since,since,period,period,region,region,period) as Record<string,unknown>[];
      return res.json({leaderboard:rows.map((r,i)=>({...r,rank:i+1})),resetAt:period==='All-Time'?null:end.toISOString()});
    }
    const rows = (
      region !== 'ALL' && ['NAE', 'NAC', 'NAW', 'EU'].includes(region)
        ? db.prepare('SELECT * FROM users WHERE competitive_region = ? ORDER BY elo DESC, wins DESC LIMIT 100').all(region)
        : db.prepare('SELECT * FROM users ORDER BY elo DESC, wins DESC LIMIT 100').all()
    ) as AuthUser[];

    const earningsRows = db
      .prepare(`
        SELECT user_id, COALESCE(SUM(CASE WHEN entry_type IN ('match_win_payout', 'tournament_payout') THEN delta_lamports ELSE 0 END), 0) as earned_lamports
        FROM ledger_entries
        GROUP BY user_id
      `)
      .all() as Array<{ user_id: string; earned_lamports: number }>;
    const earningsMap = new Map(earningsRows.map((r) => [r.user_id, r.earned_lamports]));

    const leaderboard = rows.map((u, idx) => ({
      rank: idx + 1,
      ...serializeUserPublic(u),
      earnedLamports: earningsMap.get(u.id) ?? 0,
    }));

    res.json({ leaderboard });
  });

  // Notifications
  app.get('/api/notifications', requireAuth, (req, res) => {
    const rows = db
      .prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 30')
      .all(req.authUser!.id);
    const unreadCount = (
      db.prepare('SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND is_read = 0').get(req.authUser!.id) as { c: number }
    ).c;
    res.json({ notifications: rows, unreadCount });
  });

  app.post('/api/notifications/read', requireAuth, (req, res) => {
    db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(req.authUser!.id);
    res.json({ ok: true });
  });
}
