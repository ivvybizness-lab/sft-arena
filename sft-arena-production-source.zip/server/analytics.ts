import { teamIcons, teamColours } from '../src/lib/team-options.ts';
import type { Express } from 'express';
import { db, newId, writeAuditLog, notifyUser } from './db.ts';
import { applyLedgerGroup, runImmediateTransaction } from './ledger.ts';
import { requireAuth, requireRole } from './auth.ts';
import { registerAdminDashboard } from './admin-dashboard.ts';

export function registerAnalyticsAndStaffRoutes(app: Express) {
  registerAdminDashboard(app);
  // =========================================================================
  // 1. OWNER-ONLY BUSINESS ANALYTICS (Highest-Priority Owner Feature)
  // =========================================================================
  app.get('/api/owner/analytics', requireRole(['owner']), (req, res) => {
    const days = Math.min(365, Math.max(1, Number(req.query.days || 30)));
    const region = String(req.query.region || 'ALL');
    const country = String(req.query.country || 'ALL');
    const mode = String(req.query.mode || 'ALL');
    const includeDemo = req.query.includeDemo !== 'false';

    const sinceIso = new Date(Date.now() - days * 86400 * 1000).toISOString();
    const dayAgoIso = new Date(Date.now() - 86400 * 1000).toISOString();
    const weekAgoIso = new Date(Date.now() - 7 * 86400 * 1000).toISOString();
    const monthAgoIso = new Date(Date.now() - 30 * 86400 * 1000).toISOString();

    const cfg = db.prepare('SELECT network_mode, fee_bps FROM wallet_config WHERE id = 1').get() as {
      network_mode: string;
      fee_bps: number;
    };

    const demoFilterMatches = includeDemo ? '' : 'AND m.is_demo = 0';
    const demoFilterUsers = includeDemo ? '' : 'AND u.is_demo = 0';
    const regionFilter = region !== 'ALL' ? 'AND m.region = ?' : '';
    const modeFilter = mode !== 'ALL' ? 'AND m.mode = ?' : '';
    const matchParams: unknown[] = [sinceIso];
    if (region !== 'ALL') matchParams.push(region);
    if (mode !== 'ALL') matchParams.push(mode);

    // Match volume, fees, completion, cancellations
    const matchStats = db
      .prepare(`
        SELECT
          COUNT(*) as total_matches,
          SUM(CASE WHEN m.status = 'Complete' THEN 1 ELSE 0 END) as completed_matches,
          SUM(CASE WHEN m.status = 'Cancelled' THEN 1 ELSE 0 END) as cancelled_matches,
          SUM(CASE WHEN m.status = 'Disputed' THEN 1 ELSE 0 END) as open_disputes,
          SUM(CASE WHEN m.status IN ('Waiting', 'Ready', 'In Progress') THEN 1 ELSE 0 END) as active_matches,
          COALESCE(SUM(CASE WHEN m.status = 'Complete' THEN m.total_prize_lamports + m.platform_fee_lamports ELSE 0 END), 0) as total_match_volume_lamports,
          COALESCE(SUM(CASE WHEN m.status = 'Complete' THEN m.platform_fee_lamports ELSE 0 END), 0) as gross_fees_lamports,
          COALESCE(AVG(CASE WHEN m.entry_lamports > 0 THEN m.entry_lamports END), 0) as avg_entry_lamports,
          COALESCE(AVG(CASE WHEN m.started_at IS NOT NULL THEN (julianday(m.started_at) - julianday(m.created_at)) * 86400 END), 0) as avg_time_to_match_sec
        FROM matches m
        WHERE m.created_at >= ? ${demoFilterMatches} ${regionFilter} ${modeFilter}
      `)
      .get(...matchParams) as {
      total_matches: number;
      completed_matches: number;
      cancelled_matches: number;
      open_disputes: number;
      active_matches: number;
      total_match_volume_lamports: number;
      gross_fees_lamports: number;
      avg_entry_lamports: number;
      avg_time_to_match_sec: number;
    };

    // Ledger financial metrics (deposits, withdrawals, refunds/reversals, rewards/referrals)
    const ledgerAgg = db
      .prepare(`
        SELECT
          COALESCE(SUM(CASE WHEN entry_type = 'deposit_credit' AND reference_type != 'demo_seed' THEN delta_lamports ELSE 0 END), 0) as deposits_lamports,
          COALESCE(SUM(CASE WHEN entry_type = 'withdrawal_confirm' THEN ABS(delta_lamports) ELSE 0 END), 0) as withdrawals_lamports,
          COALESCE(SUM(CASE WHEN entry_type IN ('match_refund', 'match_override_adjustment', 'tournament_refund') AND delta_lamports < 0 THEN ABS(delta_lamports) ELSE 0 END), 0) as fee_reversals_lamports,
          COALESCE(SUM(CASE WHEN entry_type IN ('reward_bonus', 'referral_bonus') THEN delta_lamports ELSE 0 END), 0) as bonus_referral_cost_lamports
        FROM ledger_entries
        WHERE created_at >= ?
      `)
      .get(sinceIso) as {
      deposits_lamports: number;
      withdrawals_lamports: number;
      fee_reversals_lamports: number;
      bonus_referral_cost_lamports: number;
    };

    const liabilities = db
      .prepare('SELECT COALESCE(SUM(available_lamports + reserved_lamports + frozen_lamports), 0) as total FROM user_balances')
      .get() as { total: number };

    // Player Activity (DAU/WAU/MAU, registrations, first deposit, first match, retention D1/D7/D30)
    const countryFilter = country !== 'ALL' ? 'AND u.country = ?' : '';
    const userParams: unknown[] = [];
    if (country !== 'ALL') userParams.push(country);

    const totalUsers = (
      db.prepare(`SELECT COUNT(*) as c FROM users u WHERE 1=1 ${demoFilterUsers} ${countryFilter}`).get(...userParams) as { c: number }
    ).c;

    const newRegistrations = (
      db
        .prepare(`SELECT COUNT(*) as c FROM users u WHERE u.created_at >= ? ${demoFilterUsers} ${countryFilter}`)
        .get(sinceIso, ...userParams) as { c: number }
    ).c;

    const dau = (
      db
        .prepare('SELECT COUNT(DISTINCT user_id) as c FROM analytics_sessions WHERE started_at >= ?')
        .get(dayAgoIso) as { c: number }
    ).c;
    const wau = (
      db
        .prepare('SELECT COUNT(DISTINCT user_id) as c FROM analytics_sessions WHERE started_at >= ?')
        .get(weekAgoIso) as { c: number }
    ).c;
    const mau = (
      db
        .prepare('SELECT COUNT(DISTINCT user_id) as c FROM analytics_sessions WHERE started_at >= ?')
        .get(monthAgoIso) as { c: number }
    ).c;

    const avgSessionSec = (
      db.prepare('SELECT COALESCE(AVG(duration_seconds), 0) as a FROM analytics_sessions WHERE started_at >= ?').get(sinceIso) as { a: number }
    ).a;

    const depositorsCount = (
      db
        .prepare("SELECT COUNT(DISTINCT user_id) as c FROM deposit_invoices WHERE status = 'Matched' AND created_at >= ?")
        .get(sinceIso) as { c: number }
    ).c;

    const wageredUsersCount = (
      db
        .prepare("SELECT COUNT(DISTINCT mp.user_id) as c FROM match_participants mp JOIN matches m ON m.id = mp.match_id WHERE m.entry_lamports > 0 AND mp.joined_at >= ?")
        .get(sinceIso) as { c: number }
    ).c;

    const firstMatchUsersCount = (
      db.prepare('SELECT COUNT(DISTINCT user_id) as c FROM match_participants WHERE joined_at >= ?').get(sinceIso) as { c: number }
    ).c;

    // Retention Cohorts (D1, D7, D30: users created >= N days ago who had session or match >= 1/7/30 days after signup)
    const calcRetention = (cohortDays: number) => {
      const eligible = (
        db
          .prepare(`SELECT COUNT(*) as c FROM users u WHERE julianday('now') - julianday(u.created_at) >= ? ${demoFilterUsers}`)
          .get(cohortDays) as { c: number }
      ).c;
      if (eligible === 0) return { eligible: 0, retained: 0, ratePct: 0 };
      const retained = (
        db
          .prepare(`
            SELECT COUNT(DISTINCT u.id) as c
            FROM users u
            WHERE julianday('now') - julianday(u.created_at) >= ? ${demoFilterUsers}
              AND (
                EXISTS (SELECT 1 FROM analytics_sessions s WHERE s.user_id = u.id AND julianday(s.started_at) - julianday(u.created_at) >= ?)
                OR EXISTS (SELECT 1 FROM match_participants mp WHERE mp.user_id = u.id AND julianday(mp.joined_at) - julianday(u.created_at) >= ?)
              )
          `)
          .get(cohortDays, cohortDays * 0.5, cohortDays * 0.8) as { c: number }
      ).c;
      return { eligible, retained, ratePct: Math.round((retained / eligible) * 1000) / 10 };
    };

    // Unmatched queue & dispute health
    const totalDisputesInPeriod = (
      db.prepare('SELECT COUNT(*) as c FROM disputes WHERE created_at >= ?').get(sinceIso) as { c: number }
    ).c;
    const avgDisputeResSec = (
      db
        .prepare("SELECT COALESCE(AVG((julianday(resolved_at) - julianday(created_at)) * 86400), 0) as a FROM disputes WHERE status = 'Resolved' AND resolved_at IS NOT NULL")
        .get() as { a: number }
    ).a;
    const unassistedComplete = (
      db
        .prepare("SELECT COUNT(*) as c FROM matches m WHERE m.status = 'Complete' AND m.created_at >= ? AND NOT EXISTS (SELECT 1 FROM disputes d WHERE d.match_id = m.id)")
        .get(sinceIso) as { c: number }
    ).c;
    const unmatchedWaits = (
      db.prepare("SELECT COUNT(*) as c FROM matchmaking_attempts WHERE matched = 0 AND created_at >= ?").get(sinceIso) as { c: number }
    ).c;

    // Breakdowns
    const byRegion = db
      .prepare(`
        SELECT region, COUNT(*) as matches,
               COALESCE(SUM(CASE WHEN status = 'Complete' THEN total_prize_lamports + platform_fee_lamports ELSE 0 END), 0) as volume_lamports,
               COALESCE(SUM(CASE WHEN status = 'Complete' THEN platform_fee_lamports ELSE 0 END), 0) as fees_lamports
        FROM matches WHERE created_at >= ? GROUP BY region ORDER BY matches DESC
      `)
      .all(sinceIso);

    const byMode = db
      .prepare(`
        SELECT mode, COUNT(*) as matches,
               COALESCE(SUM(CASE WHEN status = 'Complete' THEN total_prize_lamports + platform_fee_lamports ELSE 0 END), 0) as volume_lamports,
               COALESCE(SUM(CASE WHEN status = 'Complete' THEN platform_fee_lamports ELSE 0 END), 0) as fees_lamports
        FROM matches WHERE created_at >= ? GROUP BY mode ORDER BY matches DESC
      `)
      .all(sinceIso);

    const byStakeTier = db
      .prepare(`
        SELECT
          CASE
            WHEN entry_lamports = 0 THEN 'Free'
            WHEN entry_lamports <= 250000000 THEN '0.01 - 0.25 SOL'
            WHEN entry_lamports <= 1000000000 THEN '0.25 - 1.00 SOL'
            ELSE '1.00+ SOL'
          END as stake_tier,
          COUNT(*) as matches
        FROM matches WHERE created_at >= ?
        GROUP BY stake_tier ORDER BY matches DESC
      `)
      .all(sinceIso);

    const byAcquisition = db
      .prepare(`SELECT acquisition_source, COUNT(*) as users FROM users WHERE 1=1 ${includeDemo ? '' : 'AND is_demo = 0'} GROUP BY acquisition_source ORDER BY users DESC`)
      .all();

    const byCountry = db
      .prepare(`SELECT country, COUNT(*) as users FROM users WHERE 1=1 ${includeDemo ? '' : 'AND is_demo = 0'} GROUP BY country ORDER BY users DESC`)
      .all();

    const dailyRevenueSeries = db
      .prepare(`
        SELECT substr(created_at, 1, 10) as day,
               COUNT(*) as matches,
               COALESCE(SUM(CASE WHEN status = 'Complete' THEN total_prize_lamports + platform_fee_lamports ELSE 0 END), 0) as volume_lamports,
               COALESCE(SUM(CASE WHEN status = 'Complete' THEN platform_fee_lamports ELSE 0 END), 0) as fees_lamports
        FROM matches
        WHERE created_at >= ?
        GROUP BY day
        ORDER BY day ASC
      `)
      .all(sinceIso);

    const netRevenueLamports = Math.max(0, matchStats.gross_fees_lamports - ledgerAgg.bonus_referral_cost_lamports);
    const activeWagerersOrUsers = Math.max(1, totalUsers);

    res.json({
      currency: 'SOL',
      networkMode: cfg.network_mode,
      filters: { days, region, country, mode, includeDemo },
      financial: {
        totalMatchVolumeLamports: matchStats.total_match_volume_lamports,
        grossFeesLamports: matchStats.gross_fees_lamports,
        netRevenueLamports,
        averageEntryLamports: Math.round(matchStats.avg_entry_lamports),
        arpuLamports: Math.round(matchStats.gross_fees_lamports / activeWagerersOrUsers),
        depositToWagerConversionPct: depositorsCount > 0 ? Math.min(100, Math.round((wageredUsersCount / depositorsCount) * 1000) / 10) : 0,
        depositsLamports: ledgerAgg.deposits_lamports,
        withdrawalsLamports: ledgerAgg.withdrawals_lamports,
        outstandingLiabilitiesLamports: liabilities.total,
        bonusAndReferralCostLamports: ledgerAgg.bonus_referral_cost_lamports,
        feeReversalsLamports: ledgerAgg.fee_reversals_lamports,
      },
      activity: {
        totalUsers,
        newRegistrations,
        firstDepositCount: depositorsCount,
        firstMatchCount: firstMatchUsersCount,
        dau,
        wau,
        mau,
        avgSessionDurationSec: Math.round(avgSessionSec),
        retention: {
          d1: calcRetention(1),
          d7: calcRetention(7),
          d30: calcRetention(30),
        },
        funnel: [
          { stage: 'Registered', count: totalUsers },
          { stage: 'First Match Joined', count: firstMatchUsersCount },
          { stage: 'Paid Entry Match', count: wageredUsersCount },
          { stage: 'SOL Deposited', count: depositorsCount },
        ],
      },
      marketplaceHealth: {
        totalMatches: matchStats.total_matches,
        completedMatches: matchStats.completed_matches,
        cancelledMatches: matchStats.cancelled_matches,
        activeLobbies: matchStats.active_matches,
        completionRatePct: matchStats.total_matches > 0 ? Math.round((matchStats.completed_matches / matchStats.total_matches) * 1000) / 10 : 0,
        cancellationRatePct: matchStats.total_matches > 0 ? Math.round((matchStats.cancelled_matches / matchStats.total_matches) * 1000) / 10 : 0,
        avgTimeToMatchSec: Math.round(matchStats.avg_time_to_match_sec),
        unmatchedWaits,
        disputeRatePct: matchStats.total_matches > 0 ? Math.round((totalDisputesInPeriod / matchStats.total_matches) * 1000) / 10 : 0,
        openDisputes: matchStats.open_disputes,
        avgDisputeResolutionSec: Math.round(avgDisputeResSec),
        unassistedCompletionPct:
          matchStats.completed_matches > 0 ? Math.round((unassistedComplete / matchStats.completed_matches) * 1000) / 10 : 100,
      },
      breakdowns: {
        byRegion,
        byMode,
        byStakeTier,
        byAcquisition,
        byCountry,
        dailyRevenueSeries,
      },
    });
  });

  // =========================================================================
  // 2. STAFF CONSOLE ROUTES (Moderators, Finance, Owner)
  // =========================================================================

  // Dispute queue & open flagged risk items
  app.get('/api/staff/overview', requireRole(['moderator', 'finance', 'owner']), (req, res) => {
    const disputes = db
      .prepare(`
        SELECT d.*, m.title as match_title, m.mode, m.format, m.region, m.entry_lamports, m.status as match_status,
               u.username as opened_by_username
        FROM disputes d
        JOIN matches m ON m.id = d.match_id
        JOIN users u ON u.id = d.opened_by_user_id
        ORDER BY CASE d.status WHEN 'Open' THEN 0 WHEN 'Under Review' THEN 1 ELSE 2 END, d.created_at DESC
        LIMIT 60
      `)
      .all();

    const riskFlags = db
      .prepare(`
        SELECT rf.*, u.username, u.email, u.risk_score, u.status as account_status
        FROM risk_flags rf
        JOIN users u ON u.id = rf.user_id
        ORDER BY CASE rf.status WHEN 'Open' THEN 0 WHEN 'Investigating' THEN 1 ELSE 2 END, rf.created_at DESC
        LIMIT 60
      `)
      .all();

    const loginEvents = db
      .prepare(`
        SELECT s.*, u.username
        FROM security_login_events s
        LEFT JOIN users u ON u.id = s.user_id
        ORDER BY s.created_at DESC
        LIMIT 60
      `)
      .all();

    const tickets = db
      .prepare(`
        SELECT st.*, u.username
        FROM support_tickets st
        JOIN users u ON u.id = st.user_id
        ORDER BY st.created_at DESC
        LIMIT 40
      `)
      .all();

    res.json({ disputes, riskFlags, loginEvents, tickets });
  });

  // Staff Accounts Directory (includes restricted risk/private inspection fields)
  app.get('/api/staff/users', requireRole(['moderator', 'finance', 'owner']), (req, res) => {
    const q = String(req.query.q || '').trim();
    const users = q
      ? db
          .prepare(`
            SELECT u.id,u.username,u.email,u.epic_display_name,u.role,u.status,u.risk_score,ub.available_lamports,ub.reserved_lamports,ub.frozen_lamports
            FROM users u LEFT JOIN user_balances ub ON ub.user_id = u.id
            WHERE u.username LIKE ? OR u.email LIKE ? OR u.epic_display_name LIKE ? OR u.id = ?
            ORDER BY u.created_at DESC LIMIT 50
          `)
          .all(`%${q}%`, `%${q}%`, `%${q}%`, q)
      : db
          .prepare(`
            SELECT u.id,u.username,u.email,u.epic_display_name,u.role,u.status,u.risk_score,ub.available_lamports,ub.reserved_lamports,ub.frozen_lamports
            FROM users u LEFT JOIN user_balances ub ON ub.user_id = u.id
            ORDER BY u.created_at DESC LIMIT 50
          `)
          .all();
    res.json({ users });
  });

  const staffAccess = requireRole(['moderator','finance','owner']);
  const moderationAccess = requireRole(['moderator','owner']);

  app.get('/api/staff/players/:id', staffAccess, (req,res) => {
    const {id}=req.params;
    const player=db.prepare(`SELECT u.id,u.username,u.display_name,u.created_at,u.role,u.status,u.email,u.epic_display_name,u.avatar_url,
      u.competitive_region,u.risk_score,u.is_demo,b.available_lamports,b.reserved_lamports,b.frozen_lamports,
      m.chat_banned,m.force_stream,m.force_anticheat,m.lock_tipping,m.staff_verified
      FROM users u JOIN user_balances b ON b.user_id=u.id LEFT JOIN player_moderation m ON m.user_id=u.id WHERE u.id=?`).get(id);
    if (!player) return res.status(404).json({error:'Player not found.'});
    const security=db.prepare('SELECT flag_type AS title,status AS body,created_at FROM risk_flags WHERE user_id=? ORDER BY created_at DESC LIMIT 100').all(id);
    const logs=db.prepare(`SELECT a.action AS title,a.summary AS body,a.created_at,u.username AS author
      FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_user_id WHERE a.entity_type='user' AND a.entity_id=? ORDER BY a.created_at DESC LIMIT 100`).all(id);
    const notes=db.prepare(`SELECT n.body,n.created_at,u.username AS author FROM staff_notes n JOIN users u ON u.id=n.author_id
      WHERE n.user_id=? ORDER BY n.created_at DESC LIMIT 100`).all(id);
    const history=db.prepare(`SELECT m.id,m.title,m.status AS body,p.joined_at AS created_at FROM match_participants p JOIN matches m ON m.id=p.match_id
      WHERE p.user_id=? ORDER BY p.joined_at DESC LIMIT 100`).all(id);
    const ledger=db.prepare(`SELECT entry_type AS title,description AS body,delta_lamports AS amount,created_at
      FROM ledger_entries WHERE user_id=? ORDER BY created_at DESC LIMIT 150`).all(id);
    res.json({player,security,logs,notes,history,ledger});
  });

  app.post('/api/staff/players/:id/notes', moderationAccess, (req,res) => {
    const staff=req.authUser!;
    const body=String(req.body?.body || '').trim();
    if (!body || body.length>1500) return res.status(400).json({error:'Enter a note between 1 and 1,500 characters.'});
    if (!db.prepare('SELECT 1 FROM users WHERE id=?').get(req.params.id)) return res.status(404).json({error:'Player not found.'});
    runImmediateTransaction(()=>{
      db.prepare('INSERT INTO staff_notes(id,user_id,author_id,body) VALUES(?,?,?,?)').run(newId('snt'),req.params.id,staff.id,body);
      writeAuditLog({actorUserId:staff.id,actorRole:staff.role,action:'staff_note_added',entityType:'user',entityId:req.params.id,summary:'Added a staff note'});
    });
    res.status(201).json({ok:true});
  });

  app.post('/api/staff/players/:id/control', moderationAccess, (req,res) => {
    const staff=req.authUser!;
    const target=db.prepare('SELECT id,role,epic_display_name FROM users WHERE id=?').get(req.params.id) as {id:string;role:string;epic_display_name:string}|undefined;
    const reason=String(req.body?.reason||'').trim().slice(0,500);
    const action=String(req.body?.action||'');
    const fields=['chat_banned','force_stream','lock_tipping','force_anticheat','staff_verified'];
    if (!target) return res.status(404).json({error:'Player not found.'});
    if (target.id===staff.id || (target.role!=='player' && staff.role!=='owner')) return res.status(403).json({error:'You cannot moderate this account.'});
    if ((reason.length<3) || (!fields.includes(action) && action!=='unlink_game_account')) return res.status(400).json({error:'A valid action and audit reason are required.'});
    runImmediateTransaction(()=>{
      if (action==='unlink_game_account') {
        db.prepare("UPDATE users SET epic_account_id='',epic_display_name='' WHERE id=?").run(target.id);
        db.prepare("INSERT INTO linked_accounts_history(id,user_id,provider,previous_value,new_value) VALUES(?,?,'epic',?,'')").run(newId('lkh'),target.id,target.epic_display_name);
      } else {
        db.prepare('INSERT INTO player_moderation(user_id) VALUES(?) ON CONFLICT DO NOTHING').run(target.id);
        db.prepare('UPDATE player_moderation SET '+ action +'=? WHERE user_id=?').run(req.body.enabled===true?1:0,target.id);
      }
      writeAuditLog({actorUserId:staff.id,actorRole:staff.role,action,entityType:'user',entityId:target.id,summary:reason,metadata:{enabled:req.body.enabled===true}});
    });
    res.json({ok:true});
  });

  // Update Account Status (active, restricted, suspended, banned) + optional role (Owner only)
  app.patch('/api/staff/users/:userId', requireRole(['moderator', 'finance', 'owner']), (req, res) => {
    const actor = req.authUser!;
    const { status, reason, role, freezeLamports } = req.body || {};
    const target = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.userId) as {
      id: string;
      username: string;
      status: string;
      role: string;
    } | undefined;
    if (!target) return res.status(404).json({ error: 'User not found' });

    if (target.id === actor.id || (target.role !== 'player' && actor.role !== 'owner')) return res.status(403).json({error:'You cannot moderate this account.'});
    if (role && actor.role !== 'owner') {
      return res.status(403).json({ error: 'Only the Owner can modify staff roles' });
    }

    runImmediateTransaction(() => {
      if (status && ['active', 'restricted', 'suspended', 'banned'].includes(status) && status !== target.status) {
        if (!reason) throw new Error('A reason is required for account status changes');
        db.prepare("UPDATE users SET status = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(status, target.id);
        db.prepare(`
          INSERT INTO account_status_history (id, user_id, previous_status, new_status, actor_user_id, reason)
          VALUES (?, ?, ?, ?, ?, ?)
        `).run(newId('ash'), target.id, target.status, status, actor.id, String(reason));
      }

      if (role && ['player', 'moderator', 'finance', 'owner'].includes(role) && role !== target.role) {
        if (String(reason || '').trim().length < 3) throw new Error('An audit reason is required for role changes');
        db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, target.id);
      }

      if (freezeLamports !== undefined && Number(freezeLamports) > 0 && ['finance', 'owner'].includes(actor.role)) {
        const amt = Math.round(Number(freezeLamports));
        applyLedgerGroup([
          {
            idempotencyKey: `freeze_${target.id}_${Date.now()}`,
            userId: target.id,
            entryType: 'staff_freeze',
            bucket: 'available',
            deltaLamports: -amt,
            referenceType: 'account',
            referenceId: target.id,
            description: `Staff froze ${(amt / 1e9).toFixed(4)} SOL (${reason || 'Security review'})`,
            actorUserId: actor.id,
          },
          {
            idempotencyKey: `freeze_b_${target.id}_${Date.now()}`,
            userId: target.id,
            entryType: 'staff_freeze',
            bucket: 'frozen',
            deltaLamports: amt,
            referenceType: 'account',
            referenceId: target.id,
            description: `Moved to frozen bucket (${reason || 'Security review'})`,
            actorUserId: actor.id,
          },
        ]);
      }

      writeAuditLog({
        actorUserId: actor.id,
        actorRole: actor.role,
        action: 'staff_user_updated',
        entityType: 'user',
        entityId: target.id,
        summary: `Updated user ${target.username}: status=${status || target.status}, role=${role || target.role} (${reason || 'no note'})`,
      });
    });

    res.json({ ok: true });
  });

  // Resolve Fraud / Risk Flag
  app.post('/api/staff/risk-flags/:id/decision', requireRole(['moderator', 'finance', 'owner']), (req, res) => {
    const actor = req.authUser!;
    const { status, decisionNote } = req.body || {};
    if (!['Investigating', 'Cleared', 'Confirmed'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    db.prepare(`
      UPDATE risk_flags
      SET status = ?, decision_note = ?, reviewed_by_user_id = ?, reviewed_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
      WHERE id = ?
    `).run(status, String(decisionNote || '').trim(), actor.id, req.params.id);

    writeAuditLog({
      actorUserId: actor.id,
      actorRole: actor.role,
      action: 'risk_flag_reviewed',
      entityType: 'risk_flag',
      entityId: req.params.id,
      summary: `Risk flag ${req.params.id} marked ${status}: ${decisionNote || ''}`,
    });
    res.json({ ok: true });
  });

  // Searchable Audit Log
  app.get('/api/staff/audit-logs', requireRole(['moderator', 'finance', 'owner']), (req, res) => {
    const q = String(req.query.q || '').trim();
    const rows = q
      ? db
          .prepare(`
            SELECT a.*, u.username as actor_username
            FROM audit_logs a LEFT JOIN users u ON u.id = a.actor_user_id
            WHERE a.action LIKE ? OR a.summary LIKE ? OR a.entity_id LIKE ?
            ORDER BY a.created_at DESC LIMIT 120
          `)
          .all(`%${q}%`, `%${q}%`, `%${q}%`)
      : db
          .prepare(`
            SELECT a.*, u.username as actor_username
            FROM audit_logs a LEFT JOIN users u ON u.id = a.actor_user_id
            ORDER BY a.created_at DESC LIMIT 120
          `)
          .all();
    res.json({ logs: rows });
  });

  // Publish new policy / rules version (Owner / Mod)
  app.post('/api/staff/policies', requireRole(['moderator', 'owner']), (req, res) => {
    const { policyType, version, title, contentMd } = req.body || {};
    if (!['terms', 'privacy', 'competition_rules'].includes(policyType) || !version || !title || !contentMd) {
      return res.status(400).json({ error: 'policyType, version, title, and contentMd are required' });
    }
    runImmediateTransaction(() => {
      db.prepare('UPDATE policy_versions SET is_active = 0 WHERE policy_type = ?').run(policyType);
      db.prepare(`
        INSERT INTO policy_versions (id, policy_type, version, title, content_md, is_active, published_by_user_id)
        VALUES (?, ?, ?, ?, ?, 1, ?)
      `).run(newId('pol'), policyType, version, title, contentMd, req.authUser!.id);
    });
    res.status(201).json({ ok: true });
  });

  // =========================================================================
  // 3. SHOP, TEAMS, REWARDS, RULES, STREAMS & SUPPORT
  // =========================================================================

  app.get('/api/shop', (req, res) => {
    const items = db.prepare('SELECT * FROM shop_items WHERE is_active = 1 ORDER BY is_featured DESC, price_lamports DESC').all();
    const inventory = req.authUser
      ? db.prepare('SELECT item_id, equipped, acquired_at FROM user_inventory WHERE user_id = ?').all(req.authUser.id)
      : [];
    res.json({ items, inventory });
  });

  app.post('/api/shop/:itemId/buy', requireAuth, (req, res) => {
    const user = req.authUser!;
    try {
      runImmediateTransaction(() => {
        const item = db.prepare('SELECT * FROM shop_items WHERE id = ? AND is_active = 1').get(req.params.itemId) as {
          id: string;
          name: string;
          price_lamports: number;
          category: string;
          preview_value: string;
        } | undefined;
        if (!item) throw new Error('Shop item not found');

        const owned = db.prepare('SELECT id FROM user_inventory WHERE user_id = ? AND item_id = ?').get(user.id, item.id);
        if (owned) throw new Error('Item already owned');

        if (item.price_lamports > 0) {
          applyLedgerGroup([
            {
              idempotencyKey: `shop_buy_${user.id}_${item.id}`,
              userId: user.id,
              entryType: 'shop_purchase',
              bucket: 'available',
              deltaLamports: -item.price_lamports,
              referenceType: 'shop_item',
              referenceId: item.id,
              description: `Purchased cosmetic: ${item.name}`,
              actorUserId: user.id,
            },
          ]);
        }

        db.prepare('INSERT INTO user_inventory (id, user_id, item_id, purchased_lamports, equipped) VALUES (?, ?, ?, ?, 0)').run(
          newId('inv'),
          user.id,
          item.id,
          item.price_lamports
        );
      });
      res.json({ ok: true });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Purchase failed' });
    }
  });

  app.post('/api/shop/:itemId/equip', requireAuth, (req, res) => {
    const user = req.authUser!;
    const item = db.prepare('SELECT * FROM shop_items WHERE id = ?').get(req.params.itemId) as {
      id: string;
      category: string;
      preview_value: string;
      portrait_index: number | null;
    } | undefined;
    if (!item) return res.status(404).json({ error: 'Item not found' });

    const owned = runImmediateTransaction(() => {
      const inv = db.prepare('SELECT id,equipped FROM user_inventory WHERE user_id=? AND item_id=?')
        .get(user.id,item.id) as {id:string;equipped:number}|undefined;
      if (!inv) return false;

      if (item.portrait_index !== null) {
        db.prepare(`UPDATE user_inventory SET equipped=0
          WHERE user_id=? AND item_id IN (SELECT id FROM shop_items WHERE portrait_index IS NOT NULL)`).run(user.id);
      } else {
        db.prepare(`UPDATE user_inventory SET equipped=0
          WHERE user_id=? AND item_id IN (SELECT id FROM shop_items WHERE category=? AND portrait_index IS NULL)`).run(user.id,item.category);
      }

      const nextEquipped = inv.equipped ? 0 : 1;
      db.prepare('UPDATE user_inventory SET equipped = ? WHERE id = ?').run(nextEquipped, inv.id);

      if (item.portrait_index !== null) {
        db.prepare('UPDATE users SET profile_portrait=? WHERE id=?').run(nextEquipped ? item.portrait_index : null,user.id);
      } else if (item.category === 'Title') {
        db.prepare('UPDATE users SET active_title = ? WHERE id = ?').run(nextEquipped ? item.preview_value : '', user.id);
      } else if (item.category === 'Avatar Border') {
        db.prepare('UPDATE users SET active_border = ? WHERE id = ?').run(nextEquipped ? item.preview_value : 'default', user.id);
      }
      return true;
    });
    if (!owned) return res.status(400).json({error:'You do not own this item'});
    res.json({ ok: true });
  });

  function queueTeamInvite(team: {id: string; name: string}, inviter: {id: string; username: string}, targetId: string) {
    const inviteId = newId('tinv');
    db.prepare("INSERT INTO team_invites (id, team_id, invited_user_id, invited_by_user_id, status) VALUES (?, ?, ?, ?, 'pending')")
      .run(inviteId, team.id, targetId, inviter.id);
    notifyUser({ userId: targetId, category: 'team', title: 'Team Roster Invite',
      body: `${inviter.username} invited you to join ${team.name}.`, linkUrl: '/teams' });
    return inviteId;
  }

  // Teams & Invites
  app.get('/api/teams', requireAuth, (req, res) => {
    const user = req.authUser!;
    const teams = db
      .prepare(`
        SELECT t.*, tm.role as my_role
        FROM teams t
        JOIN team_members tm ON tm.team_id = t.id
        WHERE tm.user_id = ? AND tm.status = 'active'
      `)
      .all(user.id) as Array<{ id: string }>;

    const fullTeams = teams.map((t) => {
      const members = db
        .prepare(`
          SELECT u.id, u.username, u.display_name, u.epic_display_name, tm.role
          FROM team_members tm JOIN users u ON u.id = tm.user_id
          WHERE tm.team_id = ? AND tm.status = 'active'
        `)
        .all(t.id);
      return { ...t, members };
    });

    const invites = db
      .prepare(`
        SELECT ti.*, t.name as team_name, t.tag as team_tag, t.region, u.username as invited_by_username
        FROM team_invites ti
        JOIN teams t ON t.id = ti.team_id
        JOIN users u ON u.id = ti.invited_by_user_id
        WHERE ti.invited_user_id = ? AND ti.status = 'pending'
      `)
      .all(user.id);

    res.json({ teams: fullTeams, invites });
  });

  app.post('/api/teams', requireAuth, (req, res) => {
    const user = req.authUser!;
    const { name, tag, region = user.competitive_region, maxPlayers = 4, icon = 'shield',
      iconColour = 'gold', inviteUsernames = [] } = req.body || {};
    const teamName = typeof name === 'string' ? name.trim() : '';
    if (teamName.length < 2 || teamName.length > 25) return res.status(400).json({error: 'Use a team name of 2–25 characters.'});
    if (![2, 3, 4].includes(maxPlayers) || !teamIcons.includes(icon) || !Object.hasOwn(teamColours, iconColour)) {
      return res.status(400).json({error: 'Choose a valid team size, icon, and colour.'});
    }
    if (!Array.isArray(inviteUsernames) || inviteUsernames.length >= maxPlayers ||
        inviteUsernames.some(name => typeof name !== 'string' || name.length > 24)) {
      return res.status(400).json({error: 'Choose a player for each available team slot.'});
    }
    const playerByName = db.prepare("SELECT id FROM users WHERE username = ? COLLATE NOCASE AND status = 'active'");
    const inviteIds = new Set<string>();
    for (const name of inviteUsernames) {
      const target = playerByName.get(name.trim()) as {id:string} | undefined;
      if (!target || target.id === user.id) return res.status(400).json({error: 'Invite an active player by username.'});
      inviteIds.add(target.id);
    }
    const teamId = newId('team');
    try {
      runImmediateTransaction(() => {
        db.prepare(`INSERT INTO teams (id, name, tag, region, captain_user_id, is_demo, max_players, icon, icon_colour)
          VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?)`).run(teamId, teamName,
          String(tag || teamName).trim().toUpperCase().slice(0, 4),
          ['NAE', 'NAC', 'NAW', 'EU'].includes(region) ? region : 'NAE', user.id, maxPlayers, icon, iconColour);
        db.prepare("INSERT INTO team_members (id, team_id, user_id, role, status) VALUES (?, ?, ?, 'captain', 'active')")
          .run(newId('tmem'), teamId, user.id);
        if (iconColour !== 'gold') {
          const network = db.prepare('SELECT network_mode FROM wallet_config WHERE id = 1').pluck().get();
          if (network !== 'demo') throw new Error('Custom team colours are available with simulated SOL.');
          applyLedgerGroup([{ idempotencyKey: 'team-colour:' + teamId, userId: user.id, entryType: 'shop_purchase',
            bucket: 'available', deltaLamports: -200_000_000, referenceType: 'team_colour', referenceId: teamId,
            network: 'demo', description: 'Custom team icon colour', actorUserId: user.id }]);
        }
        for (const targetId of inviteIds) queueTeamInvite({id:teamId, name:teamName}, user, targetId);
      });
      res.status(201).json({ teamId });
    } catch (error) {
      res.status(400).json({error: (error as Error).message});
    }
  });

  app.post('/api/teams/:id/invite', requireAuth, (req, res) => {
    const user = req.authUser!;
    const targetUsername = String(req.body?.username || '').trim();
    const target = db.prepare("SELECT id FROM users WHERE username = ? COLLATE NOCASE AND status = 'active'").get(targetUsername) as { id: string } | undefined;
    if (!target || target.id === user.id) return res.status(404).json({ error: 'Invite another active player by username.' });
    const team = db.prepare('SELECT id, name, captain_user_id, max_players FROM teams WHERE id = ?').get(req.params.id) as
      { id: string; name: string; captain_user_id: string; max_players: number } | undefined;
    if (!team || team.captain_user_id !== user.id) return res.status(403).json({ error: 'Only the team captain can send invites.' });
    const inviteId = runImmediateTransaction(() => {
      if (db.prepare(`SELECT 1 FROM team_members WHERE team_id = ? AND user_id = ? AND status = 'active'
          UNION ALL SELECT 1 FROM team_invites WHERE team_id = ? AND invited_user_id = ? AND status = 'pending'`)
          .get(team.id, target.id, team.id, target.id)) return null;
      if (Number(db.prepare(`SELECT (SELECT count(*) FROM team_members WHERE team_id = ? AND status = 'active') +
          (SELECT count(*) FROM team_invites WHERE team_id = ? AND status = 'pending')`).pluck().get(team.id, team.id)) >= team.max_players) return null;
      return queueTeamInvite(team, user, target.id);
    });
    if (!inviteId) return res.status(409).json({error: 'The team is full or this player already has a roster spot or invite.'});
    res.status(201).json({ inviteId });
  });

  app.post('/api/teams/invites/:inviteId/respond', requireAuth, (req, res) => {
    const user = req.authUser!;
    const accept = Boolean(req.body?.accept);
    const inv = db
      .prepare("SELECT * FROM team_invites WHERE id = ? AND invited_user_id = ? AND status = 'pending'")
      .get(req.params.inviteId, user.id) as { id: string; team_id: string } | undefined;
    if (!inv) return res.status(404).json({ error: 'Pending invite not found' });

    const responded = runImmediateTransaction(() => {
      if (accept && db.prepare(`SELECT 1 FROM teams t WHERE t.id = ?
          AND (SELECT count(*) FROM team_members WHERE team_id = t.id AND status = 'active') >= t.max_players`).get(inv.team_id)) return false;
      db.prepare("UPDATE team_invites SET status = ?, responded_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(
        accept ? 'accepted' : 'declined',
        inv.id
      );
      if (accept) {
        db.prepare(`
          INSERT INTO team_members (id, team_id, user_id, role, status)
          VALUES (?, ?, ?, 'starter', 'active')
          ON CONFLICT(team_id, user_id) DO UPDATE SET status = 'active'
        `).run(newId('tmem'), inv.team_id, user.id);
      }
      return true;
    });
    if (!responded) return res.status(409).json({error:'This team is full.'});
    res.json({ ok: true });
  });

  // Rewards (Daily check-in + milestone bonuses)
  app.get('/api/rewards', requireAuth, (req, res) => {
    const user = req.authUser!;
    const today = new Date().toISOString().slice(0, 10);
    const claims = db.prepare('SELECT * FROM rewards_claims WHERE user_id = ? ORDER BY created_at DESC LIMIT 20').all(user.id);
    const dailyClaimed = Boolean(
      db.prepare("SELECT 1 FROM rewards_claims WHERE user_id = ? AND reward_key = 'daily_checkin' AND claim_period = ?").get(user.id, today)
    );
    const firstWinClaimed = Boolean(
      db.prepare("SELECT 1 FROM rewards_claims WHERE user_id = ? AND reward_key = 'first_win_bonus'").get(user.id)
    );

    const referralCount = (db.prepare('SELECT COUNT(*) AS count FROM users WHERE referred_by_user_id=?').get(user.id) as {count:number}).count;
    const rewardsTotal = (db.prepare(`SELECT COALESCE(SUM(delta_lamports),0) AS total FROM ledger_entries
      WHERE user_id=? AND bucket='available' AND entry_type IN ('reward_bonus','referral_bonus') AND delta_lamports>0`).get(user.id) as {total:number}).total;
    const earnings = db.prepare(`
      WITH days(day, offset) AS (SELECT date('now','-6 days'),0 UNION ALL
        SELECT date(day,'+1 day'), offset+1 FROM days WHERE offset<6)
      SELECT day, (SELECT COALESCE(SUM(delta_lamports),0) FROM ledger_entries
        WHERE user_id=? AND bucket='available' AND entry_type IN ('reward_bonus','referral_bonus')
          AND delta_lamports>0 AND created_at<date(day,'+1 day')) AS lamports FROM days
    `).all(user.id);
    res.json({
      dailyClaimed,
      firstWinEligible: user.wins >= 1 && !firstWinClaimed,
      firstWinClaimed,
      referralCode: user.referral_code,
      referralCount,
      rewardsTotal,
      earnings,
      claims,
    });
  });

  app.post('/api/rewards/claim', requireAuth, (req, res) => {
    const user = req.authUser!;
    const { rewardKey } = req.body || {};
    const today = new Date().toISOString().slice(0, 10);

    try {
      let amount = 0;
      let label = '';
      let period = today;

      if (rewardKey === 'daily_checkin') {
        amount = 5_000_000; // 0.005 SOL Demo/Devnet reward
        label = 'Daily Arena Check-In';
      } else if (rewardKey === 'first_win_bonus') {
        if (user.wins < 1) throw new Error('Complete 1 win first to unlock this bonus');
        amount = 25_000_000; // 0.025 SOL
        label = 'First Victory Milestone';
        period = 'once';
      } else {
        throw new Error('Unknown reward key');
      }

      runImmediateTransaction(() => {
        const exists = db
          .prepare('SELECT id FROM rewards_claims WHERE user_id = ? AND reward_key = ? AND claim_period = ?')
          .get(user.id, rewardKey, period);
        if (exists) throw new Error('Reward already claimed for this period');

        db.prepare('INSERT INTO rewards_claims (id, user_id, reward_key, reward_label, amount_lamports, claim_period) VALUES (?, ?, ?, ?, ?, ?)').run(
          newId('rwc'),
          user.id,
          rewardKey,
          label,
          amount,
          period
        );

        applyLedgerGroup([
          {
            idempotencyKey: `reward_${user.id}_${rewardKey}_${period}`,
            userId: user.id,
            entryType: 'reward_bonus',
            bucket: 'available',
            deltaLamports: amount,
            referenceType: 'reward',
            referenceId: `${rewardKey}:${period}`,
            description: `Claimed reward: ${label}`,
            actorUserId: user.id,
          },
        ]);
      });

      res.json({ ok: true, amountLamports: amount });
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to claim reward' });
    }
  });

  // Live Streams (authorized Twitch channels only)
  app.get('/api/streams', (_req, res) => {
    const streams = db
      .prepare(`
        SELECT ts.*, u.username, u.display_name
        FROM twitch_streams ts
        JOIN users u ON u.id = ts.user_id
        WHERE ts.is_authorized = 1 AND ts.is_live = 1 AND u.is_demo = 0
        ORDER BY ts.viewer_count DESC
        LIMIT 12
      `)
      .all();
    res.json({ streams });
  });

  // Policies / Rules
  app.get('/api/policies', (_req, res) => {
    const active = db.prepare('SELECT * FROM policy_versions WHERE is_active = 1 ORDER BY policy_type ASC').all();
    const history = db.prepare('SELECT id, policy_type, version, title, created_at FROM policy_versions ORDER BY created_at DESC LIMIT 20').all();
    res.json({ active, history });
  });

  // Support Tickets
  app.get('/api/support/tickets', requireAuth, (req, res) => {
    const user = req.authUser!;
    const isStaff = ['moderator', 'finance', 'owner'].includes(user.role);
    const tickets = isStaff
      ? db.prepare('SELECT st.*, u.username FROM support_tickets st JOIN users u ON u.id = st.user_id ORDER BY st.created_at DESC').all()
      : db.prepare('SELECT * FROM support_tickets WHERE user_id = ? ORDER BY created_at DESC').all(user.id);
    res.json({ tickets });
  });

  app.post('/api/support/tickets', requireAuth, (req, res) => {
    const user = req.authUser!;
    const { category = 'General', subject, description } = req.body || {};
    if (!subject || !description) return res.status(400).json({ error: 'Subject and description are required' });
    const tid = newId('tkt');
    db.prepare('INSERT INTO support_tickets (id, user_id, category, subject, description, status) VALUES (?, ?, ?, ?, ?, ?)').run(
      tid,
      user.id,
      String(category).slice(0, 40),
      String(subject).slice(0, 120),
      String(description).slice(0, 2000),
      'Open'
    );
    res.status(201).json({ ticketId: tid });
  });

  app.post('/api/support/tickets/:id/status', requireRole(['moderator', 'finance', 'owner']), (req, res) => {
    const status = String(req.body?.status || 'Resolved');
    if (!['Open', 'In Progress', 'Resolved', 'Closed'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    db.prepare("UPDATE support_tickets SET status = ?, assigned_staff_id = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(
      status,
      req.authUser!.id,
      req.params.id
    );
    res.json({ ok: true });
  });

  // Global Platform Stats (real persisted totals for Homepage counters)
  app.get('/api/platform/stats', (_req, res) => {
    const players = (db.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number }).c;
    const matchesPlayed = (db.prepare("SELECT COUNT(*) as c FROM matches WHERE status = 'Complete'").get() as { c: number }).c;
    const openLobbies = (db.prepare("SELECT COUNT(*) as c FROM matches WHERE status = 'Waiting' AND is_private = 0").get() as { c: number }).c;
    const ongoingMatches = (db.prepare("SELECT COUNT(*) as c FROM matches WHERE status IN ('Ready', 'In Progress') AND is_private = 0").get() as { c: number }).c;
    const totalPaidLamports = (
      db
        .prepare("SELECT COALESCE(SUM(delta_lamports), 0) as s FROM ledger_entries WHERE entry_type IN ('match_win_payout', 'tournament_payout')")
        .get() as { s: number }
    ).s;
    const activeTournaments = (
      db.prepare("SELECT COUNT(*) as c FROM tournaments WHERE status IN ('Registration Open', 'Check-In', 'Live')").get() as { c: number }
    ).c;

    res.json({
      players,
      matchesPlayed,
      openLobbies,
      ongoingMatches,
      totalPaidLamports,
      activeTournaments,
    });
  });
}
