import { db, hashPassword, newId, hashSensitive } from './db.ts';
import { applyLedgerGroup } from './ledger.ts';
import { hostedDemo } from './hosting.ts';
import { randomBytes } from 'node:crypto';
import { Keypair } from '@solana/web3.js';

export const LAMPORTS_PER_SOL = 1_000_000_000;

let runtimeEphemeralTreasury: Keypair | null = null;

export async function getServerTreasuryPublicAddress(): Promise<string> {
  if (hostedDemo) return '11111111111111111111111111111111';
  if (process.env.SOLANA_TREASURY_ADDRESS) {
    return process.env.SOLANA_TREASURY_ADDRESS;
  }
  const kp = await getServerTreasuryKeypair();
  return kp ? kp.publicKey.toBase58() : '11111111111111111111111111111111';
}

export async function getServerTreasuryKeypair(): Promise<Keypair | null> {
  const secret = hostedDemo ? undefined : process.env.SOLANA_TREASURY_SECRET_KEY;
  if (secret) {
    try {
      const parsed = JSON.parse(secret) as number[];
      return await Keypair.fromSecretKey(Uint8Array.from(parsed));
    } catch {
      return null;
    }
  }
  if (!runtimeEphemeralTreasury) {
    runtimeEphemeralTreasury = await Keypair.generate();
  }
  return runtimeEphemeralTreasury;
}

export async function seedInitialData(): Promise<void> {
  const existingUserCount = (db.prepare('SELECT COUNT(*) as c FROM users').get() as { c: number }).c;
  const treasuryAddress = await getServerTreasuryPublicAddress();

  const networkMode = hostedDemo ? 'demo' : (process.env.SOLANA_NETWORK === 'mainnet' || process.env.SOLANA_NETWORK === 'devnet' || process.env.SOLANA_NETWORK === 'demo')
    ? process.env.SOLANA_NETWORK
    : 'devnet';

  db.prepare(`
    INSERT INTO wallet_config (id, network_mode, mainnet_enabled, paid_matches_enabled, fee_bps, min_withdrawal_lamports, treasury_address)
    VALUES (1, ?, 0, 1, 500, 10000000, ?)
    ON CONFLICT(id) DO UPDATE SET
      treasury_address = CASE WHEN wallet_config.treasury_address = '' THEN excluded.treasury_address ELSE wallet_config.treasury_address END
  `).run(networkMode, treasuryAddress);

  db.prepare(`
    INSERT OR IGNORE INTO solana_watcher_cursor (network, last_signature, last_slot)
    VALUES ('devnet', NULL, 0), ('demo', NULL, 0), ('mainnet', NULL, 0)
  `).run();

  if (existingUserCount > 0) return;

  const tx = db.transaction(() => {
    // 1. Policy Versions
    const policies = [
      {
        id: 'pol_privacy_v1',
        type: 'privacy',
        version: 'v2.0',
        title: 'SFT Privacy & Security Policy',
        content: 'IP hashes, device identifiers, and linked account histories are retained in restricted staff audit storage exclusively for anti-fraud, chargeback/dispute review, and security compliance.'
      },
      {
        id: 'pol_rules_v1',
        type: 'competition_rules',
        version: 'v3.0',
        title: 'Competitive Match & Tournament Rules',
        content: 'Matches must be played on the designated Creative map code using approved tournament loadouts. Both captains report final scores within 15 minutes of match completion.'
      }
    ];
    for (const p of policies) {
      db.prepare(`
        INSERT INTO policy_versions (id, policy_type, version, title, content_md, is_active)
        VALUES (?, ?, ?, ?, ?, 1)
      `).run(p.id, p.type, p.version, p.title, p.content);
    }

    // 2. Default match islands
    const maps = [
      {
        id: 'map_d1_zw',
        name: 'PRO ZONE WARS (1V1 TO 4V4)',
        mode: 'Zone Wars',
        code: '3537-4087-0888',
        creator: 'chap',
        loadout: 'Blue AR, Gold Pump, Blue SMG, 1 Slurpfish, 3 Mini Shields',
        rules: [
          'Use map code 3537-4087-0888 unless both captains agree in Match Chat before Ready Up.',
          'Boxfight / Competitive loot pool only; unapproved mythics forfeit the round.',
          'First to target rounds wins (e.g., First to 5, win by 2 when enabled).',
          'Host server region must match the scheduled match server region.'
        ]
      },
      {
        id: 'map_d1_bf',
        name: '1v1 Build Fight [Rezon]',
        mode: 'Build Fights',
        code: '7835-3901-1999',
        creator: 'heavyblue',
        loadout: 'Gold Pump / Sharp Tooth, Scar, Grappler (optional per chat), 200 HP',
        rules: [
          'Use map code 7835-3901-1999 with standard SFT Build Fight settings.',
          'No pre-aiming or shooting before countdown finishes after barrier drop.',
          'Max height limit resets only when both players drop and agree in chat.',
          'Proof clips must show Epic display name and round scoreboard clearly.'
        ]
      },
      {
        id: 'map_box_clix',
        name: 'PRO BOX FIGHTS (1V1 TO 4V4)',
        mode: 'Box Fights',
        code: '2355-0939-8965',
        creator: 'chap',
        loadout: 'Gold SPAS Pump, Blue Assault Rifle, 1 Slurpfish, 2 Mini Shields',
        rules: [
          'Standard 3x3 enclosed box fight arena, zero fall damage.',
          'Breaking spawn barriers early or exploiting out of bounds forfeits the round.',
          'Report round count accurately immediately after the final elimination.'
        ]
      },
      {
        id: 'map_real_finest',
        name: 'PRO REALISTICS (1v1 to 4v4)',
        mode: 'Realistics',
        code: '9520-0654-8075',
        creator: 'chap',
        loadout: 'Competitive BR Loot Pool, Full Mats, Storm Surge Active',
        rules: [
          'Standard realistic terrain POI rotations across 5 randomized zones.',
          'No intentional stall above max build height after storm closes.',
          'Disconnects after first elimination count as active round losses.'
        ]
      },
      {
        id: 'map_piece_ctrl',
        name: 'Piece Control 1v1 🎯',
        mode: 'Piece Control',
        code: '8298-6891-9930',
        creator: 'bullseye',
        loadout: 'Hammer Pump, Striker AR, 2x Big Pots',
        rules: [
          'Tight piece-control tunnel grids; reset builds only between rounds.',
          'Record full match replay or medal clip in case of ping/rule dispute.'
        ]
      },
      {
        id: 'map_zero_build',
        name: 'SFT Zero Build Showdown',
        mode: 'Zero Build',
        code: '4412-8820-9301',
        creator: 'SFT Arena',
        loadout: 'Gatekeeper Shotgun, Warforged AR, Shockwave Grenades, Overshield 50',
        rules: [
          'Overshield enabled; no building structures allowed.',
          'Port-a-Bunker usage restricted to 2 per round.'
        ]
      }
    ];
    for (const m of maps) {
      db.prepare(`
        INSERT INTO maps (id, name, mode, code, creator, loadout_summary, rules_json, is_featured)
        VALUES (?, ?, ?, ?, ?, ?, ?, 1)
      `).run(m.id, m.name, m.mode, m.code, m.creator, m.loadout, JSON.stringify(m.rules));
    }

    // 3. Shop Items
    const shopItems = [
      { id: 'shop_title_highground', name: 'Highground King', desc: 'Golden display title shown beneath your IGN in match rooms & leaderboard.', category: 'Title', rarity: 'Mythic', price: 250000000, preview: 'Highground King', featured: 1 },
      { id: 'shop_title_piece', name: 'Piece Control Demon', desc: 'Crimson tactical title for aggressive box fighters.', category: 'Title', rarity: 'Epic', price: 150000000, preview: 'Piece Control Demon', featured: 1 },
      { id: 'shop_title_sol_shark', name: 'Solana Shark', desc: 'Verified high-stakes competitor flair.', category: 'Title', rarity: 'Rare', price: 100000000, preview: 'Solana Shark', featured: 1 },
      { id: 'shop_title_zero_ping', name: '0 Ping Warrior', desc: 'Clean cyan competitive title.', category: 'Title', rarity: 'Common', price: 50000000, preview: '0 Ping Warrior', featured: 0 },
      { id: 'shop_border_sol_gold', name: 'Solana Gold Crown', desc: 'Radiant gold-amber avatar border ring.', category: 'Avatar Border', rarity: 'Mythic', price: 300000000, preview: 'border-gold', featured: 1 },
      { id: 'shop_border_violet', name: 'Storm Violet Pulse', desc: 'Electric purple border seen in championship finals.', category: 'Avatar Border', rarity: 'Epic', price: 180000000, preview: 'border-violet', featured: 0 },
      { id: 'shop_border_emerald', name: 'Emerald Victor', desc: 'Crisp emerald tournament winner border.', category: 'Avatar Border', rarity: 'Rare', price: 100000000, preview: 'border-emerald', featured: 0 },
      { id: 'shop_badge_founder', name: 'SFT Genesis Badge', desc: 'Limited Season 1 competitor insignia.', category: 'Badge', rarity: 'Epic', price: 120000000, preview: 'badge-genesis', featured: 0 }
    ];
    for (const s of shopItems) {
      db.prepare(`
        INSERT INTO shop_items (id, name, description, category, rarity, price_lamports, preview_value, is_featured, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
      `).run(s.id, s.name, s.desc, s.category, s.rarity, s.price, s.preview, s.featured);
    }

    // 4. Demo & Staff Accounts (explicitly labeled is_demo = 1, known demo password for QA/testing)
    const demoPassHash = hashPassword((!hostedDemo && process.env.SFT_LOCAL_DEMO_PASSWORD) || randomBytes(32).toString('hex'));
    const nowIso = new Date().toISOString();
    const daysAgoIso = (days: number) => new Date(Date.now() - days * 86400 * 1000).toISOString();

    const users = [
      {
        id: 'usr_owner_demo',
        username: 'ivvy',
        display_name: 'ivvy',
        email: 'owner@solanafortnitetokens.com',
        role: 'owner',
        region: 'NAC',
        country: 'US',
        epic_name: 'ivvyXX',
        epic_id: 'epic_ivvy_9910',
        title: 'Highground King',
        border: 'border-gold',
        wins: 142,
        losses: 29,
        elo: 2140,
        xp: 18400,
        bal: 25_000_000_000, // 25 SOL (Demo)
        source: 'founder',
        createdAt: daysAgoIso(28),
        twitch: 'ivvy_live'
      },
      {
        id: 'usr_mod_demo',
        username: 'KovaMod',
        display_name: 'KovaMod',
        email: 'mod@solanafortnitetokens.com',
        role: 'moderator',
        region: 'NAE',
        country: 'US',
        epic_name: 'KovaFN',
        epic_id: 'epic_kova_4411',
        title: 'Solana Shark',
        border: 'border-violet',
        wins: 64,
        losses: 21,
        elo: 1680,
        xp: 9200,
        bal: 4_500_000_000,
        source: 'staff_invite',
        createdAt: daysAgoIso(20),
        twitch: null
      },
      {
        id: 'usr_fin_demo',
        username: 'LedgerOps',
        display_name: 'LedgerOps',
        email: 'finance@solanafortnitetokens.com',
        role: 'finance',
        region: 'NAE',
        country: 'CA',
        epic_name: 'LedgerFN',
        epic_id: 'epic_ledger_8820',
        title: '',
        border: 'default',
        wins: 18,
        losses: 9,
        elo: 1210,
        xp: 3100,
        bal: 8_000_000_000,
        source: 'staff_invite',
        createdAt: daysAgoIso(18),
        twitch: null
      },
      {
        id: 'usr_player1_demo',
        username: 'VortexFN',
        display_name: 'VortexFN',
        email: 'vortex@solanafortnitetokens.com',
        role: 'player',
        region: 'NAE',
        country: 'US',
        epic_name: 'TTV_VortexFN',
        epic_id: 'epic_vortex_2219',
        title: 'Piece Control Demon',
        border: 'border-violet',
        wins: 118,
        losses: 31,
        elo: 1985,
        xp: 14900,
        bal: 6_250_000_000,
        source: 'twitch',
        createdAt: daysAgoIso(14),
        twitch: 'vortexfn_tv'
      },
      {
        id: 'usr_player2_demo',
        username: 'Sloocwtw07',
        display_name: 'Sloocwtw07',
        email: 'slooc@solanafortnitetokens.com',
        role: 'player',
        region: 'NAC',
        country: 'US',
        epic_name: 'Sloocwtw07',
        epic_id: 'epic_slooc_7712',
        title: '0 Ping Warrior',
        border: 'border-emerald',
        wins: 96,
        losses: 38,
        elo: 1875,
        xp: 12200,
        bal: 5_400_000_000,
        source: 'referral',
        createdAt: daysAgoIso(12),
        twitch: 'slooc_fn'
      },
      {
        id: 'usr_player3_demo',
        username: 'ClixCloneEU',
        display_name: 'ClixCloneEU',
        email: 'clixclone@solanafortnitetokens.com',
        role: 'player',
        region: 'EU',
        country: 'GB',
        epic_name: 'ClixClone_EU',
        epic_id: 'epic_clix_5531',
        title: '',
        border: 'default',
        wins: 81,
        losses: 40,
        elo: 1740,
        xp: 9800,
        bal: 3_150_000_000,
        source: 'discord',
        createdAt: daysAgoIso(7),
        twitch: null
      },
      {
        id: 'usr_player4_demo',
        username: 'WestCoastZex',
        display_name: 'WestCoastZex',
        email: 'zex@solanafortnitetokens.com',
        role: 'player',
        region: 'NAW',
        country: 'US',
        epic_name: 'Zex_NAW',
        epic_id: 'epic_zex_6620',
        title: '',
        border: 'default',
        wins: 54,
        losses: 27,
        elo: 1590,
        xp: 7400,
        bal: 2_800_000_000,
        source: 'tiktok',
        createdAt: daysAgoIso(3),
        twitch: null
      }
    ];

    for (const u of users) {
      db.prepare(`
        INSERT INTO users (
          id, username, display_name, email, email_verified, phone_verified, password_hash, role,
          country, competitive_region, age_verified, age_verification_ref, epic_display_name, epic_account_id,
          status, referral_code, acquisition_source, risk_score, twitch_channel, twitch_authorized,
          active_title, active_border, payout_address, wins, losses, elo, xp, is_demo, created_at
        ) VALUES (?, ?, ?, ?, 1, 1, ?, ?, ?, ?, 1, 'demo_kyc_18plus', ?, ?, 'active', ?, ?, 8, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
      `).run(
        u.id, u.username, u.display_name, u.email, demoPassHash, u.role,
        u.country, u.region, u.epic_name, u.epic_id,
        `SFT-${u.username.toUpperCase()}`, u.source, u.twitch, u.twitch ? 1 : 0,
        u.title, u.border, '', u.wins, u.losses, u.elo, u.xp, u.createdAt
      );

      db.prepare(`
        INSERT INTO user_balances (user_id, available_lamports, reserved_lamports, frozen_lamports)
        VALUES (?, ?, 0, 0)
      `).run(u.id, u.bal);

      // Initial demo deposit ledger entry
      db.prepare(`
        INSERT INTO ledger_entries (
          id, tx_group_id, idempotency_key, user_id, entry_type, bucket, delta_lamports, balance_after_lamports,
          reference_type, reference_id, network, description, actor_user_id, created_at
        ) VALUES (?, ?, ?, ?, 'deposit_credit', 'available', ?, ?, 'demo_seed', ?, 'demo', 'Demo account initial SOL seed', ?, ?)
      `).run(
        newId('led'), newId('grp'), `seed_bal_${u.id}`, u.id, u.bal, u.bal, u.id, u.id, u.createdAt
      );

      // Policy acceptances
      for (const p of policies) {
        db.prepare(`
          INSERT INTO policy_acceptances (id, user_id, policy_type, policy_version, accepted_at, ip_hash)
          VALUES (?, ?, ?, ?, ?, ?)
        `).run(newId('pac'), u.id, p.type, p.version, u.createdAt, hashSensitive('127.0.0.1'));
      }

      // Sample session telemetry for analytics
      db.prepare(`
        INSERT INTO analytics_sessions (id, user_id, duration_seconds, started_at, ended_at)
        VALUES (?, ?, ?, ?, ?)
      `).run(newId('ses'), u.id, 1850 + u.wins * 12, daysAgoIso(1), nowIso);
    }

    // Equip starter shop item for owner
    db.prepare(`
      INSERT INTO user_inventory (id, user_id, item_id, purchased_lamports, equipped)
      VALUES (?, 'usr_owner_demo', 'shop_title_highground', 250000000, 1),
             (?, 'usr_owner_demo', 'shop_border_sol_gold', 300000000, 1),
             (?, 'usr_player1_demo', 'shop_title_piece', 150000000, 1)
    `).run(newId('inv'), newId('inv'), newId('inv'));

    // 5. Teams
    db.prepare(`
      INSERT INTO teams (id, name, tag, region, captain_user_id, is_demo)
      VALUES ('team_d1_duos', 'SFT Solana Duo', 'SFT', 'NAC', 'usr_owner_demo', 1),
             ('team_na_clutch', 'Clutch Mechanics', 'CLM', 'NAE', 'usr_player1_demo', 1)
    `).run();

    db.prepare(`
      INSERT INTO team_members (id, team_id, user_id, role, status)
      VALUES (?, 'team_d1_duos', 'usr_owner_demo', 'captain', 'active'),
             (?, 'team_d1_duos', 'usr_player2_demo', 'starter', 'active'),
             (?, 'team_na_clutch', 'usr_player1_demo', 'captain', 'active'),
             (?, 'team_na_clutch', 'usr_mod_demo', 'starter', 'active')
    `).run(newId('tmem'), newId('tmem'), newId('tmem'), newId('tmem'));

    // 6. Demo Live Streams (authorized Twitch channels)
    db.prepare(`
      INSERT INTO twitch_streams (id, user_id, channel_name, stream_title, game_mode, viewer_count, is_live, is_authorized, thumbnail_accent)
      VALUES ('str_1', 'usr_owner_demo', 'ivvy_live', 'SFT 1v1 Zone Wars Tokens | NAC', 'Zone Wars', 184, 1, 1, '#6d4aff'),
             ('str_2', 'usr_player1_demo', 'vortexfn_tv', '2v2 Boxfight Wagers + Tournaments', 'Box Fights', 129, 1, 1, '#22c55e'),
             ('str_3', 'usr_player2_demo', 'slooc_fn', 'Build Fights Grinding', 'Build Fights', 74, 1, 1, '#eab308')
    `).run();

    // 7. Demo Matches (covering Open, Ongoing, Ranked, and Complete states for rich UI & analytics)
    const demoMatches = [
      {
        id: 'm_demo_open_1',
        title: '1v1 Boxfight',
        priv: 0, ranked: 1, format: '1v1', mode: 'Box Fights', platform: 'All', region: 'NAW',
        serverRegion: 'NA-West (Oregon)', entry: 500_000_000, prize: 950_000_000, fee: 50_000_000,
        firstTo: 5, mapId: 'map_box_clix', mapCode: '2355-0939-8965', creator: 'usr_player4_demo',
        status: 'Waiting', scoreA: 0, scoreB: 0, winner: null, created: daysAgoIso(0.02)
      },
      {
        id: 'm_demo_open_2',
        title: '1v1 Zone Wars',
        priv: 0, ranked: 1, format: '1v1', mode: 'Zone Wars', platform: 'All', region: 'NAC',
        serverRegion: 'NA-Central (Dallas)', entry: 1_000_000_000, prize: 1_900_000_000, fee: 100_000_000,
        firstTo: 5, mapId: 'map_d1_zw', mapCode: '3537-4087-0888', creator: 'usr_player1_demo',
        status: 'Waiting', scoreA: 0, scoreB: 0, winner: null, created: daysAgoIso(0.03)
      },
      {
        id: 'm_demo_open_3',
        title: '1v1 Realistic',
        priv: 0, ranked: 0, format: '1v1', mode: 'Realistics', platform: 'PC', region: 'NAE',
        serverRegion: 'NA-East (Virginia)', entry: 250_000_000, prize: 475_000_000, fee: 25_000_000,
        firstTo: 5, mapId: 'map_real_finest', mapCode: '9520-0654-8075', creator: 'usr_player1_demo',
        status: 'Waiting', scoreA: 0, scoreB: 0, winner: null, created: daysAgoIso(0.04)
      },
      {
        id: 'm_demo_open_4',
        title: '1v1 Build Fights',
        priv: 0, ranked: 1, format: '1v1', mode: 'Build Fights', platform: 'All', region: 'EU',
        serverRegion: 'EU (Frankfurt)', entry: 500_000_000, prize: 950_000_000, fee: 50_000_000,
        firstTo: 7, mapId: 'map_d1_bf', mapCode: '7835-3901-1999', creator: 'usr_player3_demo',
        status: 'Waiting', scoreA: 0, scoreB: 0, winner: null, created: daysAgoIso(0.05)
      },
      {
        id: 'm_demo_live_1',
        title: '1v1 Piece Control',
        priv: 0, ranked: 1, format: '1v1', mode: 'Piece Control', platform: 'All', region: 'NAE',
        serverRegion: 'NA-East (Virginia)', entry: 500_000_000, prize: 950_000_000, fee: 50_000_000,
        firstTo: 5, mapId: 'map_piece_ctrl', mapCode: '8298-6891-9930', creator: 'usr_player1_demo',
        status: 'In Progress', scoreA: 3, scoreB: 2, winner: null, created: daysAgoIso(0.1)
      },
      {
        id: 'm_demo_complete_1',
        title: '1v1 Zone Wars',
        priv: 1, ranked: 1, format: '1v1', mode: 'Zone Wars', platform: 'All', region: 'NAC',
        serverRegion: 'NA-Central (Dallas)', entry: 2_850_000_000, prize: 5_420_000_000, fee: 280_000_000,
        firstTo: 5, mapId: 'map_d1_zw', mapCode: '3537-4087-0888', creator: 'usr_owner_demo',
        status: 'Complete', scoreA: 5, scoreB: 3, winner: 'A', created: daysAgoIso(1)
      }
    ];

    for (const dm of demoMatches) {
      db.prepare(`
        INSERT INTO matches (
          id, title, is_private, is_ranked, is_demo, format, mode, platform, region, game_server_region,
          stake_basis, entry_lamports, total_prize_lamports, platform_fee_lamports, first_to, win_by_two, movement_type,
          map_id, map_code, creator_user_id, lobby_code, status, winner_side, score_a, score_b,
          chat_open, started_at, completed_at, created_at
        ) VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?, 'per_player', ?, ?, ?, ?, ?, 'Creative', ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)
      `).run(
        dm.id, dm.title, dm.priv, dm.ranked, dm.format, dm.mode, dm.platform, dm.region, dm.serverRegion,
        dm.entry, dm.prize, dm.fee, dm.firstTo, Number(dm.status === 'Waiting'), dm.mapId, dm.mapCode, dm.creator,
        dm.status === 'In Progress' || dm.status === 'Complete' ? `SFT-${dm.id.slice(-4).toUpperCase()}` : '',
        dm.status, dm.winner, dm.scoreA, dm.scoreB,
        dm.status === 'In Progress' || dm.status === 'Complete' ? dm.created : null,
        dm.status === 'Complete' ? dm.created : null,
        dm.created
      );

      const creatorUser = users.find((u) => u.id === dm.creator)!;
      const participantId = newId('mp');
      const simulatedStake = networkMode === 'demo' && dm.status === 'Waiting' ? dm.entry : 0;
      if (simulatedStake > 0) {
        applyLedgerGroup([{
          idempotencyKey: `demo_lobby_stake_${participantId}`, userId: creatorUser.id, entryType: 'admin_adjustment',
          bucket: 'reserved', deltaLamports: simulatedStake, referenceType: 'match', referenceId: dm.id,
          network: 'demo', description: 'Backed simulated stake for seeded match',
        }]);
      }
      db.prepare(`
        INSERT INTO match_participants (
          id, match_id, team_side, user_id, username_snapshot, display_name_snapshot, epic_name_snapshot,
          active_title_snapshot, is_captain, ready_state, stake_reserved_lamports, joined_at
        ) VALUES (?, ?, 'A', ?, ?, ?, ?, ?, 1, ?, ?, ?)
      `).run(
        participantId, dm.id, creatorUser.id, creatorUser.username, creatorUser.display_name, creatorUser.epic_name,
        creatorUser.title, dm.status === 'Waiting' ? 0 : 1, simulatedStake, dm.created
      );

      db.prepare(`
        INSERT INTO match_events (id, match_id, event_type, actor_user_id, summary, created_at)
        VALUES (?, ?, 'match_created', ?, ?, ?)
      `).run(newId('mev'), dm.id, creatorUser.id, `${creatorUser.username} created the ${dm.format} ${dm.mode} room.`, dm.created);
    }

    // Add Team B to live and completed demo matches
    db.prepare(`
      INSERT INTO match_participants (
        id, match_id, team_side, user_id, username_snapshot, display_name_snapshot, epic_name_snapshot,
        active_title_snapshot, is_captain, ready_state, stake_reserved_lamports
      ) VALUES
        (?, 'm_demo_live_1', 'B', 'usr_player2_demo', 'Sloocwtw07', 'Sloocwtw07', 'Sloocwtw07', '0 Ping Warrior', 1, 1, 500000000),
        (?, 'm_demo_complete_1', 'B', 'usr_player2_demo', 'Sloocwtw07', 'Sloocwtw07', 'Sloocwtw07', '0 Ping Warrior', 1, 1, 0)
    `).run(newId('mp'), newId('mp'));

    // Demo match chat for m_demo_complete_1
    const chatSamples = [
      { id: newId('mch'), uid: 'usr_owner_demo', name: 'ivvy', role: 'owner', type: 'user', body: 'simple edit macro? queueing map 3537-4087-0888', t: daysAgoIso(1) },
      { id: newId('mch'), uid: 'usr_player2_demo', name: 'Sloocwtw07', role: 'player', type: 'user', body: 'ggs clean rounds', t: daysAgoIso(1) },
      { id: newId('mch'), uid: null, name: 'MATCH', role: 'system', type: 'system', body: "Match settled: ivvy's team won 5-3 (+5.4200 SOL credited).", t: daysAgoIso(1) }
    ];
    for (const c of chatSamples) {
      db.prepare(`
        INSERT INTO match_chat_messages (id, match_id, user_id, sender_name, sender_role, message_type, body, created_at)
        VALUES (?, 'm_demo_complete_1', ?, ?, ?, ?, ?, ?)
      `).run(c.id, c.uid, c.name, c.role, c.type, c.body, c.t);
    }

    // Completed match ledger settlement history for analytics metrics
    db.prepare(`
      INSERT INTO ledger_entries (
        id, tx_group_id, idempotency_key, user_id, entry_type, bucket, delta_lamports, balance_after_lamports,
        reference_type, reference_id, network, description, actor_user_id, created_at
      ) VALUES
        (?, 'grp_demo_win', 'demo_win_1', 'usr_owner_demo', 'match_win_payout', 'available', 5420000000, 25000000000, 'match', 'm_demo_complete_1', 'demo', 'Demo settled win payout', 'usr_mod_demo', ?),
        (?, 'grp_demo_win', 'demo_fee_1', 'usr_owner_demo', 'match_fee', 'available', -280000000, 25000000000, 'match', 'm_demo_complete_1', 'demo', 'Demo platform fee recorded', 'usr_mod_demo', ?)
    `).run(newId('led'), daysAgoIso(1), newId('led'), daysAgoIso(1));

    // 8. Demo Tournaments (matching visual reference Image 2)
    const hoursFromNow = (h: number) => new Date(Date.now() + h * 3600 * 1000).toISOString();
    const tournaments = [
      {
        id: 't_demo_1',
        title: 'SFT Solana Special - 2v2 Realistics [Demo]',
        subtitle: 'Free Entry Championship Bracket',
        mode: 'Realistics',
        format: '2v2',
        region: 'EU',
        entry: 0,
        prize: 5_000_000_000, // 5 SOL
        maxTeams: 64,
        accent: '#6d4aff',
        regOpens: hoursFromNow(-12),
        regCloses: hoursFromNow(22),
        checkinOpens: hoursFromNow(21),
        startsAt: hoursFromNow(24),
        status: 'Registration Open'
      },
      {
        id: 't_demo_2',
        title: 'Zone Wars Cup - 2v2 Invitational [Demo]',
        subtitle: 'Official Bracket',
        mode: 'Zone Wars',
        format: '2v2',
        region: 'NAC',
        entry: 0,
        prize: 5_000_000_000, // 5 SOL
        maxTeams: 64,
        accent: '#eab308',
        regOpens: hoursFromNow(-6),
        regCloses: hoursFromNow(28),
        checkinOpens: hoursFromNow(27),
        startsAt: hoursFromNow(30),
        status: 'Registration Open'
      },
      {
        id: 't_demo_3',
        title: '1v1 Build Fights Cup [Demo]',
        subtitle: 'Highground Open',
        mode: 'Build Fights',
        format: '1v1',
        region: 'NAE',
        entry: 250_000_000, // 0.25 SOL
        prize: 3_500_000_000,
        maxTeams: 32,
        accent: '#22c55e',
        regOpens: hoursFromNow(-48),
        regCloses: hoursFromNow(-2),
        checkinOpens: hoursFromNow(-1),
        startsAt: hoursFromNow(-0.5),
        status: 'Live'
      },
      {
        id: 't_demo_4',
        title: 'SFT Box Fight Zero Ping Classic [Demo]',
        subtitle: 'Completed Season Opener',
        mode: 'Box Fights',
        format: '1v1',
        region: 'NAW',
        entry: 0,
        prize: 2_000_000_000,
        maxTeams: 16,
        accent: '#3b82f6',
        regOpens: daysAgoIso(6),
        regCloses: daysAgoIso(5),
        checkinOpens: daysAgoIso(5),
        startsAt: daysAgoIso(5),
        status: 'Completed'
      }
    ];

    for (const t of tournaments) {
      db.prepare(`
        INSERT INTO tournaments (
          id, title, subtitle, is_demo, mode, format, region, platform, entry_lamports, prize_pool_lamports,
          max_teams, accent_color, registration_opens_at, registration_closes_at, checkin_opens_at, starts_at, status,
          rules_json, created_by_user_id
        ) VALUES (?, ?, ?, 1, ?, ?, ?, 'All', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'usr_owner_demo')
      `).run(
        t.id, t.title, t.subtitle, t.mode, t.format, t.region, t.entry, t.prize, t.maxTeams,
        t.accent, t.regOpens, t.regCloses, t.checkinOpens, t.startsAt, t.status,
        JSON.stringify([
          'Check-in opens 60 minutes before tournament start (server UTC).',
          'Teams failing to ready up within 10 minutes of bracket call are forfeited.',
          'All matches follow official SFT map codes and competitive loot pools.'
        ])
      );
    }

    // Seed some registrations into Demo Tournaments
    db.prepare(`
      INSERT INTO tournament_registrations (id, tournament_id, team_name, captain_user_id, seed, checked_in, status)
      VALUES
        ('treg_1', 't_demo_1', 'Clutch Mechanics', 'usr_player1_demo', 1, 1, 'Checked In'),
        ('treg_2', 't_demo_1', 'EU Kings', 'usr_player3_demo', 2, 0, 'Registered'),
        ('treg_3', 't_demo_2', 'SFT Solana Duo', 'usr_owner_demo', 1, 1, 'Checked In'),
        ('treg_4', 't_demo_3', 'VortexFN', 'usr_player1_demo', 1, 1, 'Checked In'),
        ('treg_5', 't_demo_3', 'Sloocwtw07', 'usr_player2_demo', 2, 1, 'Checked In')
    `).run();

    // Seed live bracket match for t_demo_3
    db.prepare(`
      INSERT INTO tournament_matches (id, tournament_id, round_number, match_slot, reg_a_id, reg_b_id, status)
      VALUES ('tm_demo_1', 't_demo_3', 1, 1, 'treg_4', 'treg_5', 'Ready')
    `).run();

    // Seed sample risk flag & support ticket for Staff Console
    db.prepare(`
      INSERT INTO risk_flags (id, user_id, flag_type, severity, details_json, status)
      VALUES (?, 'usr_player3_demo', 'repeated_opponents', 'medium', ?, 'Open')
    `).run(newId('rf'), JSON.stringify({ note: 'Played 4 consecutive demo sets against same opponent.', matchCount: 4 }));

    db.prepare(`
      INSERT INTO support_tickets (id, user_id, category, subject, description, status)
      VALUES (?, 'usr_player4_demo', 'Match Dispute', 'Ping spike check on West server [Demo]', 'Checking how NAW server selection appears in match room.', 'Open')
    `).run(newId('tkt'));
  });

  tx();
}
