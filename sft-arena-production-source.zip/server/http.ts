import express from 'express';
import { attachAuthUser, originCsrfGuard, registerAuthRoutes } from './auth.ts';
import { registerMatchRoutes } from './matches.ts';
import { registerTournamentRoutes } from './tournaments.ts';
import { registerWalletRoutes } from './solana.ts';
import { registerAnalyticsAndStaffRoutes } from './analytics.ts';

export function createApp() {
  const app = express();
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '2mb' }));
  app.use(originCsrfGuard);
  app.use(attachAuthUser);
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'solanafortnitetokens', timeUtc: new Date().toISOString() });
  });
  registerAuthRoutes(app);
  registerMatchRoutes(app);
  registerTournamentRoutes(app);
  registerWalletRoutes(app);
  registerAnalyticsAndStaffRoutes(app);
  app.use('/api', (_req, res) => res.status(404).json({ error: 'API endpoint not found' }));
  return app;
}
