import type { Express } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { db, EVIDENCE_DIR, newId, writeAuditLog, notifyUser } from './db.ts';
import { applyLedgerGroup, runImmediateTransaction } from './ledger.ts';
import { requireAuth, requireRole, type AuthUser } from './auth.ts';
import { hostedDemo } from './hosting.ts';
import { broadcastToMatch, broadcastGlobal } from './ws.ts';

const VALID_FORMATS = ['1v1', '2v2', '3v3', '4v4'] as const;
const VALID_MODES = ['Zone Wars', 'Realistics', 'Box Fights', 'Build Fights', 'Piece Control', 'Zero Build'] as const;
const VALID_REGIONS = ['NAE', 'NAC', 'NAW', 'EU'] as const;
const VALID_PLATFORMS = ['All', 'PC', 'Console'] as const;

const SERVER_REGION_MAP: Record<string, string> = {
  NAE: 'NA-East (Virginia)',
  NAC: 'NA-Central (Dallas)',
  NAW: 'NA-West (Oregon)',
  EU: 'EU (Frankfurt)',
};

function entryEligibilityError(user: AuthUser, network: string) {
  if (user.age_verified || (network === 'demo' && (user.age_attested_at || user.legacy_demo_match_eligible))) return null;
  return network === 'demo' ? 'Confirm that you are 18 or older in Settings to join simulated SOL matches.'
    : 'Verified 18+ eligibility is required for non-demo SOL matches.';
}

function teamSizeForFormat(format: string): number {
  return parseInt(format[0] || '1', 10) || 1;
}

const upload = multer({
  storage: hostedDemo ? multer.memoryStorage() : multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, EVIDENCE_DIR),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase().replace(/[^.a-z0-9]/g, '').slice(0, 8);
      cb(null, `${crypto.randomUUID()}${ext || '.bin'}`);
    },
  }),
  limits: { fileSize: (hostedDemo ? 3 : 15) * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ['image/png', 'image/jpeg', 'image/webp', 'video/mp4', 'video/webm', 'text/plain', 'application/pdf'];
    if (allowed.includes(file.mimetype)) return cb(null, true);
    cb(new Error('Unsupported evidence file type. Allowed: PNG, JPG, WEBP, MP4, WEBM, TXT, PDF.'));
  },
});

interface MatchRow {
  id: string;
  title: string;
  is_private: number;
  is_ranked: number;
  is_demo: number;
  format: string;
  mode: string;
  platform: string;
  region: string;
  game_server_region: string;
  stake_basis: 'per_player' | 'per_team';
  entry_lamports: number;
  total_prize_lamports: number;
  platform_fee_lamports: number;
  first_to: number;
  win_by_two: number;
  movement_type: string;
  map_id: string | null;
  map_code: string;
  creator_user_id: string;
  creator_team_id: string | null;
  lobby_code: string;
  status: 'Waiting' | 'Ready' | 'In Progress' | 'Disputed' | 'Complete' | 'Cancelled';
  winner_side: 'A' | 'B' | null;
  score_a: number;
  score_b: number;
  chat_open: number;
  cancelled_reason: string | null;
  started_at: string | null;
  completed_at: string | null;
  expires_at: string | null;
  created_at: string;
  updated_at: string;
}

interface ParticipantRow {
  id: string;
  match_id: string;
  team_side: 'A' | 'B';
  user_id: string;
  roster_id: string | null;
  username_snapshot: string;
  display_name_snapshot: string;
  epic_name_snapshot: string;
  active_title_snapshot: string;
  is_captain: number;
  ready_state: number;
  reported_winner_side: 'A' | 'B' | null;
  reported_score_a: number | null;
  reported_score_b: number | null;
  reported_at: string | null;
  stake_reserved_lamports: number;
  joined_at: string;
}

function startedControlsAllowed(match: MatchRow) {
  return match.entry_lamports === 0 || db.prepare('SELECT network_mode FROM wallet_config WHERE id=1').pluck().get() === 'demo';
}

function cancelVotes(matchId: string) {
  return db.prepare(`SELECT DISTINCT json_extract(metadata_json,'$.side') AS side FROM match_events
    WHERE match_id=? AND event_type='cancel_vote' AND rowid > COALESCE(
      (SELECT MAX(rowid) FROM match_events WHERE match_id=? AND event_type='staff_reset'),0)`)
    .all(matchId,matchId).map(row => (row as {side:string}).side);
}

function getFullMatchRoom(matchId: string, viewerUserId: string | null, viewerRole: string | null) {
  const match = db.prepare('SELECT * FROM matches WHERE id = ?').get(matchId) as MatchRow | undefined;
  if (!match) return null;

  const participants = db
    .prepare('SELECT * FROM match_participants WHERE match_id = ? ORDER BY team_side ASC, is_captain DESC, joined_at ASC')
    .all(matchId) as ParticipantRow[];

  const isStaff = Boolean(viewerRole && ['moderator', 'finance', 'owner'].includes(viewerRole));
  const isParticipant = Boolean(viewerUserId && participants.some((p) => p.user_id === viewerUserId));

  const isInvited = viewerUserId && db.prepare('SELECT 1 FROM match_invites WHERE match_id=? AND user_id=?').get(matchId,viewerUserId);
  if (match.is_private === 1 && !isStaff && !isParticipant && !isInvited) {
    return { forbidden: true as const };
  }

  const canReadRoomHistory = isParticipant || isStaff;
  const events = canReadRoomHistory ? db
    .prepare('SELECT id, event_type, actor_user_id, summary, metadata_json, created_at FROM match_events WHERE match_id = ? ORDER BY created_at ASC')
    .all(matchId) : [];

  const chat = canReadRoomHistory ? db
    .prepare('SELECT id, user_id, sender_name, sender_role, message_type, body, attachment_evidence_id, created_at FROM match_chat_messages WHERE match_id = ? ORDER BY created_at ASC')
    .all(matchId) : [];

  const map = match.map_id
    ? db.prepare('SELECT * FROM maps WHERE id = ?').get(match.map_id)
    : db.prepare('SELECT * FROM maps WHERE mode = ? LIMIT 1').get(match.mode);

  const revisions = canReadRoomHistory ? db
    .prepare(`
      SELECT r.*, u.username as actor_username
      FROM match_result_revisions r
      LEFT JOIN users u ON u.id = r.actor_user_id
      WHERE r.match_id = ?
      ORDER BY r.version_num ASC
    `)
    .all(matchId) : [];

  const disputes = canReadRoomHistory ? db
    .prepare(`
      SELECT d.*, u.username as opened_by_username, r.username as resolved_by_username
      FROM disputes d
      LEFT JOIN users u ON u.id = d.opened_by_user_id
      LEFT JOIN users r ON r.id = d.resolved_by_user_id
      WHERE d.match_id = ?
      ORDER BY d.created_at DESC
    `)
    .all(matchId) : [];

  const evidence =
    isParticipant || isStaff
      ? db
          .prepare(`
            SELECT e.id, e.match_id, e.dispute_id, e.uploader_user_id, e.original_filename, e.mime_type, e.size_bytes, e.note, e.created_at, u.username as uploader_username
            FROM evidence_files e
            JOIN users u ON u.id = e.uploader_user_id
            WHERE e.match_id = ?
            ORDER BY e.created_at DESC
          `)
          .all(matchId)
      : [];

  return {
    forbidden: false as const,
    match: canReadRoomHistory ? match : { ...match, lobby_code: '' },
    participants,
    events,
    chat,
    map,
    revisions,
    disputes,
    evidence,
    cancelVotes: canReadRoomHistory ? cancelVotes(matchId) : [],
    startedControlsAllowed: startedControlsAllowed(match),
    viewerPermissions: {
      isParticipant,
      isStaff,
      canUploadEvidence: Boolean(match.started_at) && (isParticipant || isStaff),
    },
  };
}

function appendSystemChatAndEvent(matchId: string, eventType: string, actorUserId: string | null, summary: string, metadata: Record<string, unknown> = {}) {
  db.prepare('INSERT INTO match_events (id, match_id, event_type, actor_user_id, summary, metadata_json) VALUES (?, ?, ?, ?, ?, ?)').run(
    newId('mev'),
    matchId,
    eventType,
    actorUserId,
    summary,
    JSON.stringify(metadata)
  );
  const chatId = newId('mch');
  db.prepare(`
    INSERT INTO match_chat_messages (id, match_id, user_id, sender_name, sender_role, message_type, body)
    VALUES (?, ?, NULL, 'MATCH', 'system', 'system', ?)
  `).run(chatId, matchId, summary);
}

function finalizeMatchSettlementInsideTx(params: {
  match: MatchRow;
  winnerSide: 'A' | 'B';
  scoreA: number;
  scoreB: number;
  actorUserId: string | null;
  reason: string;
  isOverride: boolean;
}) {
  const { match, winnerSide, scoreA, scoreB, actorUserId, reason, isOverride } = params;
  const participants = db
    .prepare('SELECT * FROM match_participants WHERE match_id = ?')
    .all(match.id) as ParticipantRow[];

  const winners = participants.filter((p) => p.team_side === winnerSide);
  const losers = participants.filter((p) => p.team_side !== winnerSide);
  if (winners.length === 0) throw new Error('Cannot settle match: winning side has no players');

  const txGroupId = newId('txg');
  let financialCorrection = 0;

  if (!isOverride) {
    // Release reserved stakes for all players
    const mutations = [];
    for (const p of participants) {
      if (p.stake_reserved_lamports > 0) {
        mutations.push({
          idempotencyKey: `match_rel_${match.id}_${p.user_id}`,
          userId: p.user_id,
          entryType: 'match_stake_release' as const,
          bucket: 'reserved' as const,
          deltaLamports: -p.stake_reserved_lamports,
          referenceType: 'match',
          referenceId: match.id,
          description: `Stake settled for match ${match.id}`,
          actorUserId,
        });
      }
    }

    // Pay prize split equally among winning team members
    if (match.total_prize_lamports > 0) {
      const share = Math.floor(match.total_prize_lamports / winners.length);
      const remainder = match.total_prize_lamports - share * winners.length;
      winners.forEach((w, idx) => {
        const credit = share + (idx === 0 ? remainder : 0);
        if (credit > 0) {
          mutations.push({
            idempotencyKey: `match_win_${match.id}_${w.user_id}_v1`,
            userId: w.user_id,
            entryType: 'match_win_payout' as const,
            bucket: 'available' as const,
            deltaLamports: credit,
            referenceType: 'match',
            referenceId: match.id,
            description: `Match victory payout (${match.title})`,
            actorUserId,
          });
        }
      });

      if (match.platform_fee_lamports > 0) {
        mutations.push({
          idempotencyKey: `match_fee_${match.id}_v1`,
          userId: winners[0].user_id,
          entryType: 'match_fee' as const,
          bucket: 'available' as const,
          deltaLamports: 0,
          referenceType: 'match',
          referenceId: match.id,
          description: `Platform fee retained: ${(match.platform_fee_lamports / 1_000_000_000).toFixed(4)} SOL`,
          actorUserId,
        });
      }
    }

    if (mutations.length > 0) {
      applyLedgerGroup(mutations, txGroupId);
    }

    db.prepare('UPDATE match_participants SET stake_reserved_lamports = 0 WHERE match_id = ?').run(match.id);

    // Update rankings / wins / losses
    for (const w of winners) {
      db.prepare('UPDATE users SET wins = wins + 1, elo = elo + ?, xp = xp + 120 WHERE id = ?').run(match.is_ranked ? 24 : 10, w.user_id);
    }
    for (const l of losers) {
      db.prepare('UPDATE users SET losses = losses + 1, elo = MAX(500, elo - ?), xp = xp + 35 WHERE id = ?').run(match.is_ranked ? 18 : 6, l.user_id);
    }
  } else {
    // Result Override on an already-complete match: compute revision version & reverse prior payout if winner changed
    const revCount = (db.prepare('SELECT COUNT(*) as c FROM match_result_revisions WHERE match_id = ?').get(match.id) as { c: number }).c;
    const nextVer = revCount + 1;
    const priorWinner = match.winner_side;

    if (priorWinner && priorWinner !== winnerSide && match.total_prize_lamports > 0) {
      const priorWinners = participants.filter((p) => p.team_side === priorWinner);
      const newWinners = winners;
      const priorShare = Math.floor(match.total_prize_lamports / priorWinners.length);
      const priorRem = match.total_prize_lamports - priorShare * priorWinners.length;
      const newShare = Math.floor(match.total_prize_lamports / newWinners.length);
      const newRem = match.total_prize_lamports - newShare * newWinners.length;

      const mutations = [];
      priorWinners.forEach((pw, idx) => {
        const revAmt = priorShare + (idx === 0 ? priorRem : 0);
        // Check balance; if withdrawn already, clamp available deduction and flag deficit
        const bal = db.prepare('SELECT available_lamports FROM user_balances WHERE user_id = ?').get(pw.user_id) as { available_lamports: number };
        const actualDeduct = Math.min(bal.available_lamports, revAmt);
        if (actualDeduct > 0) {
          mutations.push({
            idempotencyKey: `match_ovr_rev_${match.id}_${pw.user_id}_v${nextVer}`,
            userId: pw.user_id,
            entryType: 'match_override_adjustment' as const,
            bucket: 'available' as const,
            deltaLamports: -actualDeduct,
            referenceType: 'match_override',
            referenceId: match.id,
            description: `Result override clawback (v${nextVer}): ${reason}`,
            actorUserId,
          });
        }
      });

      newWinners.forEach((nw, idx) => {
        const payAmt = newShare + (idx === 0 ? newRem : 0);
        if (payAmt > 0) {
          mutations.push({
            idempotencyKey: `match_ovr_pay_${match.id}_${nw.user_id}_v${nextVer}`,
            userId: nw.user_id,
            entryType: 'match_override_adjustment' as const,
            bucket: 'available' as const,
            deltaLamports: payAmt,
            referenceType: 'match_override',
            referenceId: match.id,
            description: `Result override award (v${nextVer}): ${reason}`,
            actorUserId,
          });
        }
      });

      if (mutations.length > 0) {
        applyLedgerGroup(mutations, txGroupId);
      }
      financialCorrection = match.total_prize_lamports;

      for (const pw of priorWinners) {
        db.prepare('UPDATE users SET wins = MAX(0, wins - 1), losses = losses + 1, elo = MAX(500, elo - 24) WHERE id = ?').run(pw.user_id);
      }
      for (const nw of newWinners) {
        db.prepare('UPDATE users SET wins = wins + 1, losses = MAX(0, losses - 1), elo = elo + 24 WHERE id = ?').run(nw.user_id);
      }
    }

    db.prepare(`
      INSERT INTO match_result_revisions (
        id, match_id, version_num, prior_winner_side, prior_score_a, prior_score_b,
        new_winner_side, new_score_a, new_score_b, actor_user_id, reason, financial_correction_lamports, ledger_tx_group_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      newId('mrv'),
      match.id,
      nextVer,
      match.winner_side,
      match.score_a,
      match.score_b,
      winnerSide,
      scoreA,
      scoreB,
      actorUserId,
      reason,
      financialCorrection,
      txGroupId
    );
  }

  if (!isOverride) {
    // Also record v1 initial official result revision for full immutability
    db.prepare(`
      INSERT INTO match_result_revisions (
        id, match_id, version_num, prior_winner_side, prior_score_a, prior_score_b,
        new_winner_side, new_score_a, new_score_b, actor_user_id, reason, financial_correction_lamports, ledger_tx_group_id
      ) VALUES (?, ?, 1, NULL, 0, 0, ?, ?, ?, ?, ?, 0, ?)
    `).run(newId('mrv'), match.id, winnerSide, scoreA, scoreB, actorUserId, reason, txGroupId);
  }

  db.prepare(`
    UPDATE matches
    SET status = 'Complete', winner_side = ?, score_a = ?, score_b = ?,
        completed_at = COALESCE(completed_at, strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
        updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
    WHERE id = ?
  `).run(winnerSide, scoreA, scoreB, match.id);

  // Risk signal check: repeated opponent sets (>3 completed matches between same two captains in 24h)
  if (winners[0] && losers[0]) {
    const pairCount = (
      db
        .prepare(`
          SELECT COUNT(DISTINCT m.id) as c
          FROM matches m
          JOIN match_participants p1 ON p1.match_id = m.id AND p1.user_id = ?
          JOIN match_participants p2 ON p2.match_id = m.id AND p2.user_id = ?
          WHERE m.status = 'Complete' AND m.created_at >= datetime('now', '-24 hours')
        `)
        .get(winners[0].user_id, losers[0].user_id) as { c: number }
    ).c;
    if (pairCount >= 4) {
      db.prepare(`
        INSERT INTO risk_flags (id, user_id, flag_type, severity, details_json)
        VALUES (?, ?, 'repeated_opponents', 'medium', ?)
      `).run(newId('rf'), winners[0].user_id, JSON.stringify({ opponentUserId: losers[0].user_id, matchCount24h: pairCount, matchId: match.id }));
    }
  }
}

export function registerMatchRoutes(app: Express) {
  // List maps
  app.get('/api/maps', (_req, res) => {
    const maps = db.prepare('SELECT * FROM maps ORDER BY is_featured DESC, name ASC').all();
    res.json({ maps });
  });

  // List matches with filters & search
  app.get('/api/matches', (req, res) => {
    const tab = String(req.query.tab || 'open'); // open | ongoing | ranked | my | all
    const region = String(req.query.region || 'ALL');
    const mode = String(req.query.mode || 'ALL');
    const format = String(req.query.format || 'ALL');
    const platform = String(req.query.platform || 'ALL');
    const search = String(req.query.search || '').trim();
    const minFirstTo = req.query.firstTo ? Number(req.query.firstTo) : 0;

    const supportedRoom = "(mode <> 'Build Fights' OR format = '1v1')";
    const where: string[] = [];
    const params: unknown[] = [];

    if (tab === 'open') {
      where.push("m.status = 'Waiting' AND m.is_private = 0", supportedRoom);
    } else if (tab === 'ongoing') {
      where.push("m.status IN ('Ready', 'In Progress', 'Disputed') AND m.is_private = 0");
    } else if (tab === 'ranked') {
      where.push("m.is_ranked = 1 AND m.status != 'Cancelled' AND m.is_private = 0", `(m.status <> 'Waiting' OR ${supportedRoom})`);
    } else if (tab === 'my') {
      if (!req.authUser) return res.json({ matches: [], counts: { open: 0, ongoing: 0, ranked: 0 } });
      where.push('(EXISTS (SELECT 1 FROM match_participants mp WHERE mp.match_id=m.id AND mp.user_id=?) OR EXISTS (SELECT 1 FROM match_invites i WHERE i.match_id=m.id AND i.user_id=?))');
      params.push(req.authUser.id,req.authUser.id);
    } else {
      const isStaff = req.authUser && ['moderator', 'finance', 'owner'].includes(req.authUser.role);
      if (!isStaff) {
        where.push('(m.is_private = 0 OR EXISTS (SELECT 1 FROM match_participants mp WHERE mp.match_id = m.id AND mp.user_id = ?))');
        params.push(req.authUser?.id || '');
      }
    }

    if (region !== 'ALL' && region !== 'None') {
      where.push('m.region = ?');
      params.push(region);
    }
    if (mode !== 'ALL' && mode !== 'None') {
      where.push('m.mode = ?');
      params.push(mode);
    }
    if (format !== 'ALL' && format !== 'None') {
      where.push('m.format = ?');
      params.push(format);
    }
    if (platform !== 'ALL' && platform !== 'None') {
      where.push('m.platform = ?');
      params.push(platform);
    }
    if (minFirstTo > 0) {
      where.push('m.first_to = ?');
      params.push(minFirstTo);
    }
    if (search) {
      where.push('(m.title LIKE ? OR m.id LIKE ? OR EXISTS (SELECT 1 FROM match_participants mp WHERE mp.match_id = m.id AND mp.username_snapshot LIKE ?))');
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    const sql = `
      SELECT m.*,
        u.username as creator_username,
        u.epic_display_name as creator_epic_name
      FROM matches m
      JOIN users u ON u.id = m.creator_user_id
      ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
      ORDER BY CASE m.status WHEN 'Waiting' THEN 0 WHEN 'Ready' THEN 1 WHEN 'In Progress' THEN 2 WHEN 'Disputed' THEN 3 ELSE 4 END, m.created_at DESC
      LIMIT 80
    `;
    const rows = db.prepare(sql).all(...params) as Array<MatchRow & { creator_username: string; creator_epic_name: string }>;

    // Attach participants count cleanly
    const matches = rows.map((m) => {
      const participants = db
        .prepare('SELECT id, team_side, user_id, username_snapshot, epic_name_snapshot, is_captain, ready_state FROM match_participants WHERE match_id = ?')
        .all(m.id);
      const { map_code, ...listMatch } = m;
      return { ...listMatch, participants };
    });

    const counts = {
      open: (db.prepare(`SELECT COUNT(*) as c FROM matches WHERE status = 'Waiting' AND is_private = 0 AND ${supportedRoom}`).get() as { c: number }).c,
      ongoing: (db.prepare("SELECT COUNT(*) as c FROM matches WHERE status IN ('Ready', 'In Progress', 'Disputed') AND is_private = 0").get() as { c: number }).c,
      ranked: (db.prepare("SELECT COUNT(*) as c FROM matches WHERE is_ranked = 1 AND status != 'Cancelled' AND is_private = 0").get() as { c: number }).c,
      totalCompleted: (db.prepare("SELECT COUNT(*) as c FROM matches WHERE status = 'Complete'").get() as { c: number }).c,
    };

    res.json({ matches, counts });
  });

  // Lookup / open specific match room by permanent ID (/matches/:id)
  app.get('/api/matches/config', (_req,res) => {
    const config = db.prepare('SELECT fee_bps,network_mode FROM wallet_config WHERE id=1').get();
    res.json(config);
  });

  app.get('/api/matches/:id', (req, res) => {
    const room = getFullMatchRoom(req.params.id, req.authUser?.id ?? null, req.authUser?.role ?? null);
    if (!room) return res.status(404).json({ error: 'Match not found' });
    if (room.forbidden) return res.status(403).json({ error: 'You are not authorized to view this private match room.' });
    res.json(room);
  });

  // Create Match (Atomic with creator stake reservation)
  app.post('/api/matches', requireAuth, (req, res) => {
    const user = req.authUser!;
    if (user.status === 'restricted') {
      return res.status(403).json({ error: 'Your account is restricted from creating matches.' });
    }

    const {
      title,
      format = '1v1',
      mode = 'Zone Wars',
      platform = 'All',
      region = user.competitive_region || 'NAE',
      stakeBasis = 'per_player',
      entryLamports = 0,
      firstTo = 5,
      winByTwo = false,
      mapId,
      mapCode,
      isPrivate = false,
      isRanked = false,
      creatorTeamId = null,
      inviteUsernames = [],
      loadout = '',
      roundsLead = 0,
      disableSimpleEdit = false,
    } = req.body || {};

    if (!VALID_FORMATS.includes(format)) return res.status(400).json({ error: 'Invalid format (1v1, 2v2, 3v3, 4v4)' });
    if (!VALID_MODES.includes(mode)) return res.status(400).json({ error: 'Invalid mode' });
    if (mode === 'Build Fights' && format !== '1v1') return res.status(400).json({ error: 'Build Fights is available in 1v1 only.' });
    if (!VALID_REGIONS.includes(region)) return res.status(400).json({ error: 'Invalid region (NAE, NAC, NAW, EU)' });
    if (!VALID_PLATFORMS.includes(platform)) return res.status(400).json({ error: 'Invalid platform' });

    const entryInt = Math.round(Number(entryLamports || 0));
    if (!Number.isSafeInteger(entryInt) || entryInt < 0 || entryInt > Number.MAX_SAFE_INTEGER / 16) {
      return res.status(400).json({ error: 'Invalid entry lamports amount' });
    }

    const walletCfg = db.prepare('SELECT paid_matches_enabled, fee_bps, network_mode FROM wallet_config WHERE id = 1').get() as {
      paid_matches_enabled: number;
      fee_bps: number;
      network_mode: string;
    };
    if (entryInt > 0 && walletCfg.paid_matches_enabled !== 1) {
      return res.status(403).json({ error: 'Paid SOL matches are currently disabled by platform settings.' });
    }
    const eligibilityError = entryInt > 0 && entryEligibilityError(user, walletCfg.network_mode);
    if (eligibilityError) return res.status(403).json({ error: eligibilityError });

    const teamSize = teamSizeForFormat(format);
    const firstToInt = Number(firstTo);
    if (!Number.isInteger(firstToInt) || firstToInt < 1 || firstToInt > 25 || typeof winByTwo !== 'boolean') {
      return res.status(400).json({ error: 'Invalid first-to target or win-by-two rule' });
    }

    if (!Array.isArray(inviteUsernames) || inviteUsernames.length>7 || inviteUsernames.some(name=>typeof name!=='string' || !name.trim() || name.length>24)
      || typeof loadout!=='string' || loadout.length>60 || !Number.isInteger(roundsLead) || roundsLead<0 || roundsLead>4 || roundsLead>=firstToInt || typeof disableSimpleEdit!=='boolean') {
      return res.status(400).json({error:'Check the match settings and invite usernames.'});
    }
    const invitedUsers = new Map<string,string>();
    if (isPrivate) {
      for (const name of inviteUsernames) {
        const target = db.prepare("SELECT id,username FROM users WHERE username=? COLLATE NOCASE AND status='active'").get(name.trim()) as {id:string;username:string}|undefined;
        if (!target || target.id===user.id) return res.status(400).json({error:'Invite another active player by their exact username.'});
        invitedUsers.set(target.id,target.username);
      }
    }

    const selectedMap = mapId
      ? (db.prepare('SELECT * FROM maps WHERE id = ?').get(mapId) as { id: string; code: string } | undefined)
      : (db.prepare('SELECT * FROM maps WHERE mode = ? LIMIT 1').get(mode) as { id: string; code: string } | undefined);

    const finalMapCode = String(mapCode || selectedMap?.code || '3537-4087-0888').trim();
    const matchId = newId('m');
    const finalTitle = String(title || `${format} ${mode}`).trim().slice(0, 80);

    // Fee calculation: feeBps of total pot (2 teams * entry)
    const stakePerPlayer = stakeBasis === 'per_team' ? Math.floor(entryInt / teamSize) : entryInt;
    const totalPot = stakePerPlayer * teamSize * 2;
    const feeLamports = totalPot > 0 ? Math.floor((totalPot * walletCfg.fee_bps) / 10000) : 0;
    const prizeLamports = totalPot - feeLamports;

    let room: ReturnType<typeof getFullMatchRoom> = null;

    try { runImmediateTransaction(() => {
      let teamRosterUsers: Array<{ id: string; username: string; display_name: string; epic_display_name: string; active_title: string; is_captain: number }> = [];

      if (creatorTeamId) {
        const team = db.prepare('SELECT * FROM teams WHERE id = ?').get(creatorTeamId) as { id: string; captain_user_id: string } | undefined;
        if (!team) throw new Error('Selected team roster not found');
        const members = db
          .prepare(`
            SELECT u.id, u.username, u.display_name, u.epic_display_name, u.active_title,
                   CASE WHEN tm.user_id = ? OR tm.role = 'captain' THEN 1 ELSE 0 END as is_captain
            FROM team_members tm
            JOIN users u ON u.id = tm.user_id
            WHERE tm.team_id = ? AND tm.status = 'active'
          `)
          .all(team.captain_user_id, team.id) as typeof teamRosterUsers;

        if (!members.some((m) => m.id === user.id)) {
          throw new Error('You must be an active member of the selected team roster');
        }
        if (members.length < teamSize) {
          throw new Error(`Selected roster needs at least ${teamSize} active players for ${format}`);
        }
        const orderedMembers = [members.find(member=>member.id===user.id)!, ...members.filter(member=>member.id!==user.id)];
        if (stakePerPlayer > 0 && walletCfg.network_mode!=='demo' && teamSize>1) throw Error('Each player must join individually for this entry.');
        teamRosterUsers = orderedMembers.slice(0, teamSize);
      } else {
        teamRosterUsers = [
          {
            id: user.id,
            username: user.username,
            display_name: user.display_name,
            epic_display_name: user.epic_display_name || user.username,
            active_title: user.active_title || '',
            is_captain: 1,
          },
        ];
      }

      db.prepare(`
        INSERT INTO matches (
          id, title, is_private, is_ranked, is_demo, format, mode, platform, region, game_server_region,
          stake_basis, entry_lamports, total_prize_lamports, platform_fee_lamports, first_to, win_by_two,
          map_id, map_code, creator_user_id, creator_team_id, loadout, rounds_lead, disable_simple_edit, status
        ) VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Waiting')
      `).run(
        matchId,
        finalTitle,
        isPrivate ? 1 : 0,
        isRanked ? 1 : 0,
        format,
        mode,
        platform,
        region,
        SERVER_REGION_MAP[region],
        stakeBasis === 'per_team' ? 'per_team' : 'per_player',
        stakePerPlayer,
        prizeLamports,
        feeLamports,
        firstToInt,
        Number(winByTwo),
        selectedMap?.id ?? null,
        finalMapCode,
        user.id,
        creatorTeamId || null, loadout.trim(), roundsLead, Number(disableSimpleEdit)
      );

      for (const invitedId of invitedUsers.keys()) {
        db.prepare('INSERT INTO match_invites(match_id,user_id) VALUES(?,?)').run(matchId,invitedId);
        notifyUser({userId:invitedId,category:'match',title:'Private Match Invite',body:user.username+' invited you to '+finalTitle+'.',linkUrl:'/matches/'+matchId});
      }

      for (const member of teamRosterUsers) {
        if (stakePerPlayer > 0) {
          applyLedgerGroup([
            {
              idempotencyKey: `match_join_${matchId}_${member.id}`,
              userId: member.id,
              entryType: 'match_stake_reserve',
              bucket: 'available',
              deltaLamports: -stakePerPlayer,
              referenceType: 'match',
              referenceId: matchId,
              network: walletCfg.network_mode,
              description: `Reserved ${stakePerPlayer} lamports for ${finalTitle}`,
              actorUserId: user.id,
            },
            {
              idempotencyKey: `match_join_res_${matchId}_${member.id}`,
              userId: member.id,
              entryType: 'match_stake_reserve',
              bucket: 'reserved',
              deltaLamports: stakePerPlayer,
              referenceType: 'match',
              referenceId: matchId,
              network: walletCfg.network_mode,
              description: `Escrow reserve for ${finalTitle}`,
              actorUserId: user.id,
            },
          ]);
        }

        db.prepare(`
          INSERT INTO match_participants (
            id, match_id, team_side, user_id, roster_id, username_snapshot, display_name_snapshot,
            epic_name_snapshot, active_title_snapshot, is_captain, ready_state, stake_reserved_lamports
          ) VALUES (?, ?, 'A', ?, ?, ?, ?, ?, ?, ?, 0, ?)
        `).run(
          newId('mp'),
          matchId,
          member.id,
          creatorTeamId || null,
          member.username,
          member.display_name,
          member.epic_display_name || member.username,
          member.active_title || '',
          member.is_captain,
          stakePerPlayer
        );
      }

      db.prepare('INSERT INTO matchmaking_attempts (id, user_id, mode, format, region, entry_lamports, matched, wait_seconds) VALUES (?, ?, ?, ?, ?, ?, 0, 0)').run(
        newId('mma'),
        user.id,
        mode,
        format,
        region,
        stakePerPlayer
      );

      appendSystemChatAndEvent(matchId, 'match_created', user.id, `${user.username} created the ${format} ${mode} lobby (${region}).`);
      writeAuditLog({
        actorUserId: user.id,
        actorRole: user.role,
        action: 'match_created',
        entityType: 'match',
        entityId: matchId,
        summary: `Match created: ${finalTitle} (${format} ${mode}, entry ${stakePerPlayer} lamports)`,
      });

      room = getFullMatchRoom(matchId, user.id, user.role);
    }); } catch (error) {
      return res.status(400).json({error:(error as Error).message});
    }

    broadcastGlobal({ type: 'matches_updated' });
    res.status(201).json(room);
  });

  // Join Match (Atomic stake reserve + simultaneous-join concurrency lock)
  app.post('/api/matches/:id/join', requireAuth, (req, res) => {
    const user = req.authUser!;
    if (user.status === 'restricted') {
      return res.status(403).json({ error: 'Restricted accounts cannot join competitive matches.' });
    }
    const matchId = req.params.id;
    const requestedSide = req.body?.teamSide === 'A' ? 'A' : 'B';
    const requestedTeamId = typeof req.body?.teamId === 'string' ? req.body.teamId : null;

    try {
      let updatedRoom: ReturnType<typeof getFullMatchRoom> = null;
      runImmediateTransaction(() => {
        const match = db.prepare('SELECT * FROM matches WHERE id = ?').get(matchId) as MatchRow | undefined;
        if (!match) throw new Error('Match not found');
        if (match.mode === 'Build Fights' && match.format !== '1v1') throw new Error('Build Fights is available in 1v1 only.');
        const teamId = match.format === '1v1' ? null : requestedTeamId;
        if (match.is_private && !db.prepare('SELECT 1 FROM match_invites WHERE match_id=? AND user_id=?').get(matchId,user.id)) {
          throw Error('A private match invitation is required.');
        }
        if (teamId && !db.prepare("SELECT 1 FROM team_members WHERE team_id=? AND user_id=? AND status='active'").get(teamId,user.id)) {
          throw Error('Choose one of your active teams.');
        }
        if (match.status !== 'Waiting') {
          throw new Error('Match is no longer open for joining');
        }

        const existingPart = db.prepare('SELECT id FROM match_participants WHERE match_id = ? AND user_id = ?').get(matchId, user.id);
        if (existingPart) {
          throw new Error('You have already joined this match');
        }

        const teamSize = teamSizeForFormat(match.format);
        const sideCountA = (db.prepare("SELECT COUNT(*) as c FROM match_participants WHERE match_id = ? AND team_side = 'A'").get(matchId) as { c: number }).c;
        const sideCountB = (db.prepare("SELECT COUNT(*) as c FROM match_participants WHERE match_id = ? AND team_side = 'B'").get(matchId) as { c: number }).c;

        const rosterSide = teamId ? db.prepare('SELECT team_side FROM match_participants WHERE match_id=? AND roster_id=? LIMIT 1').get(matchId,teamId) as {team_side:'A'|'B'}|undefined : undefined;
        if (rosterSide && (rosterSide.team_side==='A' ? sideCountA : sideCountB)>=teamSize) throw Error('Your team side is already full.');
        let targetSide: 'A' | 'B' = rosterSide?.team_side ?? requestedSide;
        if (targetSide === 'A' && sideCountA >= teamSize) targetSide = 'B';
        if (targetSide === 'B' && sideCountB >= teamSize) {
          if (sideCountA < teamSize) targetSide = 'A';
          else throw new Error('Match roster is already full');
        }

        const participantId = newId('mp');
        const isCaptain = (targetSide === 'A' ? sideCountA : sideCountB) === 0 ? 1 : 0;

        if (match.entry_lamports > 0) {
          const config = db.prepare('SELECT network_mode, paid_matches_enabled FROM wallet_config WHERE id=1').get() as {network_mode:string;paid_matches_enabled:number};
          if (!config.paid_matches_enabled) throw new Error('SOL-entry matches are currently disabled.');
          const eligibilityError = entryEligibilityError(user, config.network_mode);
          if (eligibilityError) throw new Error(eligibilityError);
          applyLedgerGroup([
            {
              idempotencyKey: `match_join_${participantId}`,
              userId: user.id,
              entryType: 'match_stake_reserve',
              bucket: 'available',
              deltaLamports: -match.entry_lamports,
              referenceType: 'match',
              referenceId: matchId,
              description: `Reserved stake for ${match.title}`,
              actorUserId: user.id,
            },
            {
              idempotencyKey: `match_join_res_${participantId}`,
              userId: user.id,
              entryType: 'match_stake_reserve',
              bucket: 'reserved',
              deltaLamports: match.entry_lamports,
              referenceType: 'match',
              referenceId: matchId,
              description: `Escrow reserve for ${match.title}`,
              actorUserId: user.id,
            },
          ]);
        }

        db.prepare(`
          INSERT INTO match_participants (
            id, match_id, team_side, user_id, roster_id, username_snapshot, display_name_snapshot,
            epic_name_snapshot, active_title_snapshot, is_captain, ready_state, stake_reserved_lamports
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
        `).run(
          participantId,
          matchId,
          targetSide,
          user.id,
          teamId,
          user.username,
          user.display_name,
          user.epic_display_name || user.username,
          user.active_title || '',
          isCaptain,
          match.entry_lamports
        );

        const totalAfter = sideCountA + sideCountB + 1;
        const neededTotal = teamSize * 2;
        if (totalAfter >= neededTotal) {
          db.prepare("UPDATE matches SET status = 'Ready', updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(matchId);
          db.prepare("UPDATE matchmaking_attempts SET matched = 1 WHERE user_id = ? AND mode = ? AND format = ?").run(user.id, match.mode, match.format);
          appendSystemChatAndEvent(matchId, 'opponent_joined', user.id, `${user.username} joined Team ${targetSide}. All slots filled — Ready Up to begin!`);
        } else {
          appendSystemChatAndEvent(matchId, 'player_joined', user.id, `${user.username} joined Team ${targetSide}.`);
        }

        notifyUser({
          userId: match.creator_user_id,
          category: 'match',
          title: 'Opponent Joined Match',
          body: `${user.username} joined ${match.title}. Ready up in the match room.`,
          linkUrl: `/matches/${matchId}`,
        });

        updatedRoom = getFullMatchRoom(matchId, user.id, user.role);
      });

      broadcastToMatch(matchId, { type: 'match_state', room: updatedRoom });
      broadcastGlobal({ type: 'matches_updated' });
      res.json(updatedRoom);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to join match';
      const status = msg.includes('full') || msg.includes('longer open') || msg.includes('already joined') ? 409 : msg.includes('invitation') ? 403 : 400;
      res.status(status).json({ error: msg });
    }
  });

  // Non-creators can leave before play and reopen their slot.
  app.post('/api/matches/:id/leave', requireAuth, (req, res) => {
    const user = req.authUser!;
    const matchId = req.params.id;
    try {
      runImmediateTransaction(() => {
        const match = db.prepare('SELECT * FROM matches WHERE id = ?').get(matchId) as MatchRow | undefined;
        if (!match) throw new Error('Match not found');
        if (match.started_at || !['Waiting', 'Ready'].includes(match.status)) throw new Error('This match has already closed or started.');
        if (match.creator_user_id === user.id) throw new Error('The match creator must cancel the lobby to leave.');

        const participant = db.prepare('SELECT * FROM match_participants WHERE match_id = ? AND user_id = ?')
          .get(matchId, user.id) as ParticipantRow | undefined;
        if (!participant) throw new Error('You have already left this match.');
        if (participant.stake_reserved_lamports > 0) {
          applyLedgerGroup((['reserved', 'available'] as const).map(bucket => ({
            idempotencyKey: `match_leave_${participant.id}_${bucket}`,
            userId: user.id,
            entryType: 'match_refund',
            bucket,
            deltaLamports: (bucket === 'reserved' ? -1 : 1) * participant.stake_reserved_lamports,
            referenceType: 'match',
            referenceId: matchId,
            description: `Returned stake on leaving ${match.title}`,
            actorUserId: user.id,
          })));
        }

        db.prepare('DELETE FROM match_participants WHERE id = ?').run(participant.id);
        if (participant.is_captain) {
          db.prepare(`UPDATE match_participants SET is_captain = 1 WHERE id = (
            SELECT id FROM match_participants WHERE match_id = ? AND team_side = ? ORDER BY joined_at, id LIMIT 1
          )`).run(matchId, participant.team_side);
        }
        db.prepare('UPDATE match_participants SET ready_state = 0 WHERE match_id = ?').run(matchId);
        db.prepare("UPDATE matches SET status = 'Waiting', updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(matchId);
        appendSystemChatAndEvent(matchId, 'player_left', user.id, 'A player left the lobby. The slot is open and ready states were reset.');
        writeAuditLog({
          actorUserId: user.id, actorRole: user.role, action: 'match_left', entityType: 'match',
          entityId: matchId, summary: 'Player left the lobby before play.',
        });
      });
      broadcastToMatch(matchId, { type: 'match_state' });
      broadcastGlobal({ type: 'matches_updated' });
      res.json({ ok: true });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // Ready Up
  app.post('/api/matches/:id/ready', requireAuth, (req, res) => {
    const user = req.authUser!;
    const matchId = req.params.id;
    try {
      let updatedRoom: ReturnType<typeof getFullMatchRoom> = null;
      runImmediateTransaction(() => {
        const match = db.prepare('SELECT * FROM matches WHERE id = ?').get(matchId) as MatchRow | undefined;
        if (!match) throw new Error('Match not found');
        if (!['Waiting', 'Ready'].includes(match.status)) throw new Error('Match is not awaiting ready-up');

        const part = db.prepare('SELECT * FROM match_participants WHERE match_id = ? AND user_id = ?').get(matchId, user.id) as ParticipantRow | undefined;
        if (!part) throw new Error('Only match participants can ready up');

        const nextReady = req.body?.ready === false ? 0 : 1;
        db.prepare('UPDATE match_participants SET ready_state = ? WHERE id = ?').run(nextReady, part.id);

        const allParts = db.prepare('SELECT * FROM match_participants WHERE match_id = ?').all(matchId) as ParticipantRow[];
        const requiredCount = teamSizeForFormat(match.format) * 2;
        if (allParts.length >= requiredCount && allParts.every((p) => p.ready_state === 1)) {
          const lobbyCode = match.lobby_code || `SFT-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
          db.prepare(`
            UPDATE matches
            SET status = 'In Progress', lobby_code = ?, started_at = COALESCE(started_at, strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
                updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
            WHERE id = ?
          `).run(lobbyCode, matchId);
          appendSystemChatAndEvent(matchId, 'match_started', user.id, `All players ready! Match is now In Progress. Lobby Code: ${lobbyCode}`);
        } else {
          appendSystemChatAndEvent(matchId, 'player_ready', user.id, `${user.username} marked ${nextReady ? 'READY' : 'NOT READY'}.`);
        }

        updatedRoom = getFullMatchRoom(matchId, user.id, user.role);
      });

      broadcastToMatch(matchId, { type: 'match_state', room: updatedRoom });
      broadcastGlobal({ type: 'matches_updated' });
      res.json(updatedRoom);
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Failed to ready up' });
    }
  });

  // Submit Result (Captains report; matching confirms & pays out; conflicting opens Dispute)
  app.post('/api/matches/:id/report', requireAuth, (req, res) => {
    const user = req.authUser!;
    const matchId = req.params.id;
    const { winnerSide, scoreA, scoreB, condition } = req.body || {};

    if (!['A', 'B'].includes(winnerSide)) return res.status(400).json({ error: 'winnerSide must be A or B' });
    const sA = Number(scoreA);
    const sB = Number(scoreB);
    if (![sA, sB].every(score => Number.isSafeInteger(score) && score >= 0)) {
      return res.status(400).json({ error: 'Enter a whole, nonnegative score for each side' });
    }

    try {
      let updatedRoom: ReturnType<typeof getFullMatchRoom> = null;
      runImmediateTransaction(() => {
        const match = db.prepare('SELECT * FROM matches WHERE id = ?').get(matchId) as MatchRow | undefined;
        if (!match) throw new Error('Match not found');
        if (match.status !== 'In Progress') {
          throw new Error('Match must be In Progress to submit results');
        }

        const part = db.prepare('SELECT * FROM match_participants WHERE match_id = ? AND user_id = ?').get(matchId, user.id) as ParticipantRow | undefined;
        if (!part) throw new Error('Only match participants can submit results');
        if (!part.is_captain) throw new Error('Only team captains can submit final match scores');

        if (condition !== undefined && !startedControlsAllowed(match)) throw new Error('This result option is available for free and simulated matches.');
        if (condition !== undefined && !['score','timer','defeat'].includes(condition)) throw new Error('Choose a valid outcome.');
        if (condition === 'defeat' && winnerSide === part.team_side) throw new Error('Choose the opposing team when conceding.');
        if (condition === 'timer' && (winnerSide !== part.team_side || !match.started_at || Date.now() - Date.parse(match.started_at) < 600000)) throw new Error('Timer wins unlock ten minutes after the match starts.');
        if (condition === 'score' && winnerSide !== part.team_side) throw new Error('Choose your team for a victory claim.');
        const [winningScore, losingScore] = winnerSide === 'A' ? [sA, sB] : [sB, sA];
        const requiredLead = match.win_by_two ? 2 : 1;
        if (condition !== 'timer' && condition !== 'defeat' && (winningScore < match.first_to || winningScore - losingScore < requiredLead)) {
          throw new Error(match.win_by_two ? 'The winner must reach the round target and lead by at least two' :
            'The winner must reach the round target and have the higher score');
        }

        if (part.reported_winner_side) {
          throw new Error('You have already submitted results for this match');
        }

        if (condition === 'defeat') {
          const opponent = db.prepare('SELECT * FROM match_participants WHERE match_id=? AND team_side=? AND is_captain=1').get(matchId,winnerSide) as ParticipantRow | undefined;
          const agreedScore = opponent?.reported_winner_side === winnerSide;
          finalizeMatchSettlementInsideTx({match,winnerSide,scoreA:agreedScore ? opponent.reported_score_a ?? 0 : 0,scoreB:agreedScore ? opponent.reported_score_b ?? 0 : 0,actorUserId:user.id,reason:'Captain accepted defeat',isOverride:false});
          appendSystemChatAndEvent(matchId,'match_settled',user.id,`${user.username} accepted defeat. Team ${winnerSide} wins.`);
          updatedRoom = getFullMatchRoom(matchId,user.id,user.role);
          return;
        }

        db.prepare(`
          UPDATE match_participants
          SET reported_winner_side = ?, reported_score_a = ?, reported_score_b = ?, reported_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
          WHERE id = ?
        `).run(winnerSide, sA, sB, part.id);

        appendSystemChatAndEvent(matchId, 'score_reported', user.id, `${user.username} (Team ${part.team_side}) reported Team ${winnerSide} won ${condition === 'timer' ? 'by timer' : '('+sA+'-'+sB+')'}.`);

        const captains = db
          .prepare('SELECT * FROM match_participants WHERE match_id = ? AND is_captain = 1')
          .all(matchId) as ParticipantRow[];

        const capA = captains.find((c) => c.team_side === 'A');
        const capB = captains.find((c) => c.team_side === 'B');

        if (capA?.reported_winner_side && capB?.reported_winner_side) {
          if (
            capA.reported_winner_side === capB.reported_winner_side &&
            capA.reported_score_a === capB.reported_score_a &&
            capA.reported_score_b === capB.reported_score_b
          ) {
            finalizeMatchSettlementInsideTx({
              match,
              winnerSide: capA.reported_winner_side,
              scoreA: capA.reported_score_a ?? 0,
              scoreB: capA.reported_score_b ?? 0,
              actorUserId: user.id,
              reason: 'Confirmed by both team captains',
              isOverride: false,
            });
            appendSystemChatAndEvent(
              matchId,
              'match_settled',
              null,
              `Match confirmed! Team ${capA.reported_winner_side} wins ${capA.reported_score_a}-${capA.reported_score_b}. Prize settled automatically.`
            );
          } else {
            // Conflict -> Dispute
            db.prepare("UPDATE matches SET status = 'Disputed', updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(matchId);
            db.prepare(`
              INSERT INTO disputes (id, match_id, opened_by_user_id, reason, status)
              VALUES (?, ?, ?, ?, 'Open')
            `).run(
              newId('dsp'),
              matchId,
              user.id,
              `Conflicting reports: Team A (${capA.reported_winner_side} ${capA.reported_score_a}-${capA.reported_score_b}) vs Team B (${capB.reported_winner_side} ${capB.reported_score_a}-${capB.reported_score_b})`
            );
            appendSystemChatAndEvent(
              matchId,
              'match_disputed',
              null,
              'Score conflict detected! Match moved to Disputed status. Please upload evidence screenshots/clips for Staff review.'
            );
          }
        }

        updatedRoom = getFullMatchRoom(matchId, user.id, user.role);
      });

      broadcastToMatch(matchId, { type: 'match_state', room: updatedRoom });
      broadcastGlobal({ type: 'matches_updated' });
      res.json(updatedRoom);
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to submit score' });
    }
  });

  // Open manual Dispute
  app.post('/api/matches/:id/dispute', requireAuth, (req, res) => {
    const user = req.authUser!;
    const matchId = req.params.id;
    const reason = String(req.body?.reason || '').trim();
    if (!reason) return res.status(400).json({ error: 'Dispute reason is required' });

    try {
      let updatedRoom: ReturnType<typeof getFullMatchRoom> = null;
      runImmediateTransaction(() => {
        const match = db.prepare('SELECT * FROM matches WHERE id = ?').get(matchId) as MatchRow | undefined;
        if (!match) throw new Error('Match not found');
        if (!['Ready', 'In Progress'].includes(match.status)) throw new Error('Cannot dispute match in current status');

        const part = db.prepare('SELECT id FROM match_participants WHERE match_id = ? AND user_id = ?').get(matchId, user.id);
        if (!part) throw new Error('Only match participants can open a dispute');

        db.prepare("UPDATE matches SET status = 'Disputed', updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(matchId);
        db.prepare(`
          INSERT INTO disputes (id, match_id, opened_by_user_id, reason, status)
          VALUES (?, ?, ?, ?, 'Open')
        `).run(newId('dsp'), matchId, user.id, reason);

        appendSystemChatAndEvent(matchId, 'match_disputed', user.id, `Dispute opened by ${user.username}: ${reason}`);
        updatedRoom = getFullMatchRoom(matchId, user.id, user.role);
      });

      broadcastToMatch(matchId, { type: 'match_state', room: updatedRoom });
      res.json(updatedRoom);
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Failed to open dispute' });
    }
  });

  // Cancel Match & Refund Escrow
  app.post('/api/matches/:id/cancel', requireAuth, (req, res) => {
    const user = req.authUser!;
    const matchId = req.params.id;
    const isStaff = ['moderator', 'finance', 'owner'].includes(user.role);

    try {
      let updatedRoom: ReturnType<typeof getFullMatchRoom> = null;
      runImmediateTransaction(() => {
        const match = db.prepare('SELECT * FROM matches WHERE id = ?').get(matchId) as MatchRow | undefined;
        if (!match) throw new Error('Match not found');

        if (req.body?.vote === true) {
          if (match.status !== 'In Progress' || !match.started_at || !startedControlsAllowed(match)) throw new Error('Cancellation voting is available during free and simulated matches.');
          const captain = db.prepare('SELECT team_side FROM match_participants WHERE match_id=? AND user_id=? AND is_captain=1').get(matchId,user.id) as {team_side:string} | undefined;
          if (!captain) throw new Error('Only team captains can vote.');
          const votes = cancelVotes(matchId);
          if (!votes.includes(captain.team_side)) appendSystemChatAndEvent(matchId,'cancel_vote',user.id,`Team ${captain.team_side} voted to cancel the match.`,{side:captain.team_side});
          if (cancelVotes(matchId).length < 2) {
            updatedRoom = getFullMatchRoom(matchId,user.id,user.role);
            return;
          }
        } else {
        if (!isStaff && match.creator_user_id !== user.id) {
          throw new Error('Only the match creator or staff can cancel this match');
        }
        if (!isStaff && (match.started_at || !['Waiting', 'Ready'].includes(match.status))) {
          throw new Error('Players can cancel only before a match starts');
        }
        }
        if (['Complete', 'Cancelled'].includes(match.status)) {
          throw new Error(`Match is already ${match.status}`);
        }

        const participants = db.prepare('SELECT * FROM match_participants WHERE match_id = ?').all(matchId) as ParticipantRow[];
        const refundGroup = newId('txg');
        const mutations = [];
        for (const p of participants) {
          if (p.stake_reserved_lamports > 0) {
            mutations.push({
              idempotencyKey: `match_cancel_rel_${refundGroup}_${p.user_id}`,
              userId: p.user_id,
              entryType: 'match_refund' as const,
              bucket: 'reserved' as const,
              deltaLamports: -p.stake_reserved_lamports,
              referenceType: 'match',
              referenceId: matchId,
              description: `Refunded stake on match cancellation (${match.title})`,
              actorUserId: user.id,
            });
            mutations.push({
              idempotencyKey: `match_cancel_av_${refundGroup}_${p.user_id}`,
              userId: p.user_id,
              entryType: 'match_refund' as const,
              bucket: 'available' as const,
              deltaLamports: p.stake_reserved_lamports,
              referenceType: 'match',
              referenceId: matchId,
              description: `Returned stake to available SOL (${match.title})`,
              actorUserId: user.id,
            });
          }
        }
        if (mutations.length > 0) applyLedgerGroup(mutations, refundGroup);

        db.prepare('UPDATE match_participants SET stake_reserved_lamports = 0 WHERE match_id = ?').run(matchId);
        db.prepare("UPDATE matches SET status = 'Cancelled', cancelled_reason = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(
          String(req.body?.reason || `Cancelled by ${user.username}`),
          matchId
        );

        appendSystemChatAndEvent(matchId, 'match_cancelled', user.id, `Match cancelled by ${user.username}. All reserved SOL stakes refunded.`, {refundGroup});
        writeAuditLog({
          actorUserId: user.id,
          actorRole: user.role,
          action: 'match_cancelled',
          entityType: 'match',
          entityId: matchId,
          summary: `Cancelled match ${matchId} and refunded ${participants.length} participant stakes`,
        });

        updatedRoom = getFullMatchRoom(matchId, user.id, user.role);
      });

      broadcastToMatch(matchId, { type: 'match_state', room: updatedRoom });
      broadcastGlobal({ type: 'matches_updated' });
      res.json(updatedRoom);
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to cancel match' });
    }
  });

  app.post('/api/matches/:id/staff-reset', requireRole(['owner']), (req, res) => {
    const reason = String(req.body?.reason || '').trim().slice(0, 500);
    const staff = req.authUser!;
    if (reason.length < 3) return res.status(400).json({ error: 'Enter an audit reason.' });
    try {
      const room = runImmediateTransaction(() => {
        const match = db.prepare('SELECT * FROM matches WHERE id=?').get(req.params.id) as MatchRow | undefined;
        if (!match) throw new Error('Match not found.');
        if (match.status === 'Complete') {
          if (match.mode === 'Build Fights' && match.format !== '1v1') throw new Error('Build Fights is available in 1v1 only.');
          const previous = db.prepare(`SELECT metadata_json FROM match_events WHERE match_id=? AND event_type='staff_rematch' ORDER BY rowid DESC LIMIT 1`).get(match.id) as {metadata_json:string} | undefined;
          if (previous) {
            const rematch = getFullMatchRoom(JSON.parse(previous.metadata_json).rematchId, staff.id, staff.role);
            if (rematch) return rematch;
          }
          const participants = db.prepare('SELECT * FROM match_participants WHERE match_id=?').all(match.id) as ParticipantRow[];
          if (participants.length !== teamSizeForFormat(match.format) * 2) throw new Error('Both teams must be full to reset a completed match.');
          const rematchId = newId('match');
          db.prepare(`INSERT INTO matches (id,title,is_private,is_ranked,is_demo,format,mode,platform,region,game_server_region,
            stake_basis,first_to,win_by_two,movement_type,map_id,map_code,creator_user_id,creator_team_id,loadout,rounds_lead,disable_simple_edit,status)
            SELECT ?,title,1,is_ranked,is_demo,format,mode,platform,region,game_server_region,
            stake_basis,first_to,win_by_two,movement_type,map_id,map_code,creator_user_id,creator_team_id,loadout,rounds_lead,disable_simple_edit,'Ready'
            FROM matches WHERE id=?`).run(rematchId, match.id);
          for (const player of participants) {
            db.prepare(`INSERT INTO match_participants (id,match_id,team_side,user_id,roster_id,username_snapshot,display_name_snapshot,epic_name_snapshot,active_title_snapshot,is_captain)
              VALUES (?,?,?,?,?,?,?,?,?,?)`).run(newId('mp'),rematchId,player.team_side,player.user_id,player.roster_id,player.username_snapshot,player.display_name_snapshot,player.epic_name_snapshot,player.active_title_snapshot,player.is_captain);
            notifyUser({userId:player.user_id,category:'match',title:'Match reset',body:'An administrator opened a free rematch.',linkUrl:'/matches/'+rematchId});
          }
          appendSystemChatAndEvent(match.id,'staff_rematch',staff.id,'An administrator opened a free rematch.',{reason,rematchId});
          appendSystemChatAndEvent(rematchId,'staff_reset',staff.id,'Match reset. Players can ready up again.',{originalMatchId:match.id,reason});
          writeAuditLog({actorUserId:staff.id,actorRole:staff.role,action:'match_reset',entityType:'match',entityId:match.id,summary:reason,metadata:{rematchId}});
          return getFullMatchRoom(rematchId,staff.id,staff.role);
        }
        if (match.status === 'Cancelled') {
          if (match.mode === 'Build Fights' && match.format !== '1v1') throw new Error('Build Fights is available in 1v1 only.');
          const participants = db.prepare('SELECT * FROM match_participants WHERE match_id = ?').all(match.id) as ParticipantRow[];
          if (participants.length === 0) throw new Error('This match has no players to reset.');
          const cancellation = db.prepare("SELECT metadata_json FROM match_events WHERE match_id=? AND event_type='match_cancelled' ORDER BY rowid DESC LIMIT 1").get(match.id) as {metadata_json:string} | undefined;
          const refundGroup = JSON.parse(cancellation?.metadata_json ?? '{}').refundGroup
            ?? db.prepare(`SELECT tx_group_id FROM ledger_entries WHERE reference_type='match' AND reference_id=?
              AND entry_type='match_refund' AND substr(idempotency_key, 1, 16)='match_cancel_av_' ORDER BY rowid DESC LIMIT 1`).pluck().get(match.id);
          const refunds = db.prepare(`SELECT user_id, delta_lamports FROM ledger_entries
            WHERE tx_group_id=? AND reference_type='match' AND reference_id=? AND entry_type='match_refund'
              AND bucket='available' AND delta_lamports > 0`).all(refundGroup ?? '', match.id) as {user_id:string;delta_lamports:number}[];
          const cycle = newId('reset');
          const wallet = db.prepare('SELECT network_mode, paid_matches_enabled FROM wallet_config WHERE id=1').get() as {network_mode:string;paid_matches_enabled:number};
          for (const player of participants) {
            const stake = refunds.find(refund => refund.user_id === player.user_id)?.delta_lamports ?? 0;
            if (stake !== match.entry_lamports) throw new Error('The original entry stake could not be restored.');
            if (stake > 0) {
              if (!wallet.paid_matches_enabled) throw new Error('SOL-entry matches are currently disabled.');
              const account = db.prepare('SELECT * FROM users WHERE id=?').get(player.user_id) as Parameters<typeof entryEligibilityError>[0] | undefined;
              const ineligible = !account || entryEligibilityError(account, wallet.network_mode);
              if (ineligible) throw new Error('A player is no longer eligible for this SOL entry.');
              applyLedgerGroup((['available', 'reserved'] as const).map(bucket => ({
                idempotencyKey: `match_reset_${cycle}_${player.id}_${bucket}`,
                userId: player.user_id, entryType: 'match_stake_reserve', bucket, deltaLamports: bucket === 'available' ? -stake : stake,
                referenceType: 'match', referenceId: match.id, network: wallet.network_mode,
                description: 'Restored entry stake when staff reset the match', actorUserId: staff.id,
              })));
            }
            db.prepare(`UPDATE match_participants SET stake_reserved_lamports=?, ready_state=0,
              reported_winner_side=NULL, reported_score_a=NULL, reported_score_b=NULL, reported_at=NULL WHERE id=?`).run(stake, player.id);
          }
          const status = participants.length === teamSizeForFormat(match.format) * 2 ? 'Ready' : 'Waiting';
          db.prepare(`UPDATE matches SET status=?, cancelled_reason=NULL, started_at=NULL, completed_at=NULL,
            winner_side=NULL, score_a=0, score_b=0, lobby_code='', chat_open=1,
            updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?`).run(status, match.id);
          db.prepare("UPDATE disputes SET status='Dismissed', resolution_notes=?, resolved_by_user_id=?, resolved_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE match_id=? AND status IN ('Open','Under Review')").run(reason,staff.id,match.id);
          appendSystemChatAndEvent(match.id, 'staff_reset', staff.id, 'Staff reset the match. Players can ready up again.', {reason});
          writeAuditLog({actorUserId:staff.id,actorRole:staff.role,action:'match_reset',entityType:'match',entityId:match.id,summary:reason});
          return getFullMatchRoom(match.id, staff.id, staff.role);
        }
        if (match.status !== 'Disputed' || !match.started_at) throw new Error('Only cancelled or disputed matches can be reset.');
        const reports = db.prepare('SELECT user_id, reported_winner_side, reported_score_a, reported_score_b, reported_at FROM match_participants WHERE match_id=? AND reported_at IS NOT NULL').all(match.id);
        db.prepare('UPDATE match_participants SET reported_winner_side=NULL,reported_score_a=NULL,reported_score_b=NULL,reported_at=NULL WHERE match_id=?').run(match.id);
        db.prepare("UPDATE disputes SET status='Dismissed', resolution_notes=?, resolved_by_user_id=?, resolved_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE match_id=? AND status IN ('Open','Under Review')").run(reason,staff.id,match.id);
        db.prepare("UPDATE matches SET status='In Progress', chat_open=1,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?").run(match.id);
        appendSystemChatAndEvent(match.id,'staff_reset',staff.id,'Staff has reopened score submissions.',{reason,reports});
        writeAuditLog({actorUserId:staff.id,actorRole:staff.role,action:'match_reset',entityType:'match',entityId:match.id,summary:reason,metadata:{reports}});
        return getFullMatchRoom(match.id,staff.id,staff.role);
      });
      broadcastToMatch(req.params.id, {type:'match_state'});
      broadcastGlobal({type:'matches_updated'});
      return res.json(room);
    } catch (error) { return res.status(400).json({error:(error as Error).message}); }
  });

  // Match Chat message
  app.post('/api/matches/:id/chat', requireAuth, (req, res) => {
    const user = req.authUser!;
    if (db.prepare('SELECT 1 FROM player_moderation WHERE user_id=? AND chat_banned=1').get(user.id))
      return res.status(403).json({error:'Your match chat access has been suspended by staff.'});
    const matchId = req.params.id;
    const body = String(req.body?.body || '').trim();
    if (!body || body.length > 500) return res.status(400).json({ error: 'Message must be 1-500 characters' });

    const match = db.prepare('SELECT * FROM matches WHERE id = ?').get(matchId) as MatchRow | undefined;
    if (!match) return res.status(404).json({ error: 'Match not found' });

    const isStaff = ['moderator', 'finance', 'owner'].includes(user.role);
    const isPart = db.prepare('SELECT 1 FROM match_participants WHERE match_id = ? AND user_id = ?').get(matchId, user.id);
    if (!isStaff && !isPart) {
      return res.status(403).json({ error: 'Only match participants or staff can post in Match Chat' });
    }
    if (!match.chat_open && !isStaff) {
      return res.status(403).json({ error: 'Match Chat has been closed by staff' });
    }

    const msgId = newId('mch');
    db.prepare(`
      INSERT INTO match_chat_messages (id, match_id, user_id, sender_name, sender_role, message_type, body)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(msgId, matchId, user.id, user.display_name, user.role, isStaff ? 'staff' : 'user', body);

    const created = db.prepare('SELECT * FROM match_chat_messages WHERE id = ?').get(msgId);
    broadcastToMatch(matchId, { type: 'chat_message', message: created });
    res.status(201).json({ message: created });
  });

  // Toggle Match Chat Open/Closed (Staff)
  app.post('/api/matches/:id/chat/toggle', requireRole(['moderator', 'owner']), (req, res) => {
    const match = db.prepare('SELECT * FROM matches WHERE id = ?').get(req.params.id) as MatchRow | undefined;
    if (!match) return res.status(404).json({ error: 'Match not found' });
    const nextOpen = match.chat_open ? 0 : 1;
    db.prepare('UPDATE matches SET chat_open = ? WHERE id = ?').run(nextOpen, match.id);
    appendSystemChatAndEvent(match.id, 'chat_toggled', req.authUser!.id, `Match chat ${nextOpen ? 'reopened' : 'closed'} by staff (${req.authUser!.username}).`);
    const room = getFullMatchRoom(match.id, req.authUser!.id, req.authUser!.role);
    broadcastToMatch(match.id, { type: 'match_state', room });
    res.json(room);
  });

  // Upload Private Evidence (Match participants & Staff only)
  app.post('/api/matches/:id/evidence', requireAuth, (req, res) => {
    const matchId = req.params.id;
    const user = req.authUser!;
    const match = db.prepare('SELECT started_at FROM matches WHERE id = ?').get(matchId) as Pick<MatchRow, 'started_at'> | undefined;
    if (!match) return res.status(404).json({ error: 'Match not found' });

    if (!match.started_at) return res.status(409).json({ error: 'Evidence uploads open after the match starts.' });

    const isStaff = ['moderator', 'finance', 'owner'].includes(user.role);
    const isPart = db.prepare('SELECT 1 FROM match_participants WHERE match_id = ? AND user_id = ?').get(matchId, user.id);
    if (!isStaff && !isPart) {
      return res.status(403).json({ error: 'Only match participants or staff can upload evidence' });
    }

    upload.single('file')(req, res, (err) => {
      if (err) return res.status(400).json({ error: err.message });
      if (!req.file) return res.status(400).json({ error: 'Evidence file is required' });

      const file = req.file;
      const buf = hostedDemo ? file.buffer : fs.readFileSync(path.resolve(EVIDENCE_DIR, file.filename));
      const sha256 = crypto.createHash('sha256').update(buf).digest('hex');
      const evidenceId = newId('evd');
      const note = String(req.body?.note || '').slice(0, 300);

      const dispute = db.prepare('SELECT id FROM disputes WHERE match_id = ? ORDER BY created_at DESC LIMIT 1').get(matchId) as { id: string } | undefined;

      db.prepare(`
        INSERT INTO evidence_files (id, match_id, dispute_id, uploader_user_id, original_filename, stored_filename, mime_type, size_bytes, sha256, note)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(evidenceId, matchId, dispute?.id ?? null, user.id, file.originalname, hostedDemo ? evidenceId : file.filename, file.mimetype, file.size, sha256, note);
      if (hostedDemo) db.prepare('INSERT INTO evidence_blob_bytes (evidence_id, contents) VALUES (?, ?)').run(evidenceId, buf);

      appendSystemChatAndEvent(matchId, 'evidence_uploaded', user.id, `${user.username} uploaded private evidence (${req.file.originalname}).`);
      const room = getFullMatchRoom(matchId, user.id, user.role);
      broadcastToMatch(matchId, { type: 'match_state', room });
      res.status(201).json({ evidenceId, room });
    });
  });

  // Download Private Evidence (Strictly restricted to participants & staff + path confinement)
  app.get('/api/matches/:id/evidence/:evidenceId/download', requireAuth, (req, res) => {
    const user = req.authUser!;
    const { id: matchId, evidenceId } = req.params;

    const isStaff = ['moderator', 'finance', 'owner'].includes(user.role);
    const isPart = db.prepare('SELECT 1 FROM match_participants WHERE match_id = ? AND user_id = ?').get(matchId, user.id);
    if (!isStaff && !isPart) {
      return res.status(403).json({ error: 'Forbidden: unauthorized evidence access' });
    }

    const row = db
      .prepare('SELECT * FROM evidence_files WHERE id = ? AND match_id = ?')
      .get(evidenceId, matchId) as { stored_filename: string; original_filename: string; mime_type: string } | undefined;
    if (!row) return res.status(404).json({ error: 'Evidence file not found' });

    const name = row.original_filename.replace(/[^a-zA-Z0-9._-]/g, '_');
    if (hostedDemo) {
      const file = db.prepare('SELECT contents FROM evidence_blob_bytes WHERE evidence_id = ?')
        .get(evidenceId) as { contents: Buffer } | undefined;
      if (!file) return res.status(404).json({ error: 'Evidence file missing from storage' });
      res.setHeader('Content-Type', row.mime_type);
      res.setHeader('Content-Disposition', `attachment; filename="${name}"`);
      return res.send(file.contents);
    }

    const baseDir = path.resolve(EVIDENCE_DIR);
    const resolvedPath = path.resolve(baseDir, row.stored_filename);
    if (!resolvedPath.startsWith(baseDir + path.sep) || !fs.existsSync(resolvedPath)) {
      return res.status(404).json({ error: 'Evidence file missing from storage' });
    }

    res.setHeader('Content-Type', row.mime_type);
    res.setHeader('Content-Disposition', `inline; filename="${row.original_filename.replace(/[^a-zA-Z0-9._-]/g, '_')}"`);
    res.sendFile(resolvedPath);
  });

  // Staff Resolve Dispute / Override Match Result
  app.post('/api/matches/:id/staff-resolve', requireRole(['moderator', 'owner']), (req, res) => {
    const staff = req.authUser!;
    const matchId = req.params.id;
    const { winnerSide, scoreA, scoreB, reason } = req.body || {};

    if (!['A', 'B'].includes(winnerSide)) return res.status(400).json({ error: 'winnerSide must be A or B' });
    if (!reason || String(reason).trim().length < 3) {
      return res.status(400).json({ error: 'Audit reason is required for staff match resolution/override' });
    }

    try {
      let updatedRoom: ReturnType<typeof getFullMatchRoom> = null;
      runImmediateTransaction(() => {
        const match = db.prepare('SELECT * FROM matches WHERE id = ?').get(matchId) as MatchRow | undefined;
        if (!match) throw new Error('Match not found');
        if (match.status === 'Cancelled') throw new Error('Cannot resolve a cancelled match');

        if (match.status !== 'Complete') {
          const rosterCount = Number(db.prepare('SELECT COUNT(*) FROM match_participants WHERE match_id=?').pluck().get(matchId));
          if (rosterCount !== teamSizeForFormat(match.format) * 2) throw new Error('Both teams must be full to award a win.');
        }
        const isOverride = match.status === 'Complete';
        finalizeMatchSettlementInsideTx({
          match,
          winnerSide,
          scoreA: Math.max(0, Math.round(Number(scoreA ?? 0))),
          scoreB: Math.max(0, Math.round(Number(scoreB ?? 0))),
          actorUserId: staff.id,
          reason: String(reason).trim(),
          isOverride,
        });

        db.prepare(`
          UPDATE disputes
          SET status = 'Resolved', resolved_winner_side = ?, resolved_by_user_id = ?, resolution_notes = ?,
              resolved_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
          WHERE match_id = ? AND status IN ('Open', 'Under Review')
        `).run(winnerSide, staff.id, String(reason).trim(), matchId);

        appendSystemChatAndEvent(
          matchId,
          isOverride ? 'staff_result_override' : 'staff_dispute_resolved',
          staff.id,
          `Moderator ${staff.username} ${isOverride ? 'overrode' : 'awarded'} Team ${winnerSide} (${scoreA}-${scoreB}): ${String(reason).trim()}`
        );

        writeAuditLog({
          actorUserId: staff.id,
          actorRole: staff.role,
          action: isOverride ? 'match_result_override' : 'match_dispute_resolved',
          entityType: 'match',
          entityId: matchId,
          summary: `Staff ${staff.username} set result Team ${winnerSide} (${scoreA}-${scoreB}) — ${reason}`,
        });

        updatedRoom = getFullMatchRoom(matchId, staff.id, staff.role);
      });

      broadcastToMatch(matchId, { type: 'match_state', room: updatedRoom });
      broadcastGlobal({ type: 'matches_updated' });
      res.json(updatedRoom);
    } catch (err) {
      res.status(400).json({ error: err instanceof Error ? err.message : 'Unable to resolve match' });
    }
  });
}
