# SFT (Solana Fortnite Tokens) — Complete Codebase & Technical Handoff

Target Domain: `solanafortnitetokens.com`
Purpose: Full-stack competitive Fortnite matchmaking, tournament bracket management, SOL-only integer-lamport wallet/escrow system, and Owner/Moderator/Finance Staff Operations platform.

---

## 1. Tech Stack & Runtime
- **Frontend**: React 19, TypeScript (`~5.8.2`), React Router DOM v7, Tailwind CSS v4 (`@tailwindcss/vite`), Lucide Icons, Motion (`motion/react`), Vite 6.
- **Backend**: Node.js (`tsx server.ts` in dev, `node server.ts` in prod) running Express 4 + `ws` WebSocket server on port `3000`.
- **Database**: SQLite in WAL mode via `better-sqlite3` (`foreign_keys = ON`, `BEGIN IMMEDIATE` serialization). Numbered migrations in `/migrations/` run automatically on startup.
- **Solana**: `@solana/web3.js` (`^3.2.1`) Devnet RPC watcher, 9-decimal unique deposit invoice generation, signed withdrawal persistence, and idempotent reconciliation retries.
- **Verification**: `/scripts/verify_e2e.mjs` (6 automated E2E API/WebSocket/ledger tests).

---

## 2. Project File Structure

```text
├── .env.example                 # Environment variable template (never commit secrets)
├── index.html                   # SPA HTML shell & metadata
├── metadata.json                # Applet metadata
├── package.json                 # Dependencies & npm scripts (dev, build, start, lint)
├── tsconfig.json / vite.config.ts
├── server.ts                    # Main Express + Vite + WebSocket entrypoint (port 3000)
├── migrations/
│   └── 001_init.sql             # Complete SQLite relational schema + indexes
├── server/
│   ├── db.ts                    # SQLite WAL setup, runMigrations(), UUID/timestamp helpers
│   ├── ledger.ts                # Append-only integer-lamport accounting (available/reserved/frozen)
│   ├── auth.ts                  # Sessions, scrypt password hashing, RBAC middleware, profile/leaderboard/notifications
│   ├── matches.ts               # Matchmaking, escrow lock, concurrency join, ready/report/dispute/resolve, evidence upload
│   ├── tournaments.ts           # Tournament registration, check-in, single-elim bracket generation, 70/30 payouts
│   ├── solana.ts                # SOL invoices, Devnet watcher cursor, withdrawals, finance reconciliation, owner config
│   ├── analytics.ts             # Owner Business Analytics KPIs, Staff console, shop, teams, rewards, streams, support
│   ├── seed.ts                  # Idempotent demo accounts, matches, maps, cosmetics, tournaments, policies
│   └── ws.ts                    # WebSocket server (/ws) room subscriptions & live broadcasts
├── src/
│   ├── main.tsx / App.tsx / index.css
│   ├── context/AuthContext.tsx  # Auth state, balance polling, region preference
│   ├── lib/api.ts               # Typed fetch wrapper & CSRF header helper
│   ├── lib/format.ts            # SOL lamport formatters, full region names, timer MM:SS, mode gradients/art
│   ├── assets/images/           # Generated mode artwork tiles & tournament hero banner
│   ├── components/
│   │   ├── Layout.tsx           # Top header, player search, region selector, collapsible activity rail, mobile drawer
│   │   ├── MatchCard.tsx        # Reference-matched match card component
│   │   ├── CreateMatchModal.tsx # Create 1v1/2v2/3v3/4v4 match modal (SOL entry, platform, region, map)
│   │   └── AuthModal.tsx        # Sign In / Sign Up / Demo account quick-login modal
│   └── pages/
│       ├── HomePage.tsx         # Hero, Browse Modes carousel, Open Lobbies, Featured Tournaments, Leaderboard preview, Streams
│       ├── MatchesPage.tsx      # Open / Ongoing / Ranked / My Matches tabs, toolbar filters, MatchCard grid
│       ├── MatchRoomPage.tsx    # Top hero, Share Match, Entry>Prize, 6 tiles, 5-step timeline, Team A/B, action buttons, tabbed Rules+Map Code, 300px Match Chat
│       ├── TournamentsPage.tsx  # Upcoming / Live / Past, two-up tournament cards with registration progress & bracket view
│       ├── WalletPage.tsx       # SOL deposit invoice generator, QR/address, watcher sync, withdrawals, ledger history
│       ├── StaffConsolePage.tsx # Owner Business Analytics KPIs, Finance Reconciliation, Disputes, Accounts, Policies, Audit Logs
│       ├── LeaderboardPage.tsx  # Podium + full ELO/Wins/SOL ranking table
│       ├── ShopPage.tsx         # Cosmetic titles, borders, badges with Buy / Equip / Equipped states
│       ├── TeamsPage.tsx        # Team creation, invites, rosters
│       ├── MapsPage.tsx         # Verified Fortnite Creative / D1 map codes directory
│       ├── RewardsPage.tsx      # Milestone/achievement SOL reward claims
│       ├── ProfilePage.tsx      # Public/self player profile, stats, match history
│       ├── SettingsPage.tsx     # Epic username, Discord/Twitch, region, password, 18+ compliance
│       ├── RulesPage.tsx        # Platform rules, anti-cheat, fair play, dispute SLA
│       └── SupportPage.tsx      # Ticket creation & Staff support resolution
├── public/assets/aistudio/      # Visual target reference screenshots supplied by the user
└── scripts/verify_e2e.mjs       # Full 6-scenario E2E verification suite
```

---

## 3. Visual Reference Screenshots Included (`public/assets/aistudio/`)
If continuing UI tweaks with another AI, inspect these attached target screenshots included in the zip:
- `public/assets/aistudio/image_3135c95d.png` — Exact **Match Card** layout (mode gradient art fading into `#1b2434`, clean top-left art, top-right rounded SOL pill, stopwatch + `MM:SS` timer, title, 3 pills `[Platform] [Full Region Name] [FirstTo⁺²]`, full-width `View Opponent` button).
- `public/assets/aistudio/image_646f7210.png` — Exact **Match Room** layout (back button, centered title + Share Match, `Entry > Prize`, 6 tiles, 5-step timeline, Team A/B cards, stacked colored action buttons, tabbed Rules + `MAP CODE:`, 300px right Match Chat column).
- `public/assets/aistudio/image_f99b053e.png` — Tournament card layout.
- `public/assets/aistudio/image_bce95176.png`, `image_3b654e0d.png`, `image_08b1018e.png`, `image_60447adb.png`, `image_c2bc4f76.png` — Additional app shell & layout references.

---

## 4. Database Schema Highlights (`migrations/001_init.sql`)
- `users`: Auth credentials (`password_hash`), RBAC role (`player` | `moderator` | `finance` | `owner`), Epic username, Discord/Twitch handles, `elo`, `wins`, `losses`, `is_adult_verified`, ban/freeze flags, equipped shop item IDs.
- `user_balances` & `ledger_entries`: Strict integer lamports (`available_lamports`, `reserved_lamports`, `frozen_lamports`). Every movement writes an immutable `ledger_entries` row with unique `idempotency_key` (`deposit`, `escrow_lock`, `escrow_release`, `escrow_payout`, `platform_fee`, `withdrawal_hold`, `withdrawal_settle`, `withdrawal_refund`, `shop_purchase`, `reward_claim`, `tournament_entry`, `tournament_payout`).
- `matches`, `match_teams`, `match_participants`, `match_chat_messages`, `match_evidence`, `match_result_versions`: Full match lifecycle (`waiting` → `ready_up` → `playing` → `submitting` → `disputed`/`completed`/`cancelled`) with versioned score settlement overrides and private evidence files stored outside `public/` in `data/evidence/`.
- `tournaments`, `tournament_entries`, `tournament_bracket_matches`: Registration caps, check-in, single-elimination brackets, 70%/30% prize pool splits.
- `deposit_invoices`, `solana_withdrawals`, `wallet_config`, `solana_watcher_state`: Solana deposit invoice matching & pre-signed withdrawal tracking.
- `audit_logs`, `risk_flags`, `support_tickets`, `policies`, `shop_items`, `user_shop_items`, `teams`, `team_members`, `maps`, `notifications`.

---

## 5. Complete REST API & WebSocket Reference

### Auth, Account & Social (`server/auth.ts`)
- `GET /api/auth/me`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `PATCH /api/account/profile`
- `GET /api/users/search`
- `GET /api/users/:username`
- `GET /api/leaderboard`
- `GET /api/notifications`
- `POST /api/notifications/read`

### Matches, Maps & Disputes (`server/matches.ts`)
- `GET /api/maps`
- `GET /api/matches`
- `GET /api/matches/:id`
- `POST /api/matches`
- `POST /api/matches/:id/join`
- `POST /api/matches/:id/ready`
- `POST /api/matches/:id/report`
- `POST /api/matches/:id/dispute`
- `POST /api/matches/:id/cancel`
- `POST /api/matches/:id/chat`
- `POST /api/matches/:id/chat/toggle` (Moderator / Owner)
- `POST /api/matches/:id/evidence`
- `GET /api/matches/:id/evidence/:evidenceId/download` (Participant / Moderator / Owner)
- `POST /api/matches/:id/staff-resolve` (Moderator / Owner)

### Tournaments (`server/tournaments.ts`)
- `GET /api/tournaments`
- `GET /api/tournaments/:id`
- `POST /api/tournaments` (Moderator / Owner)
- `POST /api/tournaments/:id/register`
- `POST /api/tournaments/:id/checkin`
- `POST /api/tournaments/:id/withdraw`
- `POST /api/tournaments/:id/generate-bracket` (Moderator / Owner)
- `POST /api/tournaments/:id/bracket/:bracketMatchId/result` (Moderator / Owner)

### Wallet & Solana Reconciliation (`server/solana.ts`)
- `GET /api/wallet`
- `POST /api/wallet/deposit-invoice`
- `POST /api/wallet/sync`
- `POST /api/wallet/withdraw`
- `POST /api/wallet/devnet-simulate-transfer` (Devnet/Demo testing)
- `POST /api/finance/withdrawals/:id/retry` (Finance / Owner)
- `POST /api/finance/deposits/:invoiceId/approve` (Finance / Owner)
- `GET /api/finance/reconciliation` (Finance / Owner)
- `PATCH /api/finance/config` (Owner)

### Analytics, Staff, Shop, Teams, Rewards & Support (`server/analytics.ts`)
- `GET /api/owner/analytics` (Owner only)
- `GET /api/staff/overview` (Moderator / Finance / Owner)
- `GET /api/staff/users` (Moderator / Finance / Owner)
- `PATCH /api/staff/users/:userId` (Moderator / Finance / Owner; role promotion Owner only)
- `POST /api/staff/risk-flags/:id/decision` (Moderator / Finance / Owner)
- `GET /api/staff/audit-logs` (Moderator / Finance / Owner)
- `POST /api/staff/policies` (Moderator / Owner)
- `GET /api/shop` | `POST /api/shop/:itemId/buy` | `POST /api/shop/:itemId/equip`
- `GET /api/teams` | `POST /api/teams` | `POST /api/teams/:id/invite` | `POST /api/teams/invites/:inviteId/respond`
- `GET /api/rewards` | `POST /api/rewards/claim`
- `GET /api/streams` | `GET /api/policies` | `GET /api/platform/stats`
- `GET /api/support/tickets` | `POST /api/support/tickets` | `POST /api/support/tickets/:id/status`

### WebSocket (`server/ws.ts`)
- Connect at `/ws`
- Client messages: `{ type: "subscribe", matchId }` / `{ type: "unsubscribe", matchId }`
- Server pushes: `match:update` and `match:chat`

---

## 6. Quick Start & Demo Credentials
```bash
npm install
cp .env.example .env
npm run dev      # Starts Express + Vite on http://localhost:3000
npm run lint     # tsc --noEmit
npm run build    # Production Vite build
node scripts/verify_e2e.mjs
```

Seeded demo accounts (password: `DemoSFT!2026`):
- **Owner**: `ivvy`
- **Moderator**: `KovaMod`
- **Finance**: `LedgerOps`
- **Players**: `VortexFN`, `Sloocwtw07`, `ClixCloneEU`, `WestCoastZex`
