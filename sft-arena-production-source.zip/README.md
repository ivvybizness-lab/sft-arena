# SFT — Solana Fortnite Tokens (`solanafortnitetokens.com`)

Full-stack competitive Fortnite matchmaking, tournament orchestration, SOL-only ledger & escrow wallet, and role-enforced Staff & Owner Analytics platform.

---

## Core Architecture

- **Frontend**: React 19, React Router v7, Tailwind CSS v4, TypeScript, WebSocket room client (`/ws`).
- **Backend**: Node.js + Express + `ws` (`server.ts`, `./server/*`), served alongside Vite in development or built static `dist/` in production.
- **Database**: SQLite in WAL mode (`better-sqlite3`, `foreign_keys = ON`, `BEGIN IMMEDIATE` serialization) with numbered SQL migrations in `migrations/`.
- **Accounting**: Integer lamports (`1 SOL = 1,000,000,000 lamports`), append-only `ledger_entries` with strict `idempotency_key` deduplication across `available`, `reserved`, and `frozen` buckets.
- **Solana Integration**: `@solana/web3.js` Devnet RPC deposit watcher (`syncSolanaDevnetDeposits`), unique 9-decimal deposit invoice matching, persistent watcher cursor, and pre-signed withdrawal persistence with idempotent reconciliation retries.

---

## Local Development Setup

1. **Install dependencies**:
   ```bash
   npm install
   ```

2. **Configure environment variables**:
   Copy `.env.example` to `.env` and fill in values as needed (never commit `.env` or secrets):
   - `SESSION_SECRET`: Strong random secret used to sign/hash session tokens and device fingerprints.
   - `SOLANA_NETWORK`: `devnet` (default) or `demo`.
   - `SOLANA_RPC_URL`: Solana RPC endpoint (defaults to `https://api.devnet.solana.com`).
   - `SOLANA_TREASURY_SECRET_KEY`: Base58 or JSON byte-array keypair for server-side SOL treasury operations (optional in `devnet`/`demo`; required for live broadcasts & `mainnet`).

3. **Run development server (port 3000)**:
   ```bash
   npm run dev
   ```
   Startup automatically runs numbered SQLite migrations (`migrations/001_init.sql`) and seeds `[Demo]` accounts, current Creative maps, cosmetics, and sample tournaments idempotently.

4. **Typecheck, build & E2E verification**:
   ```bash
   npm run lint
   npm run build
   node scripts/verify_e2e.mjs
   ```

---

## Database Migrations

- Numbered SQL files live in `/migrations/` (e.g. `001_init.sql`).
- `runMigrations()` in `server/db.ts` tracks applied files inside `_migrations` and executes pending `.sql` migrations inside serialized transactions on startup.
- Default database path: `data/sft.sqlite` (override via `SFT_DB_PATH`), private evidence storage: `data/evidence/` (outside static `public/` serving, gated by participant/staff auth checks).

---

## Demo Accounts (Seeded for Testing)

All seeded `[Demo]` accounts use the development password `DemoSFT!2026` (or the one-click Demo buttons inside the Sign In modal):

| Role | Username | Notes |
| --- | --- | --- |
| Owner | `ivvy` | Full access to Business Analytics, Finance Config, Disputes, Accounts |
| Moderator | `KovaMod` | Dispute resolution, match result overrides, bracket & user moderation |
| Finance | `LedgerOps` | Deposit exception approval, withdrawal retry reconciliation, ledger audit |
| Player | `VortexFN` | Verified 18+ player account with seeded SOL balance |
| Player | `Sloocwtw07` | Verified 18+ player account for 2-player match & chat testing |

---

## Production & Mainnet Readiness Checklist

Before switching `wallet_config.network_mode` to `mainnet`:
1. Set a strong production `SESSION_SECRET` and configure `APP_URL` to your HTTPS domain (`https://solanafortnitetokens.com`).
2. Supply `SOLANA_RPC_URL` (dedicated Helius/QuickNode/Triton Mainnet RPC) and `SOLANA_TREASURY_SECRET_KEY` (multisig/hot treasury funded only for operational float) in server environment secrets.
3. Explicitly enable `mainnet` and `paidMatchesEnabled` in **Staff Console → Finance & Solana Reconciliation → Owner Wallet Config**.
4. Disable or wipe demo accounts/records before opening public registration (`is_demo = 1`).
5. Run behind a TLS-terminating reverse proxy and take scheduled encrypted backups of `data/sft.sqlite` and `data/evidence/`.
