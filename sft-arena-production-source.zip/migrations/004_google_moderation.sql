CREATE TABLE google_identities (
  subject TEXT PRIMARY KEY,
  user_id TEXT NOT NULL UNIQUE REFERENCES users(id)
);
CREATE TABLE google_challenges (
  digest TEXT PRIMARY KEY,
  expires_at INTEGER NOT NULL
);
CREATE TABLE player_moderation (
  user_id TEXT PRIMARY KEY REFERENCES users(id),
  chat_banned INTEGER NOT NULL DEFAULT 0,
  force_stream INTEGER NOT NULL DEFAULT 0,
  lock_tipping INTEGER NOT NULL DEFAULT 0,
  force_anticheat INTEGER NOT NULL DEFAULT 0,
  staff_verified INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE staff_notes (
  id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id),
  author_id TEXT NOT NULL REFERENCES users(id), body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX staff_notes_user ON staff_notes(user_id, created_at);
