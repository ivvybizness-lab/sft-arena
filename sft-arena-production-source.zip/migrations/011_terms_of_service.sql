UPDATE policy_versions SET is_active = 0 WHERE policy_type = 'terms';
INSERT INTO policy_versions (id, policy_type, version, title, content_md, is_active)
VALUES ('pol_terms_v3', 'terms', 'v3.0', 'Terms of Service', '1. Acceptance of Terms
1.1. By accessing or using our website, you agree to these Terms of Service ("Terms"), forming a legally binding agreement between you and SFT.GG Limited. Please read these Terms carefully before proceeding.
2. Changes to Terms
2.1. SFT.GG Limited reserves the right to update these Terms at any time. Changes will become effective immediately upon posting on our website. Users will be notified of significant updates via a banner or other prominent notification.
3. Eligibility and Access
3.1. To use SFT, you must:
* Be at least 18 years old;
* Comply with the laws of your jurisdiction;
* Use the website solely for lawful purposes;
* Adhere to these Terms at all times.
4. Registration and Account Use
4.1. Users must create an account to access the platform. Registration is free, and each individual is allowed one account.
4.2. Users must provide accurate and complete information during registration. False or misleading information is prohibited.
4.3. Refunds for virtual currency or other digital assets are not permitted.
4.4. Accounts may be terminated or restricted at SFT''s discretion.
5. User Responsibilities
5.1. Users are responsible for safeguarding their account credentials and regularly updating passwords.
5.2. SFT must be notified immediately of any suspected unauthorized access to an account.
6. Fees and Withdrawals
6.1. Per Game Fee: SFT charges a 5% fee on the total game amount. Winners receive 95% of the total game amount as their prize.
6.2. Withdrawal Fees:
* Normal Withdrawal: 5% of the withdrawal amount plus $1.
* VIP Withdrawal: 5% of the withdrawal amount plus $0.50.
6.3. Withdrawal Processing Time:
Withdrawals typically take 2–5 working days to process. Delays may occur due to bank holidays, payment provider issues, or other unforeseen circumstances.
6.4. Discord Server Requirement:
Users must be members of the SFT Discord server during the withdrawal process. This allows the support team to contact users for verification or to address any issues related to their withdrawal.
6.5. Withdrawal Conditions:
* SFT reserves the right to request additional verification for withdrawals if deemed necessary to ensure the security of the platform and its users.
* Withdrawals may be denied or delayed if suspicious activity is detected or if the user fails to meet the verification requirements.
6.6. Purchase Fee: SFT does not charge any fees for purchasing tokens.
6.7. Payment Processing: The SFT Arena demo uses simulated SOL. Real deposits and payment processing are unavailable in the demo.
6.8. Fee rates are subject to change, and users will be notified in advance of any adjustments.
7. Games, Fees, and Winnings
7.1. Participation fees for games will be deducted from the user''s account upon registration.
7.2. Winners will receive 95% of the total game fees as their prize. The remaining 5% is retained as administrative and platform fees.
7.3. Winnings will be credited to the user''s virtual wallet immediately or within 24 hours in case of technical delays.
7.4. No Purchase Fees: SFT does not charge any fees for purchased funds into your account.
7.5. Demo Balances: Simulated SOL balances and winnings have no cash value and cannot be withdrawn as real funds.
7.6. Match Results: SFT reserves the right to alter the result of completed or ongoing matches if it is determined that the match was not played in accordance with the rules or if any suspicious activity is detected.
8. Prohibited Activities
8.1. Users are prohibited from:
* Engaging in unlawful, fraudulent, or harmful activities;
* Facilitating or encouraging others to breach these Terms;
* Attempting to trade virtual assets for real-world currency or other compensation outside the platform.
8.2. Violations may result in account suspension or termination without prior notice.
9. Security Measures
9.1. SFT implements advanced security measures, including:
* Technical safeguards;
* Physical access controls;
* Systems to detect and prevent unauthorized access or misuse.
10. Chat Bans
10.1. SFT reserves the right to impose chat bans on players who violate the platform''s code of conduct or engage in inappropriate behaviour during matches.
10.2. Duration of Chat Bans: Chat bans can be temporary or permanent, depending on the severity of the violation.
10.3. Impact of Chat Bans: Players who are chat banned will be restricted from using the chat feature in matches. The duration and conditions of the ban will be determined by SFT.
10.4. Appeals: Players may appeal chat bans by contacting SFT support. The appeal process will be reviewed, and decisions will be made at SFT''s discretion.
11. Promotions and Offers
11.1. Eligibility: Promotions and offers are available to users who meet the specified requirements, such as minimum deposit amounts, registration status, or other criteria outlined in each promotion''s terms.
11.2. Terms and Conditions: Each promotion or offer is subject to its own specific terms, which will be clearly stated at the time the promotion is offered. These terms may include expiry dates, usage limits, or other restrictions.
11.3. Right to Modify or Cancel: SFT reserves the right to modify, extend, or cancel any promotion or offer at its sole discretion, at any time, without prior notice.
11.4. Abuse of Promotions: Any user found to be abusing or exploiting promotions in any way will be disqualified from the offer, and their account may be suspended or terminated.
12. Entire Agreement
12.1. These Terms, along with the Privacy Policy and any additional policies referenced, constitute the entire agreement between the user and SFT.GG Limited.
12.2. They supersede any prior agreements, whether written or oral.
13. Contact Us
If you have any questions about these Terms of Service, please contact us through our support channels.', 1);
