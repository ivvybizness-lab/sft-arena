CREATE TABLE evidence_blob_bytes (
  evidence_id TEXT PRIMARY KEY REFERENCES evidence_files(id) ON DELETE CASCADE,
  contents BLOB NOT NULL
);
