-- Migration 001: Core SFT Relational Schema (SQLite WAL + Strict Constraints)
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_migrations (
  version TEXT PRIMARY KEY,
  applied_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  display_name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  email_verified INTEGER NOT NULL DEFAULT 0 CHECK (email_verified IN (0, 1)),
  phone TEXT,
  phone_verified INTEGER NOT NULL DEFAULT 0 CHECK (phone_verified IN (0, 1)),
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'player' CHECK (role IN ('player', 'moderator', 'finance', 'owner')),
  country TEXT NOT NULL DEFAULT 'US',
  competitive_region TEXT NOT NULL DEFAULT 'NAE' CHECK (competitive_region IN ('NAE', 'NAC', 'NAW', 'EU')),
  age_verified INTEGER NOT NULL DEFAULT 0 CHECK (age_verified IN (0, 1)),
  age_verification_ref TEXT,
  epic_display_name TEXT NOT NULL DEFAULT '',
  epic_account_id TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'restricted', 'suspended', 'banned')),
  referral_code TEXT NOT NULL UNIQUE,
  referred_by_user_id TEXT REFERENCES users(id),
  acquisition_source TEXT NOT NULL DEFAULT 'organic',
  risk_score INTEGER NOT NULL DEFAULT 0 CHECK (risk_score >= 0 AND risk_score <= 100),
  twitch_channel TEXT,
  twitch_authorized INTEGER NOT NULL DEFAULT 0 CHECK (twitch_authorized IN (0, 1)),
  avatar_url TEXT NOT NULL DEFAULT '',
  active_title TEXT NOT NULL DEFAULT '',
  active_border TEXT NOT NULL DEFAULT 'default',
  payout_address TEXT NOT NULL DEFAULT '',
  wins INTEGER NOT NULL DEFAULT 0,
  losses INTEGER NOT NULL DEFAULT 0,
  elo INTEGER NOT NULL DEFAULT 1000,
  xp INTEGER NOT NULL DEFAULT 0,
  is_demo INTEGER NOT NULL DEFAULT 0 CHECK (is_demo IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_region ON users(competitive_region);
CREATE INDEX IF NOT EXISTS idx_users_elo ON users(elo DESC);

CREATE TABLE IF NOT EXISTS user_sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  device_id TEXT NOT NULL,
  browser TEXT NOT NULL DEFAULT '',
  os TEXT NOT NULL DEFAULT '',
  ip_hash TEXT NOT NULL DEFAULT '',
  ip_country TEXT NOT NULL DEFAULT 'US',
  is_vpn_proxy INTEGER NOT NULL DEFAULT 0,
  last_seen_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  expires_at TEXT NOT NULL,
  revoked_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON user_sessions(user_id);

CREATE TABLE IF NOT EXISTS username_history (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  previous_username TEXT NOT NULL,
  new_username TEXT NOT NULL,
  changed_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_username_history_user ON username_history(user_id);

CREATE TABLE IF NOT EXISTS linked_accounts_history (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider TEXT NOT NULL CHECK (provider IN ('epic', 'twitch', 'solana_wallet')),
  previous_value TEXT NOT NULL,
  new_value TEXT NOT NULL,
  changed_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_linked_history_user ON linked_accounts_history(user_id);

CREATE TABLE IF NOT EXISTS account_status_history (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  previous_status TEXT NOT NULL,
  new_status TEXT NOT NULL,
  actor_user_id TEXT REFERENCES users(id),
  reason TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS policy_versions (
  id TEXT PRIMARY KEY,
  policy_type TEXT NOT NULL CHECK (policy_type IN ('terms', 'privacy', 'competition_rules')),
  version TEXT NOT NULL,
  title TEXT NOT NULL,
  content_md TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  published_by_user_id TEXT REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE(policy_type, version)
);

CREATE TABLE IF NOT EXISTS policy_acceptances (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  policy_type TEXT NOT NULL,
  policy_version TEXT NOT NULL,
  accepted_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  ip_hash TEXT NOT NULL DEFAULT '',
  UNIQUE(user_id, policy_type, policy_version)
);

CREATE TABLE IF NOT EXISTS teams (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  tag TEXT NOT NULL,
  region TEXT NOT NULL CHECK (region IN ('NAE', 'NAC', 'NAW', 'EU')),
  captain_user_id TEXT NOT NULL REFERENCES users(id),
  is_demo INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS team_members (
  id TEXT PRIMARY KEY,
  team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('captain', 'starter', 'sub')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'left', 'removed')),
  joined_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE(team_id, user_id)
);

CREATE TABLE IF NOT EXISTS team_invites (
  id TEXT PRIMARY KEY,
  team_id TEXT NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  invited_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  invited_by_user_id TEXT NOT NULL REFERENCES users(id),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'declined', 'revoked')),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  responded_at TEXT
);

CREATE TABLE IF NOT EXISTS maps (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  mode TEXT NOT NULL CHECK (mode IN ('Zone Wars', 'Realistics', 'Box Fights', 'Build Fights', 'Piece Control', 'Zero Build')),
  code TEXT NOT NULL,
  creator TEXT NOT NULL,
  loadout_summary TEXT NOT NULL,
  rules_json TEXT NOT NULL,
  is_featured INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS matches (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  is_private INTEGER NOT NULL DEFAULT 0 CHECK (is_private IN (0, 1)),
  is_ranked INTEGER NOT NULL DEFAULT 0 CHECK (is_ranked IN (0, 1)),
  is_demo INTEGER NOT NULL DEFAULT 0 CHECK (is_demo IN (0, 1)),
  format TEXT NOT NULL CHECK (format IN ('1v1', '2v2', '3v3', '4v4')),
  mode TEXT NOT NULL CHECK (mode IN ('Zone Wars', 'Realistics', 'Box Fights', 'Build Fights', 'Piece Control', 'Zero Build')),
  platform TEXT NOT NULL DEFAULT 'All' CHECK (platform IN ('All', 'PC', 'Console')),
  region TEXT NOT NULL CHECK (region IN ('NAE', 'NAC', 'NAW', 'EU')),
  game_server_region TEXT NOT NULL,
  stake_basis TEXT NOT NULL DEFAULT 'per_player' CHECK (stake_basis IN ('per_player', 'per_team')),
  entry_lamports INTEGER NOT NULL DEFAULT 0 CHECK (entry_lamports >= 0),
  total_prize_lamports INTEGER NOT NULL DEFAULT 0 CHECK (total_prize_lamports >= 0),
  platform_fee_lamports INTEGER NOT NULL DEFAULT 0 CHECK (platform_fee_lamports >= 0),
  first_to INTEGER NOT NULL DEFAULT 5 CHECK (first_to >= 1 AND first_to <= 25),
  movement_type TEXT NOT NULL DEFAULT 'Creative',
  map_id TEXT REFERENCES maps(id),
  map_code TEXT NOT NULL,
  creator_user_id TEXT NOT NULL REFERENCES users(id),
  creator_team_id TEXT REFERENCES teams(id),
  lobby_code TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'Waiting' CHECK (status IN ('Waiting', 'Ready', 'In Progress', 'Disputed', 'Complete', 'Cancelled')),
  winner_side TEXT CHECK (winner_side IN ('A', 'B') OR winner_side IS NULL),
  score_a INTEGER NOT NULL DEFAULT 0,
  score_b INTEGER NOT NULL DEFAULT 0,
  chat_open INTEGER NOT NULL DEFAULT 1 CHECK (chat_open IN (0, 1)),
  cancelled_reason TEXT,
  started_at TEXT,
  completed_at TEXT,
  expires_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_matches_status ON matches(status);
CREATE INDEX IF NOT EXISTS idx_matches_filters ON matches(mode, format, region, platform, status);
CREATE INDEX IF NOT EXISTS idx_matches_created ON matches(created_at DESC);

CREATE TABLE IF NOT EXISTS match_participants (
  id TEXT PRIMARY KEY,
  match_id TEXT NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  team_side TEXT NOT NULL CHECK (team_side IN ('A', 'B')),
  user_id TEXT NOT NULL REFERENCES users(id),
  roster_id TEXT REFERENCES teams(id),
  username_snapshot TEXT NOT NULL,
  display_name_snapshot TEXT NOT NULL,
  epic_name_snapshot TEXT NOT NULL,
  active_title_snapshot TEXT NOT NULL DEFAULT '',
  is_captain INTEGER NOT NULL DEFAULT 0 CHECK (is_captain IN (0, 1)),
  ready_state INTEGER NOT NULL DEFAULT 0 CHECK (ready_state IN (0, 1)),
  reported_winner_side TEXT CHECK (reported_winner_side IN ('A', 'B') OR reported_winner_side IS NULL),
  reported_score_a INTEGER,
  reported_score_b INTEGER,
  reported_at TEXT,
  stake_reserved_lamports INTEGER NOT NULL DEFAULT 0 CHECK (stake_reserved_lamports >= 0),
  joined_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE(match_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_match_participants_match ON match_participants(match_id);
CREATE INDEX IF NOT EXISTS idx_match_participants_user ON match_participants(user_id);

CREATE TABLE IF NOT EXISTS match_events (
  id TEXT PRIMARY KEY,
  match_id TEXT NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL,
  actor_user_id TEXT REFERENCES users(id),
  summary TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_match_events_match ON match_events(match_id);

CREATE TABLE IF NOT EXISTS match_chat_messages (
  id TEXT PRIMARY KEY,
  match_id TEXT NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  user_id TEXT REFERENCES users(id),
  sender_name TEXT NOT NULL,
  sender_role TEXT NOT NULL DEFAULT 'player',
  message_type TEXT NOT NULL DEFAULT 'user' CHECK (message_type IN ('user', 'system', 'staff')),
  body TEXT NOT NULL,
  attachment_evidence_id TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_match_chat_match ON match_chat_messages(match_id, created_at);

CREATE TABLE IF NOT EXISTS match_result_revisions (
  id TEXT PRIMARY KEY,
  match_id TEXT NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  version_num INTEGER NOT NULL,
  prior_winner_side TEXT,
  prior_score_a INTEGER,
  prior_score_b INTEGER,
  new_winner_side TEXT,
  new_score_a INTEGER NOT NULL,
  new_score_b INTEGER NOT NULL,
  actor_user_id TEXT REFERENCES users(id),
  reason TEXT NOT NULL,
  financial_correction_lamports INTEGER NOT NULL DEFAULT 0,
  ledger_tx_group_id TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_result_revisions_match ON match_result_revisions(match_id);

CREATE TABLE IF NOT EXISTS disputes (
  id TEXT PRIMARY KEY,
  match_id TEXT NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  opened_by_user_id TEXT NOT NULL REFERENCES users(id),
  reason TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open', 'Under Review', 'Resolved', 'Dismissed')),
  assigned_staff_id TEXT REFERENCES users(id),
  resolution_notes TEXT,
  resolved_winner_side TEXT CHECK (resolved_winner_side IN ('A', 'B') OR resolved_winner_side IS NULL),
  resolved_by_user_id TEXT REFERENCES users(id),
  resolved_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_disputes_status ON disputes(status);

CREATE TABLE IF NOT EXISTS evidence_files (
  id TEXT PRIMARY KEY,
  match_id TEXT NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  dispute_id TEXT REFERENCES disputes(id),
  uploader_user_id TEXT NOT NULL REFERENCES users(id),
  original_filename TEXT NOT NULL,
  stored_filename TEXT NOT NULL UNIQUE,
  mime_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  sha256 TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_evidence_match ON evidence_files(match_id);

CREATE TABLE IF NOT EXISTS tournaments (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  subtitle TEXT NOT NULL DEFAULT '',
  is_demo INTEGER NOT NULL DEFAULT 0,
  mode TEXT NOT NULL CHECK (mode IN ('Zone Wars', 'Realistics', 'Box Fights', 'Build Fights', 'Piece Control', 'Zero Build')),
  format TEXT NOT NULL CHECK (format IN ('1v1', '2v2', '3v3', '4v4')),
  region TEXT NOT NULL CHECK (region IN ('NAE', 'NAC', 'NAW', 'EU')),
  platform TEXT NOT NULL DEFAULT 'All',
  entry_lamports INTEGER NOT NULL DEFAULT 0 CHECK (entry_lamports >= 0),
  prize_pool_lamports INTEGER NOT NULL DEFAULT 0 CHECK (prize_pool_lamports >= 0),
  max_teams INTEGER NOT NULL CHECK (max_teams >= 2),
  accent_color TEXT NOT NULL DEFAULT '#6d4aff',
  registration_opens_at TEXT NOT NULL,
  registration_closes_at TEXT NOT NULL,
  checkin_opens_at TEXT NOT NULL,
  starts_at TEXT NOT NULL,
  ends_at TEXT,
  status TEXT NOT NULL DEFAULT 'Registration Open' CHECK (status IN ('Upcoming', 'Registration Open', 'Check-In', 'Live', 'Completed', 'Cancelled')),
  rules_json TEXT NOT NULL DEFAULT '[]',
  created_by_user_id TEXT REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS tournament_registrations (
  id TEXT PRIMARY KEY,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  team_name TEXT NOT NULL,
  captain_user_id TEXT NOT NULL REFERENCES users(id),
  team_id TEXT REFERENCES teams(id),
  member_snapshots_json TEXT NOT NULL DEFAULT '[]',
  seed INTEGER,
  checked_in INTEGER NOT NULL DEFAULT 0 CHECK (checked_in IN (0, 1)),
  checked_in_at TEXT,
  eliminated_round INTEGER,
  final_rank INTEGER,
  status TEXT NOT NULL DEFAULT 'Registered' CHECK (status IN ('Registered', 'Checked In', 'Withdrawn', 'Disqualified')),
  entry_paid_lamports INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE(tournament_id, captain_user_id)
);

CREATE TABLE IF NOT EXISTS tournament_matches (
  id TEXT PRIMARY KEY,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  round_number INTEGER NOT NULL,
  match_slot INTEGER NOT NULL,
  reg_a_id TEXT REFERENCES tournament_registrations(id),
  reg_b_id TEXT REFERENCES tournament_registrations(id),
  winner_reg_id TEXT REFERENCES tournament_registrations(id),
  score_a INTEGER NOT NULL DEFAULT 0,
  score_b INTEGER NOT NULL DEFAULT 0,
  linked_match_id TEXT REFERENCES matches(id),
  status TEXT NOT NULL DEFAULT 'Scheduled' CHECK (status IN ('Scheduled', 'Ready', 'Live', 'Complete', 'Bye')),
  completed_at TEXT
);

CREATE TABLE IF NOT EXISTS tournament_payouts (
  id TEXT PRIMARY KEY,
  tournament_id TEXT NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  registration_id TEXT NOT NULL REFERENCES tournament_registrations(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  rank_position INTEGER NOT NULL,
  amount_lamports INTEGER NOT NULL,
  ledger_entry_id TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS wallet_config (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  network_mode TEXT NOT NULL DEFAULT 'devnet' CHECK (network_mode IN ('demo', 'devnet', 'mainnet')),
  mainnet_enabled INTEGER NOT NULL DEFAULT 0 CHECK (mainnet_enabled IN (0, 1)),
  paid_matches_enabled INTEGER NOT NULL DEFAULT 1 CHECK (paid_matches_enabled IN (0, 1)),
  fee_bps INTEGER NOT NULL DEFAULT 500 CHECK (fee_bps >= 0 AND fee_bps <= 2500),
  min_withdrawal_lamports INTEGER NOT NULL DEFAULT 10000000,
  treasury_address TEXT NOT NULL DEFAULT '',
  updated_by_user_id TEXT REFERENCES users(id),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS user_balances (
  user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  available_lamports INTEGER NOT NULL DEFAULT 0 CHECK (available_lamports >= 0),
  reserved_lamports INTEGER NOT NULL DEFAULT 0 CHECK (reserved_lamports >= 0),
  frozen_lamports INTEGER NOT NULL DEFAULT 0 CHECK (frozen_lamports >= 0),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS deposit_invoices (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  network TEXT NOT NULL,
  treasury_address TEXT NOT NULL,
  base_lamports INTEGER NOT NULL CHECK (base_lamports > 0),
  unique_suffix_lamports INTEGER NOT NULL CHECK (unique_suffix_lamports > 0),
  expected_lamports INTEGER NOT NULL CHECK (expected_lamports > 0),
  status TEXT NOT NULL DEFAULT 'Waiting' CHECK (status IN ('Waiting', 'Matched', 'Expired', 'Needs Review')),
  matched_signature TEXT,
  matched_instruction_index INTEGER,
  received_lamports INTEGER,
  matched_sender_address TEXT,
  matched_at TEXT,
  expires_at TEXT NOT NULL,
  review_note TEXT,
  reviewed_by_user_id TEXT REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_deposit_invoices_user ON deposit_invoices(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_deposit_invoices_expected ON deposit_invoices(expected_lamports, status);

CREATE TABLE IF NOT EXISTS solana_watcher_cursor (
  network TEXT PRIMARY KEY,
  last_signature TEXT,
  last_slot INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS processed_chain_transfers (
  id TEXT PRIMARY KEY,
  network TEXT NOT NULL,
  tx_signature TEXT NOT NULL,
  instruction_index INTEGER NOT NULL,
  from_address TEXT NOT NULL,
  to_address TEXT NOT NULL,
  lamports INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('Matched', 'Unmatched', 'Wrong Amount', 'Late', 'Duplicate Ignored', 'Resolved')),
  matched_invoice_id TEXT REFERENCES deposit_invoices(id),
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE(network, tx_signature, instruction_index)
);

CREATE TABLE IF NOT EXISTS withdrawal_requests (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  network TEXT NOT NULL,
  destination_address TEXT NOT NULL,
  amount_lamports INTEGER NOT NULL CHECK (amount_lamports > 0),
  fee_lamports INTEGER NOT NULL DEFAULT 0 CHECK (fee_lamports >= 0),
  status TEXT NOT NULL DEFAULT 'Queued' CHECK (status IN ('Queued', 'Processing', 'Confirmed', 'Failed', 'Needs Review')),
  tx_signature TEXT,
  signed_tx_base64 TEXT,
  attempt_count INTEGER NOT NULL DEFAULT 0,
  idempotency_key TEXT NOT NULL UNIQUE,
  last_error TEXT,
  reviewed_by_user_id TEXT REFERENCES users(id),
  confirmed_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_withdrawals_user ON withdrawal_requests(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_withdrawals_status ON withdrawal_requests(status);

CREATE TABLE IF NOT EXISTS ledger_entries (
  id TEXT PRIMARY KEY,
  tx_group_id TEXT NOT NULL,
  idempotency_key TEXT NOT NULL UNIQUE,
  user_id TEXT NOT NULL REFERENCES users(id),
  entry_type TEXT NOT NULL CHECK (entry_type IN (
    'deposit_credit', 'withdrawal_reserve', 'withdrawal_confirm', 'withdrawal_refund',
    'match_stake_reserve', 'match_stake_release', 'match_win_payout', 'match_fee',
    'match_refund', 'match_override_adjustment', 'tournament_entry', 'tournament_refund',
    'tournament_payout', 'shop_purchase', 'reward_bonus', 'referral_bonus',
    'staff_freeze', 'staff_unfreeze', 'admin_adjustment'
  )),
  bucket TEXT NOT NULL CHECK (bucket IN ('available', 'reserved', 'frozen')),
  delta_lamports INTEGER NOT NULL,
  balance_after_lamports INTEGER NOT NULL,
  reference_type TEXT NOT NULL,
  reference_id TEXT NOT NULL,
  network TEXT NOT NULL DEFAULT 'devnet',
  description TEXT NOT NULL,
  actor_user_id TEXT REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_ledger_user ON ledger_entries(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ledger_ref ON ledger_entries(reference_type, reference_id);
CREATE INDEX IF NOT EXISTS idx_ledger_type ON ledger_entries(entry_type, created_at);

CREATE TABLE IF NOT EXISTS shop_items (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('Title', 'Avatar Border', 'Profile Banner', 'Badge')),
  rarity TEXT NOT NULL CHECK (rarity IN ('Common', 'Rare', 'Epic', 'Mythic')),
  price_lamports INTEGER NOT NULL CHECK (price_lamports >= 0),
  preview_value TEXT NOT NULL,
  is_featured INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS user_inventory (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  item_id TEXT NOT NULL REFERENCES shop_items(id),
  purchased_lamports INTEGER NOT NULL,
  equipped INTEGER NOT NULL DEFAULT 0 CHECK (equipped IN (0, 1)),
  acquired_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE(user_id, item_id)
);

CREATE TABLE IF NOT EXISTS rewards_claims (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reward_key TEXT NOT NULL,
  reward_label TEXT NOT NULL,
  amount_lamports INTEGER NOT NULL,
  claim_period TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE(user_id, reward_key, claim_period)
);

CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  link_url TEXT NOT NULL DEFAULT '/',
  is_read INTEGER NOT NULL DEFAULT 0 CHECK (is_read IN (0, 1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read, created_at DESC);

CREATE TABLE IF NOT EXISTS twitch_streams (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel_name TEXT NOT NULL UNIQUE,
  stream_title TEXT NOT NULL,
  game_mode TEXT NOT NULL DEFAULT 'Box Fights',
  viewer_count INTEGER NOT NULL DEFAULT 0,
  is_live INTEGER NOT NULL DEFAULT 1,
  is_authorized INTEGER NOT NULL DEFAULT 1,
  thumbnail_accent TEXT NOT NULL DEFAULT '#6d4aff',
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS support_tickets (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  subject TEXT NOT NULL,
  description TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open', 'In Progress', 'Resolved', 'Closed')),
  assigned_staff_id TEXT REFERENCES users(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS support_messages (
  id TEXT PRIMARY KEY,
  ticket_id TEXT NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id),
  body TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS security_login_events (
  id TEXT PRIMARY KEY,
  user_id TEXT REFERENCES users(id),
  username_or_email TEXT NOT NULL,
  event_type TEXT NOT NULL CHECK (event_type IN ('login_success', 'login_failed', 'password_reset', 'new_device', 'logout')),
  ip_hash TEXT NOT NULL,
  country TEXT NOT NULL DEFAULT 'US',
  device_id TEXT NOT NULL,
  browser TEXT NOT NULL DEFAULT '',
  os TEXT NOT NULL DEFAULT '',
  is_vpn_proxy INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_sec_events_user ON security_login_events(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sec_events_ip ON security_login_events(ip_hash);
CREATE INDEX IF NOT EXISTS idx_sec_events_device ON security_login_events(device_id);

CREATE TABLE IF NOT EXISTS risk_flags (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  flag_type TEXT NOT NULL CHECK (flag_type IN (
    'shared_ip_device', 'shared_payout_address', 'repeated_opponents',
    'win_trading_suspected', 'rapid_deposit_withdraw', 'referral_bonus_abuse',
    'vpn_proxy_login', 'manual_review'
  )),
  severity TEXT NOT NULL CHECK (severity IN ('low', 'medium', 'high', 'critical')),
  details_json TEXT NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open', 'Investigating', 'Cleared', 'Confirmed')),
  reviewed_by_user_id TEXT REFERENCES users(id),
  decision_note TEXT,
  reviewed_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_risk_flags_status ON risk_flags(status, severity);

CREATE TABLE IF NOT EXISTS analytics_sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  duration_seconds INTEGER NOT NULL DEFAULT 0,
  started_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  ended_at TEXT
);

CREATE TABLE IF NOT EXISTS matchmaking_attempts (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  mode TEXT NOT NULL,
  format TEXT NOT NULL,
  region TEXT NOT NULL,
  entry_lamports INTEGER NOT NULL,
  matched INTEGER NOT NULL DEFAULT 0,
  wait_seconds INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  actor_user_id TEXT REFERENCES users(id),
  actor_role TEXT NOT NULL DEFAULT 'system',
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  summary TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type, entity_id);
