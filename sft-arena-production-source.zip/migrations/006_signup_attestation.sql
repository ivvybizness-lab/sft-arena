ALTER TABLE users ADD COLUMN age_attested_at TEXT;

UPDATE users
SET age_attested_at = COALESCE(updated_at, created_at), age_verified = 0
WHERE age_verification_ref = 'self_attested_18plus';

-- Earlier password registrations were marked verified at signup without a verification reference.
UPDATE users
SET age_verified = 0
WHERE age_verified = 1 AND age_verification_ref IS NULL;
