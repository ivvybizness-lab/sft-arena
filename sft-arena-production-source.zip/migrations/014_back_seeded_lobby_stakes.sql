-- The original demo lobbies recorded creator stakes without backing them in the ledger.
CREATE TEMP TABLE seeded_lobby_stakes AS
SELECT p.id, p.user_id, p.match_id, p.stake_reserved_lamports,
       SUM(p.stake_reserved_lamports) OVER (PARTITION BY p.user_id ORDER BY p.id) AS running_total
FROM match_participants p
JOIN matches m ON m.id = p.match_id AND m.creator_user_id = p.user_id
JOIN users u ON u.id = p.user_id
WHERE m.id IN ('m_demo_open_1', 'm_demo_open_2', 'm_demo_open_3', 'm_demo_open_4')
  AND m.is_demo = 1 AND u.is_demo = 1 AND m.started_at IS NULL AND m.status IN ('Waiting', 'Ready')
  AND p.stake_reserved_lamports > 0
  AND EXISTS (SELECT 1 FROM wallet_config WHERE id = 1 AND network_mode = 'demo')
  AND NOT EXISTS (SELECT 1 FROM ledger_entries WHERE idempotency_key = 'demo_lobby_stake_' || p.id);

INSERT INTO ledger_entries (id, tx_group_id, idempotency_key, user_id, entry_type, bucket,
  delta_lamports, balance_after_lamports, reference_type, reference_id, network, description)
SELECT 'led_demo_lobby_' || s.id, 'txg_demo_lobby_' || s.id, 'demo_lobby_stake_' || s.id,
  s.user_id, 'admin_adjustment', 'reserved', s.stake_reserved_lamports, b.reserved_lamports + s.running_total,
  'match', s.match_id, 'demo', 'Backed simulated stake for seeded match'
FROM seeded_lobby_stakes s JOIN user_balances b ON b.user_id = s.user_id;

UPDATE user_balances
SET reserved_lamports = reserved_lamports + (SELECT SUM(s.stake_reserved_lamports) FROM seeded_lobby_stakes s WHERE s.user_id = user_balances.user_id),
    updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
WHERE user_id IN (SELECT user_id FROM seeded_lobby_stakes);
DROP TABLE seeded_lobby_stakes;
