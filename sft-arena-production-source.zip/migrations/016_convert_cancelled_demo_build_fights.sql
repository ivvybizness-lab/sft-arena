UPDATE matches SET format = '1v1', title = '1v1 Build Fights',
  total_prize_lamports = 950000000, platform_fee_lamports = 50000000
WHERE id = 'm_demo_open_4' AND mode = 'Build Fights' AND format = '2v2'
  AND status IN ('Waiting', 'Ready', 'Cancelled') AND started_at IS NULL
  AND (SELECT COUNT(*) FROM match_participants WHERE match_id = matches.id AND team_side = 'A') = 1
  AND (SELECT COUNT(*) FROM match_participants WHERE match_id = matches.id AND team_side = 'B') <= 1;
