ALTER TABLE users ADD COLUMN profile_banner TEXT NOT NULL DEFAULT 'violet';
ALTER TABLE users ADD COLUMN profile_portrait INTEGER;
