UPDATE tournaments SET subtitle = 'Official Bracket'
WHERE id = 't_demo_2' AND (subtitle LIKE '%3298-5204-8076%' OR subtitle LIKE '%3537-4087-0888%');
UPDATE tournaments SET subtitle = 'Highground Open'
WHERE id = 't_demo_3' AND (subtitle LIKE '%1644-3182-3703%' OR subtitle LIKE '%7835-3901-1999%');
