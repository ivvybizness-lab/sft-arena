ALTER TABLE matches ADD COLUMN win_by_two INTEGER NOT NULL DEFAULT 0 CHECK (win_by_two IN (0,1));
UPDATE matches SET win_by_two = 1 WHERE is_demo = 1 AND status = 'Waiting';
