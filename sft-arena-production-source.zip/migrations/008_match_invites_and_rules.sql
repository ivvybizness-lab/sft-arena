ALTER TABLE users ADD COLUMN legacy_demo_match_eligible INTEGER NOT NULL DEFAULT 0 CHECK(legacy_demo_match_eligible IN (0,1));
UPDATE users SET legacy_demo_match_eligible=1;

ALTER TABLE matches ADD COLUMN loadout TEXT NOT NULL DEFAULT '';
ALTER TABLE matches ADD COLUMN rounds_lead INTEGER NOT NULL DEFAULT 0 CHECK(rounds_lead BETWEEN 0 AND 4);
ALTER TABLE matches ADD COLUMN disable_simple_edit INTEGER NOT NULL DEFAULT 0 CHECK(disable_simple_edit IN (0,1));

CREATE TABLE match_invites (
  match_id TEXT NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY(match_id,user_id)
);
CREATE INDEX idx_match_invites_user ON match_invites(user_id);
