import { build } from 'esbuild';
import { readFileSync, readdirSync } from 'node:fs';

const { dependencies } = JSON.parse(readFileSync('package.json', 'utf8'));
const migrations = readdirSync('migrations').filter((name) => name.endsWith('.sql')).sort()
  .map((name) => ({ name, sql: readFileSync(`migrations/${name}`, 'utf8') }));

// Bundle the Solana SDK and its mixed CJS/ESM dependencies so the hosted
// runtime never has to require an ESM-only dependency from CommonJS.
await build({
  entryPoints: ['api/sft-api.ts'],
  outfile: 'api/sft-api.js',
  bundle: true,
  platform: 'node',
  target: 'node24',
  format: 'esm',
  external: Object.keys(dependencies).filter((name) => name !== '@solana/web3.js'),
  banner: { js: "import { createRequire } from 'node:module'; const require = createRequire(import.meta.url);" },
  define: { __SFT_PACKAGED_MIGRATIONS__: JSON.stringify(migrations) },
  legalComments: 'none',
});
