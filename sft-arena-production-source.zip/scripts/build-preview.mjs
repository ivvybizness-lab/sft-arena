import { spawn } from 'node:child_process';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { setTimeout } from 'node:timers/promises';

function run(args, env) {
  return spawn(process.execPath, args, { env, stdio: 'inherit' });
}

const build = run(['node_modules/vite/bin/vite.js', 'build', '--mode', 'preview'], process.env);
const buildCode = await new Promise((resolve, reject) => {
  build.once('error', reject);
  build.once('exit', resolve);
});
if (buildCode !== 0) throw new Error('Preview build failed');

const dataDir = await mkdtemp(join(tmpdir(), 'sft-preview-'));
const port = 3817;
const base = `http://127.0.0.1:${port}`;
const server = run(['--experimental-transform-types', 'server.ts'], {
  PATH: process.env.PATH,
  NODE_ENV: 'production',
  PORT: String(port),
  SOLANA_NETWORK: 'demo',
  DATABASE_PATH: join(dataDir, 'preview.db'),
  EVIDENCE_STORAGE_DIR: join(dataDir, 'evidence'),
  SOLANA_TREASURY_ADDRESS: '11111111111111111111111111111111',
  DOTENV_CONFIG_PATH: join(dataDir, 'no-secrets.env'),
});
const serverExit = new Promise(resolve => server.once('exit', resolve));

async function get(path) {
  const response = await fetch(base + path, { signal: AbortSignal.timeout(5000) });
  if (!response.ok) throw new Error(`${path} returned ${response.status}`);
  return response.json();
}

try {
  let ready = false;
  for (let attempt = 0; attempt < 30 && server.exitCode === null; attempt++) {
    try { ready = (await get('/api/health')).status === 'ok'; } catch { }
    if (ready) break;
    await setTimeout(200);
  }
  if (!ready) throw new Error('The demo server did not become ready');

  const paths = ['/api/platform/stats','/api/matches?tab=all','/api/tournaments','/api/leaderboard',
    '/api/streams','/api/maps','/api/shop','/api/policies'];
  const publicData = await Promise.all(paths.map(get));
  const [, matchList, tournaments, leaderboard] = publicData;
  const detailPaths = [
    ...matchList.matches.map(match => '/api/matches/' + encodeURIComponent(match.id)),
    ...tournaments.tournaments.map(event => '/api/tournaments/' + encodeURIComponent(event.id)),
    ...leaderboard.leaderboard.map(player => '/api/users/' + encodeURIComponent(player.username)),
  ];
  const details = await Promise.all(detailPaths.map(get));
  const snapshot = Object.fromEntries([
    ...paths.map((path, index) => [path.split('?')[0], publicData[index]]),
    ...detailPaths.map((path, index) => [path, details[index]]),
  ]);
  await writeFile('dist/preview-data.json', JSON.stringify(snapshot));
  console.log(`Preview snapshot contains ${Object.keys(snapshot).length} public demo responses.`);
} finally {
  server.kill();
  await serverExit;
  await rm(dataDir, { recursive: true, force: true });
}
