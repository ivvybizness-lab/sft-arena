import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import WebSocket from 'ws';

const BASE = 'http://localhost:3000';
const httpOnly = process.env.SFT_TEST_HTTP_ONLY === '1';
const DEMO_PASS = 'DemoSFT!2026';

async function api(method, urlPath, body, token, isMultipart = false) {
  const headers = {};
  if (token) headers['Authorization'] = `Bearer ${token}`;
  if (!isMultipart && body !== undefined) headers['Content-Type'] = 'application/json';

  const res = await fetch(`${BASE}${urlPath}`, {
    method,
    headers,
    body: isMultipart ? body : body !== undefined ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let json = null;
  try {
    json = JSON.parse(text);
  } catch {
    json = { raw: text };
  }
  return { status: res.status, ok: res.ok, json, headers: res.headers };
}

async function login(identifier, password = DEMO_PASS) {
  const r = await api('POST', '/api/auth/login', { identifier, password });
  assert.equal(r.status, 200, `Login failed for ${identifier}: ${JSON.stringify(r.json)}`);
  assert.ok(r.json.token, 'Expected token from login');
  return r.json;
}

async function run() {
  console.log('=== SFT E2E Verification Suite ===');

  // Login key roles
  const owner = await login('ivvy');
  const mod = await login('KovaMod');
  const finance = await login('LedgerOps');
  const p1 = await login('VortexFN');
  const p2 = await login('Sloocwtw07');
  const p3 = await login('ClixCloneEU');
  const p4 = await login('WestCoastZex');

  // -------------------------------------------------------------------------
  // TEST 1: Match Creation, Persistence (/matches/:id), WebSocket + Chat
  // -------------------------------------------------------------------------
  console.log('\n[1/6] Testing Match Creation, Permanent Link Reopen & Live WebSocket Chat...');
  const p1BalBefore = (await api('GET', '/api/wallet', undefined, p1.token)).json.balance.available_lamports;
  const p2BalBefore = (await api('GET', '/api/wallet', undefined, p2.token)).json.balance.available_lamports;

  const entryLamports = 100_000_000; // 0.1 SOL
  const createRes = await api(
    'POST',
    '/api/matches',
    {
      title: 'E2E Box Fight Verification',
      format: '1v1',
      mode: 'Box Fights',
      platform: 'PC',
      region: 'NAE',
      stakeBasis: 'per_player',
      entryLamports,
      firstTo: 5,
    },
    p1.token
  );
  assert.equal(createRes.status, 201, `Match create failed: ${JSON.stringify(createRes.json)}`);
  const matchId = createRes.json.match.id;
  assert.ok(matchId.startsWith('m_'));

  // Subscribe via WebSocket before p2 joins & posts chat
  const wsEvents = [];
  let ws;
  if (!httpOnly) {
    ws = new WebSocket(`ws://127.0.0.1:3000/ws?token=${encodeURIComponent(p1.token)}`);
    await new Promise((resolve, reject) => {
      ws.on('open', () => {
        ws.send(JSON.stringify({ type: 'subscribe_match', matchId }));
        resolve();
      });
      ws.on('error', reject);
    });
    ws.on('message', (raw) => {
      try {
        wsEvents.push(JSON.parse(String(raw)));
      } catch {}
    });
  }

  // p2 joins match
  const joinRes = await api('POST', `/api/matches/${matchId}/join`, { teamSide: 'B' }, p2.token);
  assert.equal(joinRes.status, 200, `Join failed: ${JSON.stringify(joinRes.json)}`);
  assert.equal(joinRes.json.match.status, 'Ready');

  // Post chat message
  const chatRes = await api('POST', `/api/matches/${matchId}/chat`, { body: 'glhf e2e verify!' }, p2.token);
  assert.equal(chatRes.status, 201);

  if (ws) {
    await new Promise((r) => setTimeout(r, 250));
    ws.close();

    assert.ok(wsEvents.some((e) => e.type === 'match_state'), 'Expected WebSocket match_state broadcast');
    assert.ok(wsEvents.some((event) => event.type === 'chat_message'), 'Expected WebSocket chat notification');
    assert.ok(wsEvents.every((event) => !event.room && !event.message), 'Socket notifications must omit private room data');
  }
  const publicRoom = await api('GET', `/api/matches/${matchId}`);
  assert.equal(publicRoom.status, 200);
  assert.deepEqual(publicRoom.json.chat, [], 'Chat must be hidden from spectators');

  // Reopen match from scratch by ID (refresh/another device simulation)
  const reopenRes = await api('GET', `/api/matches/${matchId}`, undefined, p1.token);
  assert.equal(reopenRes.status, 200);
  assert.equal(reopenRes.json.participants.length, 2);
  assert.ok(reopenRes.json.chat.some(message => message.body === 'glhf e2e verify!'));
  assert.ok(reopenRes.json.participants.every((pt) => pt.epic_name_snapshot && pt.username_snapshot));
  assert.equal(reopenRes.json.participants[0].stake_reserved_lamports, entryLamports);

  const p1BalReservedCheck = (await api('GET', '/api/wallet', undefined, p1.token)).json.balance;
  assert.equal(p1BalReservedCheck.available_lamports, p1BalBefore - entryLamports);
  assert.ok(p1BalReservedCheck.reserved_lamports >= entryLamports);
  console.log(`  PASS: Match ${matchId} persisted, ${httpOnly ? 'HTTP chat synced' : 'WS synced'}, snapshots & reserved escrow accurate.`);

  // -------------------------------------------------------------------------
  // TEST 2: Simultaneous Join Race Condition + Conflict Dispute + Private Evidence + Override
  // -------------------------------------------------------------------------
  console.log('\n[2/6] Testing Simultaneous Join Concurrency, Disputes, Private Evidence & Result Override...');
  const raceCreate = await api(
    'POST',
    '/api/matches',
    {
      title: 'E2E Concurrency Race',
      format: '1v1',
      mode: 'Zone Wars',
      platform: 'All',
      region: 'NAC',
      entryLamports: 50_000_000, // 0.05 SOL
      firstTo: 5,
      winByTwo: true,
    },
    p1.token
  );
  assert.equal(raceCreate.status, 201);
  const raceMatchId = raceCreate.json.match.id;

  const p3BeforeRace = (await api('GET', '/api/wallet', undefined, p3.token)).json.balance.available_lamports;
  const p4BeforeRace = (await api('GET', '/api/wallet', undefined, p4.token)).json.balance.available_lamports;

  // Fire p3 and p4 join simultaneously
  const [raceA, raceB] = await Promise.all([
    api('POST', `/api/matches/${raceMatchId}/join`, { teamSide: 'B' }, p3.token),
    api('POST', `/api/matches/${raceMatchId}/join`, { teamSide: 'B' }, p4.token),
  ]);
  const statuses = [raceA.status, raceB.status].sort((a, b) => a - b);
  assert.deepEqual(statuses, [200, 409], `Expected [200, 409] on race join, got ${JSON.stringify(statuses)}`);

  const winnerJoiner = raceA.status === 200 ? p3 : p4;
  const rejectedJoiner = raceA.status === 200 ? p4 : p3;
  const rejectedBefore = raceA.status === 200 ? p4BeforeRace : p3BeforeRace;
  const rejectedAfter = (await api('GET', '/api/wallet', undefined, rejectedJoiner.token)).json.balance.available_lamports;
  assert.equal(rejectedAfter, rejectedBefore, 'Rejected race joiner must NOT be charged!');

  // Ready up both players to move to In Progress
  await api('POST', `/api/matches/${raceMatchId}/ready`, { ready: true }, p1.token);
  const readyDone = await api('POST', `/api/matches/${raceMatchId}/ready`, { ready: true }, winnerJoiner.token);
  assert.equal(readyDone.json.match.status, 'In Progress');
  assert.ok(readyDone.json.match.lobby_code.startsWith('SFT-'));

  // An insufficient lead must not lock the captain out of reporting a valid result.
  const shortLead = await api('POST', `/api/matches/${raceMatchId}/report`, { winnerSide: 'A', scoreA: 5, scoreB: 4 }, p1.token);
  assert.equal(shortLead.status, 400);
  // Conflicting score reports -> Disputed
  await api('POST', `/api/matches/${raceMatchId}/report`, { winnerSide: 'A', scoreA: 5, scoreB: 3 }, p1.token);
  const conflictRes = await api('POST', `/api/matches/${raceMatchId}/report`, { winnerSide: 'B', scoreA: 3, scoreB: 5 }, winnerJoiner.token);
  assert.equal(conflictRes.status, 200);
  assert.equal(conflictRes.json.match.status, 'Disputed');

  // Upload private evidence PNG from p1
  const pngBytes = Buffer.from(
    '89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000a49444154789c63000100000500010d0a2db40000000049454e44ae426082',
    'hex'
  );
  const form = new FormData();
  form.append('file', new Blob([pngBytes], { type: 'image/png' }), 'proof.png');
  form.append('note', 'Round 5 final elimination screenshot');
  const upRes = await api('POST', `/api/matches/${raceMatchId}/evidence`, form, p1.token, true);
  assert.equal(upRes.status, 201, `Evidence upload failed: ${JSON.stringify(upRes.json)}`);
  const evidenceId = upRes.json.evidenceId;

  // Verify access control on evidence download:
  const unauthEv = await fetch(`${BASE}/api/matches/${raceMatchId}/evidence/${evidenceId}/download`);
  assert.equal(unauthEv.status, 401, 'Unauthenticated evidence download must return 401');
  const outsiderEv = await api('GET', `/api/matches/${raceMatchId}/evidence/${evidenceId}/download`, undefined, rejectedJoiner.token);
  assert.equal(outsiderEv.status, 403, 'Non-participant player evidence download must return 403');
  const modEv = await fetch(`${BASE}/api/matches/${raceMatchId}/evidence/${evidenceId}/download`, {
    headers: { Authorization: `Bearer ${mod.token}` },
  });
  assert.equal(modEv.status, 200, 'Staff moderator must be able to download evidence');

  // Staff resolves dispute in favor of A (v1)
  const p1BalPreResolve = (await api('GET', '/api/wallet', undefined, p1.token)).json.balance.available_lamports;
  const wjBalPreResolve = (await api('GET', '/api/wallet', undefined, winnerJoiner.token)).json.balance.available_lamports;

  const resolve1 = await api(
    'POST',
    `/api/matches/${raceMatchId}/staff-resolve`,
    { winnerSide: 'A', scoreA: 5, scoreB: 3, reason: 'Verified round 5 screenshot' },
    mod.token
  );
  assert.equal(resolve1.status, 200);
  assert.equal(resolve1.json.match.status, 'Complete');
  assert.equal(resolve1.json.revisions.length, 1);

  const prizeLamports = resolve1.json.match.total_prize_lamports;
  const p1BalAfterV1 = (await api('GET', '/api/wallet', undefined, p1.token)).json.balance.available_lamports;
  assert.equal(p1BalAfterV1, p1BalPreResolve + prizeLamports);

  // Staff overrides result to B (v2) -> must record immutable v2 + reverse A + pay B!
  const resolve2 = await api(
    'POST',
    `/api/matches/${raceMatchId}/staff-resolve`,
    { winnerSide: 'B', scoreA: 4, scoreB: 5, reason: 'Replay timestamp showed prior round rule breach' },
    mod.token
  );
  assert.equal(resolve2.status, 200);
  assert.equal(resolve2.json.match.winner_side, 'B');
  assert.equal(resolve2.json.revisions.length, 2, 'Both immutable revisions v1 and v2 must be preserved');

  const p1BalAfterV2 = (await api('GET', '/api/wallet', undefined, p1.token)).json.balance.available_lamports;
  const wjBalAfterV2 = (await api('GET', '/api/wallet', undefined, winnerJoiner.token)).json.balance.available_lamports;
  assert.equal(p1BalAfterV2, p1BalPreResolve, 'Prior winner clawback must restore original available balance');
  assert.equal(wjBalAfterV2, wjBalPreResolve + prizeLamports, 'New winner must receive exact match prize');
  console.log('  PASS: Race lock, conflict dispute, private evidence AuthZ, and v1->v2 financial override verified.');

  // Also cancel the first test match so escrow refund is exercised & balances stay clean
  const cancelRes = await api('POST', `/api/matches/${matchId}/cancel`, { reason: 'E2E cleanup test' }, mod.token);
  assert.equal(cancelRes.status, 200);
  assert.equal(cancelRes.json.match.status, 'Cancelled');
  const p2BalRestored = (await api('GET', '/api/wallet', undefined, p2.token)).json.balance.available_lamports;
  assert.equal(p2BalRestored, p2BalBefore, 'Match cancel must refund full stake');

  // -------------------------------------------------------------------------
  // TEST 3: Solana 9-Decimal Deposit Matching + Idempotency + Withdrawal Retry
  // -------------------------------------------------------------------------
  console.log('\n[3/6] Testing Solana Exact/Wrong/Late/Duplicate Deposits & Safe Withdrawal Retry...');
  // Exact match
  const invExact = (await api('POST', '/api/wallet/deposit-invoice', { amountSol: 0.25 }, p2.token)).json.invoice;
  assert.ok(invExact.expected_lamports > invExact.base_lamports, 'Expected unique 9-decimal suffix lamports');
  const balBeforeDep = (await api('GET', '/api/wallet', undefined, p2.token)).json.balance.available_lamports;
  const exactTxSig = `e2e_exact_${Date.now()}`;

  const simExact = await api(
    'POST',
    '/api/wallet/devnet-simulate-transfer',
    { invoiceId: invExact.id, txSignature: exactTxSig, instructionIndex: 0 },
    p2.token
  );
  assert.equal(simExact.status, 200);
  assert.equal(simExact.json.outcome.outcome, 'Matched');
  assert.equal(simExact.json.balance.available_lamports, balBeforeDep + invExact.expected_lamports);

  // Duplicate of exact transfer must be ignored and NOT double-credit!
  const simDup = await api(
    'POST',
    '/api/wallet/devnet-simulate-transfer',
    { invoiceId: invExact.id, txSignature: exactTxSig, instructionIndex: 0 },
    p2.token
  );
  assert.equal(simDup.json.outcome.outcome, 'Duplicate Ignored');
  assert.equal(simDup.json.balance.available_lamports, balBeforeDep + invExact.expected_lamports);

  // Wrong amount transfer -> Needs Review, balance untouched
  const invWrong = (await api('POST', '/api/wallet/deposit-invoice', { amountSol: 0.2 }, p2.token)).json.invoice;
  const simWrong = await api(
    'POST',
    '/api/wallet/devnet-simulate-transfer',
    { invoiceId: invWrong.id, overrideLamports: invWrong.base_lamports, txSignature: `e2e_wrong_${Date.now()}` },
    p2.token
  );
  assert.equal(simWrong.json.outcome.outcome, 'Wrong Amount');
  assert.equal(simWrong.json.invoice.status, 'Needs Review');
  assert.equal(simWrong.json.balance.available_lamports, balBeforeDep + invExact.expected_lamports);

  // Late expired transfer -> Needs Review -> Finance approves
  const invLate = (await api('POST', '/api/wallet/deposit-invoice', { amountSol: 0.15 }, p2.token)).json.invoice;
  const simLate = await api(
    'POST',
    '/api/wallet/devnet-simulate-transfer',
    { invoiceId: invLate.id, forceExpireFirst: true, txSignature: `e2e_late_${Date.now()}` },
    p2.token
  );
  assert.equal(simLate.json.outcome.outcome, 'Late');
  assert.equal(simLate.json.invoice.status, 'Needs Review');
  const finApprove = await api('POST', `/api/finance/deposits/${invLate.id}/approve`, { note: 'Verified late arrival' }, finance.token);
  assert.equal(finApprove.status, 200);
  const balAfterLateApprove = (await api('GET', '/api/wallet', undefined, p2.token)).json.balance.available_lamports;
  assert.equal(balAfterLateApprove, balBeforeDep + invExact.expected_lamports + invLate.expected_lamports);

  // Withdrawal uncertain timeout -> Needs Review -> Finance safe idempotent retry -> Confirmed once!
  const wdLamports = 100_000_000; // 0.1 SOL
  const wdReq = await api(
    'POST',
    '/api/wallet/withdraw',
    {
      destinationAddress: '9xQeWvG816bUx9EPjHmaT23yvVM2ZWbrrpZb9PusVFin',
      amountSol: 0.1,
      simulateUncertainTimeout: true,
    },
    p2.token
  );
  assert.equal(wdReq.status, 201, `Withdraw request failed: ${JSON.stringify(wdReq.json)}`);
  assert.equal(wdReq.json.withdrawal.status, 'Needs Review');
  assert.ok(wdReq.json.withdrawal.signed_tx_base64, 'Signed tx must be persisted prior to broadcast');
  const wdId = wdReq.json.withdrawal.id;

  const balWhileWdPending = (await api('GET', '/api/wallet', undefined, p2.token)).json.balance;
  assert.equal(balWhileWdPending.available_lamports, balAfterLateApprove - wdLamports);

  const retry1 = await api('POST', `/api/finance/withdrawals/${wdId}/retry`, {}, finance.token);
  assert.equal(retry1.status, 200);
  assert.equal(retry1.json.withdrawal.status, 'Confirmed');

  // Re-running retry a second time must be idempotent and never double-debit
  const retry2 = await api('POST', `/api/finance/withdrawals/${wdId}/retry`, {}, finance.token);
  assert.equal(retry2.status, 200);
  assert.equal(retry2.json.withdrawal.status, 'Confirmed');
  const balAfterWd = (await api('GET', '/api/wallet', undefined, p2.token)).json.balance;
  assert.equal(balAfterWd.available_lamports, balAfterLateApprove - wdLamports);
  console.log('  PASS: Exact/Duplicate/Wrong/Late deposits & idempotent withdrawal retry verified.');

  // -------------------------------------------------------------------------
  // TEST 4: Tournaments (Capacity, Registration, Check-in, Bracket, 70/30 Payouts)
  // -------------------------------------------------------------------------
  console.log('\n[4/6] Testing Tournament Capacity, Check-In, Bracket & 70/30 Payout...');
  const trnCreate = await api(
    'POST',
    '/api/tournaments',
    {
      title: 'E2E Micro 2-Team Cup',
      mode: 'Zone Wars',
      format: '1v1',
      region: 'NAC',
      entryLamports: 0,
      prizePoolLamports: 1_000_000_000, // 1 SOL -> 0.7 / 0.3 split
      maxTeams: 2,
    },
    mod.token
  );
  assert.equal(trnCreate.status, 201);
  const trnId = trnCreate.json.tournament.id;

  const reg1 = await api('POST', `/api/tournaments/${trnId}/register`, { teamName: 'Alpha E2E' }, p1.token);
  assert.equal(reg1.status, 201);
  const reg2 = await api('POST', `/api/tournaments/${trnId}/register`, { teamName: 'Bravo E2E' }, p3.token);
  assert.equal(reg2.status, 201);
  const reg3OverCap = await api('POST', `/api/tournaments/${trnId}/register`, { teamName: 'Charlie Overflow' }, p4.token);
  assert.equal(reg3OverCap.status, 409, '3rd registration over capacity=2 must return 409');

  assert.equal((await api('POST', `/api/tournaments/${trnId}/checkin`, {}, p1.token)).status, 200);
  assert.equal((await api('POST', `/api/tournaments/${trnId}/checkin`, {}, p3.token)).status, 200);

  const genBracket = await api('POST', `/api/tournaments/${trnId}/generate-bracket`, {}, mod.token);
  assert.equal(genBracket.status, 200);
  assert.equal(genBracket.json.matchCount, 1);

  const trnDetail = (await api('GET', `/api/tournaments/${trnId}`, undefined, p1.token)).json;
  const bmId = trnDetail.bracket[0].id;
  const p1PreCup = (await api('GET', '/api/wallet', undefined, p1.token)).json.balance.available_lamports;
  const p3PreCup = (await api('GET', '/api/wallet', undefined, p3.token)).json.balance.available_lamports;

  const recRes = await api(
    'POST',
    `/api/tournaments/${trnId}/bracket/${bmId}/result`,
    { winnerRegId: reg1.json.registration.id, scoreA: 5, scoreB: 2 },
    mod.token
  );
  assert.equal(recRes.status, 200);
  assert.equal(recRes.json.settledTournament, true);

  const p1PostCup = (await api('GET', '/api/wallet', undefined, p1.token)).json.balance.available_lamports;
  const p3PostCup = (await api('GET', '/api/wallet', undefined, p3.token)).json.balance.available_lamports;
  assert.equal(p1PostCup, p1PreCup + 700_000_000, '1st place must receive 70% prize share');
  assert.equal(p3PostCup, p3PreCup + 300_000_000, '2nd place must receive 30% prize share');
  console.log('  PASS: Capacity cap, check-in, bracket advancement, and 70/30 SOL payouts verified.');

  // -------------------------------------------------------------------------
  // TEST 5: RBAC & Security Negative Checks
  // -------------------------------------------------------------------------
  console.log('\n[5/6] Testing RBAC & Security Negative Checks...');
  assert.equal((await api('GET', '/api/owner/analytics')).status, 401);
  assert.equal((await api('GET', '/api/owner/analytics', undefined, p1.token)).status, 403);
  assert.equal((await api('GET', '/api/owner/analytics', undefined, mod.token)).status, 403);
  assert.equal((await api('GET', '/api/owner/analytics', undefined, finance.token)).status, 403);
  assert.equal((await api('GET', '/api/finance/reconciliation', undefined, p1.token)).status, 403);
  assert.equal((await api('GET', '/api/finance/reconciliation', undefined, mod.token)).status, 403);
  assert.equal((await api('GET', '/api/staff/overview', undefined, p1.token)).status, 403);
  assert.equal(
    (await api('POST', `/api/matches/${raceMatchId}/staff-resolve`, { winnerSide: 'A', scoreA: 5, scoreB: 0, reason: 'hack' }, p1.token)).status,
    403
  );
  console.log('  PASS: All direct unauthorized/privilege-escalation endpoints strictly blocked (401/403).');

  // -------------------------------------------------------------------------
  // TEST 6: Owner Business Analytics SQL Verification
  // -------------------------------------------------------------------------
  console.log('\n[6/6] Verifying Owner Business Analytics KPIs & Health...');
  const ownerAnalytics = await api('GET', '/api/owner/analytics?days=30', undefined, owner.token);
  assert.equal(ownerAnalytics.status, 200);
  const { financial, activity, marketplaceHealth, breakdowns } = ownerAnalytics.json;
  assert.ok(activity.totalUsers >= 7);
  assert.ok(marketplaceHealth.completedMatches >= 2);
  assert.ok(financial.totalMatchVolumeLamports > 0);
  assert.ok(financial.grossFeesLamports >= 0);
  assert.ok(financial.outstandingLiabilitiesLamports > 0);
  assert.ok(Array.isArray(breakdowns.byMode));
  assert.ok(Array.isArray(breakdowns.byRegion));
  assert.ok(Array.isArray(activity.funnel));

  const finRec = await api('GET', '/api/finance/reconciliation', undefined, finance.token);
  assert.equal(finRec.status, 200);
  assert.equal(
    finRec.json.liabilities.totalLiabilityLamports,
    financial.outstandingLiabilitiesLamports,
    'Owner analytics liabilities must match Finance reconciliation lamport-for-lamport'
  );
  console.log('  PASS: Owner Analytics KPIs match Finance Reconciliation lamport-for-lamport.');

  console.log('\nALL 6 E2E VERIFICATION SCENARIOS PASSED SUCCESSFULLY.');
}

run().catch((err) => {
  console.error('\nE2E VERIFICATION FAILED:', err);
  process.exit(1);
});
