import type { IncomingMessage, ServerResponse } from 'node:http';
import { BlobPreconditionFailedError, get, head, put } from '@vercel/blob';
import { createHostedApi, WriteConflict } from '../server/hosted-api.ts';

const key = 'sft-arena-demo-v1.sqlite';
const serve = createHostedApi({
  async load() {
    const result = await get(key, { access: 'private', useCache: false });
    if (!result) return null;
    if (result.statusCode !== 200) throw new Error('Snapshot request did not return a body');
    const metadata = await head(result.blob.url);
    const etagValue = (tag: string) => tag?.replace(/^W\//, '').replace(/^"|"$/g, '');
    if (!metadata.etag || !result.blob.etag || etagValue(metadata.etag) !== etagValue(result.blob.etag)) {
      await result.stream.cancel();
      throw new WriteConflict();
    }
    return { bytes: Buffer.from(await new Response(result.stream).arrayBuffer()), revision: metadata.etag };
  },
  async save(bytes, previousRevision) {
    try {
      await put(key, bytes, {
        access: 'private',
        contentType: 'application/octet-stream',
        addRandomSuffix: false,
        allowOverwrite: previousRevision !== null,
        ...(previousRevision ? { ifMatch: previousRevision } : {}),
      });
    } catch (error) {
      if (error instanceof BlobPreconditionFailedError ||
          (!previousRevision && error instanceof Error && /blob already exists/i.test(error.message))) {
        throw new WriteConflict();
      }
      throw error;
    }
  },
});

export default async function handler(req: IncomingMessage, res: ServerResponse) {
  if (!process.env.SESSION_SECRET || !process.env.BLOB_READ_WRITE_TOKEN) {
    res.statusCode = 503;
    return res.end('Demo storage is not configured.');
  }
  const url = new URL(req.url || '/', 'https://sft.invalid');
  const route = url.searchParams.get('__sft_path');
  if (route !== null) {
    if (!/^[a-z0-9_\-/]{1,250}$/i.test(route)) {
      res.statusCode = 404;
      return res.end('Unknown API route.');
    }
    url.pathname = '/api/' + route;
    url.searchParams.delete('__sft_path');
  }
  req.url = url.pathname + url.search;
  return serve(req, res);
}
