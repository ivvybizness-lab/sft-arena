import 'dotenv/config';
import express from 'express';
import http from 'http';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { runMigrations } from './server/db.ts';
import { seedInitialData } from './server/seed.ts';
import { createApp } from './server/http.ts';
import { startSolanaWatcherLoop } from './server/solana.ts';
import { attachWebSocketServer } from './server/ws.ts';

async function startServer() {
  // Initialize SQLite database, run numbered migrations, and ensure base config & demo seed
  runMigrations();
  await seedInitialData();

  const app = createApp();
  const PORT = Number(process.env.PORT || 3000);

  const server = http.createServer(app);
  attachWebSocketServer(server);
  startSolanaWatcherLoop();

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`SFT server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start SFT server:', err);
  process.exit(1);
});
