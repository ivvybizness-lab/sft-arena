import { useEffect, useRef, useState } from 'react';
import { apiFetch } from '../lib/api';
import { readOnlyPreview } from '../lib/preview';

type GoogleClient = {
  initialize(options: { client_id:string; nonce:string; callback:(res:{credential:string})=>void; auto_select:boolean }):void;
  renderButton(node:HTMLElement, options:Record<string,string|number>):void;
};
let loader: Promise<GoogleClient> | undefined;
function loadGoogle() {
  if (!loader) loader = new Promise<GoogleClient>((resolve,reject) => {
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.async = true;
    script.onload = () => {
      const client = (window as Window & {google?:{accounts:{id:GoogleClient}}}).google?.accounts.id;
      if (client) resolve(client);
      else { loader=undefined; script.remove(); reject(Error('Google Sign-In is unavailable.')); }
    };
    script.onerror = () => { loader=undefined; script.remove(); reject(Error('Google Sign-In could not load. Check your browser settings and retry.')); };
    document.head.appendChild(script);
  });
  return loader;
}

export function preloadGoogleSignIn() {
  if (!readOnlyPreview) void loadGoogle().catch(() => {});
}

function GoogleMark() {
  return <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
    <path fill="#4285F4" d="M43.6 24.5c0-1.5-.1-2.9-.4-4.3H24v8.2h11a9.4 9.4 0 0 1-4.1 6.2v5.1h6.6c3.9-3.6 6.1-8.9 6.1-15.2Z"/>
    <path fill="#34A853" d="M24 44c5.5 0 10.1-1.8 13.5-4.9l-6.6-5.1c-1.8 1.2-4.1 1.9-6.9 1.9-5.3 0-9.8-3.6-11.4-8.4H5.8v5.3A20 20 0 0 0 24 44Z"/>
    <path fill="#FBBC05" d="M12.6 27.5a12 12 0 0 1 0-7V15H5.8a20 20 0 0 0 0 18l6.8-5.5Z"/>
    <path fill="#EA4335" d="M24 12.1c3 0 5.7 1 7.8 3.1l5.8-5.8A19.2 19.2 0 0 0 24 4 20 20 0 0 0 5.8 15l6.8 5.5c1.6-4.8 6.1-8.4 11.4-8.4Z"/>
  </svg>;
}

export default function GoogleSignIn({onSuccess, iconOnly = false}:{onSuccess:()=>void;iconOnly?:boolean}) {
  const mount = useRef<HTMLDivElement>(null);
  const success = useRef(onSuccess);
  success.current=onSuccess;
  const [pending,setPending]=useState('');
  const [ageConfirmed,setAgeConfirmed]=useState(false);
  const [agreed,setAgreed]=useState(false);
  const [error,setError]=useState('');
  const [attempt,setAttempt]=useState(0);
  const [busy,setBusy]=useState(false);
  const [buttonLoaded,setButtonLoaded]=useState(false);
  async function finish(credential:string,acceptTerms:boolean,ageConfirmed=false) {
    setBusy(true); setError('');
    try {
      const response=await apiFetch<{needsConsent?:boolean}>('/api/auth/google',{method:'POST',body:JSON.stringify({credential,acceptTerms,ageConfirmed})});
      if (response.needsConsent) setPending(credential);
      else success.current();
    } catch (e) { setError((e as Error).message); setPending(''); }
    finally {setBusy(false);}
  }
  useEffect(()=>{
    let active=true;
    setButtonLoaded(false);
    Promise.all([loadGoogle(),apiFetch<{clientId:string;nonce:string}>('/api/auth/google/challenge')]).then(([google,options])=>{
      if (!active || !mount.current) return;
      mount.current.replaceChildren();
      google.initialize({client_id:options.clientId,nonce:options.nonce,auto_select:false,callback:r=>{if(active) void finish(r.credential,false);}});
      google.renderButton(mount.current, iconOnly ? {type:'icon',theme:'outline',size:'large'} : {type:'standard',theme:'outline',size:'large',text:'continue_with',width:265});
    }).catch(e=>{if(active)setError(e.message);});
    return ()=>{active=false;};
  },[attempt,iconOnly]);
  return <div className="arena-google">
    {!pending && !error && <div className={'arena-google-slot' + (iconOnly ? ' arena-google-slot-icon' : '')} aria-busy={!buttonLoaded}>
      {!buttonLoaded && <span className="arena-google-placeholder" aria-hidden="true"><GoogleMark/>{!iconOnly && <span>Continue with Google</span>}</span>}
      <div ref={mount} className="arena-google-sdk" onLoadCapture={()=>setButtonLoaded(true)} aria-label="Continue with Google"/>
    </div>}
    {pending && <><label><input type="checkbox" checked={ageConfirmed} onChange={event=>setAgeConfirmed(event.target.checked)}/> Are you over 18?</label><label><input type="checkbox" checked={agreed} onChange={e=>setAgreed(e.target.checked)}/> I accept the SFT <a href="/rules" target="_blank" rel="noreferrer">terms, privacy policy and competition rules</a>.</label><button disabled={!agreed||!ageConfirmed||busy} onClick={()=>void finish(pending,true,ageConfirmed)}>Create my SFT account</button></>}
    {busy && <small role="status">Verifying with Google…</small>}
    {error && <p role="alert">{error} <button type="button" onClick={()=>{setError('');setAttempt(n=>n+1);}}>Retry</button></p>}
  </div>;
}
