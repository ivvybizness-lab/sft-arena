import { Clock, Gamepad2, MapPin, Trophy, Users } from 'lucide-react';
import { formatCountdownUntil, formatSol, getModeArt } from '../lib/format';
import boxFightsProp from '../assets/match-props/box-fights.webp';
import zoneWarsProp from '../assets/match-props/zone-wars.webp';
import realisticsProp from '../assets/match-props/realistics.webp';
import buildFightsProp from '../assets/match-props/build-fights.webp';

export interface TournamentSummary {
  id: string;
  title: string;
  subtitle: string;
  is_demo: number;
  mode: string;
  format: string;
  region: string;
  entry_lamports: number;
  prize_pool_lamports: number;
  max_teams: number;
  registered_teams: number;
  accent_color: string;
  registration_opens_at: string;
  registration_closes_at: string;
  checkin_opens_at: string;
  starts_at: string;
  status: string;
}

const MODE_PROPS: Record<string, string> = {
  Realistics: realisticsProp,
  'Zone Wars': zoneWarsProp,
  'Box Fights': boxFightsProp,
  'Build Fights': buildFightsProp,
};

const MODE_TINTS: Record<string, string> = {
  Realistics: '#1b5534',
  'Zone Wars': '#325b6b',
  'Box Fights': '#5f5030',
  'Build Fights': '#42395e',
};

function getTiming(tournament: TournamentSummary, serverTimeUtc: string) {
  const now = Date.parse(serverTimeUtc);
  const opensAt = Date.parse(tournament.registration_opens_at);
  const closesAt = Date.parse(tournament.registration_closes_at);
  const startsAt = Date.parse(tournament.starts_at);
  const hasEndedRegistration = ['Live', 'Completed', 'Cancelled'].includes(tournament.status);

  let registration = 'Registration Closed';
  if (!hasEndedRegistration && opensAt > now) {
    registration = 'Registration Opens in ' + formatCountdownUntil(tournament.registration_opens_at, serverTimeUtc);
  } else if (!hasEndedRegistration && closesAt > now) {
    if (['Registration Open', 'Check-In'].includes(tournament.status)) {
      registration = 'Registration Closes in ' + formatCountdownUntil(tournament.registration_closes_at, serverTimeUtc);
    } else {
      registration = 'Registration Pending';
    }
  }

  const start = !hasEndedRegistration && startsAt > now
    ? 'Tournament Starts in ' + formatCountdownUntil(tournament.starts_at, serverTimeUtc)
    : 'Tournament ' + (hasEndedRegistration ? tournament.status : 'Start Time Passed');

  return { registration, start };
}

export default function TournamentCard({ tournament, serverTimeUtc, onOpen }: {
  key?: string;
  tournament: TournamentSummary;
  serverTimeUtc: string;
  onOpen: (id: string) => void;
}) {
  const { title, mode, format, region, registered_teams, max_teams, prize_pool_lamports } = tournament;
  const prop = MODE_PROPS[mode];
  const art = getModeArt(mode);
  const prize = formatSol(prize_pool_lamports, 2);
  const timing = getTiming(tournament, serverTimeUtc);
  const details = [
    { label: 'Teams', value: registered_teams + '/' + max_teams, Icon: Users },
    { label: 'Mode', value: mode, Icon: Gamepad2 },
    { label: 'Region', value: region, Icon: MapPin },
    { label: 'Team Size', value: format, Icon: Users },
  ];

  return (
    <article className="sft-tournament-card">
      <div className="sft-tournament-card__panel">
        <div className="sft-tournament-card__art" style={{ backgroundColor: MODE_TINTS[mode] ?? '#32505e' }} aria-hidden="true">
          <img className={prop ? 'sft-tournament-card__prop' : undefined} src={prop ?? art.img} alt="" loading="lazy" decoding="async" />
        </div>

        <div className="sft-tournament-card__heading">
          <h2>
            <button type="button" aria-haspopup="dialog" onClick={() => onOpen(tournament.id)}>
              {title}
            </button>
          </h2>
        </div>

        <div className="sft-tournament-card__prize">
          <span className="sft-tournament-card__coin" aria-hidden="true">S</span>
          <span>{prize}<span className="sr-only"> SOL prize pool</span></span>
        </div>

        <ul className="sft-tournament-card__timing" aria-label="Tournament schedule">
          {[timing.registration, timing.start].map(value => (
            <li key={value}>
              <Clock size={13} aria-hidden="true" />
              <span>{value}</span>
            </li>
          ))}
        </ul>

        <dl className="sft-tournament-card__details">
          {details.map(({ label, value, Icon }) => (
            <div key={label}>
              <Icon size={18} aria-hidden="true" />
              <div>
                <dt>{label}</dt>
                <dd>{value}</dd>
              </div>
            </div>
          ))}
        </dl>
      </div>
    </article>
  );
}
