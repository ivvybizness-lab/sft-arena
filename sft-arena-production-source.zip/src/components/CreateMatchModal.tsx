import { useEffect, useRef, useState, type ReactNode, type FormEvent } from 'react';
import { Check, Coins, Crown, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { apiFetch } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import { LAMPORTS_PER_SOL, formatSol } from '../lib/format';

const modes = ['Zone Wars','Box Fights','Realistics','Build Fights','Piece Control','Zero Build'];
const stages = ['Game','Settings','Tokens'];
const loadouts = ['Map default','Iron Pump (Ranger Pistol)','Auto Shotgun (Hammer AR)','Boxfight Loot (Default AR)','Havoc (Default AR)'];
interface TeamItem { id:string; name:string; members:{id:string}[] }

function Choices({label,children}:{label:string;children:ReactNode}) {
  return <fieldset className="match-choices"><legend>{label}</legend><div>{children}</div></fieldset>;
}

export default function CreateMatchModal({open,onClose,defaultMode='Zone Wars'}:{open:boolean;onClose:()=>void;defaultMode?:string}) {
  const {user,openAuthModal,refreshUser,notify} = useAuth();
  const navigate = useNavigate();
  const dialog = useRef<HTMLDialogElement>(null);
  const [stage,setStage] = useState(0);
  const [teams,setTeams] = useState<TeamItem[]>([]);
  const [feeBps,setFeeBps] = useState<number|null>(null);
  const [format,setFormat] = useState('1v1');
  const [mode,setMode] = useState(defaultMode);
  const [region,setRegion] = useState<string>(user?.competitiveRegion ?? 'NAE');
  const [platform,setPlatform] = useState('All');
  const [firstTo,setFirstTo] = useState(5);
  const [winByTwo,setWinByTwo] = useState(true);
  const [roundsLead,setRoundsLead] = useState(0);
  const [loadout,setLoadout] = useState(loadouts[0]);
  const [disableSimpleEdit,setDisableSimpleEdit] = useState(false);
  const [stakeBasis,setStakeBasis] = useState<'per_player'|'per_team'>('per_player');
  const [entrySol,setEntrySol] = useState('0');
  const [title,setTitle] = useState('');
  const [creatorTeamId,setCreatorTeamId] = useState('');
  const [isRanked,setIsRanked] = useState(true);
  const [isPrivate,setIsPrivate] = useState(false);
  const [inviteInput,setInviteInput] = useState('');
  const [invites,setInvites] = useState<string[]>([]);
  const [submitting,setSubmitting] = useState(false);
  const [error,setError] = useState('');

  useEffect(()=>{
    if (!open) return;
    setStage(0);setError('');setIsPrivate(false);setInvites([]);setInviteInput('');setMode(modes.includes(defaultMode)?defaultMode:modes[0]);
    if (defaultMode === 'Build Fights') {setFormat('1v1');setCreatorTeamId('');}
    setRegion(user?.competitiveRegion ?? 'NAE');
    let current = true;
    apiFetch<{fee_bps:number}>('/api/matches/config').then(data=>{if(current)setFeeBps(data.fee_bps);}).catch(()=>{});
    if (user) apiFetch<{teams:TeamItem[]}>('/api/teams').then(data=>{if(current)setTeams(data.teams);}).catch(()=>{});
    const node=dialog.current;
    if (node && !node.open) node.showModal();
    return ()=>{current=false;if(node?.open)node.close();};
  },[open,defaultMode,user?.id]);

  if (!open) return null;
  const teamSize=Number(format[0]);
  const entryLamports=Math.round(Number(entrySol || 0)*LAMPORTS_PER_SOL);
  const safeAmount=Number.isSafeInteger(entryLamports) && entryLamports>=0 && entryLamports<=Number.MAX_SAFE_INTEGER/16;
  const perPlayer=safeAmount?(stakeBasis==='per_team'?Math.floor(entryLamports/teamSize):entryLamports):0;
  const pool=perPlayer*teamSize*2;
  const fee=feeBps===null ? null : Math.floor(pool*feeBps/10_000);
  const draftInvite=inviteInput.trim();
  const pendingInvites=draftInvite && !invites.some(name=>name.toLowerCase()===draftInvite.toLowerCase()) ? [...invites,draftInvite] : invites;

  function addInvite() {
    const name=inviteInput.trim();
    if (!name) return;
    if (!invites.some(invite=>invite.toLowerCase()===name.toLowerCase()) && invites.length<7) setInvites([...invites,name]);
    setInviteInput('');
  }

  async function submit(event:FormEvent) {
    event.preventDefault();
    if (submitting) return;
    setError('');
    if (stage<2) {
      if (stage===1 && isPrivate && !pendingInvites.length) return setError('Enter a username to invite.');
      setStage(stage+1);
      return;
    }
    if (!user) {onClose();openAuthModal('login');return;}
    if (!safeAmount) return setError('Enter a valid SOL amount.');
    if (isPrivate && pendingInvites.length>7) {setStage(1);return setError('Invite at most seven players.');}
    if (isPrivate && !pendingInvites.length) {setStage(1);return setError('Enter a username to invite.');}
    setSubmitting(true);
    try {
      const response=await apiFetch<{match:{id:string}}>('/api/matches',{method:'POST',body:JSON.stringify({
        title:title.trim()||format+' '+mode+(loadout!==loadouts[0]?' ('+loadout+')':''),
        format,mode,region,platform,firstTo,winByTwo,roundsLead,disableSimpleEdit,loadout:loadout===loadouts[0]?'':loadout,
        stakeBasis,entryLamports,creatorTeamId:creatorTeamId||null,isRanked,isPrivate,
        inviteUsernames:isPrivate?pendingInvites:[],
      })});
      onClose();
      notify(isPrivate?'Private match created and invitations sent.':'Match created.','success');
      navigate('/matches/'+response.match.id);
      void refreshUser();
    } catch (error) {setError((error as Error).message);}
    finally {setSubmitting(false);}
  }

  return <dialog ref={dialog} className="arena-match-flow" aria-label="Create Match" onCancel={event=>{event.preventDefault();if(!submitting)onClose();}}>
    <form onSubmit={submit}>
      <header><button type="button" className="flow-close" aria-label="Close Create Match" disabled={submitting} onClick={onClose}><X size={21}/></button>
        <h2>Create Match</h2><p>Choose your game, rules, and SOL entry.</p></header>
      <div className="flow-summary"><span>Type <b>{mode}</b></span><span>Mode <b>{format}</b></span><span>First to <b>{firstTo}{winByTwo?'+2':''}</b></span><span>Region <b>{region}</b></span></div>
      <nav className="flow-tabs" aria-label="Create match steps">{stages.map((label,index)=><button type="button" key={label} aria-current={stage===index?'step':undefined} disabled={index>stage||submitting} onClick={()=>{setError('');setStage(index);}}>{label}</button>)}</nav>
      <div className="flow-content">
        {stage===0 && <>
          <Choices label="Game type">{modes.map(value=><button type="button" key={value} aria-pressed={mode===value} onClick={()=>{setMode(value);if(value==='Build Fights'){setFormat('1v1');setCreatorTeamId('');}}}>{value}</button>)}</Choices>
          <Choices label="Mode">{(mode==='Build Fights'?['1v1']:['1v1','2v2','3v3','4v4']).map(value=><button type="button" key={value} aria-pressed={format===value} onClick={()=>{setFormat(value);setCreatorTeamId('');}}>{value}</button>)}</Choices>
          <Choices label="Region">{['NAE','NAC','NAW','EU'].map(value=><button type="button" key={value} aria-pressed={region===value} onClick={()=>setRegion(value)}>{value}</button>)}</Choices>
          <Choices label="Platform">{['All','PC','Console'].map(value=><button type="button" key={value} aria-pressed={platform===value} onClick={()=>setPlatform(value)}>{value==='All'?'Any':value}</button>)}</Choices>
        </>}
        {stage===1 && <>
          <Choices label="First to">{[[1,0],[2,0],[3,1],[5,1],[7,1],[10,1],[15,1]].map(([value,two])=><button key={value} type="button" aria-pressed={firstTo===value && winByTwo===Boolean(two)} onClick={()=>{setFirstTo(value);setWinByTwo(Boolean(two));setRoundsLead(previous=>Math.min(previous,value-1));}}>{value}{two?'+2':''}</button>)}</Choices>
          <label className="flow-field">Loadout<select value={loadout} onChange={event=>setLoadout(event.target.value)}>{loadouts.map(value=><option key={value}>{value}</option>)}</select></label>
          <Choices label="Rounds lead">{[0,1,2,3,4].map(value=><button type="button" key={value} disabled={value>=firstTo} aria-pressed={roundsLead===value} onClick={()=>setRoundsLead(value)}>{value}</button>)}</Choices>
          <label className="flow-toggle"><span>Disable Simple Edit<small>Both sides should turn off Simple Edit in Fortnite.</small></span><input type="checkbox" role="switch" checked={disableSimpleEdit} onChange={event=>setDisableSimpleEdit(event.target.checked)}/></label>
          <label className="flow-toggle"><span>Private Match<small>Only invited players can join.</small></span><input type="checkbox" role="switch" checked={isPrivate} onChange={event=>setIsPrivate(event.target.checked)}/></label>
          {isPrivate && <div className="flow-invites"><label className="flow-field">Invite players by username<div>
            <input value={inviteInput} maxLength={24} onChange={event=>setInviteInput(event.target.value)} placeholder="Enter a username" onKeyDown={event=>{if(event.key==='Enter'){event.preventDefault();addInvite();}}}/>
            <button type="button" onClick={addInvite} disabled={!inviteInput.trim()||invites.length>=7}>Add</button></div></label>
            {invites.map(name=><button type="button" key={name} aria-label={'Remove '+name} onClick={()=>setInvites(invites.filter(invite=>invite!==name))}>{name}<X size={14}/></button>)}
          </div>}
          <details className="flow-more"><summary>More settings</summary>
            <label className="flow-field">Match title <input value={title} maxLength={80} onChange={event=>setTitle(event.target.value)} placeholder="Optional title"/></label>
            {teams.length>0 && <label className="flow-field">Your roster <select value={creatorTeamId} onChange={event=>setCreatorTeamId(event.target.value)}><option value="">Open fill</option>{teams.filter(team=>team.members.length>=teamSize).map(team=><option key={team.id} value={team.id}>{team.name}</option>)}</select></label>}
            <label className="flow-toggle"><span>Ranked Match</span><input type="checkbox" role="switch" checked={isRanked} onChange={event=>setIsRanked(event.target.checked)}/></label>
          </details>
        </>}
        {stage===2 && <>
          <Choices label="Entry fee in SOL">{[0,0.05,0.1,0.25,0.5,1].map(value=><button type="button" key={value} aria-pressed={Number(entrySol)===value} onClick={()=>setEntrySol(String(value))}>{value===0?'Free':value+' SOL'}</button>)}</Choices>
          <label className="flow-field">Custom SOL amount <div className="flow-amount"><input type="number" min="0" step="0.000000001" value={entrySol} onChange={event=>setEntrySol(event.target.value)}/>{user && <button type="button" onClick={()=>{setStakeBasis('per_player');setEntrySol(formatSol(user.balance.available_lamports,9).replaceAll(',',''));}}>All In</button>}</div></label>
          {teamSize>1 && <label className="flow-field">Entry basis <select value={stakeBasis} onChange={event=>setStakeBasis(event.target.value as typeof stakeBasis)}><option value="per_player">Per player</option><option value="per_team">Per team</option></select></label>}
          <section className="flow-cost"><h3>Match Summary</h3><div><div><small>Entry per player</small><strong>{formatSol(perPlayer,4)} SOL</strong></div><div><small>Total pool · {teamSize*2} players</small><strong>{formatSol(pool,4)} SOL</strong></div></div>
            <footer><div><small><Crown size={16}/>Winning team</small><strong>{fee===null?'—':formatSol(pool-fee,4)+' SOL'}</strong></div><div><small>Platform fee{feeBps===null?'':' · '+feeBps/100+'%'}</small><strong>{fee===null?'—':formatSol(fee,4)+' SOL'}</strong></div></footer>
          </section>
        </>}
        {error && <p className="flow-error" role="alert">{error}</p>}
      </div>
      <footer className="flow-actions">
        <button type="button" disabled={submitting} onClick={onClose}>Cancel</button>
        {stage>0 && <button type="button" disabled={submitting} onClick={()=>{setStage(stage-1);setError('');}}>Back</button>}
        <button type="submit" disabled={submitting} className="flow-primary">{submitting?'Creating…':stage===2?<><Check size={17}/>Create Match</>:'Next'}</button>
      </footer>
    </form>
  </dialog>;
}
