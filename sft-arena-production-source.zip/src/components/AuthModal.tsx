import sftLogo from '../assets/brand/sft-logo.png';
import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { X } from 'lucide-react';
import GoogleSignIn, { preloadGoogleSignIn } from './GoogleSignIn';
import { apiFetch } from '../lib/api';
import { useAuth } from '../context/AuthContext';

export default function AuthModal() {
  const { user, loading, authModalOpen, authModalMode, closeAuthModal, refreshUser, notify } = useAuth();
  const [mode, setMode] = useState(authModalMode);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const dialog = useRef<HTMLDialogElement>(null);
  const registering = mode === 'register';
  const title = registering ? 'Sign Up' : 'Sign In';

  useEffect(() => {
    if (!loading && !user) preloadGoogleSignIn();
  }, [loading, user]);

  useEffect(() => {
    setMode(authModalMode);
    setError('');
    const node = dialog.current;
    if (authModalOpen) node?.showModal();
    return () => node?.close();
  }, [authModalOpen, authModalMode]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    setSubmitting(true);
    const fields = new FormData(event.currentTarget);
    const email = String(fields.get('email') ?? '').trim();
    const password = fields.get('password');
    try {
      await apiFetch('/api/auth/' + mode, {
        method: 'POST',
        body: JSON.stringify(registering ? {
          email, password,
          username: fields.get('username'),
          referralCodeUsed: fields.get('referral'),
          ageConfirmed: fields.has('age'),
          acceptTerms: fields.has('terms'),
        } : { identifier: email, password }),
      });
      await refreshUser();
      closeAuthModal();
      notify(registering ? 'Account created.' : 'Welcome back to SFT Arena.', 'success');
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setSubmitting(false);
    }
  }

  if (!authModalOpen) return null;

  return <dialog ref={dialog} className="arena-form-dialog arena-sign-in" aria-labelledby="sft-auth-title"
    onCancel={event=>{event.preventDefault(); closeAuthModal();}}
    onClick={event=>{if(event.target===event.currentTarget) closeAuthModal();}}>
    <div className="arena-form-panel">
      <header><h2 id="sft-auth-title"><img className="arena-small-logo" src={sftLogo} alt="" width={34} height={34}/>{title}</h2><button type="button" aria-label="Close" onClick={closeAuthModal}><X size={20}/></button></header>
      <form key={mode} onSubmit={submit} className="arena-form-stack">
        <label>{registering ? 'Email' : 'Email or username'} <em>*</em>
          <input name="email" type={registering ? 'email' : 'text'} autoComplete={registering ? 'email' : 'username'} required />
        </label>
        {registering && <div className="arena-form-pair">
          <label>Username <em>*</em><input name="username" autoComplete="username" required minLength={3} maxLength={12} pattern="[A-Za-z0-9]+" /><small>3–12 characters. Letters and numbers only.</small></label>
          <label>Referral <small>(optional)</small><input name="referral" maxLength={64}/></label>
        </div>}
        <label>Password <em>*</em><input name="password" type="password" autoComplete={registering ? 'new-password' : 'current-password'} required
          minLength={registering ? 8 : undefined} maxLength={registering ? 25 : undefined} pattern={registering ? '(?=.*[A-Za-z])(?=.*[0-9]).{8,25}' : undefined}/>
          {registering && <small>8–25 characters, with at least one letter and one number.</small>}
        </label>
        {registering && <div className="arena-form-checks">
          <label><input name="age" type="checkbox" required/> Are you over 18?</label>
          <label><input name="terms" type="checkbox" required/> <span>I accept the <Link to="/rules" onClick={closeAuthModal}>Terms of Service</Link>, <Link to="/rules#privacy" onClick={closeAuthModal}>Privacy Policy</Link>, and <Link to="/rules#competition_rules" onClick={closeAuthModal}>General Rules</Link>.</span></label>
        </div>}
        {error && <p role="alert" className="arena-form-error">{error}</p>}
        <button className="arena-form-primary" disabled={submitting}>{submitting ? 'Loading…' : title}</button>
      </form>
      <div className="arena-form-divider">OR</div>
      <GoogleSignIn iconOnly onSuccess={async()=>{await refreshUser();closeAuthModal();notify('Signed in with Google.', 'success');}}/>
      <div className="arena-auth-foot">
        {!registering && <Link to="/support#account-recovery" onClick={closeAuthModal}>Forgot Password</Link>}
        <span>{registering ? 'Already have an account?' : 'Need an account?'} <button type="button" disabled={submitting} onClick={()=>{setError('');setMode(registering ? 'login' : 'register');}}>{registering ? 'Sign In' : 'Create here'}</button></span>
      </div>
    </div>
  </dialog>;
}
