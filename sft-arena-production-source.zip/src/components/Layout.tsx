import sftLogo from '../assets/brand/sft-logo.png';
import React, { useState, useEffect, useRef } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  Home,
  Gamepad2,
  ShoppingBag,
  Swords,
  Trophy,
  Store,
  BarChart3,
  Search,
  Bell,
  Wallet,
  Coins,
  LayoutGrid,
  ArrowLeftToLine,
  ArrowRightFromLine,
  ShieldAlert,
  Menu,
  X,
  Users,
  Gift,
  FileText,
  HelpCircle,
  User as UserIcon,
  LogOut,
  MessageCircle,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { apiFetch } from '../lib/api';
import { readOnlyPreview, pollingTransport } from '../lib/preview';
import { formatSol } from '../lib/format';
import PlayerPortrait from './PlayerPortrait';
import AuthModal from './AuthModal';
import WalletDialog from '../pages/WalletPage';
import AdminNavigation from './AdminNavigation';

interface QuickMatchRow {
  id: string;
  title: string;
  format: string;
  mode: string;
  first_to: number;
  entry_lamports: number;
  status: string;
}

interface SearchUserResult {
  id: string;
  username: string;
  displayName: string;
  epicDisplayName: string;
  competitiveRegion: string;
  elo: number;
}

export default function Layout({ children }: { children: React.ReactNode }) {
  const {
    user,
    notifications,
    unreadCount,
    markNotificationsRead,
    openAuthModal,
    logout,
  } = useAuth();

  const [walletOpen, setWalletOpen] = useState(false);
  const location = useLocation();
  const isProfileArea = location.pathname.startsWith("/profile/") || location.pathname === "/teams";
  const staffArea = location.pathname.startsWith('/staff') && Boolean(user && ['moderator','finance','owner'].includes(user.role));
  const accountRail = isProfileArea || location.pathname === "/leaderboard";
  const navigate = useNavigate();

  const [railOpen, setRailOpen] = useState(() => accountRail || location.pathname.startsWith('/staff'));
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [appsMenuOpen, setAppsMenuOpen] = useState(false);
  const appMenu = useRef<HTMLDialogElement>(null);
  useEffect(()=>{
    const dialog=appMenu.current;
    if (appsMenuOpen && dialog && !dialog.open) dialog.showModal();
    if (!appsMenuOpen && dialog?.open) dialog.close();
  },[appsMenuOpen]);
  const [notifOpen, setNotifOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchUserResult[]>([]);
  const [searchOpen, setSearchOpen] = useState(false);

  const [recentMatches, setRecentMatches] = useState<QuickMatchRow[]>([]);

  useEffect(() => {
    setRailOpen(accountRail || location.pathname.startsWith("/staff"));
    setMobileMenuOpen(false);
    setAppsMenuOpen(false);
    setNotifOpen(false);
    setProfileMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const tab = user ? 'my' : 'open';
    apiFetch<{ matches: QuickMatchRow[] }>(`/api/matches?tab=${tab}`)
      .then((d) => setRecentMatches(d.matches.slice(0, 6)))
      .catch(() => {});
  }, [user?.id, location.pathname]);

  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }
    const timer = setTimeout(() => {
      apiFetch<{ users: SearchUserResult[] }>(`/api/users/search?q=${encodeURIComponent(searchQuery.trim())}`)
        .then((d) => setSearchResults(d.users.slice(0, 6)))
        .catch(() => {});
    }, 180);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  const activeOngoingMatch = recentMatches.find((m) => ['Waiting', 'Ready', 'In Progress', 'Disputed'].includes(m.status));
  const isStaff = user?.role==='owner';
  const appTiles = [
    ...(isStaff ? [
      {to:'/staff',label:'Admin',detail:'Panel',icon:ShieldAlert,tone:'red'},
      {to:'/tournaments?panel=1',label:'Tournament',detail:'Panel',icon:Trophy,tone:'purple'},
    ] : []),
    {to:'/matches',label:'Matches',detail:'Compete',icon:Gamepad2,tone:'gold'},
    {to:'/tournaments',label:'Tournaments',detail:'Events',icon:Trophy,tone:'amber'},
    {to:'/leaderboard',label:'Leaderboard',detail:'Rankings',icon:BarChart3,tone:'violet'},
    {to:'/shop',label:'Store',detail:'Shop',icon:Store,tone:'blue'},
  ];
  const communityUrl = import.meta.env.VITE_SFT_DISCORD_URL;

  const primaryTabs = [
    { to: '/', label: 'Home', icon: Home },
    { to: '/matches', label: 'Matches', icon: Gamepad2 },
    { to: '/tournaments', label: 'Tournaments', icon: Trophy },
    { to: '/shop', label: 'Shop', icon: ShoppingBag },
  ];

  const railLinks = [
    { to: '/', label: 'Home', icon: Home },
    { to: '/matches', label: 'Matches', icon: Swords },
    { to: '/tournaments', label: 'Tournaments', icon: Trophy },
    { to: '/leaderboard', label: 'Leaderboard', icon: BarChart3 },
    { to: '/shop', label: 'Shop', icon: Store },
    { to: '/teams', label: 'Teams & Rosters', icon: Users },
    { to: '/rewards', label: 'Rewards', icon: Gift },
    { to: '/rules', label: 'Rules & Terms', icon: FileText },
    { to: '/support', label: 'Support', icon: HelpCircle },
    ...(user ? [{ to: '/profile/'+encodeURIComponent(user.username), label: 'Profile', icon: UserIcon }] : []),
  ];

  function playerSearch(className: string) {
    return (
      <div className={className}>
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onFocus={() => setSearchOpen(true)}
              onBlur={() => setTimeout(() => setSearchOpen(false), 180)}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setSearchOpen(true);
              }}
              placeholder="Search players..." aria-label="Search players"
              className="w-full h-8 pl-8 pr-3 rounded-full bg-[#111521] border border-[#2a3248] text-xs text-slate-200 placeholder-slate-500 focus:border-[#6d4aff]"
            />
            {searchOpen && searchResults.length > 0 && (
              <div className="absolute left-0 right-0 mt-1.5 bg-[#181d2c] border border-[#2a3248] rounded-lg shadow-2xl overflow-hidden z-50">
                {searchResults.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => { navigate(`/profile/${encodeURIComponent(p.username)}`); setSearchOpen(false); setMobileMenuOpen(false); }}
                    className="w-full px-3 py-2 flex items-center justify-between text-left hover:bg-[#232a3f] transition-colors cursor-pointer"
                  >
                    <div>
                      <div className="text-xs font-semibold text-white">{p.username}</div>
                      <div className="text-[11px] text-slate-400">
                        Epic: {p.epicDisplayName || p.username} · {p.competitiveRegion}
                      </div>
                    </div>
                    <span className="text-[11px] font-mono text-[#9d85ff] tabular-nums">{p.elo}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#101420] text-[#f1f5f9] flex flex-col">
      {readOnlyPreview && <p className="bg-[#222b42] text-slate-200 text-xs text-center px-3 py-2">
        Private preview · Demo data · Accounts, live matches, and SOL transfers are unavailable.
      </p>}
      {pollingTransport && <p className="arena-demo-label">
        Private demo · Simulated SOL
      </p>}
      {/* Sticky Top Header */}
      <header data-profile={isProfileArea || staffArea} data-admin={staffArea} className="arena-header sticky top-0 z-50 h-14 bg-[#171c2b] border-b border-[#232a3e] px-3 lg:px-5 flex items-center justify-between gap-3">
        {/* Left Cluster: Mobile Toggle + SFT Wordmark + Player Search */}
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(true)}
            aria-label="Open navigation menu"
            className="lg:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-[#242b3f] cursor-pointer"
          >
            <Menu className="w-5 h-5" />
          </button>

          <Link to="/" className="flex items-center gap-2.5 shrink-0">
            <div className="arena-brand-mark"><img src={sftLogo} alt="SFT" width={62} height={62}/></div>
            <span className="hidden 2xl:inline font-display font-bold text-sm tracking-tight text-white">
              Solana Fortnite Tokens
            </span>
          </Link>

          {playerSearch("arena-header-search relative hidden sm:block ml-1 w-40 lg:w-44 xl:w-48 shrink-0")}
        </div>

        {/* Center Main Navigation */}
        <nav className="arena-tabs hidden lg:flex items-center gap-0.5 xl:gap-1" aria-label="Main navigation">
          {primaryTabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <NavLink
                key={tab.to} title={tab.label} aria-label={tab.label}
                to={tab.to}
                end={tab.to === '/'}
                className={({ isActive }) =>
                  `px-2.5 xl:px-3.5 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 xl:gap-2 transition-colors whitespace-nowrap ${
                    isActive
                      ? 'bg-[#2a3248] text-white'
                      : 'text-slate-300 hover:text-white hover:bg-[#22283a]'
                  }`
                }
              >
                <Icon className="w-4 h-4" />
                <span className="sr-only">{tab.label}</span>
              </NavLink>
            );
          })}
        </nav>

        {/* Right Cluster: Region + Apps + Notifications + Profile + Balance/Wallet */}
        <div className="arena-header-actions flex items-center gap-2 shrink-0">
          {/* Apps quick launcher */}
          <div className="relative">
            <button
              type="button"
              onClick={() => { setAppsMenuOpen((v) => !v); setNotifOpen(false); setProfileMenuOpen(false); }}
              aria-label="More platform sections"
              aria-haspopup="dialog"
              aria-expanded={appsMenuOpen}
              className="w-8 h-8 rounded-full bg-[#22283a] hover:bg-[#2d354c] text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
          </div>
          <dialog ref={appMenu} aria-label="Menu" className="arena-launcher" onCancel={event=>{event.preventDefault();setAppsMenuOpen(false);}}
            onClick={event=>{if(event.target===event.currentTarget)setAppsMenuOpen(false);}}>
            <section>
              <header><h2 className="arena-logo-heading"><img src={sftLogo} alt="" width={30} height={30}/>Menu</h2><button type="button" aria-label="Close menu" onClick={()=>setAppsMenuOpen(false)}><X size={21}/></button></header>
              <div className="arena-launcher-grid">
                {appTiles.map(({to,label,detail,icon:Icon,tone})=><Link key={to} to={to} onClick={()=>setAppsMenuOpen(false)}>
                  <span data-tone={tone}><Icon size={24}/></span><b>{label}</b><small>{detail}</small>
                </Link>)}
                {communityUrl ? <a href={communityUrl} target="_blank" rel="noreferrer" onClick={()=>setAppsMenuOpen(false)}>
                  <span data-tone="violet"><MessageCircle size={24}/></span><b>Discord</b><small>Community</small>
                </a> : <button type="button" disabled title="A community invite has not been configured">
                  <span data-tone="violet"><MessageCircle size={24}/></span><b>Discord</b><small>Community</small>
                </button>}
              </div>
              <footer>
                <Link to="/rules#privacy" onClick={()=>setAppsMenuOpen(false)}><ShieldAlert size={15}/>Privacy</Link>
                <Link to="/rules#terms" onClick={()=>setAppsMenuOpen(false)}><FileText size={15}/>Terms</Link>
                <Link to="/support#faq" onClick={()=>setAppsMenuOpen(false)}><HelpCircle size={15}/>FAQ</Link>
              </footer>
            </section>
          </dialog>

          {/* Notifications */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setNotifOpen((v) => !v);
                setAppsMenuOpen(false);
                setProfileMenuOpen(false);
                if (!notifOpen && unreadCount > 0) markNotificationsRead();
              }}
              aria-label="Notifications"
              className="relative w-8 h-8 rounded-full bg-[#22283a] hover:bg-[#2d354c] text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center tabular-nums">
                  {unreadCount}
                </span>
              )}
            </button>
            {notifOpen && (
              <div className="arena-header-popover absolute right-0 mt-2 w-72 bg-[#181d2c] border border-[#2a3248] rounded-xl shadow-2xl overflow-hidden z-50">
                <div className="px-3.5 py-2.5 border-b border-[#242c42] flex items-center justify-between">
                  <span className="text-xs font-bold text-white">Notifications</span>
                  <span className="text-[11px] text-slate-400 tabular-nums">{notifications.length}</span>
                </div>
                <div className="max-h-72 overflow-y-auto custom-scrollbar divide-y divide-[#232a3e]">
                  {notifications.length === 0 ? (
                    <div className="p-4 text-xs text-slate-400 text-center">No notifications yet.</div>
                  ) : (
                    notifications.slice(0, 8).map((n) => (
                      <Link
                        key={n.id}
                        to={n.link_url || '/'}
                        className="block px-3.5 py-2.5 hover:bg-[#22283a] transition-colors"
                      >
                        <div className="text-xs font-semibold text-white">{n.title}</div>
                        <div className="text-[11px] text-slate-400 mt-0.5">{n.body}</div>
                      </Link>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {user ? (
            <>
              {/* Profile Dropdown */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => { setProfileMenuOpen((v) => !v); setNotifOpen(false); setAppsMenuOpen(false); }}
                  aria-label="Account menu" className="arena-account-button flex items-center gap-2 pl-1 pr-2 py-1 rounded-full hover:bg-[#242b3f] transition-colors cursor-pointer"
                >
                  <PlayerPortrait name={user.username} className="header-portrait" portrait={user.profilePortrait}/>
                  <span className="hidden sm:inline text-xs font-semibold text-slate-200 max-w-[90px] truncate">
                    {user.username}
                  </span>
                </button>
                {profileMenuOpen && (
                  <div className="arena-header-popover absolute right-0 mt-2 w-52 bg-[#181d2c] border border-[#2a3248] rounded-xl shadow-2xl p-1.5 z-50">
                    <div className="px-3 py-2 border-b border-[#242c42] mb-1">
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        {user.username}
                        <span className="text-[10px] uppercase px-1.5 py-0.5 rounded bg-[#6d4aff]/20 text-[#b4a0ff]">
                          {user.role}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 truncate">Epic: {user.epicDisplayName || 'Unlinked'}</div>
                    </div>
                    <Link to={`/profile/${user.username}`} className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-slate-200 hover:bg-[#232a3f]">
                      <UserIcon className="w-3.5 h-3.5" /> Public Profile
                    </Link>
                    <button
                      type="button"
                      onClick={logout}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-red-300 hover:bg-red-500/10 cursor-pointer mt-1"
                    >
                      <LogOut className="w-3.5 h-3.5" /> Sign Out
                    </button>
                  </div>
                )}
              </div>

              {/* Balance + Wallet Pill */}
              <button
                type="button" aria-label="Wallet" title={formatSol(user.balance.available_lamports,4) + " SOL"} onClick={()=>setWalletOpen(true)}
                className="arena-wallet-pill flex items-center bg-[#111521] border border-[#272f45] rounded-lg overflow-hidden h-9 hover:border-[#6d4aff]/60 transition-colors"
              >
                <div className="px-2.5 flex flex-col justify-center leading-none">
                  <div className="flex items-center gap-1 text-xs font-bold text-white tabular-nums">
                    <span className="w-2 h-2 rounded-full bg-[#f5c542] inline-block" />
                    {formatSol(user.balance.available_lamports, 4)}
                    <span className="text-[10px] text-slate-400 font-medium">SOL</span>
                  </div>
                  {user.balance.reserved_lamports > 0 && (
                    <div className="text-[10px] text-slate-400 tabular-nums mt-0.5">
                      {formatSol(user.balance.reserved_lamports, 2)} escrow
                    </div>
                  )}
                </div>
                <div className="h-full px-2.5 bg-[#6d4aff] hover:bg-[#7b5cff] text-white flex items-center justify-center">
                  <Wallet className="w-4 h-4" />
                </div>
              </button>
            </>
          ) : (
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => openAuthModal('login')}
                className="px-3 py-1.5 rounded-lg bg-[#232a3f] hover:bg-[#2d3650] text-xs font-semibold text-white cursor-pointer"
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => openAuthModal('register')}
                className="px-3 py-1.5 rounded-lg bg-[#6d4aff] hover:bg-[#7b5cff] text-xs font-semibold text-white cursor-pointer"
              >
                Join SFT
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Main Workspace: Collapsible Activity Rail + Page Content */}
      <div className="flex-1 flex min-w-0">
        {/* Desktop Collapsible Left Activity Rail */}
        {railOpen ? (
          <aside data-profile={isProfileArea || staffArea} data-admin={staffArea} className="arena-rail hidden lg:flex flex-col w-[228px] shrink-0 bg-[#141927] border-r border-[#21283b] h-[calc(100vh-3.5rem)] sticky top-14">
            <div className="flex items-center justify-between px-3.5 py-2.5 border-b border-[#202739]">
              {staffArea ? <div className="admin-rail-heading"><ShieldAlert size={19}/>Admin Panel</div> : accountRail ? <div className="arena-rail-balance"><Coins size={30}/><div><strong>SFT Balance</strong><small>{user ? formatSol(user.balance.available_lamports,2)+' SOL balance' : 'Sign in to view balance'}</small></div></div>
              : <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Activity Rail</span>}
              <button
                type="button"
                onClick={() => setRailOpen(false)}
                aria-label="Collapse activity rail"
                className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-[#232a3e] cursor-pointer"
              >
                <ArrowLeftToLine className="w-3.5 h-3.5" />
              </button>
            </div>

            {staffArea && user ? <AdminNavigation role={user.role}/> : <>
            {accountRail && <div className="arena-rail-actions">
              {user ? <Link to={'/profile/'+encodeURIComponent(user.username)}><UserIcon size={15}/> Profile</Link> : <button type="button" onClick={()=>openAuthModal()}><UserIcon size={15}/> Sign In</button>}
            </div>}
            <div className={'arena-rail-scroll flex-1 overflow-y-auto custom-scrollbar p-3 space-y-4'+(accountRail ? ' board-rail-scroll' : '')}>
              {/* Current Match Box */}
              <div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-2 px-1">
                  Active Match
                </div>
                {activeOngoingMatch ? (
                  <Link
                    to={`/matches/${activeOngoingMatch.id}`}
                    className="block p-3 rounded-lg bg-[#1c2336] border border-[#6d4aff]/40 hover:border-[#6d4aff] transition-colors"
                  >
                    <div className="flex items-center justify-between text-[11px] font-semibold text-[#9d85ff]">
                      <span>{activeOngoingMatch.status}</span>
                      <span className="tabular-nums">{activeOngoingMatch.format}</span>
                    </div>
                    <div className="text-xs font-bold text-white truncate mt-1">{activeOngoingMatch.title}</div>
                    <div className="text-[11px] text-slate-400 mt-1">Open Match Room →</div>
                  </Link>
                ) : (
                  <div className="p-3 rounded-lg bg-[#181e2e] border border-[#242c42] text-center">
                    <div className="text-xs font-semibold text-slate-200">No active match</div>
                    <div className="text-[11px] text-slate-400 mt-0.5 mb-2.5">Enter an open lobby now</div>
                    <Link
                      to="/matches"
                      className="block w-full py-1.5 rounded-md bg-[#232b42] hover:bg-[#2e3854] text-xs font-semibold text-white transition-colors"
                    >
                      Play Now
                    </Link>
                  </div>
                )}
              </div>

              {/* Quick Section Links */}
              <div className="rail-platform-links">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5 px-1">
                  Platform
                </div>
                <div className="space-y-0.5">
                  {railLinks.map((item) => {
                    const Icon = item.icon;
                    return (
                      <NavLink
                        key={item.to}
                        to={item.to}
                        end={item.to === '/'}
                        className={({ isActive }) =>
                          `flex items-center gap-2.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                            isActive
                              ? 'bg-[#252d43] text-white'
                              : 'text-slate-400 hover:text-white hover:bg-[#1b2133]'
                          }`
                        }
                      >
                        <Icon className="w-3.5 h-3.5 shrink-0" />
                        {item.label}
                      </NavLink>
                    );
                  })}
                </div>
              </div>
            </div>
            </>}
          </aside>
        ) : (
          <div className="arena-expand hidden lg:block fixed left-1 top-[66px] z-30">
            <button
              type="button"
              onClick={() => setRailOpen(true)}
              aria-label="Expand activity rail"
              className="p-2 rounded-lg bg-[#1b2133] border border-[#2a3248] text-slate-300 hover:text-white shadow-lg cursor-pointer"
            >
              <ArrowRightFromLine className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Mobile Drawer Navigation */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-[70] lg:hidden flex">
            <div className="fixed inset-0 bg-black/70" onClick={() => setMobileMenuOpen(false)} />
            <div className="relative w-72 max-w-[85vw] bg-[#141927] border-r border-[#232a3e] h-full flex flex-col z-10">
              <div className="px-4 py-3 border-b border-[#232a3e] flex items-center justify-between">
                <span className="font-display font-bold text-sm text-white arena-logo-heading"><img src={sftLogo} alt="" width={30} height={30}/>{staffArea ? 'Admin Panel' : 'SFT Navigation'}</span>
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  aria-label="Close drawer"
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              {staffArea && user ? <AdminNavigation role={user.role} onNavigate={()=>setMobileMenuOpen(false)}/> : <>
              <div className="flex-1 overflow-y-auto p-3 space-y-1">
                <div className="pb-3">{playerSearch("relative w-full")}</div>
                {railLinks.map((item) => {
                  const Icon = item.icon;
                  return (
                    <NavLink
                      key={item.to}
                      to={item.to}
                      onClick={()=>setMobileMenuOpen(false)}
                      end={item.to === '/'}
                      className={({ isActive }) =>
                        `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${
                          isActive ? 'bg-[#6d4aff] text-white' : 'text-slate-300 hover:bg-[#1e2438]'
                        }`
                      }
                    >
                      <Icon className="w-4 h-4" />
                      {item.label}
                    </NavLink>
                  );
                })}
              </div>
              </>}
            </div>
          </div>
        )}

        {/* Main Scrollable Viewport */}
        <main className="flex-1 min-w-0">{children}</main>
      </div>

      {walletOpen && user && <WalletDialog onClose={()=>setWalletOpen(false)} />}
      <AuthModal />
    </div>
  );
}
