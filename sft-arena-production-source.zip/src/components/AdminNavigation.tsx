import { Activity, Ban, ChartNoAxesCombined, ChevronDown, Gift, HandCoins, LayoutGrid, Shield, Store, Trophy, UserPlus, Users, Wallet } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const groups = [
  { label:'', items:[{ view:'overview', label:'Overview', icon:LayoutGrid }] },
  { label:'Users & identity', items:[
    { view:'users',label:'Users/Staff',icon:Users },{ view:'referrals',label:'Referrals',icon:UserPlus },
    { view:'signups',label:'Signups',icon:UserPlus },{ view:'accounts',label:'Alts & Risk',icon:Users },
  ] },
  { label:'Money & rewards', items:[
    { view:'balances',label:'Balances',icon:Wallet,roles:['finance','owner'] },
    { view:'deposits',label:'Money',icon:HandCoins,roles:['finance','owner'] },{ view:'gifting',label:'Rewards',icon:Gift },
  ] },
  { label:'Matches & safety', items:[
    { view:'tournaments',label:'Tournaments',icon:Trophy },{ view:'bans',label:'Moderation',icon:Ban },
  ] },
  { label:'Store & content', items:[{ view:'store', label:'Store',icon:Store }] },
  { label:'Operations', items:[
    { view:'analytics',label:'Statistics',icon:ChartNoAxesCombined,roles:['owner'] },{ view:'audit',label:'Audit Log',icon:Activity },
  ] },
];

const parentViews: Record<string,string> = {
  finance:'deposits',withdrawals:'deposits',moneyAudit:'deposits',matches:'tournaments',
  disputes:'tournaments',fees:'tournaments',claims:'gifting',locker:'store',avatars:'store',
};

export function adminHref(view:string) {
  return view==='overview' ? '/staff' : '/staff?tab='+view;
}

export default function AdminNavigation({role,onNavigate}:{role:string;onNavigate?:()=>void}) {
  const location = useLocation();
  const view = location.pathname.startsWith('/staff/players/') ? 'users' : new URLSearchParams(location.search).get('tab') || 'overview';
  const active = parentViews[view] || view;

  return <nav className="admin-navigation" aria-label="Admin sections">
    {groups.map(group=>{
      const items = group.items.filter(item=>!('roles' in item) || item.roles?.includes(role));
      if (!items.length) return null;
      const links = items.map(({view,label,icon:Icon})=><Link key={view} to={adminHref(view)}
        aria-current={view===active ? 'page' : undefined} onClick={onNavigate}><Icon size={18}/>{label}</Link>);
      return group.label ? <details key={group.label} open><summary>{group.label}<ChevronDown size={14}/></summary>{links}</details>
        : <div key="overview">{links}</div>;
    })}
    <Link className="admin-rail-back" to="/" onClick={onNavigate}><Shield size={17}/>Back to Site</Link>
  </nav>;
}
