import { Link } from 'react-router-dom';
import { Timer } from 'lucide-react';
import { formatMatchTimerMMSS, formatRegionFull, formatSol, getModeArt } from '../lib/format';
import boxFightsProp from '../assets/match-props/box-fights.webp';
import zoneWarsProp from '../assets/match-props/zone-wars.webp';
import realisticsProp from '../assets/match-props/realistics.webp';
import buildFightsProp from '../assets/match-props/build-fights.webp';

export interface MatchCardData {
  id: string;
  title: string;
  mode: string;
  format: string;
  platform: string;
  region: string;
  first_to: number;
  win_by_two?: number;
  entry_lamports: number;
  total_prize_lamports: number;
  status: string;
  is_ranked?: number;
  is_demo: number;
  created_at: string;
  creator_username: string;
}

interface MatchCardProps {
  key?: string | number;
  match: MatchCardData;
  nowMs?: number;
}

const MODE_LABELS: Record<string, string> = {
  Realistics: 'Realistic',
  'Box Fights': 'Boxfight',
};

const MODE_TINTS: Record<string, string> = {
  'Box Fights': '#9b8638',
  'Zone Wars': '#6092a4',
  Realistics: '#438940',
  'Build Fights': '#6b5898',
  'Piece Control': '#97556e',
  'Zero Build': '#37789b',
};

const MODE_PROPS: Record<string, string> = {
  'Box Fights': boxFightsProp,
  'Zone Wars': zoneWarsProp,
  Realistics: realisticsProp,
  'Build Fights': buildFightsProp,
};

export default function MatchCard({ match, nowMs }: MatchCardProps) {
  const title = `${match.format} ${MODE_LABELS[match.mode] ?? match.mode}`;
  const prop = MODE_PROPS[match.mode];
  const img = prop ?? getModeArt(match.mode).img;
  const prize = match.total_prize_lamports > 0 ? formatSol(match.total_prize_lamports, 2) : null;

  return (
    <article className="sft-match-card">
      <div
        className="sft-match-card__art"
        style={{ backgroundColor: MODE_TINTS[match.mode] ?? MODE_TINTS['Zone Wars'] }}
      >
        <img className={prop ? 'sft-match-card__prop' : undefined} src={img} alt="" loading="lazy" decoding="async" />
        <span className="sft-match-card__prize" aria-label={prize ? `Prize: ${prize} SOL` : 'Free match'}>
          {prize && <span aria-hidden="true" className="sft-match-card__coin">S</span>}
          {prize ?? 'Free'}
        </span>
      </div>

      <div className="sft-match-card__body">
        <div className="sft-match-card__timer" aria-label="Time since match creation">
          <Timer size={17} aria-hidden="true" />
          <span>{formatMatchTimerMMSS(match.created_at, nowMs)}</span>
        </div>
        <h3>{title}</h3>
        <ul className="sft-match-card__meta" aria-label="Match details">
          <li>{match.platform}</li>
          <li>{formatRegionFull(match.region)}</li>
          <li aria-label={`First to ${match.first_to}${match.win_by_two ? ', win by two' : ''}`}>
            {match.first_to}{Boolean(match.win_by_two) && <sup>+2</sup>}
          </li>
        </ul>
        <Link to={`/matches/${match.id}`} className="sft-match-card__action">
          {match.status === 'Waiting' ? 'View Opponent' : `Open Room (${match.status})`}
        </Link>
      </div>
    </article>
  );
}
