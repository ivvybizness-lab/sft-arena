import portrait1 from '../assets/player-portraits/portrait-1.webp';
import portrait2 from '../assets/player-portraits/portrait-2.webp';

const basePortraits = [portrait1, portrait2];
const collectibles = import.meta.glob<string>('../assets/shop-portraits/*.webp',{eager:true,query:'?url',import:'default'});

export function collectiblePortrait(index:number) {
  return collectibles['../assets/shop-portraits/'+String(index).padStart(2,'0')+'.webp'];
}

export default function PlayerPortrait({name,className='',portrait}:{name:string;className?:string;portrait?:number|null}) {
  const hash = Array.from(name).reduce((value,c)=>(value*31+c.charCodeAt(0))>>>0,0);
  const src = portrait == null ? basePortraits[hash % basePortraits.length] : portrait >= 0 && portrait < 6 ? basePortraits[portrait % basePortraits.length] : collectiblePortrait(portrait) ?? basePortraits[0];
  return <img className={'arena-portrait '+className} src={src} alt="" decoding="async"/>;
}
