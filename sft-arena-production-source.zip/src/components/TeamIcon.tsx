import { Crown, Shield, Star, Target, Trophy, Zap } from 'lucide-react';
import { teamColours } from '../lib/team-options';

const icons = {shield:Shield, bolt:Zap, crown:Crown, target:Target, trophy:Trophy, star:Star};

export default function TeamIcon({icon, colour, size = 18}: {icon: string; colour: string; size?: number}) {
  const Icon = icons[icon as keyof typeof icons] ?? Shield;
  return <Icon size={size} color={teamColours[colour as keyof typeof teamColours] ?? teamColours.gold} aria-hidden="true"/>;
}
