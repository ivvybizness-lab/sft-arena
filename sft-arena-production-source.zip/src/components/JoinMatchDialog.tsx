import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Check, X } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { formatSol } from '../lib/format';

export default function JoinMatchDialog({title,format,entryLamports,onClose,onJoin}:{title:string;format:string;entryLamports:number;onClose:()=>void;onJoin:(teamId:string)=>Promise<void>}) {
  const dialog=useRef<HTMLDialogElement>(null);
  const [teams,setTeams]=useState<{id:string;name:string}[]>([]);
  const [team,setTeam]=useState('');
  const [confirm,setConfirm]=useState(false);
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState('');

  useEffect(()=>{
    const node=dialog.current;
    if (node && !node.open) node.showModal();
    let active=true;
    apiFetch<{teams:typeof teams}>('/api/teams').then(value=>{if(active)setTeams(value.teams);}).catch(()=>{});
    return ()=>{active=false;if(node?.open)node.close();};
  },[]);

  async function submit(event:FormEvent) {
    event.preventDefault();
    if (!confirm) {setConfirm(true);return;}
    if (busy) return;
    setBusy(true);
    setError('');
    try {await onJoin(team);}
    catch (error) {setError((error as Error).message);}
    finally {setBusy(false);}
  }

  return <dialog ref={dialog} className="arena-match-flow join-match-flow" aria-label="Join Match" onCancel={event=>{event.preventDefault();if(!busy)onClose();}}>
    <form onSubmit={submit}>
      <header><button type="button" className="flow-close" aria-label="Close Join Match" disabled={busy} onClick={onClose}><X size={21}/></button>
        <h2>Join Match</h2><p>{title}</p></header>
      <ol className="join-progress" aria-label="Joining steps">
        <li data-done="true"><span><Check size={16}/></span>Match</li>
        <li data-done={confirm} aria-current={!confirm?'step':undefined}><span>{confirm&&<Check size={16}/>}</span>Team</li>
        <li aria-current={confirm?'step':undefined}><span/>Confirm</li>
      </ol>
      <div className="flow-content">
        {confirm ? <>
          <h3>Confirm your entry</h3><p>{team ? teams.find(item=>item.id===team)?.name : 'Solo entry'} · {format}</p>
          <div className="join-cost"><span>Entry per player</span><b>{entryLamports?formatSol(entryLamports,4)+' SOL':'Free'}</b></div>
        </> : <>
          <h3>Select your team</h3><p>Choose how you’ll enter this {format} match.</p>
          <label className="flow-field">Your team<select value={team} onChange={event=>setTeam(event.target.value)}>
            <option value="">Solo entry</option>{teams.map(item=><option key={item.id} value={item.id}>{item.name}</option>)}
          </select></label>
          {format!=='1v1' && <p>Each teammate joins and confirms their own entry.</p>}
        </>}
        {error && <p role="alert" className="flow-error">{error}</p>}
      </div>
      <footer className="flow-actions"><button type="button" disabled={busy} onClick={onClose}>Cancel</button>
        {confirm&&<button type="button" disabled={busy} onClick={()=>{setConfirm(false);setError('');}}>Back</button>}
        <button type="submit" disabled={busy} className="flow-primary">{busy?'Joining…':confirm?'Join Match':'Continue'}</button>
      </footer>
    </form>
  </dialog>;
}
