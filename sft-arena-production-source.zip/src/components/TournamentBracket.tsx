import { useRef,useState } from 'react';
import { Search,Trophy } from 'lucide-react';
import PlayerPortrait from './PlayerPortrait';

export type BracketMatch = {
  id:string;round_number:number;match_slot:number;reg_a_id:string|null;reg_b_id:string|null;
  winner_reg_id:string|null;team_a_name:string|null;team_b_name:string|null;status:string;
  score_a:number;score_b:number;
};

export default function TournamentBracket({matches,captains,recordWinner}:{matches:BracketMatch[];captains:Record<string,string>;recordWinner?:(matchId:string,winnerId:string)=>void}) {
  const [query,setQuery]=useState('');
  const scroll=useRef<HTMLDivElement>(null);
  const search=query.trim().toLowerCase();
  const initialCount=Math.max(1,...matches.filter(match=>match.round_number===1).map(match=>match.match_slot));
  const roundCount=Math.max(1+Math.ceil(Math.log2(initialCount)),...matches.map(match=>match.round_number));
  const cardHeight=88;
  const spacing=110;
  const bySlot = new Map(matches.map(match=>[match.round_number+':'+match.match_slot,match]));
  const rounds=Array.from({length:roundCount},(_,index)=>Array.from({length:Math.ceil(initialCount/2**index)},(_,slot)=>
    bySlot.get((index+1)+':'+(slot+1))));
  const hit=(match:BracketMatch|undefined)=>Boolean(match && [match.team_a_name,match.team_b_name,captains[match.reg_a_id??''],captains[match.reg_b_id??'']]
    .some(value=>value?.toLowerCase().includes(search)));
  const found=search ? matches.filter(hit).length : 0;
  const labels={0:'Finals',1:'Semifinals',2:'Quarterfinals'} as Record<number,string>;

  return <section className="tournament-detail-card">
    <div className="bracket-heading"><h3><Trophy size={20}/>Tournament Bracket</h3>
      <label className="admin-search"><Search size={16}/><input aria-label="Search player or team" value={query} placeholder="Search player or team"
        onChange={event=>setQuery(event.target.value)} onKeyDown={event=>{
          if(event.key==='Enter' && search)scroll.current?.querySelector('[data-match-hit=true]')?.scrollIntoView({block:'nearest',inline:'center'});
        }}/></label>
    </div>
    {!matches.length ? <p>Bracket pairings will appear after seeding.</p> : <>
      {search && <p role="status">{found?found+' matching '+(found===1?'pairing':'pairings')+' · Press Enter to jump':'No matching players or teams.'}</p>}
      <div ref={scroll} className="bracket-scroll" tabIndex={0} aria-label="Scrollable bracket rounds">
        <div className="bracket-inner">
          {rounds.map((round,index)=>{
            const step=spacing*2**index;
            return <section className="bracket-round" key={index}>
              <h4>{labels[roundCount-index-1] ?? 'Round '+(index+1)}</h4>
              <div className="bracket-slots" style={{height:Math.max(initialCount*spacing,step)}}>
                {round.map((match,slot)=>{
                  const sides=[
                    {id:match?.reg_a_id,name:match?.team_a_name,score:match?.score_a},
                    {id:match?.reg_b_id,name:match?.team_b_name,score:match?.score_b},
                  ];
                  const highlight=Boolean(search && hit(match));
                  const top=(slot+.5)*step-cardHeight/2;
                  const nextCenter=(Math.floor(slot/2)+.5)*step*2;
                  const currentCenter=top+cardHeight/2;
                  return <div className="bracket-slot" key={match?.id??slot} style={{top,height:cardHeight}}>
                    {index<roundCount-1 && <div aria-hidden="true" className="bracket-line"
                      data-direction={nextCenter<currentCenter?'up':'down'}
                      style={{height:Math.abs(nextCenter-currentCenter),top:Math.min(nextCenter-currentCenter,0)+cardHeight/2}} />}
                    <div className="bracket-pair" data-match-hit={highlight} data-muted={Boolean(search&&!highlight)} data-complete={Boolean(match?.winner_reg_id)}>
                      {sides.map(({id,name,score},side)=>{
                        const winner=Boolean(id && id===match?.winner_reg_id);
                        const canChoose=Boolean(recordWinner && match && match.status==='Ready' && match.reg_a_id && match.reg_b_id && id);
                        const content=<>{name && <PlayerPortrait name={id?captains[id]??name:name}/>}
                          <span>{name || (match?.status==='Bye'?'Bye':'To be decided')}</span>
                          {winner&&<Trophy size={14}/>}
                          {match?.status==='Complete'&&<b>{score??0}</b>}</>;
                        return canChoose && match && id ? <button key={side} type="button" data-winner={winner} title={'Record '+name+' as winner'}
                          onClick={()=>recordWinner?.(match.id,id)}>{content}</button>
                          : <div key={side} data-winner={winner}>{content}</div>;
                      })}
                    </div>
                  </div>;
                })}
              </div>
            </section>;
          })}
        </div>
      </div>
    </>}
  </section>;
}
