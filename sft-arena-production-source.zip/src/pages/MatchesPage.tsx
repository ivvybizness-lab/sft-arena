import React, { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Swords, Plus, Search, SlidersHorizontal } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import CreateMatchModal from '../components/CreateMatchModal';
import MatchCard, { MatchCardData } from '../components/MatchCard';

interface MatchRow {
  id: string;
  title: string;
  mode: string;
  format: string;
  platform: string;
  region: string;
  first_to: number;
  entry_lamports: number;
  total_prize_lamports: number;
  status: string;
  is_ranked: number;
  is_demo: number;
  created_at: string;
  creator_username: string;
  participants: Array<{ user_id: string; username_snapshot: string; team_side: string }>;
}

interface Counts {
  open: number;
  ongoing: number;
  ranked: number;
}

export default function MatchesPage() {
  const { user, regionFilter, openAuthModal } = useAuth();
  const [searchParams] = useSearchParams();

  const [tab, setTab] = useState<'open' | 'ongoing' | 'ranked' | 'my'>('open');
  const [platform, setPlatform] = useState('ALL');
  const [region, setRegion] = useState(regionFilter || 'ALL');
  const [mode, setMode] = useState(searchParams.get('mode') || 'ALL');
  const [format, setFormat] = useState('ALL');
  const [firstTo, setFirstTo] = useState('0');
  const [search, setSearch] = useState('');

  const [matches, setMatches] = useState<MatchRow[]>([]);
  const [counts, setCounts] = useState<Counts>({ open: 0, ongoing: 0, ranked: 0 });
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [nowMs, setNowMs] = useState(() => Date.now());

  useEffect(() => {
    const id = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const paramMode = searchParams.get('mode');
    if (paramMode) setMode(paramMode);
  }, [searchParams]);

  useEffect(() => {
    setRegion(regionFilter || 'ALL');
  }, [regionFilter]);

  const loadMatches = useCallback(async () => {
    setLoading(true);
    try {
      const qs = new URLSearchParams({
        tab,
        platform,
        region,
        mode,
        format,
        firstTo,
        search,
      });
      const data = await apiFetch<{ matches: MatchRow[]; counts: Counts }>(`/api/matches?${qs.toString()}`);
      setMatches(data.matches);
      setCounts(data.counts);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }, [tab, platform, region, mode, format, firstTo, search]);

  useEffect(() => {
    loadMatches();
  }, [loadMatches]);

  return (
    <div className="arena-match-list px-4 sm:px-6 lg:px-8 py-6 max-w-[1360px] mx-auto">
      {/* Header Row matching Reference Image 4 */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl sm:text-3xl font-display font-extrabold text-white tracking-tight">
              Find Matches
            </h1>
            <span className="px-2.5 py-0.5 rounded bg-[#f5c542] text-[#111521] text-[11px] font-extrabold uppercase tracking-wider">
              SOL ESCROW 5% FEE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1 tabular-nums">
            <strong className="text-slate-200">{counts.open}</strong> Open Matches •{' '}
            <strong className="text-slate-200">{counts.ongoing}</strong> Ongoing Matches •{' '}
            <strong className="text-slate-200">{counts.ranked}</strong> Ranked
          </p>
        </div>

        <button
          type="button"
          onClick={() => (user ? setCreateOpen(true) : openAuthModal('login'))}
          className="px-4 py-2.5 rounded-lg bg-[#6d4aff] hover:bg-[#7b5cff] text-white text-xs font-semibold flex items-center gap-1.5 shadow-lg shadow-[#6d4aff]/20 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          Create Match
        </button>
      </div>

      {/* Tabs */}
      <div className="match-list-tabs mt-5 border-b border-[#232a3e] flex items-center gap-6" role="group" aria-label="Match lists">
        {[
          { key: 'open', label: 'Open Matches' },
          { key: 'ongoing', label: 'Ongoing Matches' },
          { key: 'ranked', label: 'Ranked' },
          { key: 'my', label: 'My Matches' },
        ].map((t) => (
          <button
            key={t.key}
            type="button"
            aria-pressed={tab===t.key}
            onClick={() => setTab(t.key as typeof tab)}
            className={`pb-3 text-xs sm:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
              tab === t.key
                ? 'border-[#6d4aff] text-white'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Compact Filter Toolbar matching Reference Image 4 */}
      <div className="mt-4 flex flex-wrap items-center gap-2.5">
        <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#171d2c] border border-[#262e45] text-xs">
          <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-slate-400">Platform:</span>
          <select
            value={platform}
            onChange={(e) => setPlatform(e.target.value)}
            className="bg-transparent text-white font-semibold focus:outline-none cursor-pointer"
          >
            <option value="ALL" className="bg-[#181d2c]">Any</option>
            <option value="All" className="bg-[#181d2c]">Cross-Play</option>
            <option value="PC" className="bg-[#181d2c]">PC</option>
            <option value="Console" className="bg-[#181d2c]">Console</option>
          </select>
        </div>

        <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#171d2c] border border-[#262e45] text-xs">
          <span className="text-slate-400">Region:</span>
          <select
            value={region}
            onChange={(e) => setRegion(e.target.value)}
            className="bg-transparent text-white font-semibold focus:outline-none cursor-pointer"
          >
            <option value="ALL" className="bg-[#181d2c]">All</option>
            <option value="NAE" className="bg-[#181d2c]">NAE</option>
            <option value="NAC" className="bg-[#181d2c]">NAC</option>
            <option value="NAW" className="bg-[#181d2c]">NAW</option>
            <option value="EU" className="bg-[#181d2c]">EU</option>
          </select>
        </div>

        <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#171d2c] border border-[#262e45] text-xs">
          <span className="text-slate-400">Mode:</span>
          <select
            value={mode}
            onChange={(e) => setMode(e.target.value)}
            className="bg-transparent text-white font-semibold focus:outline-none cursor-pointer"
          >
            <option value="ALL" className="bg-[#181d2c]">All</option>
            {['Zone Wars', 'Box Fights', 'Realistics', 'Build Fights', 'Piece Control', 'Zero Build'].map((m) => (
              <option key={m} value={m} className="bg-[#181d2c]">{m}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#171d2c] border border-[#262e45] text-xs">
          <span className="text-slate-400">Team Size:</span>
          <select
            value={format}
            onChange={(e) => setFormat(e.target.value)}
            className="bg-transparent text-white font-semibold focus:outline-none cursor-pointer"
          >
            <option value="ALL" className="bg-[#181d2c]">All</option>
            {['1v1', '2v2', '3v3', '4v4'].map((f) => (
              <option key={f} value={f} className="bg-[#181d2c]">{f}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#171d2c] border border-[#262e45] text-xs">
          <span className="text-slate-400">First To:</span>
          <select
            value={firstTo}
            onChange={(e) => setFirstTo(e.target.value)}
            className="bg-transparent text-white font-semibold focus:outline-none cursor-pointer"
          >
            <option value="0" className="bg-[#181d2c]">Any</option>
            {[3, 5, 7, 10].map((n) => (
              <option key={n} value={n} className="bg-[#181d2c]">First to {n}</option>
            ))}
          </select>
        </div>

        <div className="relative flex-1 min-w-[180px] max-w-xs">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search title, match ID, or player…"
            className="w-full h-8 pl-8 pr-3 rounded-lg bg-[#171d2c] border border-[#262e45] text-xs text-white placeholder-slate-500"
          />
        </div>
      </div>

      {/* Match Cards Grid */}
      {loading ? (
        <div className="sft-match-grid mt-5">
          {[1, 2, 3, 4].map((n) => (
            <div key={n} className="h-72 rounded-xl bg-[#191f2f] border border-[#262e45] animate-pulse" />
          ))}
        </div>
      ) : matches.length === 0 ? (
        <div className="mt-6 p-10 rounded-xl bg-[#161b29] border border-[#232a3e] text-center">
          <Swords className="w-8 h-8 text-slate-500 mx-auto mb-2" />
          <div className="text-sm font-semibold text-white">No matches matched your filters</div>
          <p className="text-xs text-slate-400 mt-1">Adjust filters or host a new match room.</p>
          <button
            type="button"
            onClick={() => (user ? setCreateOpen(true) : openAuthModal('login'))}
            className="mt-4 px-4 py-2 rounded-lg bg-[#6d4aff] hover:bg-[#7b5cff] text-white text-xs font-semibold cursor-pointer"
          >
            Create Match
          </button>
        </div>
      ) : (
        <div className="sft-match-grid mt-5">
          {matches.map((m) => (
            <MatchCard key={m.id} match={m as MatchCardData} nowMs={nowMs} />
          ))}
        </div>
      )}

      <CreateMatchModal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        defaultMode={mode !== 'ALL' ? mode : 'Zone Wars'}
      />
    </div>
  );
}
