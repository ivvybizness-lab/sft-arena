import React, { useEffect, useState, useCallback } from 'react';
import { useLocation } from 'react-router-dom';
import { HelpCircle, Send } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { formatUtcTimestamp } from '../lib/format';
import { useAuth } from '../context/AuthContext';

interface Ticket {
  id: string;
  category: string;
  subject: string;
  description: string;
  status: string;
  created_at: string;
  username?: string;
}

function SupportFaq({recovering}: {recovering: boolean}) {
  return <section id="faq" className="rounded-xl bg-[#161b29] border border-[#252d44] p-5 space-y-3 text-left" style={{scrollMarginTop:115}}>
    <h2 className="font-bold text-lg">Frequently Asked Questions</h2>
    <details id="account-recovery" open={recovering}><summary className="cursor-pointer font-semibold">How can I recover my account?</summary><p className="text-sm text-slate-300 mt-2">If your account is linked to Google, sign in with Google. Self-service password reset is currently unavailable.</p></details>
    <details><summary className="cursor-pointer font-semibold">How do I join a match?</summary><p className="text-sm text-slate-300 mt-2">Open a waiting match, select solo entry or one of your teams, and confirm.</p></details>
    <details><summary className="cursor-pointer font-semibold">Where are my private match invites?</summary><p className="text-sm text-slate-300 mt-2">Open the notification bell or check My Matches for invitations.</p></details>
    <details><summary className="cursor-pointer font-semibold">Where can I find tournament prizes and brackets?</summary><p className="text-sm text-slate-300 mt-2">Open a tournament and select Prizes or Bracket.</p></details>
  </section>;
}

export default function SupportPage() {
  const {hash}=useLocation();
  const { user, openAuthModal, notify } = useAuth();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [category, setCategory] = useState('Match Dispute');
  const [subject, setSubject] = useState('');
  const [description, setDescription] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const loadTickets = useCallback(async () => {
    if (!user) return;
    try {
      const d = await apiFetch<{ tickets: Ticket[] }>('/api/support/tickets');
      setTickets(d.tickets);
    } catch {
      // ignore
    }
  }, [user]);

  useEffect(() => {
    loadTickets();
  }, [loadTickets]);

  useEffect(()=>{if(hash==='#faq' || hash==='#account-recovery')document.getElementById(hash.slice(1))?.scrollIntoView({block:'start'});},[hash,user?.id]);

  if (!user) {
    return (
      <div className="p-8 max-w-xl mx-auto text-center space-y-4">
        <div className="p-8 rounded-xl bg-[#161b29] border border-[#252d44]">
          <HelpCircle className="w-10 h-10 text-[#9d85ff] mx-auto mb-3" />
          <h1 className="text-xl font-display font-bold text-white">SFT Player Support</h1>
          <p className="text-sm text-slate-400 mt-1">Sign in to open support tickets for deposits, withdrawals, or match issues.</p>
          <button
            type="button"
            onClick={() => openAuthModal('login')}
            className="mt-4 px-5 py-2.5 rounded-lg bg-[#6d4aff] text-white text-xs font-bold cursor-pointer"
          >
            Sign In
          </button>
        </div>
        <SupportFaq recovering={hash==='#account-recovery'}/>
      </div>
    );
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      await apiFetch('/api/support/tickets', {
        method: 'POST',
        body: JSON.stringify({ category, subject, description }),
      });
      setSubject('');
      setDescription('');
      await loadTickets();
      notify('Support ticket submitted to SFT Staff.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Unable to submit ticket', 'error');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8 py-6 max-w-[1000px] mx-auto space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-display font-extrabold text-white">Support Center</h1>
        <p className="text-xs text-slate-400 mt-1">Direct ticket queue for SOL deposit/withdrawal questions, account appeals, and match help.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        <form onSubmit={handleSubmit} className="md:col-span-5 rounded-xl bg-[#161b29] border border-[#252d44] p-5 space-y-3 h-fit">
          <h2 className="text-sm font-display font-bold text-white">Open a Support Ticket</h2>
          <div>
            <label className="block text-xs text-slate-300 mb-1">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full h-9 px-3 rounded-lg bg-[#111521] border border-[#283148] text-xs text-white"
            >
              <option value="Match Dispute">Match Dispute</option>
              <option value="SOL Deposit">SOL Deposit</option>
              <option value="SOL Withdrawal">SOL Withdrawal</option>
              <option value="Account & Verification">Account & Verification</option>
              <option value="General">General</option>
            </select>
          </div>
          <div>
            <label className="block text-xs text-slate-300 mb-1">Subject</label>
            <input
              required
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Match ID or short summary..."
              className="w-full h-9 px-3 rounded-lg bg-[#111521] border border-[#283148] text-xs text-white"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-300 mb-1">Details</label>
            <textarea
              required
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Include match ID or Solana transaction signature if applicable..."
              className="w-full p-3 rounded-lg bg-[#111521] border border-[#283148] text-xs text-white"
            />
          </div>
          <button
            type="submit"
            disabled={submitting}
            className="w-full py-2.5 rounded-lg bg-[#6d4aff] hover:bg-[#7b5cff] text-white text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" /> Submit Ticket
          </button>
        </form>

        <div className="md:col-span-7 rounded-xl bg-[#161b29] border border-[#252d44] overflow-hidden">
          <div className="px-5 py-3 border-b border-[#232a3e] text-sm font-display font-bold text-white">
            Your Tickets ({tickets.length})
          </div>
          <div className="divide-y divide-[#22293d]">
            {tickets.length === 0 ? (
              <div className="p-6 text-xs text-slate-500 text-center">No support tickets submitted yet.</div>
            ) : (
              tickets.map((t) => (
                <div key={t.id} className="p-4 space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-white">{t.subject}</span>
                    <span className="px-2 py-0.5 rounded bg-[#232b42] text-[10px] font-bold uppercase text-[#c2b2ff]">
                      {t.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">{t.description}</p>
                  <div className="text-[10px] text-slate-500 tabular-nums">
                    {t.category} · {formatUtcTimestamp(t.created_at)}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
      <SupportFaq recovering={hash==='#account-recovery'}/>
    </div>
  );
}
