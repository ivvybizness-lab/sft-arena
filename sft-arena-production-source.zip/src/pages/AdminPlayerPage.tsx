import { FormEvent, useCallback, useEffect, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { ArrowLeft, ShieldAlert } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import PlayerPortrait from '../components/PlayerPortrait';
import { apiFetch } from '../lib/api';
import { formatSol } from '../lib/format';

const destinations = ['Info', 'Alts', 'Logs', 'Money Logs', 'Notes', 'History', 'Discord Transcripts', 'Withdrawals', 'Deposits', 'Tips', 'Purchases'] as const;
type Tab = typeof destinations[number];
type Entry = { id?: string; title?: string; body: string; author?: string; amount?: number; created_at: string };
type PlayerDetail = {
  player: {
    id: string; username: string; display_name: string; created_at: string; status: string; role: string;
    email: string; competitive_region: string; epic_display_name: string; risk_score: number;
    available_lamports: number; frozen_lamports: number; reserved_lamports: number;
    chat_banned: number; force_stream: number; lock_tipping: number; staff_verified: number; force_anticheat: number;
  };
  security: Entry[]; logs: Entry[]; notes: Entry[]; ledger: Entry[]; history: Entry[];
};
const moderation = [
  ['chat_banned','Chat Ban','Allow Chat'],
  ['force_stream','Force Stream','Clear Stream Requirement'],
  ['force_anticheat','Force Anticheat','Clear Anticheat Requirement'],
  ['lock_tipping','Lock Tipping','Unlock Tipping'],
  ['staff_verified','Verify User','Clear Staff Verification'],
] as const;

export default function AdminPlayerPage() {
  const { id } = useParams();
  const { user, loading, openAuthModal, notify } = useAuth();
  const [data,setData] = useState<PlayerDetail|null>(null);
  const [query] = useSearchParams();
  const [tab,setTab] = useState<Tab>(() => query.get('tab') === 'notes' ? 'Notes' : 'Logs');
  const [note,setNote] = useState('');
  const [error,setError] = useState('');
  const [busy,setBusy] = useState(false);
  const hasAccess = user && ['owner','moderator','finance'].includes(user.role);
  const path = '/api/staff/players/' + encodeURIComponent(id || '');
  const refresh = useCallback(() => apiFetch<PlayerDetail>(path).then(setData),[path]);
  useEffect(() => {
    setData(null); setError('');
    if (hasAccess) void refresh().catch(e => setError(e.message));
  },[hasAccess,refresh]);

  if (loading) return <div className="arena-admin"><p>Loading account…</p></div>;
  if (!hasAccess) return <div className="arena-admin"><h1><ShieldAlert/> Staff access required</h1>{!user && <button onClick={() => openAuthModal()}>Sign In</button>}</div>;
  if (!data) return <div className="arena-admin"><Link to="/staff?tab=accounts">Back to Accounts</Link><p>{error || 'Loading player…'}</p></div>;
  const { player, security, logs, notes, ledger, history } = data;
  const canModerate = player.id !== user.id && (user.role === 'owner' || (user.role === 'moderator' && player.role === 'player'));

  async function mutate(url:string, method:string, values:object, message:string) {
    setBusy(true);
    try {
      await apiFetch(url,{method,body:JSON.stringify(values)});
      await refresh();
      notify(message,'success');
      return true;
    } catch (err) { notify((err as Error).message,'error'); return false; }
    finally {setBusy(false);}
  }

  function accountAction(action:string,enabled:boolean) {
    const reason = window.prompt('Enter a reason for the staff log')?.trim();
    if (reason) void mutate(path+'/control','POST',{action,enabled,reason},'Account updated.');
  }

  function updateAccount(values:object) {
    const reason = window.prompt('Enter a reason for the staff log')?.trim();
    if (reason) void mutate('/api/staff/users/'+encodeURIComponent(player.id),'PATCH',{...values,reason},'Account updated.');
  }

  async function addNote(event:FormEvent) {
    event.preventDefault();
    if (await mutate(path+'/notes','POST',{body:note},'Note saved.')) setNote('');
  }

  const records: Partial<Record<Tab, Entry[]>> = {
    Alts: security.filter(r => /shared|repeated/.test(r.title || '')),
    Logs: logs, 'Money Logs': ledger, Notes: notes, History: history,
    Withdrawals: ledger.filter(e=>e.title?.startsWith('withdrawal_')),
    Deposits: ledger.filter(e=>e.title?.startsWith('deposit_')),
    Tips: ledger.filter(e=>e.title?.startsWith('tip_')),
    Purchases: ledger.filter(e=>e.title==='shop_purchase'),
  };

  return <div className="arena-admin">
    <Link className="arena-admin-back" to="/staff?tab=accounts"><ArrowLeft size={16}/> Accounts</Link>
    <section className="admin-player-card">
      <PlayerPortrait name={player.username}/>
      <h1>{player.username}</h1>
      <p>{formatSol(player.available_lamports,2)} SOL ({formatSol(player.frozen_lamports+player.reserved_lamports,2)} SOL locked)</p>
      <small>Account created {new Date(player.created_at).toLocaleString()}</small>
      {canModerate && <div className="admin-player-actions">
        {user.role === 'owner' && <button disabled={busy} onClick={()=>{
          const role=window.prompt('Enter player, moderator, finance, or owner',player.role)?.trim().toLowerCase();
          if (role && ['player','moderator','finance','owner'].includes(role)) updateAccount({role});
        }}>Set Role</button>}
        <button disabled={busy} onClick={()=>updateAccount({status:player.status==='banned'?'active':'banned'})}>{player.status==='banned'?'Unban':'Ban'}</button>
        <button disabled={busy||!player.epic_display_name} onClick={()=>accountAction('unlink_game_account',true)}>Unlink Game Account</button>
        {moderation.map(([field,enable,disable])=><button key={field} disabled={busy} onClick={()=>accountAction(field,!player[field])}>{player[field]?disable:enable}</button>)}
      </div>}
      <nav className="admin-player-tabs" aria-label="Player management views">
        {destinations.map(t=><button key={t} aria-pressed={tab===t} onClick={()=>setTab(t)}>{t}</button>)}
      </nav>
    </section>
    {tab==='Info' && <dl className="admin-player-info">
      {Object.entries({'Display name':player.display_name,Email:player.email,'Epic name':player.epic_display_name||'Unlinked',Region:player.competitive_region,Role:player.role,Status:player.status,'Risk score':player.risk_score}).map(([label,value])=><div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}
    </dl>}
    {tab==='Notes' && user.role!=='finance' && <form className="admin-note" onSubmit={addNote}>
      <label htmlFor="staff-note">Staff note</label>
      <textarea id="staff-note" value={note} onChange={e=>setNote(e.target.value)} maxLength={1500} placeholder="Add a private staff note…"/>
      <button disabled={busy||!note.trim()}>Save Note</button>
    </form>}
    {tab==='Discord Transcripts' && <p className="admin-entry">Discord transcripts require a connected Discord integration.</p>}
    {(records[tab]||[]).map((r,i)=><article className="admin-entry" key={r.created_at+'-'+i}>
      <time dateTime={r.created_at}>{new Date(r.created_at).toLocaleString()}</time>
      <div>{r.author && <strong>{r.author} </strong>}{r.title && <strong>{r.id ? <Link to={'/matches/'+r.id}>{r.title}</Link> : r.title.replaceAll('_',' ')} · </strong>}{r.body}{r.amount!==undefined && <span> · {formatSol(r.amount,4)} SOL</span>}</div>
    </article>)}
    {records[tab]?.length===0 && <p className="admin-entry">No {tab.toLowerCase()} to show.</p>}
  </div>;
}
