import { useEffect, useState } from 'react';
import { Check, Coins, Search, ShoppingBag, Sparkles } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { formatSol } from '../lib/format';
import { useAuth } from '../context/AuthContext';
import { collectiblePortrait } from '../components/PlayerPortrait';

interface ShopItem {
  id: string;
  name: string;
  description: string;
  category: 'Title' | 'Avatar Border' | 'Profile Banner' | 'Badge';
  rarity: 'Common' | 'Rare' | 'Epic' | 'Mythic';
  price_lamports: number;
  preview_value: string;
  portrait_index: number | null;
}
interface InventoryEntry { item_id:string;equipped:number }
type Catalog = {items:ShopItem[];inventory:InventoryEntry[]};

export default function ShopPage() {
  const { user, openAuthModal, refreshUser, notify } = useAuth();
  const [data,setData] = useState<Catalog|null>(null);
  const [error,setError] = useState('');
  const [query,setQuery] = useState('');
  const [tab,setTab] = useState('Item Shop');
  const [busyId,setBusyId] = useState('');

  useEffect(()=>{
    let current=true;
    setData(null);
    apiFetch<Catalog>('/api/shop').then(data=>{if(current){setData(data);setError('');}})
      .catch(error=>{if(current)setError(error.message);});
    return ()=>{current=false;};
  },[user?.id]);

  async function update(item:ShopItem, action:'buy'|'equip') {
    if (!user) return openAuthModal('login');
    if (busyId) return;
    setBusyId(item.id);
    try {
      await apiFetch('/api/shop/'+encodeURIComponent(item.id)+'/'+action,{method:'POST'});
      setData(await apiFetch<Catalog>('/api/shop'));
      await refreshUser();
      notify(action==='buy' ? item.name+' added to your locker.' : 'Locker updated.','success');
    } catch (error) {notify((error as Error).message,'error');}
    finally {setBusyId('');}
  }

  const inventory = new Map<string,InventoryEntry>(data?.inventory.map(item=>[item.item_id,item] as const));
  const items = (data?.items ?? []).filter(item=>{
    if (!item.name.toLowerCase().includes(query.trim().toLowerCase())) return false;
    if (tab==='Locker') return inventory.has(item.id);
    return tab==='Item Shop' ? item.portrait_index!=null : item.portrait_index==null;
  }).sort((first,second)=>(first.portrait_index ?? 999)-(second.portrait_index ?? 999));

  return <div className="arena-shop">
    <header><h1><ShoppingBag size={28}/>Shop</h1><label className="admin-search"><Search size={16}/><input value={query} onChange={event=>setQuery(event.target.value)} placeholder="Search shop…" aria-label="Search shop"/></label></header>
    <nav className="sft-profile-tabs" aria-label="Shop sections">{['Item Shop','Cosmetics','Locker'].map(section=>
      <button key={section} aria-current={section===tab?'page':undefined} onClick={()=>setTab(section)}>{section}</button>)}</nav>
    <section className="arena-shop-section">
      <h2>{tab==='Item Shop'?'Collectible Portraits':tab}</h2>
      {error && <p role="alert">{error}</p>}
      {!data && !error && <p role="status">Loading shop…</p>}
      {data && !items.length && <p>{tab==='Locker' && !query?'Your locker is empty.':'No matching items.'}</p>}
      <div className="arena-shop-grid">{items.map(item=>{
        const owned = inventory.get(item.id);
        const image = item.portrait_index==null ? null : collectiblePortrait(item.portrait_index);
        return <article className="arena-shop-card" key={item.id} data-rarity={item.rarity}>
          <div className="arena-shop-art">
            {image ? <img src={image} alt="" loading={item.portrait_index<9?'eager':'lazy'} decoding="async"/>
              : <div className="arena-shop-placeholder"><Sparkles size={36}/>{item.category==='Title' && <span>{item.preview_value}</span>}</div>}
            <span className="arena-shop-rarity">{item.rarity}</span>
            {owned && <span className="arena-shop-owned"><Check size={12}/>Owned</span>}
          </div>
          <div className="arena-shop-details"><h3>{item.name}</h3>
            <p>{item.price_lamports>0 ? <><Coins size={15}/>{formatSol(item.price_lamports,4)} SOL</> : 'Free'}</p>
            <button className={'admin-button '+(owned?'arena-shop-equip':'admin-primary')} disabled={!!busyId} onClick={()=>update(item,owned?'equip':'buy')}>
              {busyId===item.id?'Saving…':owned?.equipped?'Unequip':owned?'Equip':item.price_lamports?'Buy':'Unlock'}
            </button>
          </div>
        </article>;
      })}</div>
    </section>
  </div>;
}
