import { useEffect, useState, type ComponentType, type FormEvent, type ReactNode } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Activity, AlertTriangle, ArrowDownToLine, ArrowUpToLine, Ban, Bell, Coins, FileText, Gift, Search, Shield, Store, Swords, Trophy, UserPlus, Users, Wallet, Zap } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import PlayerPortrait from '../components/PlayerPortrait';
import { adminHref } from '../components/AdminNavigation';
import { apiFetch } from '../lib/api';
import { formatSol, formatUtcTimestamp } from '../lib/format';

type AdminOverview = {
  counts: { online:number; users:number; signups:number; open_matches:number; disputes:number };
  sessions: { day:string; count:number }[];
  financial: { pending:number; fees:number } | null;
};
type Audit = { id:string; actor_username:string|null; action:string; entity_id:string; summary:string; created_at:string };
type Player = { id:string; username:string; email?:string; profile_portrait?:number|null; role:string; status:string; wins:number; losses:number;
  created_at:string; referral_code:string; referrer:string|null; referrals:number; available_lamports:number;
  reserved_lamports:number; frozen_lamports:number; earnings:number; reason:string|null; banned_by:string|null; acquisition_source:string };
type Match = { id:string; title:string; players:string|null; mode:string; format:string; first_to:number; entry_lamports:number; total_prize_lamports:number;
  winner:string|null; status:string; created_at:string };
type Tournament = { id:string; title:string; mode:string; format:string; region:string; entry_lamports:number; prize_pool_lamports:number;
  registered_teams:number; max_teams:number; status:string; starts_at:string };
type Transaction = { id:string; user_id:string; username:string; email:string; network:string; status:string; created_at:string; matched_at:string|null;
  matched_signature:string|null; base_lamports:number; expected_lamports:number; received_lamports:number|null; amount_lamports:number;
  fee_lamports:number; confirmed_at:string|null; tx_signature:string|null; reviewer:string|null; destination_address:string };
type Ledger = { id:string; username:string; actor:string|null; entry_type:string; description:string; delta_lamports:number; bucket:string; created_at:string; reference_id:string };
type ShopItem = { id:string; name:string; description:string; category:string; rarity:string; price_lamports:number; preview_value:string; is_featured:number; is_active:number };
type Reward = { id:string; username:string; profile_portrait:number|null; reward_label:string; amount_lamports:number; created_at:string };
const moneyViews = ['deposits','withdrawals','moneyAudit','finance'];
const tournamentViews = ['tournaments','matches','disputes','fees'];
const rewardViews = ['gifting','claims'];
const storeViews = ['store','locker','avatars'];
const categoryOptions = ['Title','Avatar Border','Profile Banner','Badge'];
const rarityOptions = ['Common','Rare','Epic','Mythic'];
const viewTitles: Record<string,string> = {
  users:'Users', referrals:'Referrals', signups:'Signups', balances:'Balances', bans:'Banned Users', matches:'Match Games',
};
const formatAmount = (value:number|null|undefined) => formatSol(value ?? 0,4)+' SOL';
const date = (value:string|null|undefined) => value ? formatUtcTimestamp(value) : '—';
const human = (value:string) => value.replaceAll('_',' ').replace(/^./,letter=>letter.toUpperCase());
const matchesText = (query:string, ...values:(string|null|undefined)[]) => values.some(value=>value?.toLowerCase().includes(query.trim().toLowerCase()));

function useAdminData<T>(path:string|null, revision=0):{data:T|null;error:string} {
  const [state,setState] = useState<{path:string|null; data:T|null; error:string}>({path:null,data:null,error:''});
  useEffect(()=>{
    if (!path) return;
    let current=true;
    apiFetch<T>(path).then(data=>{if(current) setState({path,data,error:''});})
      .catch(error=>{if(current) setState({path,data:null,error:error.message});});
    return ()=>{current=false;};
  },[path,revision]);
  return state.path===path ? state : {data:null,error:''};
}

function Status({children}:{children:string}) {
  return <span className="arena-status-pill" data-status={children}>{children}</span>;
}

function SearchField({value,onChange,label}:{value:string;onChange:(query:string)=>void;label:string}) {
  return <label className="admin-search"><Search size={16}/><input value={value} onChange={event=>onChange(event.target.value)} placeholder={label} aria-label={label}/></label>;
}

function Panel({title,subtitle,icon,actions,children}:{title:string;subtitle?:ReactNode;icon?:ReactNode;actions?:ReactNode;children:ReactNode}) {
  return <section className="admin-panel">
    <header className="admin-panel-heading"><div><h2>{icon}{title}</h2>{subtitle && <p>{subtitle}</p>}</div>{actions}</header>
    {children}
  </section>;
}

function LoadState({error}:{error?:string}) {
  return <p className="admin-empty" role={error?'alert':'status'}>{error || 'Loading records…'}</p>;
}

function DataTable<T extends {id:string}>({headers,rows,cells,empty='No records found.'}:{headers:string[];rows:T[];cells:(row:T)=>ReactNode[];empty?:string}) {
  return <div className="admin-table-scroll"><table className="admin-table">
    <thead><tr>{headers.map((header,index)=><th scope="col" key={index}>{header}</th>)}</tr></thead>
    <tbody>{rows.map(row=><tr key={row.id}>{cells(row).map((cell,index)=><td key={index}>{cell}</td>)}</tr>)}
      {!rows.length && <tr><td colSpan={headers.length} className="admin-empty">{empty}</td></tr>}
    </tbody>
  </table></div>;
}

function ViewTabs({items,view}:{items:[string,string,ReactNode][];view:string}) {
  return <nav className="admin-tabs" aria-label="Admin subsections">{items.map(([key,label,icon])=>
    <Link key={key} to={adminHref(key)} aria-current={view===key?'page':undefined}>{icon}{label}</Link>)}</nav>;
}

function PlayerCell({player}:{player:Pick<Player,'id'|'username'|'email'|'profile_portrait'>}) {
  return <div className="admin-player-cell"><PlayerPortrait name={player.username} portrait={player.profile_portrait}/><div>
    <Link to={'/staff/players/'+encodeURIComponent(player.id)}>{player.username}</Link>
    {player.email && <small>{player.email}</small>}
  </div></div>;
}

function Overview({isFinance}:{isFinance:boolean}) {
  const {data,error} = useAdminData<AdminOverview>('/api/admin/dashboard');
  const audit = useAdminData<{logs:Audit[]}>('/api/staff/audit-logs');
  if (!data) return <LoadState error={error}/>;
  const {counts,sessions,financial} = data;
  const max = Math.max(1,...sessions.map(session=>session.count));
  const chart = sessions.map((session,index)=>[index*100,108-92*session.count/max].join(',')).join(' ');
  const metrics = [
    { label:'Live Now', value:counts.online, detail:'Active in the last 90 seconds', icon:<span className="admin-live-dot"/> },
    { label:'Total Users', value:counts.users, detail:counts.signups+' new in the last 7 days', icon:<Users size={18}/> },
    { label:'Open Matches', value:counts.open_matches, detail:'Waiting, ready or in progress', icon:<Swords size={18}/> },
    ...(financial ? [{label:'Match Fees',value:formatAmount(financial.fees), detail:'Completed matches',icon:<Coins size={18}/>}] : []),
    { label:'Open Issues', value:counts.disputes+(financial?.pending ?? 0),
      detail:counts.disputes+' disputes'+(financial ? ' · '+financial.pending+' withdrawals' : ''), icon:<AlertTriangle size={18}/> },
  ];
  return <>
    <div className="admin-metrics">{metrics.map(metric=><article className="admin-metric" key={metric.label}>
      <div>{metric.label}{metric.icon}</div><strong>{typeof metric.value==='number'?metric.value.toLocaleString():metric.value}</strong><small>{metric.detail}</small>
    </article>)}</div>
    <div className="admin-overview-grid">
      <div className="admin-stack">
        <Panel title="Sessions — Last 7 Days" icon={<Activity size={18}/>}>
          <figure className="admin-chart">
            <svg viewBox="0 0 600 110" role="img" aria-label={sessions.map(day=>day.day+' '+day.count+' sessions').join(', ')}>
              <polygon points={'0,110 '+chart+' 600,110'}/><polyline points={chart}/>
            </svg>
            <figcaption><span>{sessions[0]?.day}</span><span>{sessions[sessions.length-1]?.day}</span></figcaption>
          </figure>
        </Panel>
        <Panel title="Audit Feed" icon={<FileText size={18}/>} actions={<Link className="admin-button" to={adminHref('audit')}>View log</Link>}>
          {audit.data ? <div className="admin-feed">{audit.data.logs.slice(0,7).map(log=><div key={log.id}><strong>{human(log.action)}</strong><small>{log.summary || log.actor_username || 'System'} · {date(log.created_at)}</small></div>)}
            {!audit.data.logs.length && <p className="admin-empty">No audit entries yet.</p>}</div> : <LoadState error={audit.error}/>}
        </Panel>
      </div>
      <aside className="admin-stack">
        <Panel title="Attention" icon={<Bell size={17}/>}>
          <div className="admin-feed">{financial && financial.pending>0 && <Link to={adminHref('withdrawals')}><strong>Withdrawal review</strong><small>{financial.pending} withdrawals awaiting review</small></Link>}
            {counts.disputes>0 && <Link to={adminHref('disputes')}><strong>Match disputes</strong><small>{counts.disputes} open or under review</small></Link>}
            {!financial?.pending && !counts.disputes && <p className="admin-empty">No pending issues.</p>}</div>
        </Panel>
        <Panel title="Quick Actions" icon={<Zap size={17}/>}>
          <div className="admin-quick-actions">
            <Link to={adminHref('users')}><Users size={17}/>Users</Link>
            {isFinance && <Link to={adminHref('withdrawals')}><ArrowUpToLine size={17}/>Withdrawals</Link>}
            <Link to={adminHref('disputes')}><Shield size={17}/>Match Disputes</Link>
            <Link to={adminHref('tournaments')}><Trophy size={17}/>Tournaments</Link>
            <Link to={adminHref('gifting')}><Gift size={17}/>Gifting</Link>
            <Link to={adminHref('store')}><Store size={17}/>Item Shop</Link>
          </div>
        </Panel>
      </aside>
    </div>
  </>;
}

function Directory({view}:{view:string}) {
  const {user,notify} = useAuth();
  const [q,setQ] = useState('');
  const [scope,setScope] = useState('all');
  const [page,setPage] = useState(0);
  const [referrer,setReferrer] = useState<Player|null>(null);
  const [revision,setRevision] = useState(0);
  const [pending,setPending] = useState('');
  const query = new URLSearchParams({q,scope,page:String(page),referrer:referrer?.id || ''});
  const {data,error} = useAdminData<{rows:Player[];total:number;limit:number}>('/api/admin/directory/'+view+'?'+query,revision);
  const signups = useAdminData<AdminOverview>(view==='signups'?'/api/admin/dashboard':null);
  const isOwner = user?.role==='owner';
  const isModerator = user?.role==='moderator' || isOwner;
  const manage = (userId:string,label='Manage') => <Link className="admin-button" to={'/staff/players/'+encodeURIComponent(userId)}>{label}</Link>;

  async function update(path:string, body:object, id:string) {
    setPending(id);
    try {
      await apiFetch(path,{method:'PATCH',body:JSON.stringify(body)});
      setRevision(value=>value+1);
      notify('Saved.','success');
    } catch (error) { notify((error as Error).message,'error'); }
    finally {setPending('');}
  }

  const headers: Record<string,string[]> = {
    users:['User','Role','Balance','W/L','Joined','Status','Actions'],
    referrals:['User','Their code','Referred by','Signups','Manage'],
    balances:['User','Balance','Locked','Earnings','Actions'],
    bans:['Player','Reason','Banned by','Expires','Banned on','Actions'],
  };
  function cells(row:Player):ReactNode[] {
    const access = user?.id!==row.id && (isOwner || row.role==='player');
    const player = <PlayerCell player={row}/>;
    if (view==='users') return [player,<Status>{row.role}</Status>,formatAmount(row.available_lamports),row.wins+'W / '+row.losses+'L',date(row.created_at),<Status>{row.status}</Status>,
      <div className="admin-row-actions">{isOwner && access && <select aria-label={'Role for '+row.username} disabled={!!pending} value={row.role} onChange={event=>{
        const role = event.target.value;
        const reason = window.prompt('Enter a reason for changing '+row.username+' to '+role+'.')?.trim();
        if (reason && reason.length>=3) void update('/api/staff/users/'+row.id,{role,reason},row.id);
      }}>{['player','moderator','finance','owner'].map(role=><option key={role} value={role}>{human(role)}</option>)}</select>}{manage(row.id)}</div>];
    if (view==='referrals') return [player,<code>{row.referral_code}</code>,row.referrer || '—',row.referrals,
      <div className="admin-row-actions">
        {isOwner && <button className="admin-button" disabled={!!pending} onClick={()=>{
          const code = window.prompt('Referral code for '+row.username,row.referral_code)?.trim();
          if (code && code!==row.referral_code) void update('/api/admin/referrals/'+row.id,{code},row.id);
        }}>Edit</button>}
        <button className="admin-button" onClick={()=>{setReferrer(row);setQ('');setPage(0);}}>View referrals ({row.referrals})</button>
      </div>];
    if (view==='balances') return [player,formatAmount(row.available_lamports),<span className="admin-gold">{formatAmount(row.reserved_lamports+row.frozen_lamports)}</span>,formatAmount(row.earnings),manage(row.id)];
    return [player,row.reason || '—',row.banned_by || '—','Permanent',date(row.created_at),<div className="admin-row-actions">{manage(row.id)}
      {isModerator && access && <button className="admin-button" disabled={!!pending} onClick={()=>{
        const reason = window.prompt('Enter a reason for unbanning '+row.username+'.')?.trim();
        if (reason) void update('/api/staff/users/'+row.id,{status:'active',reason},row.id);
      }}>Unban</button>}</div>];
  }

  return <>
    {view==='signups' && <Panel title="Signups" icon={<UserPlus size={18}/>}>
      {signups.data ? <div className="admin-metrics admin-panel-metrics">
        <article className="admin-metric"><div>Total signups</div><strong>{signups.data.counts.users.toLocaleString()}</strong></article>
        <article className="admin-metric"><div>Last 7 days</div><strong>{signups.data.counts.signups.toLocaleString()}</strong></article>
      </div> : <LoadState error={signups.error}/>}
    </Panel>}
    {view==='users' && <div className="admin-tabs" aria-label="User directory filter">
      {['all','staff'].map(filter=><button key={filter} aria-pressed={scope===filter} onClick={()=>{setScope(filter);setPage(0);}}>{filter==='all'?<Users size={16}/>:<Shield size={16}/>} {filter==='all'?'All Users':'Staff'}</button>)}
    </div>}
    <Panel title={referrer ? 'Referrals from '+referrer.username : view==='signups'?'Recent Signups':viewTitles[view]}
      icon={view==='balances'?<Wallet size={18}/>:view==='bans'?<Ban size={18}/>:undefined}
      subtitle={data && data.total.toLocaleString()+' records'}
      actions={<div className="admin-row-actions">{referrer && <button className="admin-button" onClick={()=>{setReferrer(null);setPage(0);setQ('');}}>All referrals</button>}
        <SearchField value={q} onChange={value=>{setQ(value);setPage(0);}} label={view==='referrals'?'Search by name or code…':'Search by player or ID…'}/></div>}>
      {!data ? <LoadState error={error}/> : <>
        {view==='signups' ? <div className="admin-card-grid">{data.rows.map(row=><article className="admin-item-card" key={row.id}><PlayerCell player={row}/><small>{date(row.created_at)} · {human(row.acquisition_source)}</small></article>)}
          {!data.rows.length && <p className="admin-empty">No signups found.</p>}</div>
          : <DataTable headers={headers[view]} rows={data.rows} cells={cells}/>}
        {data.total>data.limit && <div className="admin-pagination">
          <button className="admin-button" disabled={page===0} onClick={()=>setPage(page-1)}>Previous</button>
          <span>{page*data.limit+1}–{Math.min((page+1)*data.limit,data.total)} of {data.total}</span>
          <button className="admin-button" disabled={(page+1)*data.limit>=data.total} onClick={()=>setPage(page+1)}>Next</button>
        </div>}
      </>}
    </Panel>
  </>;
}

function MatchGames() {
  const [q,setQ] = useState('');
  const [page,setPage] = useState(0);
  const query = new URLSearchParams({q,page:String(page)});
  const {data,error} = useAdminData<{rows:Match[];total:number;limit:number}>('/api/admin/directory/matches?'+query);
  return <Panel title="Match Games" icon={<Swords size={19}/>} subtitle={data && data.total.toLocaleString()+' matches'}
    actions={<SearchField value={q} onChange={value=>{setQ(value);setPage(0);}} label="Search by match ID or player…"/>}>
    {data ? <>
      <DataTable headers={['Match','Players','Mode','Entry / Prize','Winner','Status','Created','Manage']} rows={data.rows}
        cells={row=>[<><strong>{row.title}</strong><small className="admin-break">{row.id}</small></>,row.players || '—',row.format+' · '+row.mode+' · FT'+row.first_to,
          <>{formatAmount(row.entry_lamports)}<small>{formatAmount(row.total_prize_lamports)} prize</small></>,row.winner || '—',
          <Status>{row.status==='Waiting'?'Open':row.status}</Status>,date(row.created_at),<Link className="admin-button admin-primary" to={'/matches/'+encodeURIComponent(row.id)}>Manage</Link>]}/>
      {data.total>data.limit && <div className="admin-pagination"><button className="admin-button" disabled={!page} onClick={()=>setPage(page-1)}>Previous</button>
        <span>{page*data.limit+1}–{Math.min((page+1)*data.limit,data.total)} of {data.total}</span>
        <button className="admin-button" disabled={(page+1)*data.limit>=data.total} onClick={()=>setPage(page+1)}>Next</button></div>}
    </> : <LoadState error={error}/>}
  </Panel>;
}

function TournamentDirectory() {
  const [q,setQ] = useState('');
  const {data,error} = useAdminData<{tournaments:Tournament[]}>('/api/tournaments?search='+encodeURIComponent(q));
  return <Panel title="Tournaments" icon={<Trophy size={18}/>} actions={<div className="admin-row-actions"><SearchField value={q} onChange={setQ} label="Search tournaments…"/><Link className="admin-button" to="/tournaments">Tournament tools</Link></div>}>
    {data ? <DataTable headers={['Tournament','Mode','Region','Registered','Entry / Prize','Status','Starts','Manage']} rows={data.tournaments}
      cells={row=>[<strong>{row.title}</strong>,row.format+' · '+row.mode,row.region,row.registered_teams+' / '+row.max_teams,
        <>{formatAmount(row.entry_lamports)}<small>{formatAmount(row.prize_pool_lamports)} prize</small></>,<Status>{row.status}</Status>,date(row.starts_at),
        <Link className="admin-button" to={'/tournaments?id='+encodeURIComponent(row.id)}>Open</Link>]}/> : <LoadState error={error}/>}
  </Panel>;
}

function Money({view}:{view:string}) {
  const {notify,refreshUser} = useAuth();
  const [q,setQ] = useState('');
  const [revision,setRevision] = useState(0);
  const [pending,setPending] = useState('');
  const [receipt,setReceipt] = useState<Transaction|null>(null);
  const isDeposit = view==='deposits';
  const isAudit = view==='moneyAudit';
  const path = '/api/admin/money/'+(isAudit?'audit':view)+'?q='+encodeURIComponent(q);
  const {data,error} = useAdminData<{rows:Transaction[];totals?:never}>(isAudit?null:path,revision);
  const audit = useAdminData<{rows:Ledger[];totals:{available:number;reserved:number;frozen:number}}>(isAudit?path:null);

  async function review(row:Transaction) {
    const note = isDeposit ? window.prompt('Enter the deposit verification note.')?.trim() : '';
    if (isDeposit ? !note : !window.confirm('Retry reconciliation for this withdrawal?')) return;
    setPending(row.id);
    try {
      await apiFetch('/api/finance/'+(isDeposit?'deposits':'withdrawals')+'/'+row.id+(isDeposit?'/approve':'/retry'),
        {method:'POST',body:JSON.stringify({note})});
      setRevision(value=>value+1);
      void refreshUser();
      notify(isDeposit?'Deposit credited.':'Withdrawal reconciliation retried.','success');
    } catch (error) {notify((error as Error).message,'error');}
    finally {setPending('');}
  }

  if (isAudit) return <>
    {audit.data && <div className="admin-metrics admin-panel-metrics">{Object.entries(audit.data.totals).map(([key,value])=>
      <article className="admin-metric" key={key}><div>{human(key)} SOL</div><strong>{formatSol(value,4)}</strong></article>)}</div>}
    <Panel title="Wallet Audit" actions={<SearchField value={q} onChange={setQ} label="Search by player, entry type, or reference…"/>}>
      {audit.data ? <DataTable headers={['Entry','Player','Actor','Amount','Bucket','Date']} rows={audit.data.rows}
        cells={row=>[<><strong>{human(row.entry_type)}</strong><small>{row.description}</small><small className="admin-break">{row.reference_id}</small></>,
          row.username,row.actor || 'System',formatAmount(row.delta_lamports),row.bucket,date(row.created_at)]}/> : <LoadState error={audit.error}/>}
    </Panel>
  </>;

  return <Panel title={isDeposit?'Deposit Ledger':'Withdrawal Ledger'} subtitle={isDeposit?'SOL invoices and payments':'SOL withdrawal requests and processing history'}
    actions={<SearchField value={q} onChange={setQ} label={isDeposit?'Search by player, email, or invoice ID…':'Search by player, email, address, or ID…'}/>}>
    {data ? <DataTable headers={isDeposit?['User','Reference','Requested / Received','Network','Status','Date','Completed','Actions']:
      ['User','Amount','Network / Address','Status','Date','Processed By','Actions']} rows={data.rows}
      cells={row=>{
        const player = <><Link to={'/staff/players/'+row.user_id}>{row.username}</Link><small>{row.email}</small></>;
        const status = <Status>{row.status==='Waiting'?'Pending':row.status==='Matched'?'Confirmed':row.status}</Status>;
        const action = <div className="admin-row-actions">
          {row.status==='Needs Review' && <button className="admin-button admin-success" disabled={!!pending} onClick={()=>void review(row)}>
            {isDeposit?'Approve':'Retry'}
          </button>}
          <button className="admin-button" onClick={()=>setReceipt(row)}>{['Matched','Confirmed'].includes(row.status)?'Receipt':'Details'}</button>
        </div>;
        return isDeposit ? [player,<code className="admin-break">{row.id}</code>,
          <>{formatAmount(row.base_lamports)}<small>{row.received_lamports==null?'Awaiting transfer':formatAmount(row.received_lamports)+' received'}</small></>,
          row.network,status,date(row.created_at),date(row.matched_at),action] : [player,
          <>{formatAmount(row.amount_lamports)}<small>{formatAmount(row.fee_lamports)} fee</small></>,
          <><Status>{row.network}</Status><small className="admin-break">{row.destination_address}</small></>,
          status,date(row.created_at),row.reviewer || '—',action];
      }}/> : <LoadState error={error}/>}
    {receipt && <dialog open className="admin-dialog" aria-label="Transaction details" onKeyDown={event=>{if(event.key==='Escape')setReceipt(null);}}>
      <h2>Transaction details</h2><dl>
        <dt>Player</dt><dd>{receipt.username}</dd>
        <dt>Reference</dt><dd>{receipt.id}</dd>
        <dt>Network</dt><dd>{receipt.network}</dd>
        <dt>Status</dt><dd>{receipt.status}</dd>
        <dt>Amount</dt><dd>{formatAmount(isDeposit ? (receipt.received_lamports ?? receipt.base_lamports) : receipt.amount_lamports)}</dd>
        <dt>Signature</dt><dd>{(isDeposit?receipt.matched_signature:receipt.tx_signature) || '—'}</dd>
        <dt>Completed</dt><dd>{date(isDeposit?receipt.matched_at:receipt.confirmed_at)}</dd>
      </dl><button autoFocus className="admin-button" onClick={()=>setReceipt(null)}>Close</button>
    </dialog>}
  </Panel>;
}

function AuditLog() {
  const [q,setQ] = useState('');
  const {data,error} = useAdminData<{logs:Audit[]}>('/api/staff/audit-logs?q='+encodeURIComponent(q));
  return <Panel title="Audit Log" icon={<FileText size={18}/>} actions={<SearchField value={q} onChange={setQ} label="Search action, summary, or ID…"/>}>
    {data ? <DataTable headers={['Action','Actor','Reference','Time']} rows={data.logs}
      cells={row=>[<><strong>{human(row.action)}</strong><small>{row.summary}</small></>,row.actor_username || 'System',<code className="admin-break">{row.entity_id}</code>,date(row.created_at)]}/> : <LoadState error={error}/>}
  </Panel>;
}

function MatchFees() {
  const {data,error} = useAdminData<AdminOverview>('/api/admin/dashboard');
  return <Panel title="Match Fees" icon={<Coins size={18}/>}>
    {data?.financial ? <div className="admin-metrics admin-panel-metrics"><article className="admin-metric"><div>Fees from completed matches</div><strong>{formatAmount(data.financial.fees)}</strong></article></div>
      : error || !data ? <LoadState error={error}/> : <p className="admin-empty">Finance access is required to view fees.</p>}
  </Panel>;
}

function RewardClaims() {
  const [q,setQ] = useState('');
  const {data,error} = useAdminData<{rows:Reward[]}>('/api/admin/rewards');
  const rows = data?.rows.filter(row=>matchesText(q,row.username,row.reward_label)) || [];
  return <Panel title="Reward Claims" icon={<Gift size={18}/>} actions={<SearchField value={q} onChange={setQ} label="Search by player or reward…"/>}>
    {data ? <div className="admin-card-grid">{rows.map(row=><article key={row.id} className="admin-item-card">
      <PlayerPortrait name={row.username} portrait={row.profile_portrait}/><div><strong>{row.username}</strong><small>{row.reward_label} · {date(row.created_at)}</small></div>
      <b className="admin-gold">{formatAmount(row.amount_lamports)}</b>
    </article>)}{!rows.length && <p className="admin-empty">No reward claims found.</p>}</div> : <LoadState error={error}/>}
  </Panel>;
}

function StoreCatalog({view}:{view:string}) {
  const {user,notify} = useAuth();
  const [q,setQ] = useState('');
  const [playerQuery,setPlayerQuery] = useState('');
  const [player,setPlayer] = useState<Player|null>(null);
  const [section,setSection] = useState('Active');
  const [revision,setRevision] = useState(0);
  const [pending,setPending] = useState('');
  const [editor,setEditor] = useState<ShopItem|null>(null);
  const catalog = useAdminData<{rows:ShopItem[]}>('/api/admin/catalog',revision);
  const gifting = view==='gifting';
  const playerResults = useAdminData<{rows:Player[]}>(gifting && playerQuery.trim().length>1 && !player
    ? '/api/admin/directory/users?q='+encodeURIComponent(playerQuery) : null);
  const isOwner = user?.role==='owner';
  const sections = gifting ? categoryOptions : ['Active','Featured','Archived'];
  const activeSection = sections.includes(section) ? section : sections[0];
  const rows = catalog.data?.rows.filter(row=>{
    if (!matchesText(q,row.name,row.description,row.category)) return false;
    if (gifting) return row.is_active && row.category===activeSection;
    if (view==='avatars' && row.category!=='Avatar Border') return false;
    if (view==='locker' && row.category==='Avatar Border') return false;
    return activeSection==='Archived' ? !row.is_active : row.is_active && (activeSection!=='Featured' || row.is_featured);
  }) || [];

  async function save(event:FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!editor || pending) return;
    const form = new FormData(event.currentTarget);
    setPending(editor.id);
    try {
      await apiFetch('/api/admin/catalog/'+editor.id,{method:'PUT',body:JSON.stringify({
        name:form.get('name'),description:form.get('description'),category:form.get('category'),rarity:form.get('rarity'),
        preview_value:form.get('preview'),price_lamports:Math.round(Number(form.get('price'))*1e9),
        featured:form.has('featured'),active:form.has('active'),
      })});
      setEditor(null);
      setRevision(value=>value+1);
      notify('Shop item saved.','success');
    } catch (error) {notify((error as Error).message,'error');}
    finally {setPending('');}
  }

  async function gift(item:ShopItem) {
    if (!player || pending || !window.confirm('Gift '+item.name+' to '+player.username+'?')) return;
    setPending(item.id);
    try {
      await apiFetch('/api/admin/catalog/'+item.id+'/gift',{method:'POST',body:JSON.stringify({userId:player.id})});
      notify('Item gifted to '+player.username+'.','success');
    } catch (error) {notify((error as Error).message,'error');}
    finally {setPending('');}
  }

  const title = gifting ? 'Gift Items' : view==='avatars' ? 'Avatar Borders' : view==='locker' ? 'Locker Shop' : 'Item Shop';
  return <Panel title={title} icon={gifting?<Gift size={18}/>:<Store size={18}/>}
    subtitle={gifting ? 'Choose a player and an item from the SFT catalog.' : 'Manage the SFT cosmetic catalog and featured items.'}
    actions={!gifting && isOwner && <button className="admin-button admin-primary" onClick={()=>setEditor({
      id:'new',name:'',description:'',category:view==='avatars'?'Avatar Border':'Title',rarity:'Common',price_lamports:0,preview_value:'',is_featured:0,is_active:1,
    })}>+ New Item</button>}>
    <div className="admin-catalog-controls">
      {gifting && isOwner && <div className="admin-player-picker">
        {player ? <div className="admin-row-actions"><PlayerCell player={player}/><button className="admin-button" onClick={()=>{setPlayer(null);setPlayerQuery('');}}>Change player</button></div>
          : <SearchField value={playerQuery} onChange={setPlayerQuery} label="Search for a player…"/>}
        {gifting && !player && playerQuery.trim().length>1 && <div className="admin-player-results">
          {playerResults.error && <p role="alert">{playerResults.error}</p>}
          {playerResults.data?.rows.slice(0,8).map(row=><button className="admin-button" key={row.id} onClick={()=>setPlayer(row)}>{row.username}</button>)}
          {playerResults.data?.rows.length===0 && <p>No players found.</p>}
        </div>}
      </div>}
      <div className="admin-catalog-filters"><div className="admin-tabs" aria-label="Catalog filter">{sections.map(option=>
        <button key={option} aria-pressed={activeSection===option} onClick={()=>setSection(option)}>{option}</button>)}</div>
        <SearchField value={q} onChange={setQ} label="Search items…"/></div>
    </div>
    {catalog.data ? <div className={'admin-card-grid '+(gifting?'admin-gifts':'admin-store')}>{rows.map(item=><article key={item.id} className="admin-item-card">
      <span data-rarity={item.rarity} className="admin-item-icon">{gifting?<Gift size={22}/>:<Store size={22}/>}</span>
      <div><strong>{item.name}</strong><small>{item.rarity} · {item.category}{!gifting && ' · '+formatAmount(item.price_lamports)}{Boolean(item.is_featured) && ' · Featured'}</small></div>
      {isOwner && (gifting ? <button className="admin-button" disabled={!player || !!pending} onClick={()=>void gift(item)}>Gift</button>
        : <button className="admin-button" onClick={()=>setEditor(item)}>Edit</button>)}
    </article>)}{!rows.length && <p className="admin-empty">No items found.</p>}</div> : <LoadState error={catalog.error}/>}
    {editor && <dialog open className="admin-dialog" aria-label={editor.id==='new'?'New shop item':'Edit shop item'} onKeyDown={event=>{if(event.key==='Escape'&&!pending)setEditor(null);}}>
      <form className="admin-edit-form" onSubmit={save}>
        <h2>{editor.id==='new'?'New shop item':'Edit shop item'}</h2>
        <label>Name<input autoFocus required name="name" defaultValue={editor.name} maxLength={80}/></label>
        <label>Description<input name="description" defaultValue={editor.description} maxLength={250}/></label>
        <div><label>Category<select name="category" defaultValue={editor.category}>{categoryOptions.map(option=><option key={option}>{option}</option>)}</select></label>
          <label>Rarity<select name="rarity" defaultValue={editor.rarity}>{rarityOptions.map(option=><option key={option}>{option}</option>)}</select></label></div>
        <div><label>Price in SOL<input required type="number" name="price" min="0" step="0.000000001" defaultValue={editor.price_lamports/1e9}/></label>
          <label>Preview value<input name="preview" defaultValue={editor.preview_value} maxLength={80}/></label></div>
        <div><label className="admin-check"><input type="checkbox" name="featured" defaultChecked={!!editor.is_featured}/>Featured</label>
          <label className="admin-check"><input type="checkbox" name="active" defaultChecked={!!editor.is_active}/>Active in shop</label></div>
        <div className="admin-row-actions"><button type="button" className="admin-button" disabled={!!pending} onClick={()=>setEditor(null)}>Cancel</button>
          <button className="admin-button admin-primary" disabled={!!pending}>Save item</button></div>
      </form>
    </dialog>}
  </Panel>;
}

function GlobalResults({search}:{search:string}) {
  const q = encodeURIComponent(search);
  const users = useAdminData<{rows:Player[]}>('/api/admin/directory/users?q='+q);
  const matches = useAdminData<{rows:Match[]}>('/api/admin/directory/matches?q='+q);
  const audit = useAdminData<{logs:Audit[]}>('/api/staff/audit-logs?q='+q);
  return <Panel title={'Search results for “'+search+'”'}>
    <div className="admin-search-results">
      <section><h3>Users</h3>{users.data ? <div className="admin-feed">{users.data.rows.slice(0,6).map(row=><div key={row.id}><PlayerCell player={row}/></div>)}
        {!users.data.rows.length&&<p>No matching users.</p>}</div>:<LoadState error={users.error}/>}</section>
      <section><h3>Matches</h3>{matches.data ? <div className="admin-feed">{matches.data.rows.slice(0,6).map(row=><Link key={row.id} to={'/matches/'+row.id}><strong>{row.title}</strong><small>{row.players || row.mode}</small></Link>)}
        {!matches.data.rows.length&&<p>No matching matches.</p>}</div>:<LoadState error={matches.error}/>}</section>
      <section><h3>Audit log</h3>{audit.data ? <div className="admin-feed">{audit.data.logs.slice(0,6).map(row=><div key={row.id}><strong>{human(row.action)}</strong><small>{row.summary}</small></div>)}
        {!audit.data.logs.length&&<p>No matching entries.</p>}</div>:<LoadState error={audit.error}/>}</section>
    </div>
  </Panel>;
}

export default function AdminDashboardPage({legacy:Legacy}:{legacy:ComponentType<{embedded?:boolean}>}) {
  const { user,loading } = useAuth();
  const [params,setParams] = useSearchParams();
  const [searchInput,setSearchInput] = useState('');
  const view = params.get('tab') || 'overview';
  const search = params.get('search') || '';
  const isFinance = user?.role==='owner' || user?.role==='finance';
  if (loading) return <LoadState/>;
  if (!user || !['owner','finance','moderator'].includes(user.role)) return <Legacy/>;
  const allowed = (view!=='balances' && !moneyViews.includes(view) || isFinance) && (view!=='analytics' || user.role==='owner');
  const showLegacy = ['accounts','disputes','finance','analytics'].includes(view);
  return <div className="sft-admin">
    <header className="admin-page-heading">
      <Shield size={31}/>
      <div><h1>Admin Dashboard</h1><p>Welcome back, {user.username}. Here’s today’s platform activity.</p></div>
      <div className="admin-header-actions"><form role="search" onSubmit={event=>{
        event.preventDefault();
        const next = new URLSearchParams(params);
        const value = searchInput.trim();
        if (value) next.set('search',value); else next.delete('search');
        setParams(next);
      }}><SearchField value={searchInput} onChange={setSearchInput} label="Search users, matches, logs…"/></form>
      <Link className="admin-button" to="/">Back to Site</Link></div>
    </header>
    {search ? <GlobalResults search={search}/> : !allowed ? <p className="admin-empty">Your role does not have access to this section.</p> : <>
      {moneyViews.includes(view) && <ViewTabs view={view} items={[
        ['deposits','Deposits',<ArrowDownToLine size={16}/>],['withdrawals','Withdrawals',<ArrowUpToLine size={16}/>],
        ['moneyAudit','Audit',<FileText size={16}/>],['finance','Reconciliation',<Wallet size={16}/>],
      ]}/>}
      {tournamentViews.includes(view) && <ViewTabs view={view} items={[
        ['tournaments','Tournaments',<Trophy size={16}/>],['matches','Match Games',<Swords size={16}/>],
        ['disputes','Match Disputes',<Shield size={16}/>],['fees','Match Fees',<Coins size={16}/>],
      ]}/>}
      {(view==='bans' || view==='accounts') && <ViewTabs view={view} items={[['bans','Bans',<Ban size={16}/>],['accounts','Anti-Cheat & Risk',<Shield size={16}/>]]}/>}
      {rewardViews.includes(view) && <ViewTabs view={view} items={[['gifting','Gifting',<Gift size={16}/>],['claims','Reward Claims',<Trophy size={16}/>]]}/>}
      {storeViews.includes(view) && <ViewTabs view={view} items={[['store','Item Shop',<Store size={16}/>],['locker','Locker Shop',<Gift size={16}/>],['avatars','Avatar Borders',<Users size={16}/>]]}/>}
      {view==='overview' && <Overview isFinance={isFinance}/>}
      {['users','referrals','signups','balances','bans'].includes(view) && <div className="admin-stack" key={view}><Directory view={view}/></div>}
      {view==='matches' && <MatchGames/>}
      {view==='tournaments' && <TournamentDirectory/>}
      {view==='fees' && <MatchFees/>}
      {view==='audit' && <AuditLog/>}
      {view==='claims' && <RewardClaims/>}
      {moneyViews.includes(view) && view!=='finance' && <div className="admin-stack" key={view}><Money view={view}/></div>}
      {(storeViews.includes(view) || view==='gifting') && <div key={view}><StoreCatalog view={view}/></div>}
      {showLegacy && <Legacy key={view} embedded/>}
      {![...Object.keys(viewTitles),'overview','audit',...moneyViews,...tournamentViews,...rewardViews,...storeViews,'analytics','accounts'].includes(view) &&
        <p className="admin-empty">Admin section not found. <Link to="/staff">Return to Overview</Link></p>}
    </>}
  </div>;
}
