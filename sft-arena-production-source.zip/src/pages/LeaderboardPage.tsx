import {useEffect,useState} from 'react';
import {Link} from 'react-router-dom';
import {Trophy,Crown,Coins} from 'lucide-react';
import PlayerPortrait from '../components/PlayerPortrait';
import {apiFetch} from '../lib/api';
import {formatSol} from '../lib/format';
import {useAuth} from '../context/AuthContext';
const periods = ['Daily','Weekly','Monthly','All-Time'] as const;
const pools = {Daily:10,Weekly:30,Monthly:100};
type Period=typeof periods[number];
type Row={id:string;rank:number;username:string;wins:number;losses:number;earnedLamports:number};
export default function LeaderboardPage(){
 const {regionFilter}=useAuth();
 const [period,setPeriod]=useState<Period>('Daily'),[region,setRegion]=useState(regionFilter),[search,setSearch]=useState('');
 const [data,setData]=useState<{leaderboard:Row[];resetAt:string|null}|null>(null),[error,setError]=useState('');
 const [now,setNow]=useState(Date.now);
 useEffect(()=>setRegion(regionFilter),[regionFilter]);
 useEffect(()=>{let active=true;setData(null);setError('');apiFetch<NonNullable<typeof data>>('/api/leaderboard?region='+region+'&period='+period).then(d=>{if(active)setData(d);}).catch(e=>{if(active)setError(e.message);});return()=>{active=false;};},[period,region]);
 useEffect(()=>{const t=setInterval(()=>setNow(Date.now()),1000);return()=>clearInterval(t);},[]);
 const rows=data?.leaderboard||[],secs=Math.max(0,Math.floor((Date.parse(data?.resetAt||'')-now)/1000));
 const remaining=Number.isFinite(secs)?Math.floor(secs/3600)+'H '+Math.floor(secs%3600/60)+'M '+secs%60+'S':'—';
 useEffect(()=>{if(!data?.resetAt || now<Date.parse(data.resetAt))return;
 let active=true;apiFetch<NonNullable<typeof data>>('/api/leaderboard?region='+region+'&period='+period).then(d=>{if(active)setData(d);}).catch(()=>{});return()=>{active=false;};},[now,data?.resetAt,period,region]);
 const podium=search.trim()?[]:[2,1,3];
 return <div className="arena-board"><div className="board-column">
  <header className="board-title"><span><Trophy/></span><h1>Leaderboard</h1><p>Compete for daily, weekly &amp; monthly demo prizes</p></header>
  <div className="board-periods" role="group" aria-label="Ranking period">{periods.map(p=><button key={p} aria-pressed={p===period} onClick={()=>setPeriod(p)}>{p}{p!=='All-Time' && <small>{pools[p]} credits</small>}</button>)}</div>
  <section className="board-pool"><h2><Trophy size={18}/>{period==='All-Time'?'Top 100 Winnings':period+' Prize Pool'}</h2><strong>{period==='All-Time'?formatSol(rows.reduce((a,r)=>a+r.earnedLamports,0),2)+' SOL':pools[period]+' credits'}</strong><small>{period==='All-Time'?'Simulated SOL':'#1 · Demo prize'}</small>{data?.resetAt&&<b>RESETS IN {remaining}</b>}</section>
  {error && <p role="alert">{error}</p>}
  {!error && !data && <p role="status">Loading rankings…</p>}
  {data && !search.trim() && <div className="board-podium">{podium.map(rank=>{const r=rows[rank-1];return <div className={'podium-place rank-'+rank} key={rank}>{rank===1&&<Crown className="podium-crown"/>}<div className="podium-face">{r?<PlayerPortrait name={r.username}/>:<Trophy/>}<b>{rank}</b></div>{r?<><Link to={'/profile/'+encodeURIComponent(r.username)}>{r.username}</Link><strong><Coins/>{formatSol(r.earnedLamports,2)}</strong><small>{r.wins}W · {r.losses}L · {Math.round(100*r.wins/(r.wins+r.losses||1))}%</small></>:<><strong>Open place</strong><small>Awaiting a result</small></>}</div>;})}</div>}
  <div className="board-tools"><input value={search} onChange={e=>setSearch(e.target.value)} aria-label="Find player in leaderboard" placeholder="Find player…"/><select aria-label="Leaderboard region" value={region} onChange={e=>setRegion(e.target.value)}>{['ALL','NAE','NAC','NAW','EU'].map(r=><option key={r}>{r}</option>)}</select></div>
  <div className="board-rows">{(search.trim()?rows.filter(r=>r.username.toLowerCase().includes(search.trim().toLowerCase())):rows.slice(3)).map(r=><Link key={r.id} to={'/profile/'+encodeURIComponent(r.username)}><b>{r.rank}</b><PlayerPortrait name={r.username}/><strong>{r.username}</strong><span><Coins/>{formatSol(r.earnedLamports,2)}</span></Link>)}</div>
  {data && !rows.length&&<p className="board-empty">No completed results for this period and region.</p>}
 </div></div>;
}
