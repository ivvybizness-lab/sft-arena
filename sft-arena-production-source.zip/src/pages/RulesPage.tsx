import { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FileText } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { pollingTransport, readOnlyPreview } from '../lib/preview';

interface PolicyItem {
  id: string;
  policy_type: string;
  title: string;
  content_md: string;
  created_at: string;
}

function PolicyBody({text}: {text: string}) {
  const sections = text.split(/\n(?=\d+\. [^\n])/);
  return <>{sections.map((section, index)=>{
    const lines = section.trim().split('\n').filter(Boolean);
    const heading = /^\d+\. /.test(lines[0] ?? '') ? lines.shift() : undefined;
    const blocks: {list: boolean; lines: string[]}[] = [];
    for (const line of lines) {
      if (line.startsWith('* ')) {
        if (!blocks.at(-1)?.list) blocks.push({list:true, lines:[]});
        blocks.at(-1)!.lines.push(line.slice(2));
      } else blocks.push({list:false, lines:[line]});
    }
    return <section key={heading ?? index}>
      {heading && <h2>{heading}</h2>}
      {blocks.map((block,i)=> block.list ? <ul key={i}>{block.lines.map(line=><li key={line}>{line}</li>)}</ul>
        : <p key={i}>{block.lines[0]}</p>)}
    </section>;
  })}</>;
}

export default function RulesPage() {
  const {hash} = useLocation();
  const [active, setActive] = useState<PolicyItem[]>([]);
  const [error, setError] = useState(false);
  const type = hash === '#privacy' ? 'privacy' : hash === '#competition_rules' ? 'competition_rules' : 'terms';
  const title = {terms:'Terms of Service', privacy:'Privacy Policy', competition_rules:'General Rules'}[type];
  const policy = active.find(item=>item.policy_type === type);

  useEffect(() => {
    let current = true;
    apiFetch<{active: PolicyItem[]}>('/api/policies')
      .then(data=>{if(current) setActive(data.active);})
      .catch(()=>{if(current) setError(true);});
    return ()=>{current=false;};
  }, []);

  useEffect(() => { window.scrollTo(0, 0); }, [type]);

  return <div className="rules-page">
    <header>
      <div><h1><FileText size={24}/> {title}</h1>
        {policy && <p>Last updated {new Intl.DateTimeFormat('en-US',{dateStyle:'long',timeZone:'America/Los_Angeles'}).format(new Date(policy.created_at))}</p>}
      </div>
      <nav aria-label="Policies">
        {type !== 'terms' && <Link to="/rules">Terms of Service</Link>}
        {type !== 'privacy' && <Link to="/rules#privacy">Privacy Policy</Link>}
        {type !== 'competition_rules' && <Link to="/rules#competition_rules">General Rules</Link>}
      </nav>
    </header>
    <article>
      {type === 'terms' && (pollingTransport || readOnlyPreview) && <p className="rules-demo-note">SFT Arena is a demo. Payment processing, real withdrawals, and live-service fees and timelines are unavailable here.</p>}
      {policy ? <PolicyBody text={policy.content_md}/> : error ? <p role="alert">This policy could not be loaded.</p> : <p role="status">Loading policy…</p>}
      {policy && type === 'terms' && <Link to="/support" className="underline mt-3 inline-block">Contact SFT Support</Link>}
    </article>
  </div>;
}
