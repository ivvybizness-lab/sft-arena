import React, { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Trophy,
  Search,
  Coins,
  CheckCircle2,
  X,
  Plus,
} from 'lucide-react';
import { apiFetch } from '../lib/api';
import { formatSol, formatUtcTimestamp } from '../lib/format';
import { useAuth } from '../context/AuthContext';
import TournamentBracket, { type BracketMatch } from '../components/TournamentBracket';
import TournamentCard, { type TournamentSummary } from '../components/TournamentCard';

interface TournamentDetail {
  tournament: TournamentSummary & { rules_json: string };
  registrations: Array<{
    id: string;
    team_name: string;
    captain_user_id: string;
    captain_username: string;
    seed: number | null;
    checked_in: number;
    final_rank: number | null;
    status: string;
  }>;
  bracket: BracketMatch[];
  payouts: Array<{
    id: string;
    username: string;
    team_name: string;
    rank_position: number;
    amount_lamports: number;
  }>;
  serverTimeUtc: string;
}

export default function TournamentsPage() {
  const { user, regionFilter, openAuthModal, notify, refreshUser } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();

  const [view, setView] = useState<'all' | 'upcoming' | 'live' | 'past'>('all');
  const [region, setRegion] = useState(regionFilter || 'ALL');
  const [search, setSearch] = useState('');
  const [tournaments, setTournaments] = useState<TournamentSummary[]>([]);
  const [serverClock, setServerClock] = useState(() => ({ now: Date.now(), offset: 0 }));
  const [loading, setLoading] = useState(true);
  const serverTimeUtc = new Date(serverClock.now + serverClock.offset).toISOString();

  const [selectedDetail, setSelectedDetail] = useState<TournamentDetail | null>(null);
  const [detailTab,setDetailTab]=useState<'overview'|'prizes'|'bracket'>('overview');
  const [teamNameInput, setTeamNameInput] = useState('');
  const [createOpen, setCreateOpen] = useState(false);

  // Create Tournament Form (Staff)
  const [newTitle, setNewTitle] = useState('');
  const [newMode, setNewMode] = useState('Zone Wars');
  const [newFormat, setNewFormat] = useState('2v2');
  const [newRegion, setNewRegion] = useState('NAC');
  const [newPrizeSol, setNewPrizeSol] = useState('5');
  const [newEntrySol, setNewEntrySol] = useState('0');
  const [newMaxTeams, setNewMaxTeams] = useState('32');

  const isStaff = user && ['moderator', 'owner'].includes(user.role);

  useEffect(()=>{
    if (isStaff && searchParams.get('panel')==='1') setCreateOpen(true);
  },[isStaff,searchParams]);
  useEffect(()=>{setDetailTab('overview');},[selectedDetail?.tournament.id]);

  useEffect(() => {
    setRegion(regionFilter || 'ALL');
  }, [regionFilter]);

  const syncServerClock = useCallback((iso: string) => {
    const now = Date.now();
    const offset = Date.parse(iso) - now;
    if (Number.isFinite(offset)) setServerClock({ now, offset });
  }, []);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setServerClock(clock => ({ ...clock, now: Date.now() }));
    }, 30_000);
    return () => window.clearInterval(timer);
  }, []);

  const loadTournaments = useCallback(async () => {
    setLoading(true);
    try {
      const qs = new URLSearchParams({ view, region, search });
      const data = await apiFetch<{ tournaments: TournamentSummary[]; serverTimeUtc: string }>(`/api/tournaments?${qs.toString()}`);
      setTournaments(data.tournaments);
      syncServerClock(data.serverTimeUtc);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }, [view, region, search, syncServerClock]);

  useEffect(() => {
    loadTournaments();
  }, [loadTournaments]);

  const openDetail = useCallback(async (tid: string) => {
    try {
      const d = await apiFetch<TournamentDetail>(`/api/tournaments/${tid}`);
      setSelectedDetail(d);
      syncServerClock(d.serverTimeUtc);
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Unable to load tournament', 'error');
    }
  }, [notify, syncServerClock]);

  useEffect(() => {
    const paramId = searchParams.get('id');
    if (paramId) openDetail(paramId);
  }, [searchParams, openDetail]);

  async function handleRegister(tid: string) {
    if (!user) return openAuthModal('login');
    try {
      await apiFetch(`/api/tournaments/${tid}/register`, {
        method: 'POST',
        body: JSON.stringify({ teamName: teamNameInput.trim() || `${user.username} Squad` }),
      });
      await refreshUser();
      await loadTournaments();
      await openDetail(tid);
      notify('Registered for tournament!', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Registration failed', 'error');
    }
  }

  async function handleCheckin(tid: string) {
    try {
      await apiFetch(`/api/tournaments/${tid}/checkin`, { method: 'POST' });
      await openDetail(tid);
      notify('Checked in successfully!', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Check-in failed', 'error');
    }
  }

  async function handleWithdraw(tid: string) {
    try {
      await apiFetch(`/api/tournaments/${tid}/withdraw`, { method: 'POST' });
      await refreshUser();
      await loadTournaments();
      await openDetail(tid);
      notify('Withdrawn from tournament. Any paid entry refunded.', 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Withdrawal failed', 'error');
    }
  }

  async function handleGenerateBracket(tid: string) {
    try {
      await apiFetch(`/api/tournaments/${tid}/generate-bracket`, { method: 'POST' });
      await loadTournaments();
      await openDetail(tid);
      notify('Bracket generated & tournament started!', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Bracket generation failed', 'error');
    }
  }

  async function handleRecordBracketWinner(tid: string, bmId: string, winnerRegId: string) {
    try {
      await apiFetch(`/api/tournaments/${tid}/bracket/${bmId}/result`, {
        method: 'POST',
        body: JSON.stringify({ winnerRegId, scoreA: 1, scoreB: 0 }),
      });
      await loadTournaments();
      await openDetail(tid);
      await refreshUser();
      notify('Bracket result recorded!', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to record bracket result', 'error');
    }
  }

  function closeCreateTournament() {
    setCreateOpen(false);
    if (searchParams.has('panel')) {
      const next=new URLSearchParams(searchParams);
      next.delete('panel');
      setSearchParams(next,{replace:true});
    }
  }

  async function handleCreateTournament(e: React.FormEvent) {
    e.preventDefault();
    try {
      await apiFetch('/api/tournaments', {
        method: 'POST',
        body: JSON.stringify({
          title: newTitle,
          mode: newMode,
          format: newFormat,
          region: newRegion,
          prizePoolLamports: Math.round(Number(newPrizeSol || 0) * 1_000_000_000),
          entryLamports: Math.round(Number(newEntrySol || 0) * 1_000_000_000),
          maxTeams: Number(newMaxTeams || 32),
        }),
      });
      closeCreateTournament();
      setNewTitle('');
      await loadTournaments();
      notify('Tournament created!', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to create tournament', 'error');
    }
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8 py-6 max-w-[1360px] mx-auto">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-display font-extrabold text-white">Tournaments</h1>
          <p className="text-xs text-slate-400 mt-1 tabular-nums">
            Server Clock: <span className="font-mono text-slate-200">{formatUtcTimestamp(serverTimeUtc)}</span>
          </p>
        </div>
        {isStaff && (
          <button
            type="button"
            onClick={() => setCreateOpen(true)}
            className="px-4 py-2.5 rounded-lg bg-[#6d4aff] hover:bg-[#7b5cff] text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Create Tournament
          </button>
        )}
      </div>

      {/* Views + Filters */}
      <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-b border-[#232a3e] pb-3">
        <div className="flex items-center gap-5">
          {[
            { key: 'all', label: 'All' },
            { key: 'upcoming', label: 'Upcoming' },
            { key: 'live', label: 'Live' },
            { key: 'past', label: 'Past' },
          ].map((v) => (
            <button
              key={v.key}
              type="button"
              onClick={() => setView(v.key as typeof view)}
              className={`text-xs sm:text-sm font-semibold pb-1 border-b-2 transition-colors cursor-pointer ${
                view === v.key ? 'border-[#6d4aff] text-white' : 'border-transparent text-slate-400 hover:text-white'
              }`}
            >
              {v.label}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={region}
            onChange={(e) => setRegion(e.target.value)}
            className="h-8 px-2.5 rounded-lg bg-[#171d2c] border border-[#262e45] text-xs text-white"
          >
            <option value="ALL">All Regions</option>
            <option value="NAE">NAE</option>
            <option value="NAC">NAC</option>
            <option value="NAW">NAW</option>
            <option value="EU">EU</option>
          </select>
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search tournaments..."
              className="h-8 pl-8 pr-3 rounded-lg bg-[#171d2c] border border-[#262e45] text-xs text-white"
            />
          </div>
        </div>
      </div>

      {loading ? (
        <div className="sft-tournament-grid" aria-busy="true" aria-label="Loading tournaments">
          {[1, 2].map((i) => (
            <div key={i} className="sft-tournament-card animate-pulse" />
          ))}
        </div>
      ) : tournaments.length === 0 ? (
        <div className="mt-6 p-10 rounded-xl bg-[#161b29] border border-[#232a3e] text-center">
          <Trophy className="w-8 h-8 text-slate-500 mx-auto mb-2" />
          <div className="text-sm font-semibold text-white">No tournaments match your filter</div>
        </div>
      ) : (
        <div className="sft-tournament-grid">
          {tournaments.map((tournament) => (
            <TournamentCard
              key={tournament.id}
              tournament={tournament}
              serverTimeUtc={serverTimeUtc}
              onOpen={openDetail}
            />
          ))}
        </div>
      )}

      {/* Tournament Detail, Registration, Check-in & Bracket Modal */}
      {selectedDetail && (
        <div className="responsive-modal-overlay fixed inset-0 z-[75] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div role="dialog" aria-modal="true" aria-labelledby="tournament-detail-title" className="tournament-detail-modal">
            <div className="h-1" style={{ backgroundColor: selectedDetail.tournament.accent_color || '#6d4aff' }} />
            <div className="tournament-detail-body">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <span className="px-2 py-0.5 rounded bg-[#6d4aff]/20 text-[#b4a0ff] text-[10px] font-bold uppercase">
                    {selectedDetail.tournament.status} · {selectedDetail.tournament.region} · {selectedDetail.tournament.format} {selectedDetail.tournament.mode}
                  </span>
                  <h2 id="tournament-detail-title" className="text-xl sm:text-2xl font-display font-extrabold text-white mt-1.5">
                    {selectedDetail.tournament.title}
                  </h2>
                </div>
                <button
                  type="button"
                  aria-label="Close tournament details"
                  onClick={() => {
                    setSelectedDetail(null);
                    if (searchParams.has('id')) setSearchParams({});
                  }}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#232b42] cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="tournament-detail-metrics">
                {[['Prize pool',formatSol(selectedDetail.tournament.prize_pool_lamports,4)+' SOL'],
                  [selectedDetail.tournament.format==='1v1'?'Players':'Teams',selectedDetail.registrations.length+'/'+selectedDetail.tournament.max_teams],
                  ['Mode',selectedDetail.tournament.mode],['Start time',formatUtcTimestamp(selectedDetail.tournament.starts_at)]].map(([key,value])=>
                    <article key={key}><strong>{value}</strong><small>{key}</small></article>)}
              </div>
              <nav className="flow-tabs" aria-label="Tournament detail tabs">{(['overview','prizes','bracket'] as const).map(tab=>
                <button key={tab} type="button" aria-current={detailTab===tab?'page':undefined} onClick={()=>setDetailTab(tab)}>{tab[0].toUpperCase()+tab.slice(1)}</button>)}</nav>
              {detailTab==='overview' && <>
              {/* Player Registration / Check-In / Withdraw Controls */}
              {(() => {
                const myReg = user
                  ? selectedDetail.registrations.find((r) => r.captain_user_id === user.id)
                  : undefined;
                return (
                  <div className="p-4 rounded-xl bg-[#111521] border border-[#252d44] flex flex-wrap items-center justify-between gap-3">
                    {myReg ? (
                      <>
                        <div>
                          <div className="text-xs font-bold text-white flex items-center gap-1.5">
                            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                            Registered Team: {myReg.team_name} ({myReg.status})
                          </div>
                          <div className="text-[11px] text-slate-400 mt-0.5 tabular-nums">
                            Seed #{myReg.seed ?? '—'} · Check-in: {myReg.checked_in ? 'Confirmed' : 'Pending'}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {!myReg.checked_in && ['Registration Open', 'Check-In'].includes(selectedDetail.tournament.status) && (
                            <button
                              type="button"
                              onClick={() => handleCheckin(selectedDetail.tournament.id)}
                              className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold cursor-pointer"
                            >
                              Check In Now
                            </button>
                          )}
                          {!['Live', 'Completed'].includes(selectedDetail.tournament.status) && (
                            <button
                              type="button"
                              onClick={() => handleWithdraw(selectedDetail.tournament.id)}
                              className="px-3.5 py-2 rounded-lg bg-[#242c41] hover:bg-red-500/20 text-slate-200 text-xs font-semibold cursor-pointer"
                            >
                              Withdraw
                            </button>
                          )}
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="flex-1 min-w-[200px]">
                          <input
                            type="text"
                            value={teamNameInput}
                            onChange={(e) => setTeamNameInput(e.target.value)}
                            placeholder="Enter Team / Squad Name..."
                            className="w-full h-9 px-3 rounded-lg bg-[#171d2c] border border-[#283148] text-xs text-white"
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRegister(selectedDetail.tournament.id)}
                          className="px-4 py-2 rounded-lg bg-[#6d4aff] hover:bg-[#7b5cff] text-white text-xs font-bold cursor-pointer"
                        >
                          Register ({selectedDetail.tournament.entry_lamports > 0 ? `${formatSol(selectedDetail.tournament.entry_lamports, 2)} SOL` : 'Free'})
                        </button>
                      </>
                    )}
                    {isStaff && !['Live', 'Completed'].includes(selectedDetail.tournament.status) && (
                      <button
                        type="button"
                        onClick={() => handleGenerateBracket(selectedDetail.tournament.id)}
                        className="px-3.5 py-2 rounded-lg bg-[#f5c542] text-[#111521] text-xs font-extrabold cursor-pointer"
                      >
                        Seed & Start Bracket
                      </button>
                    )}
                  </div>
                );
              })()}

              <section className="tournament-detail-card"><h3>Registered {selectedDetail.tournament.format==='1v1'?'Players':'Teams'}</h3>
                {selectedDetail.registrations.length===0 && <p>No entries yet.</p>}
                <ul className="tournament-reg-list">{selectedDetail.registrations.map(row=><li key={row.id}>
                  <div><strong>{row.team_name}</strong><small>@{row.captain_username}</small></div>
                  <b>{row.final_rank?'Rank #'+row.final_rank:row.checked_in?'Checked In':row.status}</b>
                </li>)}</ul>
              </section>
              </>}
              {detailTab==='prizes' && <section className="tournament-detail-card">
                <h3><Trophy size={20}/>Prize Distribution</h3>
                <div className="tournament-prize-total"><small>Total prize pool</small><strong><Coins size={23}/>{formatSol(selectedDetail.tournament.prize_pool_lamports,4)} SOL</strong></div>
                {selectedDetail.payouts.length>0 ? selectedDetail.payouts.map(payout=><div className="tournament-prize-row" key={payout.id}>
                  <span><Trophy size={17}/>#{payout.rank_position} · {payout.team_name} <small>@{payout.username}</small></span>
                  <strong>{formatSol(payout.amount_lamports,4)} SOL</strong>
                </div>) : [1,2].map(rank=>{
                  const total=selectedDetail.tournament.prize_pool_lamports;
                  const first=Math.floor(total*.7);
                  return <div className="tournament-prize-row" key={rank}>
                    <span><Trophy size={17}/>{rank===1?'1st Place · 70%':'2nd Place · 30%'}</span>
                    <strong>{formatSol(rank===1?first:total-first,4)} SOL</strong>
                  </div>;
                })}
              </section>}
              {detailTab==='bracket' && <TournamentBracket matches={selectedDetail.bracket}
                captains={Object.fromEntries(selectedDetail.registrations.map(row=>[row.id,row.captain_username]))}
                recordWinner={isStaff ? (matchId,winnerId)=>{void handleRecordBracketWinner(selectedDetail.tournament.id,matchId,winnerId);} : undefined}/>}
            </div>
          </div>
        </div>
      )}

      {/* Create Tournament Modal (Staff) */}
      {createOpen && (
        <div className="responsive-modal-overlay fixed inset-0 z-[80] bg-black/75 flex items-center justify-center p-4">
          <form onSubmit={handleCreateTournament} className="w-full max-w-md bg-[#181d2c] border border-[#2a3248] rounded-xl p-5 space-y-3">
            <h3 className="text-base font-display font-bold text-white">Create Official Tournament</h3>
            <input
              required
              type="text"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="SFT Weekend 2v2 Zone Wars Open"
              className="w-full px-3 py-2 rounded-lg bg-[#111521] border border-[#283148] text-xs text-white"
            />
            <div className="grid grid-cols-3 gap-2">
              <select value={newMode} onChange={(e) => setNewMode(e.target.value)} className="px-2 py-2 rounded-lg bg-[#111521] border border-[#283148] text-xs text-white">
                {['Zone Wars', 'Box Fights', 'Realistics', 'Build Fights', 'Piece Control', 'Zero Build'].map((m) => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
              <select value={newFormat} onChange={(e) => setNewFormat(e.target.value)} className="px-2 py-2 rounded-lg bg-[#111521] border border-[#283148] text-xs text-white">
                {['1v1', '2v2', '3v3', '4v4'].map((f) => (
                  <option key={f} value={f}>{f}</option>
                ))}
              </select>
              <select value={newRegion} onChange={(e) => setNewRegion(e.target.value)} className="px-2 py-2 rounded-lg bg-[#111521] border border-[#283148] text-xs text-white">
                {['NAE', 'NAC', 'NAW', 'EU'].map((r) => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="text-[10px] text-slate-400">Prize (SOL)</label>
                <input type="number" step="0.1" value={newPrizeSol} onChange={(e) => setNewPrizeSol(e.target.value)} className="w-full px-2.5 py-2 rounded-lg bg-[#111521] border border-[#283148] text-xs text-white tabular-nums" />
              </div>
              <div>
                <label className="text-[10px] text-slate-400">Entry (SOL)</label>
                <input type="number" step="0.05" value={newEntrySol} onChange={(e) => setNewEntrySol(e.target.value)} className="w-full px-2.5 py-2 rounded-lg bg-[#111521] border border-[#283148] text-xs text-white tabular-nums" />
              </div>
              <div>
                <label className="text-[10px] text-slate-400">Max Teams</label>
                <input type="number" min="2" max="512" value={newMaxTeams} onChange={(e) => setNewMaxTeams(e.target.value)} className="w-full px-2.5 py-2 rounded-lg bg-[#111521] border border-[#283148] text-xs text-white tabular-nums" />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={closeCreateTournament} className="px-3.5 py-2 rounded-lg bg-[#232a3e] text-xs text-slate-200 cursor-pointer">
                Cancel
              </button>
              <button type="submit" className="px-4 py-2 rounded-lg bg-[#6d4aff] text-white text-xs font-bold cursor-pointer">
                Publish Tournament
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
