import sftLogo from '../assets/brand/sft-logo.png';
import { useEffect, useState, type FormEvent } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { Check, ChevronDown, Coins, FileText, Gamepad2, History, Download, Search, Upload, Link2, Pencil, Target, Trash2, Tv, X } from 'lucide-react';
import { useAuth, type AuthUser } from '../context/AuthContext';
import PlayerPortrait from '../components/PlayerPortrait';
import GoogleSignIn from '../components/GoogleSignIn';
import { apiFetch } from '../lib/api';
import { formatSol, formatUtcTimestamp } from '../lib/format';
import TeamsPage from './TeamsPage';

type PublicProfile = Pick<AuthUser,'id'|'username'|'displayName'|'activeTitle'|'profilePortrait'|'profileBanner'|'competitiveRegion'|'epicDisplayName'|'wins'|'losses'|'elo'|'xp'|'createdAt'>;
type Match = { id:string; title:string; region:string; status:string; winner_side:string|null; team_side:string; score_a:number; score_b:number; opponents:string; wallet_change_lamports?:number|null; refunded?:number };
type WalletHistory = { invoices:{id:string; expected_lamports:number; base_lamports:number; received_lamports:number|null; network:string; matched_at:string|null; expires_at:string; status:string; created_at:string}[]; withdrawals:{id:string; amount_lamports:number; status:string; created_at:string}[] };
const profileTabs = [
  ['progress','Progress'], ['teams','Teams'], ['linked','Linked Accounts'],
  ['matches','Match History'], ['deposits','Deposits'], ['withdrawals','Withdrawals'],
] as const;
function matchOutcome(match: Match) {
  if (match.status === 'Complete' && match.winner_side) return match.winner_side === match.team_side ? 'Win' : 'Loss';
  return match.status === 'Cancelled' ? 'Cancelled' : match.status;
}
const banners = [['violet','Violet'],['midnight','Midnight'],['ocean','Ocean'],['sunset','Sunset']] as const;

export default function ProfilePage() {
  const navigate = useNavigate();
  const { username } = useParams();
  const { user, refreshUser, notify } = useAuth();
  const [query,setQuery] = useSearchParams();
  const tab = query.get('tab') ?? 'progress';
  const [result,setResult] = useState<{profile:PublicProfile; recentMatches:Match[]}|null>(null);
  const [error,setError] = useState('');
  const [wallet,setWallet] = useState<WalletHistory|null>(null);
  const [walletError,setWalletError] = useState('');
  const [dialog,setDialog] = useState<'banner'|'avatar'|'google'|'identity'|'twitch'|'game'|null>(null);
  const [outcome,setOutcome] = useState('');
  const [opponent,setOpponent] = useState('');
  const [saving,setSaving] = useState(false);
  const isOwn = Boolean(user && result?.profile.id === user.id);
  const own = isOwn ? user : null;

  useEffect(() => {
    let active = true;
    setResult(null); setError(''); setDialog(null); setOutcome(''); setOpponent('');
    apiFetch<NonNullable<typeof result>>('/api/users/'+encodeURIComponent(username ?? ''))
      .then(value => { if (active) setResult(value); })
      .catch(err => { if (active) setError(err.message); });
    return () => { active = false; };
  },[username,user?.id]);

  useEffect(() => {
    if (!isOwn || !['deposits','withdrawals'].includes(tab)) return;
    let active = true;
    setWallet(null); setWalletError('');
    apiFetch<WalletHistory>('/api/wallet').then(value => { if (active) setWallet(value); })
      .catch(err => { if (active) setWalletError(err.message); });
    return () => { active = false; };
  },[isOwn,tab,user?.id]);

  useEffect(() => {
    if (!dialog) return;
    function dismiss(event:KeyboardEvent) { if(event.key === 'Escape') setDialog(null); }
    window.addEventListener('keydown',dismiss);
    return () => window.removeEventListener('keydown',dismiss);
  },[dialog]);

  async function saveAppearance(values:{banner?:string; portrait?:number|null}) {
    if (saving) return;
    setSaving(true);
    try {
      await apiFetch('/api/account/appearance',{method:'PATCH',body:JSON.stringify(values)});
      await refreshUser();
      setDialog(null);
      notify('Profile updated.','success');
    } catch (err) { notify((err as Error).message,'error'); }
    finally { setSaving(false); }
  }

  async function saveProfile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!own || saving) return;
    const values = Object.fromEntries(new FormData(event.currentTarget));
    setSaving(true);
    try {
      await apiFetch('/api/account/profile', {method:'PATCH',body:JSON.stringify(values)});
      await refreshUser();
      setDialog(null);
      if (values.username && values.username !== own.username) navigate('/profile/' + encodeURIComponent(String(values.username).trim()), {replace:true});
      notify('Profile updated.', 'success');
    } catch (err) { notify((err as Error).message, 'error'); }
    finally { setSaving(false); }
  }

  async function unlink(provider:'epic'|'twitch') {
    const label = provider === 'epic' ? 'Game Account' : 'Twitch';
    if (!window.confirm('Remove '+label+' from your profile?')) return;
    try {
      await apiFetch('/api/account/connections/'+provider,{method:'DELETE'});
      await refreshUser();
      notify(label+' removed.','success');
    } catch (err) { notify((err as Error).message,'error'); }
  }

  if (!result) return <div className="sft-profile"><p role={error ? 'alert':'status'}>{error || 'Loading player profile…'}</p></div>;
  const profile = own ?? result.profile;
  const active = own && [...profileTabs.map(([key])=>key),'subscriptions'].includes(tab) ? tab : tab==='matches' ? 'matches':'progress';
  const record = profile.wins + profile.losses;
  const select = (key:string) => setQuery(key==='progress'?{}:{tab:key});
  const canSeeNotes = Boolean(user && ['owner','moderator','finance'].includes(user.role));
  const walletTab = active==='deposits' || active==='withdrawals';
  const matchingHistory = result.recentMatches.map(match=>({match, names:JSON.parse(match.opponents) as string[], result:matchOutcome(match)}))
    .filter(row=>(!outcome || row.result===outcome) && (!opponent.trim() || row.names.some(name=>name.toLowerCase().includes(opponent.trim().toLowerCase()))));
  const dialogTitle = dialog ? {google:'Connect Google', avatar:'Change avatar', banner:'Change banner', identity:'Edit profile', twitch:'Twitch channel', game:'Game account'}[dialog] : '';
  const walletRows = active==='deposits' ? wallet?.invoices : wallet?.withdrawals;

  return <div className="sft-profile-page">
    <div className="sft-profile">
      <div className="sft-profile-banner" data-banner={profile.profileBanner || 'violet'}>
        {own && <button className="profile-neutral-button" onClick={()=>setDialog('banner')}><Pencil size={14}/>Change banner</button>}
      </div>
      <div className="sft-profile-identity">
        <div className="sft-profile-portrait">
          <PlayerPortrait name={profile.username} portrait={profile.profilePortrait}/>
          {own && <button className="profile-round-button" aria-label="Change avatar" onClick={()=>setDialog('avatar')}><Pencil size={16}/></button>}
        </div>
        <div className="sft-profile-name">
          <div><h1>{profile.username}</h1>{own&&<button type="button" className="profile-round-button" aria-label="Edit profile" onClick={()=>setDialog('identity')}><Pencil size={19}/></button>}</div>
          {own && <p><Coins size={18}/>{formatSol(own.balance.available_lamports,2)} SOL</p>}
          <p><Target size={17}/>{profile.elo} ELO</p>
          {profile.activeTitle && <small>{profile.activeTitle}</small>}
        </div>
        {canSeeNotes && <Link className="profile-neutral-button profile-notes" to={'/staff/players/'+encodeURIComponent(profile.id)+'?tab=notes'}><FileText size={16}/>View Notes</Link>}
      </div>
      <nav className="sft-profile-tabs" aria-label="Profile sections">
        {profileTabs.filter(([key])=>own || ['progress','matches'].includes(key)).map(([key,label])=>
          <button key={key} aria-current={active===key?'page':undefined} onClick={()=>select(key)}>{label}</button>)}
        {own && <details className="sft-profile-more" key={active}>
          <summary data-active={active==='subscriptions'}>More <ChevronDown size={14}/></summary>
          <div><button onClick={()=>select('subscriptions')}>Subscriptions</button></div>
        </details>}
      </nav>

      <div className="profile-content">
      {active==='progress' && <>
        <div className="profile-section-heading"><h2><Target size={21}/>Progress</h2></div>
        <div className="profile-stats">{[['ELO',profile.elo],['Wins',profile.wins],['Losses',profile.losses],['Win rate',record?Math.round(profile.wins/record*100)+'%':'0%']].map(([label,value])=>
          <div className="profile-row" key={label}><strong>{value}</strong><small>{label}</small></div>)}</div>
        <div className="profile-row"><strong>Player details</strong><small>{profile.displayName} · {profile.competitiveRegion} · Epic: {profile.epicDisplayName || 'Unlinked'}</small></div>
      </>}
      {active==='teams' && own && <TeamsPage embedded/>}
      {active==='linked' && own && <>
        <div className="profile-section-heading"><h2><Link2 size={21}/>Linked Accounts</h2></div>
        <h3>Link an account</h3>
        <div className="profile-providers">
          <button disabled title="Discord linking is unavailable"><span>◉</span>Discord</button>
          <button type="button" onClick={()=>setDialog('twitch')}><Tv size={17}/>Twitch</button>
          <button disabled title="Kick linking is unavailable"><b>K</b>Kick</button>
          <button onClick={()=>setDialog('google')} disabled={own.googleConnected}><span className="profile-google-mark">G</span>Google</button>
          <button type="button" onClick={()=>setDialog('game')}><Gamepad2 size={18}/>Game Account</button>
          <button disabled title="Clash Royale linking is unavailable"><span>♛</span>Clash Royale</button>
        </div>
        <h3>Your accounts</h3>
        <div className="profile-stack">
          {own.googleConnected && <div className="profile-row profile-account"><span className="profile-provider-icon profile-google-mark">G</span><div><strong>Google <Check size={16} aria-label="Connected"/></strong><small>{own.email}</small></div></div>}
          {own.twitchChannel && <div className="profile-row profile-account"><span className="profile-provider-icon"><Tv size={20}/></span><div><strong>Twitch</strong><small>{own.twitchChannel}</small></div><div className="profile-account-actions"><button type="button" onClick={()=>setDialog('twitch')} aria-label="Edit Twitch channel"><Pencil size={17}/></button><button type="button" aria-label="Remove Twitch channel" onClick={()=>unlink("twitch")}><Trash2 size={17}/></button></div></div>}
          {own.epicDisplayName && <div className="profile-row profile-account"><span className="profile-provider-icon"><Gamepad2 size={21}/></span><div><strong>Game Account</strong><small>{own.epicDisplayName}</small></div><div className="profile-account-actions"><button type="button" onClick={()=>setDialog('game')} aria-label="Edit game account"><Pencil size={17}/></button><button type="button" aria-label="Remove game account" onClick={()=>unlink("epic")}><Trash2 size={17}/></button></div></div>}
          {!own.googleConnected && !own.twitchChannel && !own.epicDisplayName && <p className="profile-row">No linked accounts yet.</p>}
        </div>
      </>}
      {active==='matches' && <>
        <div className="profile-section-heading"><h2><History size={21}/>Match History</h2></div>
        <div className="profile-history-filters">
          <select aria-label="Outcome" value={outcome} onChange={event=>setOutcome(event.target.value)}>
            <option value="">Outcome · All</option>
            {['Win','Loss','Cancelled','Disputed','In Progress','Ready','Waiting'].map(value=><option key={value}>{value}</option>)}
          </select>
          <label><Search size={17}/><input value={opponent} onChange={event=>setOpponent(event.target.value)} aria-label="Search opponent by name" placeholder="Search opponent by name…"/></label>
        </div>
        <div className="profile-stack">
          {matchingHistory.length===0 && <p className="profile-row">{result.recentMatches.length ? 'No matches found for these filters.' : 'No match history yet.'}</p>}
          {matchingHistory.map(({match,names,result:label})=><Link className="profile-row profile-history-row" key={match.id} to={'/matches/'+match.id}>
            <span className="arena-status-pill" data-status={label}>{label}</span>
            <div><strong>{match.title}</strong><small>{names.length ? 'vs '+names.join(', ') : match.region}{match.status==='Complete' ? ' · '+match.score_a+'–'+match.score_b : ''}</small></div>
            {own && <div className="profile-history-amount" data-status={match.wallet_change_lamports && match.wallet_change_lamports > 0 ? 'Win' : match.wallet_change_lamports ? 'Loss' : ''}>
              {match.refunded ? 'Refunded' : Boolean(match.wallet_change_lamports) && <><Coins size={16}/>{Number(match.wallet_change_lamports)>0?'+':'−'}{formatSol(Math.abs(Number(match.wallet_change_lamports)),4)} SOL</>}
            </div>}
          </Link>)}
        </div>
      </>}
      {walletTab && own && <>
        <div className="profile-section-heading"><h2>{active==='deposits'?<Download size={21}/>:<Upload size={21}/>} {active==='deposits'?'Deposits':'Withdrawals'}</h2></div>
        <div className="profile-stack">
          {walletError ? <p role="alert" className="profile-row">{walletError}</p> : !walletRows ? <p role="status" className="profile-row">Loading transactions…</p> : !walletRows.length && <p className="profile-row">No {active} yet.</p>}
          {walletRows?.map(row=>{
            const invoice = 'base_lamports' in row ? row : null;
            const amount = 'amount_lamports' in row ? row.amount_lamports : (row.received_lamports ?? row.base_lamports);
            const status = row.status==='Matched'?'Confirmed':row.status==='Waiting'?'Pending':row.status;
            return <div className="profile-row profile-history-row profile-deposit" key={row.id}>
              <Coins size={20}/>
              <div><div className="profile-deposit-summary"><strong>{formatSol(amount,4)} SOL</strong>{invoice && <span>{invoice.network}</span>}<b className="arena-status-pill" data-status={status}>{status}</b></div>
                <small>{invoice?.matched_at ? 'Confirmed '+formatUtcTimestamp(invoice.matched_at) : status==='Expired' && invoice ? 'Expired '+formatUtcTimestamp(invoice.expires_at) : formatUtcTimestamp(row.created_at)}</small>
              </div>
            </div>;
          })}
        </div>
      </>}
      {active==='subscriptions' && own && <><div className="profile-section-heading"><h2><FileText size={21}/>Subscriptions</h2></div><p className="profile-row">No subscriptions on this account.</p></>}
      </div>
    </div>
    <footer className="sft-profile-footer"><Link to="/" className="profile-footer-brand" aria-label="SFT home"><img src={sftLogo} alt="SFT" width={48} height={48}/></Link><nav aria-label="Profile footer"><Link to="/support">Support</Link><Link to="/rules">Terms &amp; Rules</Link><Link to="/shop">Shop</Link></nav></footer>
    {own && dialog && <div className="arena-modal-overlay" onClick={()=>setDialog(null)}>
      <section className="arena-game-modal profile-picker" role="dialog" aria-modal="true" aria-label={dialogTitle} onClick={e=>e.stopPropagation()}>
        <button autoFocus className="arena-modal-close" aria-label="Close" onClick={()=>setDialog(null)}><X size={22}/></button>
        <h2>{dialogTitle}</h2>
        {['identity','twitch','game'].includes(dialog) && <form onSubmit={saveProfile} className="arena-form-stack">
          {dialog==='identity' && <>
            <label>Username<input name="username" required minLength={3} maxLength={24} defaultValue={own.username} readOnly={own.role==='owner'}/></label>
            <label>Region<select name="competitiveRegion" defaultValue={own.competitiveRegion}>{['NAE','NAC','NAW','EU'].map(region=><option key={region}>{region}</option>)}</select></label>
          </>}
          {dialog==='twitch' && <label>Twitch channel<input name="twitchChannel" required maxLength={80} defaultValue={own.twitchChannel ?? ''}/></label>}
          {dialog==='game' && <label>Epic display name<input name="epicDisplayName" required maxLength={32} defaultValue={own.epicDisplayName}/></label>}
          <button className="arena-form-primary" disabled={saving}>Save</button>
        </form>}
        {dialog==='google' && <GoogleSignIn onSuccess={async()=>{await refreshUser();setDialog(null);notify('Google account connected.','success');}}/>}
        {dialog==='avatar' && <div className="profile-picker-list profile-avatar-choices">{['Male avatar','Female avatar'].map((label,i)=><button key={i} aria-label={label} aria-pressed={profile.profilePortrait != null && profile.profilePortrait >= 0 && profile.profilePortrait < 6 && profile.profilePortrait % 2 === i} disabled={saving} onClick={()=>saveAppearance({portrait:i})}><PlayerPortrait name={profile.username} portrait={i}/></button>)}</div>}
        {dialog==='banner' && <div className="profile-picker-list">{banners.map(([key,label])=><button key={key} className="profile-banner-choice" data-banner={key} aria-pressed={(profile.profileBanner||'violet')===key} disabled={saving} onClick={()=>saveAppearance({banner:key})}>{label}</button>)}</div>}
      </section>
    </div>}
  </div>;
}
