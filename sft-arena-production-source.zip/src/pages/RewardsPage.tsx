import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Activity, Coins, Gift, Share2, Sparkles, Target, Trophy } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { formatSol, formatUtcTimestamp } from '../lib/format';
import { useAuth } from '../context/AuthContext';
import PlayerPortrait from '../components/PlayerPortrait';

interface RewardsPayload {
  dailyClaimed: boolean;
  firstWinEligible: boolean;
  firstWinClaimed: boolean;
  referralCode: string;
  referralCount: number;
  rewardsTotal: number;
  earnings: {day:string;lamports:number}[];
  claims: {id:string;reward_label:string;amount_lamports:number;created_at:string}[];
}

export default function RewardsPage() {
  const { user, openAuthModal, refreshUser, notify } = useAuth();
  const [result,setResult] = useState<{id:string;data:RewardsPayload|null;error:string}|null>(null);
  const [busy,setBusy] = useState(false);
  const data = result?.id===user?.id ? result?.data : null;
  const error = result?.id===user?.id ? result?.error : '';

  useEffect(()=>{
    if (!user) return;
    let current = true;
    apiFetch<RewardsPayload>('/api/rewards').then(data=>{if(current)setResult({id:user.id,data,error:''});})
      .catch(error=>{if(current)setResult({id:user.id,data:null,error:error.message});});
    return ()=>{current=false;};
  },[user?.id]);

  if (!user) return <div className="arena-rewards"><section className="rewards-hero rewards-guest">
    <Gift size={30}/><h1>Rewards</h1><p>Sign in to claim bonuses and track your esports progress.</p>
    <button className="admin-button admin-primary" onClick={()=>openAuthModal('login')}>Sign in</button>
  </section></div>;

  const claimable = [
    ...(!data || data.dailyClaimed ? [] : [{ key:'daily_checkin', amount:5_000_000 }]),
    ...(data?.firstWinEligible ? [{ key:'first_win_bonus', amount:25_000_000 }] : []),
  ];
  const amount = claimable.reduce((total,reward)=>total+reward.amount,0);
  const points = user.xp.toLocaleString();
  const code = data?.referralCode || user.referralCode;
  const days = data?.earnings ?? [];
  const chartMax = Math.max(5_000_000,...days.map(day=>day.lamports));
  const chart = days.map((day,index)=>[index*60,160-148*day.lamports/chartMax].join(',')).join(' ');

  async function claimAll() {
    if (busy || !claimable.length) return;
    setBusy(true);
    let credited = 0;
    try {
      for (const reward of claimable) {
        const response = await apiFetch<{amountLamports:number}>('/api/rewards/claim',{method:'POST',body:JSON.stringify({rewardKey:reward.key})});
        credited += response.amountLamports;
      }
    } catch (error) {notify((error as Error).message,'error');}
    finally {
      try {
        const data = await apiFetch<RewardsPayload>('/api/rewards');
        setResult({id:user.id,data,error:''});
        await refreshUser();
      } catch (error) {notify((error as Error).message,'error');}
      if (credited) notify('Claimed '+formatSol(credited,4)+' SOL.','success');
      setBusy(false);
    }
  }

  async function shareReferral() {
    try {
      if (navigator.share) await navigator.share({title:'SFT Arena',text:'My SFT Arena referral code is '+code});
      else {
        await navigator.clipboard.writeText(code);
        notify('Referral code copied.','success');
      }
    } catch (error) {
      if ((error as Error).name!=='AbortError') notify('You can copy '+code+' from the page.','info');
    }
  }

  const quests = [
    {label:'Daily Arena Check-In',detail:data?.dailyClaimed?'Claimed today':'+0.0050 SOL each day',progress:data?.dailyClaimed?100:0,Icon:Gift},
    {label:'First Victory',detail:data?.firstWinClaimed?'Milestone claimed':'+0.0250 SOL for your first win',progress:user.wins>0?100:0,Icon:Trophy},
  ];

  return <div className="arena-rewards">
    <section className="rewards-hero">
      <div className="rewards-top">
        <nav aria-label="Rewards navigation"><Link to="/rewards" aria-current="page">Rewards</Link><Link to="/leaderboard">Leaderboard</Link></nav>
        <button className="admin-button admin-primary" disabled={busy || !amount} onClick={claimAll}><Gift size={16}/>Claim All</button>
      </div>
      <div className="rewards-player"><Sparkles size={22}/><PlayerPortrait name={user.username} portrait={user.profilePortrait}/>
        <h1>{user.username}</h1><p>{user.activeTitle || 'SFT Competitor'}</p>
        <small>{data?.referralCount ?? '—'} referrals</small>
      </div>
      <div className="rewards-totals"><div><Target size={19}/><strong>{points}</strong> XP</div>
        <div><Coins size={19}/><strong>{data ? formatSol(data.rewardsTotal,4) : '—'}</strong> SOL earned</div>
        <div className="rewards-share"><code>{code}</code><button className="admin-button" onClick={shareReferral}><Share2 size={15}/>Share referral</button></div>
      </div>
    </section>
    {error && <p role="alert">{error}</p>}
    <div className="rewards-dashboard">
      <section className="rewards-card"><h2><Activity size={18}/>SOL Rewards</h2>
        {days.length ? <figure className="rewards-chart">
          <div><span>{formatSol(chartMax,4)} SOL</span><span>0 SOL</span></div>
          <svg viewBox="0 0 360 160" role="img" aria-label={days.map(entry=>entry.day+' '+formatSol(entry.lamports,4)+' SOL').join(', ')}>
            <polygon points={'0,160 '+chart+' 360,160'}/><polyline points={chart}/>
          </svg>
          <figcaption><span>{days[0].day.slice(5)}</span><span>{days[days.length-1].day.slice(5)}</span></figcaption>
        </figure> : <p>{error ? 'Reward history is unavailable.' : 'Loading reward history…'}</p>}
      </section>
      <section className="rewards-card rewards-claim"><h2><Gift size={18}/>Claim</h2>
        <strong><Coins size={26}/>+{formatSol(amount,4)} SOL</strong>
        <p>Credits go to your SFT balance.</p>
        <button className="admin-button admin-primary" disabled={busy || !amount} onClick={claimAll}>{busy?'Claiming…':amount?'Claim available rewards':'Nothing to claim'}</button>
      </section>
      <section className="rewards-card"><h2><Sparkles size={18}/>Quests</h2>
        <div className="rewards-quests">{quests.map(({label,detail,progress,Icon})=><div key={label}>
          <div className="rewards-ring" style={{background:'conic-gradient(#9474ff '+progress+'%, #2b3245 0)'}}><span><Icon size={25}/></span></div>
          <strong>{label}</strong><small>{detail}</small>
        </div>)}</div>
      </section>
    </div>
    <section className="rewards-card"><h2>Claim history</h2>
      {data?.claims.length ? <ul className="rewards-history">{data.claims.map(row=><li key={row.id}>
        <span>{row.reward_label}<small>{formatUtcTimestamp(row.created_at)}</small></span><strong>+{formatSol(row.amount_lamports,4)} SOL</strong>
      </li>)}</ul> : <p>{data ? 'No rewards claimed yet.' : 'No claim history available.'}</p>}
    </section>
  </div>;
}
