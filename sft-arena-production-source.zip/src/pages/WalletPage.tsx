import React, { useEffect, useState, useCallback, useRef } from 'react';
import {
  ArrowDownToLine,
  ArrowUpFromLine,
  RefreshCw,
  Copy,
  AlertCircle,
  FlaskConical, Gift, X, Coins, CircleDollarSign,
} from 'lucide-react';
import { apiFetch } from '../lib/api';
import { formatSol, formatSolExactDeposit, formatUtcTimestamp } from '../lib/format';
import { useAuth } from '../context/AuthContext';

interface WalletPayload {
  config: {
    networkMode: 'demo' | 'devnet' | 'mainnet';
    mainnetEnabled: boolean;
    paidMatchesEnabled: boolean;
    feeBps: number;
    minWithdrawalLamports: number;
    treasuryAddress: string;
  };
  balance: {
    available_lamports: number;
    reserved_lamports: number;
    frozen_lamports: number;
  };
  invoices: Array<{
    id: string;
    network: string;
    treasury_address: string;
    expected_lamports: number;
    status: string;
    matched_signature: string | null;
    expires_at: string;
    review_note: string | null;
    created_at: string;
  }>;
  withdrawals: Array<{
    id: string;
    network: string;
    destination_address: string;
    amount_lamports: number;
    fee_lamports: number;
    status: string;
    tx_signature: string | null;
    last_error: string | null;
    created_at: string;
  }>;
}

export default function WalletDialog({ onClose }: { onClose: () => void }) {
  const { user, refreshUser, notify } = useAuth();
  const [active, setActive] = useState<'deposit'|'withdraw'|'tip'>('deposit');
  const [currency,setCurrency] = useState<'sol'|'usdc'|null>(null);
  const [recipient,setRecipient] = useState('');
  const [tipAmount,setTipAmount] = useState('');
  const [tipping,setTipping] = useState(false);
  const tipRequest = useRef<{key:string;id:string}|null>(null);
  const dialog = useRef<HTMLDialogElement>(null);
  const [data, setData] = useState<WalletPayload | null>(null);
  const [loading, setLoading] = useState(true);

  const [depositSol, setDepositSol] = useState('1.0');
  const [creatingInvoice, setCreatingInvoice] = useState(false);

  const [withdrawAddr, setWithdrawAddr] = useState('');
  const [withdrawSol, setWithdrawSol] = useState('0.25');
  const [withdrawing, setWithdrawing] = useState(false);
  const [syncing, setSyncing] = useState(false);

  const loadWallet = useCallback(async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    try {
      const w = await apiFetch<WalletPayload>('/api/wallet');
      setData(w);
      setWithdrawAddr(previous=>previous || user.payoutAddress || '');
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }, [user?.id, user?.payoutAddress]);

  useEffect(() => {
    loadWallet();
  }, [loadWallet]);

  useEffect(() => {
    const node = dialog.current;
    node?.showModal();
    return () => node?.close();
  }, []);

  function selectAction(value: 'deposit'|'withdraw'|'tip') {
    setCurrency(null);
    setActive(value);
  }

  if (!user) return null;

  async function handleCreateDeposit(e: React.FormEvent) {
    e.preventDefault();
    setCreatingInvoice(true);
    try {
      await apiFetch('/api/wallet/deposit-invoice', {
        method: 'POST',
        body: JSON.stringify({ asset:'SOL', amountSol:Number(depositSol) }),
      });
      await loadWallet();
      notify('SOL deposit invoice created.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Unable to create deposit invoice', 'error');
    } finally {
      setCreatingInvoice(false);
    }
  }

  async function handleDevnetSync() {
    setSyncing(true);
    try {
      const res = await apiFetch<{ scanned: number }>('/api/wallet/sync', { method: 'POST' });
      await loadWallet();
      await refreshUser();
      notify(`Solana watcher checked treasury (${res.scanned} new transfers scanned).`, 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Sync failed', 'error');
    } finally {
      setSyncing(false);
    }
  }

  async function handleSimulateExactDeposit(invoiceId: string) {
    try {
      const res = await apiFetch<{ outcome: { outcome: string } }>('/api/wallet/devnet-simulate-transfer', {
        method: 'POST',
        body: JSON.stringify({ invoiceId }),
      });
      await loadWallet();
      await refreshUser();
      notify(`Devnet simulation: ${res.outcome.outcome}`, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Simulation failed', 'error');
    }
  }

  async function handleWithdraw(e: React.FormEvent) {
    e.preventDefault();
    setWithdrawing(true);
    try {
      const res = await apiFetch<{ execution: { status: string } }>('/api/wallet/withdraw', {
        method: 'POST',
        body: JSON.stringify({
          asset:'SOL',
          destinationAddress: withdrawAddr,
          amountSol: Number(withdrawSol),
        }),
      });
      await loadWallet();
      await refreshUser();
      notify(`Withdrawal status: ${res.execution.status}`, res.execution.status === 'Confirmed' ? 'success' : 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Withdrawal failed', 'error');
    } finally {
      setWithdrawing(false);
    }
  }

  async function handleTip(event:React.FormEvent) {
    event.preventDefault();
    if (tipping) return;
    const username = recipient.trim();
    const key = username.toLowerCase()+'|'+Number(tipAmount);
    if (tipRequest.current?.key!==key) tipRequest.current={key,id:crypto.randomUUID()};
    setTipping(true);
    try {
      await apiFetch('/api/wallet/tip',{method:'POST',body:JSON.stringify({asset:'SOL',username,amountSol:Number(tipAmount),requestId:tipRequest.current.id})});
      tipRequest.current=null;
      setTipAmount('');
      await loadWallet();
      await refreshUser();
      notify('Simulated SOL tip sent.','success');
    } catch (error) {
      notify((error as Error).message,'error');
    } finally {setTipping(false);}
  }

  async function copy(text: string, label: string) {
    try {
      await navigator.clipboard.writeText(text);
      notify(`${label} copied.`, 'success');
    } catch {
      notify(text, 'info');
    }
  }

  const options = [
    { id:'deposit' as const, label:'Deposit', Icon:ArrowDownToLine },
    { id:'withdraw' as const, label:'Withdraw', Icon:ArrowUpFromLine },
    { id:'tip' as const, label:'Tip', Icon:Gift },
  ];

  return (
    <dialog ref={dialog} className="arena-wallet-dialog" aria-label="Wallet actions" onCancel={event=>{event.preventDefault();onClose();}}
        onClick={event=>{if(event.target===event.currentTarget)onClose();}}>
        <div className="arena-wallet-dialog-inner">
          <div className="arena-wallet-tabs">
            <nav className="admin-tabs" aria-label="Wallet sections">{options.map(({id,label})=>
              <button key={id} aria-pressed={active===id} onClick={()=>selectAction(id)}>{label}</button>)}</nav>
            <button className="admin-button" aria-label="Close wallet actions" onClick={()=>onClose()}><X size={18}/></button>
          </div>
          <div className="arena-wallet-balance"><Coins size={23}/><div><small>Available SOL</small><strong>{formatSol(data?.balance.available_lamports ?? user.balance.available_lamports,4)} SOL</strong></div></div>
          <h2>{active==='deposit'?'Deposit options':active==='withdraw'?'Withdrawal options':'Tip a player'}</h2>
          <div className="arena-wallet-assets">
            <button className="arena-wallet-option" aria-pressed={currency==='sol'} onClick={()=>setCurrency('sol')}><b>≋</b><strong>Solana (SOL)</strong><small>Solana network</small></button>
            <button className="arena-wallet-option" aria-pressed={currency==='usdc'} onClick={()=>setCurrency('usdc')}><CircleDollarSign/><strong>USDC (Solana)</strong><small>Unavailable</small></button>
          </div>
          {currency==='usdc' && <p role="status" className="arena-wallet-status">USDC transfers aren’t supported by the current wallet.</p>}
          {currency==='sol' && active==='tip' && <>
            {data?.config.networkMode==='demo' ? <form className="arena-tip-form" onSubmit={handleTip}>
              <label>Player username<input required value={recipient} onChange={event=>setRecipient(event.target.value)} /></label>
              <label>Amount (simulated SOL)<input type="number" required min="0.000000001" max="500" step="0.000000001" value={tipAmount} onChange={event=>setTipAmount(event.target.value)} /></label>
              <button className="admin-button admin-primary" disabled={tipping}>{tipping?'Sending…':'Send tip'}</button>
            </form> : <p className="arena-wallet-status">{loading?'Loading wallet…':'Player tips are available with simulated SOL only.'}</p>}
          </>}
        {currency==='sol' && active==='deposit' && <div className="rounded-xl bg-[#161b29] border border-[#252d44] p-5 space-y-4">
          <div className="flex items-center gap-2">
            <ArrowDownToLine className="w-4 h-4 text-emerald-400" />
            <h2 className="text-base font-display font-bold text-white">Deposit SOL</h2>
            {data?.config.networkMode === 'devnet' && <button type="button" disabled={syncing} onClick={handleDevnetSync} className="admin-button ml-auto"><RefreshCw size={16}/> Sync deposits</button>}
          </div>

          <form onSubmit={handleCreateDeposit} className="flex items-end gap-2.5">
            <div className="flex-1">
              <label className="block text-xs font-semibold text-slate-300 mb-1">Amount (SOL)</label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                value={depositSol}
                onChange={(e) => setDepositSol(e.target.value)}
                className="w-full h-9 px-3 rounded-lg bg-[#111521] border border-[#283148] text-xs text-white tabular-nums"
              />
            </div>
            <button
              type="submit"
              disabled={creatingInvoice}
              className="h-9 px-4 rounded-lg bg-[#22c55e] hover:bg-[#16a34a] text-[#0b1410] text-xs font-extrabold cursor-pointer"
            >
              {creatingInvoice ? 'Creating...' : 'Generate Deposit Address'}
            </button>
          </form>

          {data?.config.treasuryAddress && data.config.networkMode!=='demo' && (
            <div className="p-3 rounded-lg bg-[#111521] border border-[#252d44] flex items-center justify-between gap-2 text-xs">
              <div className="min-w-0">
                <div className="text-[10px] text-slate-400 uppercase">Treasury Deposit Wallet</div>
                <div className="font-mono text-slate-200 truncate">{data.config.treasuryAddress}</div>
              </div>
              <button
                type="button"
                onClick={() => copy(data.config.treasuryAddress, 'Treasury address')}
                className="px-2.5 py-1 rounded bg-[#232a3e] hover:bg-[#313b56] text-xs font-semibold shrink-0 cursor-pointer flex items-center gap-1"
              >
                <Copy className="w-3 h-3" /> Copy
              </button>
            </div>
          )}

          {/* Active & Recent Deposit Invoices */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-slate-300">Deposit Invoices (Exact 9-Decimal Match Required)</div>
            {loading ? (
              <div className="h-24 rounded-lg bg-[#111521] animate-pulse" />
            ) : !data?.invoices.length ? (
              <div className="text-xs text-slate-500">No deposit invoices created yet.</div>
            ) : (
              data.invoices.slice(0, 5).map((inv) => (
                <div key={inv.id} className="p-3 rounded-lg bg-[#111521] border border-[#242c42] text-xs space-y-1.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono font-bold text-[#f5c542] tabular-nums">
                      {formatSolExactDeposit(inv.expected_lamports)} SOL
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        inv.status === 'Matched'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : inv.status === 'Needs Review'
                          ? 'bg-amber-500/20 text-amber-300'
                          : inv.status === 'Expired'
                          ? 'bg-slate-600/30 text-slate-400'
                          : 'bg-[#6d4aff]/20 text-[#b4a0ff]'
                      }`}
                    >
                      {inv.status}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                    <span>Expires: {formatUtcTimestamp(inv.expires_at)}</span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => copy(formatSolExactDeposit(inv.expected_lamports), 'Exact SOL amount')}
                        className="text-slate-300 hover:text-white underline cursor-pointer"
                      >
                        Copy Exact SOL
                      </button>
                      {inv.status === 'Waiting' && data.config.networkMode !== 'mainnet' && (
                        <button
                          type="button"
                          onClick={() => handleSimulateExactDeposit(inv.id)}
                          className="px-2 py-0.5 rounded bg-[#242c41] hover:bg-[#313b56] text-[#9d85ff] font-semibold inline-flex items-center gap-1 cursor-pointer"
                        >
                          <FlaskConical className="w-3 h-3" /> Test Devnet Transfer
                        </button>
                      )}
                    </div>
                  </div>
                  {inv.review_note && (
                    <div className="text-[11px] text-amber-300 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" /> {inv.review_note}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>}

        {currency==='sol' && active==='withdraw' && <div className="rounded-xl bg-[#161b29] border border-[#252d44] p-5 space-y-4">
          <div className="flex items-center gap-2">
            <ArrowUpFromLine className="w-4 h-4 text-[#9d85ff]" />
            <h2 className="text-base font-display font-bold text-white">Withdraw SOL</h2>
          </div>

          <form onSubmit={handleWithdraw} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">Destination Solana Wallet (Base58)</label>
              <input
                type="text"
                required
                value={withdrawAddr}
                onChange={(e) => setWithdrawAddr(e.target.value)}
                placeholder="So11111111111111111111111111111111111111112"
                className="w-full h-9 px-3 rounded-lg bg-[#111521] border border-[#283148] text-xs font-mono text-white"
              />
            </div>
            <div className="flex items-end gap-2.5">
              <div className="flex-1">
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Amount (Min {formatSol(data?.config.minWithdrawalLamports ?? 10000000, 3)} SOL)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={withdrawSol}
                  onChange={(e) => setWithdrawSol(e.target.value)}
                  className="w-full h-9 px-3 rounded-lg bg-[#111521] border border-[#283148] text-xs text-white tabular-nums"
                />
              </div>
              <button
                type="submit"
                disabled={withdrawing}
                className="h-9 px-5 rounded-lg bg-[#6d4aff] hover:bg-[#7b5cff] disabled:opacity-50 text-white text-xs font-bold cursor-pointer"
              >
                {withdrawing ? 'Submitting...' : 'Request Withdrawal'}
              </button>
            </div>
          </form>

          <div className="space-y-2 pt-2">
            <div className="text-xs font-semibold text-slate-300">Withdrawal Queue</div>
            {!data?.withdrawals.length ? (
              <div className="text-xs text-slate-500">No withdrawal requests yet.</div>
            ) : (
              data.withdrawals.slice(0, 6).map((w) => (
                <div key={w.id} className="p-3 rounded-lg bg-[#111521] border border-[#242c42] text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white tabular-nums">{formatSol(w.amount_lamports, 4)} SOL</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        w.status === 'Confirmed'
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : w.status === 'Needs Review'
                          ? 'bg-amber-500/20 text-amber-300'
                          : w.status === 'Failed'
                          ? 'bg-red-500/20 text-red-300'
                          : 'bg-[#6d4aff]/20 text-[#b4a0ff]'
                      }`}
                    >
                      {w.status}
                    </span>
                  </div>
                  <div className="text-[11px] font-mono text-slate-400 truncate mt-1">
                    To: {w.destination_address}
                  </div>
                  {w.tx_signature && (
                    <div className="text-[10px] font-mono text-slate-500 truncate mt-0.5">Sig: {w.tx_signature}</div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>}
        </div>
      </dialog>
  );
}
