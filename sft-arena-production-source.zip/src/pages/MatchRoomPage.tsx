import './MatchRoomActions.css';
import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Share2,
  Gamepad2,
  MonitorSmartphone,
  Globe,
  Users,
  MapPin,
  Shield,
  Check,
  X,
  MessageSquare,
  Send,
  ImagePlus,
  Copy,
  ChevronsRight,
  Lock,
  Unlock,
  AlertTriangle,
  Ban, Trophy, ChevronDown, BarChart3, Flag,
  FileCheck2,
} from 'lucide-react';
import JoinMatchDialog from '../components/JoinMatchDialog';
import PlayerPortrait from '../components/PlayerPortrait';
import { apiFetch } from '../lib/api';
import { readOnlyPreview, pollingTransport } from '../lib/preview';
import { formatSol, formatUtcTimestamp } from '../lib/format';
import { useAuth } from '../context/AuthContext';

interface Participant {
  id: string;
  team_side: 'A' | 'B';
  user_id: string;
  username_snapshot: string;
  display_name_snapshot: string;
  epic_name_snapshot: string;
  active_title_snapshot: string;
  is_captain: number;
  ready_state: number;
  reported_winner_side: 'A' | 'B' | null;
  reported_score_a: number | null;
  reported_score_b: number | null;
  stake_reserved_lamports: number;
}

interface ChatMessage {
  id: string;
  user_id: string | null;
  sender_name: string;
  sender_role: string;
  message_type: 'user' | 'system' | 'staff';
  body: string;
  created_at: string;
}

interface Revision {
  id: string;
  version_num: number;
  prior_winner_side: string | null;
  new_winner_side: string;
  new_score_a: number;
  new_score_b: number;
  actor_username: string | null;
  reason: string;
  financial_correction_lamports: number;
  created_at: string;
}

interface EvidenceItem {
  id: string;
  original_filename: string;
  mime_type: string;
  size_bytes: number;
  note: string;
  uploader_username: string;
  created_at: string;
}

interface MatchRoomPayload {
  match: {
    id: string;
    title: string;
    is_private: number;
    is_ranked: number;
    is_demo: number;
    format: string;
    mode: string;
    loadout?:string;
    rounds_lead?:number;
    disable_simple_edit?:number;
    platform: string;
    region: string;
    game_server_region: string;
    entry_lamports: number;
    total_prize_lamports: number;
    platform_fee_lamports: number;
    first_to: number;
    win_by_two?: number;
    movement_type: string;
    map_code: string;
    creator_user_id: string;
    lobby_code: string;
    status: 'Waiting' | 'Ready' | 'In Progress' | 'Disputed' | 'Complete' | 'Cancelled';
    winner_side: 'A' | 'B' | null;
    score_a: number;
    score_b: number;
    chat_open: number;
    created_at: string;
    started_at: string | null;
    completed_at: string | null;
  };
  participants: Participant[];
  cancelVotes?: string[];
  startedControlsAllowed?: boolean;
  chat: ChatMessage[];
  map: {
    name: string;
    code: string;
    loadout_summary: string;
    rules_json: string;
  } | null;
  revisions: Revision[];
  evidence: EvidenceItem[];
  viewerPermissions: {
    isParticipant: boolean;
    isStaff: boolean;
    canUploadEvidence: boolean;
  };
}

export default function MatchRoomPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, openAuthModal, notify, refreshUser } = useAuth();

  const [room, setRoom] = useState<MatchRoomPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [rulesTab, setRulesTab] = useState<'mode' | 'general' | 'revisions'>('mode');
  const [mobileChatOpen, setMobileChatOpen] = useState(false);

  const [chatInput, setChatInput] = useState('');
  const [sendingChat, setSendingChat] = useState(false);
  const chatListRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Ready countdown display (5:00 window synced cleanly)
  const [readyClockSec, setReadyClockSec] = useState(300);

  // Score report & dispute / manage modals
  const [reportOpen, setReportOpen] = useState(false);
  const [resultStep, setResultStep] = useState<'outcome' | 'victory' | 'score' | 'defeat'>('outcome');
  const [resultBusy, setResultBusy] = useState(false);
  const [now, setNow] = useState(Date.now());
  const [repScoreA, setRepScoreA] = useState('3');
  const [repScoreB, setRepScoreB] = useState('0');

  const [disputeModalOpen, setDisputeModalOpen] = useState(false);
  const [disputeReason, setDisputeReason] = useState('');


  const [joinSide,setJoinSide]=useState<'A'|'B'|null>(null);
  const [joiningSolo, setJoiningSolo] = useState(false);
  const [staffPending, setStaffPending] = useState(false);
  const [preMatchAction, setPreMatchAction] = useState<'ready' | 'leave' | null>(null);
  const [uploadingEvidence, setUploadingEvidence] = useState(false);

  const loadRoom = useCallback(async () => {
    if (!id) return;
    try {
      const data = await apiFetch<MatchRoomPayload>(`/api/matches/${id}`);
      setRoom(data);
      setError('');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load match room');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    loadRoom();
  }, [loadRoom, user?.id]);

  useEffect(() => {
    const t = setInterval(() => {
      setNow(Date.now());
      setReadyClockSec((s) => (s > 0 ? s - 1 : 0));
    }, 1000);
    return () => clearInterval(t);
  }, []);

  // Real-time WebSocket subscription for this match room
  useEffect(() => {
    if (!id || readOnlyPreview) return;
    if (pollingTransport) {
      const timer = window.setInterval(() => { if (!document.hidden) loadRoom(); }, 4000);
      return () => window.clearInterval(timer);
    }
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${proto}//${window.location.host}/ws`);
    ws.onopen = () => {
      ws.send(JSON.stringify({ type: 'subscribe_match', matchId: id }));
    };
    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data) as { type: string; matchId?: string };
        if (msg.matchId !== id) return;
        if (msg.type === 'match_state' || msg.type === 'room_update' || msg.type === 'chat_message') loadRoom();
        if (msg.type === 'match_state') refreshUser();
      } catch {
        // ignore
      }
    };
    return () => ws.close();
  }, [id, loadRoom, refreshUser]);

  useEffect(() => {
    if (chatListRef.current) {
      chatListRef.current.scrollTop = chatListRef.current.scrollHeight;
    }
  }, [room?.chat.length]);

  if (loading) {
    return (
      <div className="p-8 max-w-6xl mx-auto">
        <div className="h-96 rounded-xl bg-[#161b29] border border-[#232a3e] animate-pulse" />
      </div>
    );
  }

  if (error || !room) {
    return (
      <div className="p-8 max-w-2xl mx-auto text-center">
        <div className="p-8 rounded-xl bg-[#161b29] border border-[#262e45]">
          <AlertTriangle className="w-10 h-10 text-amber-400 mx-auto mb-3" />
          <h1 className="text-xl font-display font-bold text-white">Unable to Open Match Room</h1>
          <p className="text-sm text-slate-400 mt-1">{error || 'Match not found.'}</p>
          <div className="mt-5 flex items-center justify-center gap-3">
            <Link to="/matches" className="px-4 py-2 rounded-lg bg-[#242c41] text-xs font-semibold text-white">
              Back to matches
            </Link>
            {!user && (
              <button
                type="button"
                onClick={() => openAuthModal('login')}
                className="px-4 py-2 rounded-lg bg-[#6d4aff] text-xs font-semibold text-white cursor-pointer"
              >
                Sign In
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  const { match, participants, chat, map, revisions, evidence, viewerPermissions } = room;
  const teamA = participants.filter((p) => p.team_side === 'A');
  const teamB = participants.filter((p) => p.team_side === 'B');
  const myParticipant = user ? participants.find((p) => p.user_id === user.id) : undefined;
  const isStaff = viewerPermissions.isStaff;
  const inProgress = match.status === 'In Progress';
  const startedControls = Boolean(myParticipant) && (inProgress || match.status === 'Disputed');
  const canReport = inProgress && !!match.started_at && room.startedControlsAllowed !== false && myParticipant?.is_captain === 1;
  const timerSeconds = Math.max(0, Math.ceil((Date.parse(match.started_at || '') + 600000 - now) / 1000));
  const timerLabel = Math.floor(timerSeconds / 60) + ':' + String(timerSeconds % 60).padStart(2, '0');
  const votes = room.cancelVotes ?? [];
  const voted = !!myParticipant && votes.includes(myParticipant.team_side);
  function openResults() {
    if (!myParticipant) return;
    setResultStep('outcome');
    setRepScoreA(myParticipant.team_side === 'A' ? String(match.first_to) : '0');
    setRepScoreB(myParticipant.team_side === 'B' ? String(match.first_to) : '0');
    setReportOpen(true);
  }
  async function voteCancel() {
    if (resultBusy || voted) return;
    setResultBusy(true);
    try {
      const updated = await apiFetch<MatchRoomPayload>(`/api/matches/${match.id}/cancel`, {method:'POST',body:JSON.stringify({vote:true,reason:'Both teams voted to cancel.'})});
      setRoom(updated);
      void refreshUser();
      notify(updated.match.status === 'Cancelled' ? 'Match cancelled.' : 'Cancellation vote submitted.', 'success');
    } catch (err) { notify((err as Error).message,'error'); }
    finally { setResultBusy(false); }
  }
  const hideOpponent = (player: Participant) =>
    ['Waiting', 'Ready'].includes(match.status) &&
    !match.started_at && player.ready_state !== 1 && player.team_side !== myParticipant?.team_side;
  const canModerateMatch = user?.role === 'moderator' || user?.role === 'owner';

  async function runStaffAction(path: 'cancel' | 'staff-resolve' | 'staff-reset', body: object, message: string) {
    if (staffPending) return;
    setStaffPending(true);
    try {
      const updated = await apiFetch<MatchRoomPayload>(`/api/matches/${match.id}/${path}`, { method: 'POST', body: JSON.stringify(body) });
      if (updated.match.id !== match.id) navigate(`/matches/${updated.match.id}`);
      else setRoom(updated);
      void refreshUser();
      notify(message, 'success');
    } catch (error) {
      notify((error as Error).message, 'error');
    } finally {
      setStaffPending(false);
    }
  }

  function forceWin(side: 'A' | 'B') {
    const target = match.first_to;
    void runStaffAction('staff-resolve', {
      winnerSide: side, scoreA: side === 'A' ? target : 0, scoreB: side === 'B' ? target : 0,
      reason: `Staff awarded the match to Team ${side} from the match room.`,
    }, 'Match result recorded.');
  }

  let mapRules: string[] = [];
  if (map?.rules_json && map.code === match.map_code) {
    try {
      mapRules = JSON.parse(map.rules_json);
    } catch {
      mapRules = [];
    }
  }

  function copyText(text: string, label: string) {
    navigator.clipboard.writeText(text).then(
      () => notify(`${label} copied!`, 'success'),
      () => notify(`Copy failed — ${text}`, 'info')
    );
  }

  async function handleJoin(side: 'A' | 'B') {
    if (!user) { openAuthModal('login'); return; }
    if (match.format !== '1v1') { setJoinSide(side); return; }
    if (joiningSolo) return;
    setJoiningSolo(true);
    try {
      await joinMatch(side);
    } catch (err) {
      notify((err as Error).message, 'error');
    } finally {
      setJoiningSolo(false);
    }
  }

  async function joinMatch(side: 'A' | 'B', teamId: string | null = null) {
    const updated = await apiFetch<MatchRoomPayload>('/api/matches/'+match.id+'/join',{
      method:'POST',body:JSON.stringify({teamSide:side,teamId}),
    });
    setRoom(updated);
    setJoinSide(null);
    notify('Joined match.','success');
    void refreshUser();
  }

  async function handleReady(ready: boolean) {
    setPreMatchAction('ready');
    try {
      const updated = await apiFetch<MatchRoomPayload>(`/api/matches/${match.id}/ready`, {
        method: 'POST',
        body: JSON.stringify({ ready }),
      });
      setRoom(updated);
      notify(ready ? 'Marked Ready!' : 'Ready status cleared.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to update ready state', 'error');
    } finally {
      setPreMatchAction(null);
    }
  }

  async function handleLeaveMatch() {
    const isCreator = match.creator_user_id === user?.id;
    setPreMatchAction('leave');
    try {
      await apiFetch(`/api/matches/${match.id}/${isCreator ? 'cancel' : 'leave'}`, {
        method: 'POST',
        body: JSON.stringify(isCreator ? { reason: 'The match creator left the lobby.' } : {}),
      });
      void refreshUser();
      notify(isCreator ? 'Match cancelled.' : 'You left the match.', 'info');
      navigate('/matches');
    } catch (err) {
      notify((err as Error).message, 'error');
    } finally {
      setPreMatchAction(null);
    }
  }

  async function submitOutcome(condition: 'defeat' | 'timer' | 'score') {
    if (resultBusy || !myParticipant) return;
    setResultBusy(true);
    const side = myParticipant.team_side;
    try {
      const updated = await apiFetch<MatchRoomPayload>(`/api/matches/${match.id}/report`, {
        method:'POST', body:JSON.stringify({
          winnerSide: condition === 'defeat' ? (side === 'A' ? 'B' : 'A') : side,
          scoreA: condition === 'score' ? Number(repScoreA) : 0,
          scoreB: condition === 'score' ? Number(repScoreB) : 0,
          condition,
        }),
      });
      setRoom(updated);
      setReportOpen(false);
      await refreshUser();
      notify('Match result submitted.', 'success');
    } catch (err) { notify((err as Error).message, 'error'); }
    finally { setResultBusy(false); }
  }

  async function handleOpenDispute(e: React.FormEvent) {
    e.preventDefault();
    try {
      const updated = await apiFetch<MatchRoomPayload>(`/api/matches/${match.id}/dispute`, {
        method: 'POST',
        body: JSON.stringify({ reason: disputeReason }),
      });
      setRoom(updated);
      setDisputeModalOpen(false);
      setDisputeReason('');
      notify('Dispute opened — escrow locked for staff review.', 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Failed to open dispute', 'error');
    }
  }

  async function handleSendChat(e: React.FormEvent) {
    e.preventDefault();
    if (!chatInput.trim()) return;
    setSendingChat(true);
    try {
      await apiFetch(`/api/matches/${match.id}/chat`, {
        method: 'POST',
        body: JSON.stringify({ body: chatInput.trim() }),
      });
      setChatInput('');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Could not send message', 'error');
    } finally {
      setSendingChat(false);
    }
  }

  async function handleToggleChat() {
    try {
      const updated = await apiFetch<MatchRoomPayload>(`/api/matches/${match.id}/chat/toggle`, { method: 'POST' });
      setRoom(updated);
      notify(`Match chat ${updated.match.chat_open ? 'reopened' : 'closed'}.`, 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Toggle failed', 'error');
    }
  }

  async function handleUploadEvidence(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingEvidence(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      const res = await fetch(`/api/matches/${match.id}/evidence`, {
        method: 'POST',
        credentials: 'include',
        body: fd,
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || 'Upload failed');
      setRoom(json.room);
      notify('Evidence uploaded securely for staff verification.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Upload failed', 'error');
    } finally {
      setUploadingEvidence(false);
      e.target.value = '';
    }
  }

  // Exact 5-step connected timeline matching image_646f7210.png
  const stepIndex =
    match.status === 'Waiting'
      ? 1
      : match.status === 'Ready'
      ? 2
      : match.status === 'In Progress'
      ? (participants.some(p => p.reported_winner_side) ? 4 : 3)
      : match.status === 'Disputed'
      ? 5
      : ['Complete', 'Cancelled'].includes(match.status)
      ? 5
      : 1;

  const steps = [
    { label: 'Waiting', desc: 'Waiting for an opponent to accept this match', done: stepIndex >= 1 },
    { label: 'Ready Up', desc: 'All players must ready up to start competing', done: stepIndex >= 2 },
    { label: 'Playing', desc: 'Start competing now', done: stepIndex >= 3 },
    { label: 'Submitting', desc: 'Submit your results to conclude the match', done: stepIndex >= 4 },
    { label: match.status === 'Disputed' ? 'Disputed' : match.status === 'Cancelled' ? 'Cancelled' : 'Completed', desc: match.status === 'Disputed' ? 'Staff will review the disputed result' : match.status === 'Cancelled' ? 'This match was cancelled' : 'This match has concluded', done: stepIndex >= 5 },
  ];

  const readyMinutes = Math.floor(readyClockSec / 60);
  const readySeconds = readyClockSec % 60;
  const readyTimerLabel = `${readyMinutes}:${String(readySeconds).padStart(2, '0')}`;

  function formatChatTime(iso: string) {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '';
    return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  }

  const ChatColumn = (
    <div className="room-chat flex flex-col h-full bg-[#111520] border-l border-[#202738]">
      <div className="px-4 py-3 border-b border-[#202738] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm font-display font-bold text-white">Match Chat</span>
          {!match.chat_open && (
            <span className="px-1.5 py-0.5 rounded bg-red-500/20 text-red-300 text-[10px] font-bold uppercase">
              Closed
            </span>
          )}
        </div>
        {canModerateMatch && !mobileChatOpen ? (
          <button
            type="button"
            onClick={handleToggleChat}
            title={match.chat_open ? 'Close Match Chat' : 'Reopen Match Chat'}
            className="p-1.5 rounded bg-[#1d2436] hover:bg-[#273147] text-slate-300 cursor-pointer"
          >
            {match.chat_open ? <ChevronsRight className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
          </button>
        ) : (
          <button
            type="button"
            onClick={() => setMobileChatOpen(false)}
            aria-label="Close chat"
            className="lg:hidden p-1.5 rounded bg-[#1d2436] text-slate-300"
          >
            <ChevronsRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      <div ref={chatListRef} className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2.5">
        {chat.map((c) => (
          <div
            key={c.id}
            className={`p-3 rounded-lg text-xs ${
              c.message_type === 'system'
                ? 'bg-[#171d2c] border border-[#242c40] text-slate-200'
                : c.message_type === 'staff'
                ? 'bg-[#221a38] border border-[#6d4aff]/40 text-white'
                : 'bg-[#181f2f] border border-[#242c40] text-slate-100'
            }`}
          >
            <div className="flex items-center gap-2 mb-1">
              {c.sender_role !== 'player' && (
                <span
                  className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wide ${
                    c.sender_role === 'system'
                      ? 'bg-[#0284c7] text-white'
                      : 'bg-[#6d4aff] text-white'
                  }`}
                >
                  {c.sender_role === 'system' ? 'MATCH' : c.sender_role}
                </span>
              )}
              {c.sender_role !== 'system' && <span className="font-bold text-white truncate">{c.sender_name}</span>}
              <span className="text-[11px] text-slate-400 tabular-nums shrink-0">{formatChatTime(c.created_at)}</span>
            </div>
            <p className="text-slate-200 break-words leading-relaxed">{c.body}</p>
          </div>
        ))}
      </div>

      {!viewerPermissions.isParticipant && !isStaff && <p className="room-chat-notice">You are not in this match.</p>}
      <form onSubmit={handleSendChat} className="p-2.5 border-t border-[#202738] flex items-center gap-1.5">
        {viewerPermissions.canUploadEvidence && (
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            title="Upload match evidence"
            className="w-8 h-9 rounded-md bg-[#181f2e] hover:bg-[#232c40] border border-[#263044] text-slate-400 hover:text-white flex items-center justify-center shrink-0 cursor-pointer"
          >
            <ImagePlus className="w-4 h-4" />
          </button>
        )}
        <input
          type="text"
          value={chatInput}
          disabled={(!viewerPermissions.isParticipant && !isStaff) || (!match.chat_open && !isStaff)}
          onChange={(e) => setChatInput(e.target.value)}
          placeholder={(!viewerPermissions.isParticipant && !isStaff) ? 'Chat is for players and staff' : match.chat_open ? 'Type a message…' : 'Chat closed by staff'}
          className="flex-1 min-w-0 h-9 px-3 rounded-md bg-[#161c2a] border border-[#252e42] text-xs text-white placeholder-slate-500 disabled:opacity-50"
        />
        <button
          type="submit"
          disabled={(!viewerPermissions.isParticipant && !isStaff) || sendingChat || (!match.chat_open && !isStaff)}
          className="h-9 px-3.5 rounded-md bg-[#d9a628] hover:bg-[#eab308] disabled:opacity-50 text-[#111521] font-bold text-xs shrink-0 cursor-pointer"
        >
          Send
        </button>
      </form>

    </div>
  );

  // Determine Team Panel labels & members cleanly
  const leftSideParticipants = teamB.length > 0 && myParticipant?.team_side === 'B' ? teamB : teamA;
  const rightSideParticipants = teamB.length > 0 && myParticipant?.team_side === 'B' ? teamA : teamB;
  const leftSideLabel = teamB.length > 0 && myParticipant?.team_side === 'B' ? 'Joining team' : 'Creating team';
  const rightSideLabel = teamB.length > 0 && myParticipant?.team_side === 'B' ? 'Creating team' : 'Joining team';
  const leftSideKey: 'A' | 'B' = teamB.length > 0 && myParticipant?.team_side === 'B' ? 'B' : 'A';
  const rightSideKey: 'A' | 'B' = leftSideKey === 'A' ? 'B' : 'A';

  return (
    <div className="arena-room flex flex-col lg:flex-row">
      <input ref={fileInputRef} type="file" onChange={handleUploadEvidence} className="hidden" />
      {/* Left Main Match Arena */}
      <div className="flex-1 min-w-0 overflow-y-auto">
        {/* Top Atmospheric Gradient Header matching image_646f7210.png */}
        <div className="room-heading relative bg-gradient-to-b from-[#172138] via-[#131a2d] to-[#0f131f] border-b border-[#1f273a] px-4 sm:px-6 pt-4 pb-6 overflow-hidden">
          {/* Top-left Back to matches + Mobile chat button */}
          <div className="room-actions flex items-center justify-between gap-2">
            <Link
              to="/matches"
              className="px-3 py-1.5 rounded-md bg-[#202738] hover:bg-[#2a334a] border border-[#313c55] text-xs font-medium text-slate-200 inline-flex items-center gap-1.5"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Back to matches
            </Link>

            <button
              type="button"
              onClick={() => setMobileChatOpen(true)}
              className="lg:hidden px-3 py-1.5 rounded-md bg-[#6d4aff] text-xs font-semibold text-white inline-flex items-center gap-1.5 cursor-pointer"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              Match Chat ({chat.length})
            </button>
          </div>

          {/* Centered Title, Entry/Prize & 6 Metadata Chips */}
          <div className="max-w-3xl mx-auto text-center mt-2">
            <div className="text-[11px] text-slate-400 tabular-nums">
              Match created · {formatUtcTimestamp(match.created_at)} · ID: <span className="font-mono text-slate-300">{match.id}</span>
            </div>

            <div className="mt-1.5 flex flex-wrap items-center justify-center gap-3">
              <h1 className="room-title text-2xl sm:text-3xl font-display font-extrabold text-white tracking-tight">
                {match.title}
              </h1>
              <button
                type="button"
                onClick={() => copyText(`${window.location.origin}${readOnlyPreview ? '/#' : ''}/matches/${match.id}`, 'Match link')}
                className="px-3 py-1.5 rounded-md bg-[#202738] hover:bg-[#2a334a] border border-[#313c55] text-xs font-semibold text-slate-200 inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Share2 className="w-3.5 h-3.5" />
                Share Match
              </button>
            </div>

            {(match.loadout || Boolean(match.rounds_lead) || Boolean(match.disable_simple_edit)) && <div className="flow-summary mt-3">
              {match.loadout && <span>Loadout <b>{match.loadout}</b></span>}
              {Boolean(match.rounds_lead) && <span>Rounds lead <b>{match.rounds_lead}</b></span>}
              {Boolean(match.disable_simple_edit) && <span><b>Simple Edit off</b></span>}
            </div>}

            {/* Entry > Prize Pair */}
            <div className="room-prizes mt-3.5 inline-flex items-center gap-2.5 tabular-nums">
              <div className="px-4 py-1.5 rounded-lg bg-[#161c2b]/90 border border-[#2d364d] text-center min-w-[84px]">
                <div className="text-[10px] text-slate-400">Entry</div>
                <div className="text-sm font-bold text-white flex items-center justify-center gap-1 mt-0.5">
                  <span className="w-3.5 h-3.5 rounded-full bg-[#f5c542] text-[#111521] flex items-center justify-center text-[8px] font-black">
                    S
                  </span>
                  {match.entry_lamports > 0 ? formatSol(match.entry_lamports, 2) : 'FREE'}
                </div>
              </div>

              <span className="text-slate-400 text-xs font-bold">›</span>

              <div className="px-4 py-1.5 rounded-lg bg-[#0f2924]/90 border border-[#195244] text-center min-w-[84px]">
                <div className="text-[10px] text-emerald-400">Prize</div>
                <div className="text-sm font-bold text-emerald-400 flex items-center justify-center gap-1 mt-0.5">
                  <span className="w-3.5 h-3.5 rounded-full bg-[#f5c542] text-[#111521] flex items-center justify-center text-[8px] font-black">
                    S
                  </span>
                  {match.total_prize_lamports > 0 ? `+${formatSol(match.total_prize_lamports, 2)}` : 'ELO'}
                </div>
              </div>
            </div>

            {/* 6 Metadata Chips Row */}
            <div className="room-meta mt-4 grid grid-cols-3 sm:grid-cols-6 gap-2.5 max-w-2xl mx-auto">
              {[
                { icon: Gamepad2, k: 'Game', v: 'Fortnite' },
                { icon: MonitorSmartphone, k: 'Platform', v: match.platform },
                { icon: Globe, k: 'Region', v: ({NAE:'NA East',NAW:'NA West',NAC:'NA Central',EU:'Europe'} as Record<string,string>)[match.region] || match.region },
                { icon: Users, k: 'Team Size', v: match.format },
                { icon: MapPin, k: 'First To', v: match.win_by_two ? `${match.first_to} +2` : String(match.first_to) },
                { icon: match.is_private ? Lock : Unlock, k: 'Visibility', v: match.is_private ? 'Private Match' : 'Public Match' },
              ].map((chip) => {
                const Icon = chip.icon;
                return (
                  <div
                    key={chip.k}
                    className="py-2.5 px-2 rounded-lg bg-[#161c2c]/85 border border-[#252e44] flex flex-col items-center justify-center"
                  >
                    <Icon className="w-4 h-4 text-slate-300 mb-1" />
                    <div className="text-[10px] text-slate-400">{chip.k}</div>
                    <div className="text-xs font-bold text-white mt-0.5 tabular-nums">{chip.v}</div>
                  </div>
                );
              })}
            </div>

            {match.lobby_code && (
              <div className="mt-3.5 inline-flex flex-wrap items-center justify-center gap-x-2 gap-y-1 px-3.5 py-1 rounded-md bg-[#0e2d3b]/80 border border-cyan-500/35 text-cyan-200 text-xs font-mono">
                <span>LOBBY CODE:</span>
                <strong className="text-white">{match.lobby_code}</strong>
                <span className="text-cyan-300/80">({match.game_server_region})</span>
              </div>
            )}
          </div>
        </div>

        {/* Lower Room Content */}
        <div className="room-content mx-auto px-4 sm:px-6 py-5">
          <ol className="room-timeline" aria-label="Match progress">
            {steps.map((step, i) => (
              <li key={step.label} data-state={i < stepIndex - 1 ? 'done' : i === stepIndex - 1 ? 'current' : 'next'}
                  aria-current={i === stepIndex - 1 ? 'step' : undefined}>
                <div className="room-timeline-track"><span>{i < stepIndex - 1 && <Check size={13}/>}</span><i/></div>
                <strong>{step.label}</strong><p>{step.desc}</p>
              </li>
            ))}
          </ol>
          {myParticipant && !match.started_at && ['Waiting', 'Ready'].includes(match.status) && (
            <section aria-label="Match ready-up" className="mb-5 flex flex-col items-center gap-3">
              <div className="flex flex-wrap justify-center gap-2.5">
                <button type="button" onClick={handleLeaveMatch} disabled={preMatchAction !== null}
                  className="inline-flex items-center gap-2 rounded-lg bg-red-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-red-700 disabled:opacity-60">
                  <X size={17} /> {preMatchAction === 'leave' ? 'Leaving…' : 'Leave Match'}
                </button>
                <button type="button" onClick={() => handleReady(myParticipant.ready_state !== 1)}
                  aria-pressed={myParticipant.ready_state === 1} disabled={preMatchAction !== null}
                  className="inline-flex items-center gap-2 rounded-lg bg-[#10c469] px-5 py-2.5 text-sm font-bold text-[#10201c] hover:bg-[#0eb35f] disabled:opacity-60">
                  <Check size={17} />
                  {preMatchAction === 'ready' ? 'Updating…' : myParticipant.ready_state === 1 ? 'Ready — Undo' : 'Ready Up'}
                  {myParticipant.ready_state !== 1 && preMatchAction !== 'ready' && <span className="tabular-nums opacity-75">{readyTimerLabel}</span>}
                </button>
              </div>
              <ul aria-live="polite" className="flex flex-wrap justify-center gap-x-4 gap-y-1 text-sm">
                {[teamA, teamB].map((team, index) => {
                  const ready = team.length === Number(match.format[0]) && team.every(player => player.ready_state === 1);
                  return <li key={index} className={`inline-flex items-center gap-1.5 ${ready ? 'text-emerald-400' : 'text-slate-300'}`}>
                    <span aria-hidden="true" className={`h-2 w-2 rounded-full ${ready ? 'bg-emerald-400' : 'bg-slate-400'}`}/>
                    Team {index + 1} {ready ? 'Ready' : 'Not Ready'}
                  </li>;
                })}
              </ul>
            </section>
          )}
          {/* 2-Column Body: Left Team Panels (7 cols) | Right Action Stack + Rules (5 cols) */}
          <div className="room-workspace">
            {/* Left Team Panels + Evidence (7 cols) */}
            <div className="room-teams-and-evidence space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {[
                  { side: leftSideKey, label: leftSideLabel, members: leftSideParticipants, accent: '#743ff0' },
                  { side: rightSideKey, label: rightSideLabel, members: rightSideParticipants, accent: '#ff8d27' },
                ].map((panel) => {
                  const isWinner = match.status === 'Complete' && match.winner_side === panel.side;
                  const isLoser = match.status === 'Complete' && match.winner_side && match.winner_side !== panel.side;
                  const captain = panel.members[0];

                  return (
                    <div
                      key={panel.side}
                      className={`room-team relative rounded-lg bg-[#161c2b] border p-4 overflow-hidden ${
                        isWinner
                          ? 'border-emerald-500/60'
                          : isLoser
                          ? 'border-red-500/40'
                          : 'border-[#242c40]'
                      }`}
                    >
                      {/* Subtle lower-left corner accent matching image_646f7210.png */}
                      <span
                        className="room-team-stripe absolute"
                        style={{ background: panel.accent }}
                      />

                      <div className="room-team-name flex items-start justify-between gap-2 mb-3">
                        <div className="min-w-0">
                          <div className="text-[11px] text-slate-400">{panel.label}</div>
                          <div className="text-sm font-display font-bold text-white mt-0.5 truncate">
                            {captain && !hideOpponent(captain) ? `${captain.username_snapshot} Team` : `Team ${panel.side}`}
                            {match.status === 'Complete' && (
                              <span className="ml-2 text-xs font-mono text-slate-300 tabular-nums">
                                ({panel.side === 'A' ? match.score_a : match.score_b})
                              </span>
                            )}
                          </div>
                        </div>

                        {isWinner && (
                          <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold uppercase">
                            Victory
                          </span>
                        )}
                        {isLoser && (
                          <span className="px-2 py-0.5 rounded bg-red-500/20 text-red-300 text-[10px] font-bold uppercase">
                            Defeat
                          </span>
                        )}
                      </div>

                      {panel.members.length === 0 ? (
                        <div className="flex items-center justify-between gap-3 py-1">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-full bg-[#242c40] flex items-center justify-center text-slate-400">
                              <X className="w-4 h-4" />
                            </div>
                            <div>
                              <div className="text-xs font-bold text-slate-200">Open Slot</div>
                              <div className="text-[11px] text-slate-400">Awaiting opponent</div>
                            </div>
                          </div>
                          {match.status === 'Waiting' && !myParticipant && (
                            <button
                              type="button"
                              onClick={() => handleJoin(panel.side)}
                              disabled={joiningSolo}
                              className="px-3 py-1.5 rounded-md bg-[#10c469] hover:bg-[#0eb35f] text-white text-xs font-bold cursor-pointer"
                            >
                              Join
                            </button>
                          )}
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {panel.members.map((m) => {
                            if (hideOpponent(m)) return (
                              <div key={m.id} className="flex min-h-16 items-center justify-between gap-2 rounded-lg border border-slate-400/20 bg-slate-900/25 px-2.5 py-2">
                                <div className="flex min-w-0 items-center gap-3">
                                  <span aria-hidden="true" className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border-2 border-slate-400/30 bg-slate-400/10 text-lg font-bold text-slate-400">?</span>
                                  <span className="text-xs font-bold text-white">Hidden until ready</span>
                                </div>
                                <span aria-hidden="true" className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md border border-emerald-400/30 bg-emerald-500/10 text-emerald-400"><Check size={15}/></span>
                              </div>
                            );
                            const isMe = user && m.user_id === user.id;
                            return (
                              <div key={m.id} className="flex items-center justify-between gap-2">
                                <div className="flex items-center gap-3 min-w-0">
                                  <PlayerPortrait name={m.username_snapshot} className="room-player-photo" />
                                  <div className="min-w-0">
                                    <Link
                                      to={`/profile/${m.username_snapshot}`}
                                      className="text-xs font-bold text-white hover:text-[#9d85ff] truncate block"
                                    >
                                      {m.username_snapshot}{isMe ? ' (you)' : ''}
                                    </Link>
                                    <div className={`text-[11px] ${m.ready_state === 1 ? 'text-emerald-400' : 'text-slate-400'}`}>
                                      Playing as <strong>{m.epic_name_snapshot || m.username_snapshot}</strong>
                                    </div>
                                  </div>
                                </div>

                                {m.reported_winner_side && (
                                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#232a3e] text-slate-200 shrink-0">
                                    {m.reported_winner_side} ({m.reported_score_a}-{m.reported_score_b})
                                  </span>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {isStaff && startedControls && <section className="room-started-actions" aria-label="Started match controls">
                {canReport && <button className="room-cancel-vote" type="button" disabled={resultBusy || voted} onClick={voteCancel}><Ban size={19}/>{voted ? 'Voted to Cancel' : 'Vote Match Cancel'} ({votes.length}/2)</button>}
                {inProgress && <button className="room-submit-result" type="button" disabled={!canReport || resultBusy || !!myParticipant?.reported_winner_side} onClick={openResults}><Trophy size={19}/>{myParticipant?.reported_winner_side ? 'Results Submitted' : myParticipant?.is_captain !== 1 ? 'Captain submits score' : 'Submit Results'}</button>}
                {inProgress && <button type="button" className="room-cancel-vote" onClick={() => setDisputeModalOpen(true)}><AlertTriangle size={18}/> Open Dispute</button>}
                {viewerPermissions.canUploadEvidence && <button type="button" className="room-submit-result" disabled={uploadingEvidence} onClick={() => fileInputRef.current?.click()}><ImagePlus size={18}/> {uploadingEvidence ? 'Uploading…' : 'Upload Evidence'}</button>}
              </section>}
              {/* Private Evidence List when files exist or match is Disputed/Complete */}
              {(evidence.length > 0 || ['Disputed', 'Complete'].includes(match.status)) && viewerPermissions.canUploadEvidence && (
                <div className="rounded-lg bg-[#161c2b] border border-[#242c40] p-4">
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <div className="text-xs font-bold text-white flex items-center gap-2">
                      <FileCheck2 className="w-4 h-4 text-[#9d85ff]" />
                      Private Match Evidence ({evidence.length})
                    </div>
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="px-2.5 py-1 rounded bg-[#242c40] hover:bg-[#313b56] text-xs font-semibold text-white cursor-pointer"
                    >
                      {uploadingEvidence ? 'Uploading...' : 'Upload Proof'}
                    </button>
                  </div>
                  {evidence.length === 0 ? (
                    <div className="text-xs text-slate-400">No evidence uploaded yet.</div>
                  ) : (
                    <div className="space-y-1.5">
                      {evidence.map((ev) => (
                        <div
                          key={ev.id}
                          className="px-3 py-2 rounded bg-[#111521] border border-[#232a3e] flex items-center justify-between gap-2 text-xs"
                        >
                          <span className="truncate text-slate-200">
                            {ev.original_filename} · @{ev.uploader_username}
                          </span>
                          <a
                            href={`/api/matches/${match.id}/evidence/${ev.id}/download`}
                            target="_blank"
                            rel="noreferrer"
                            className="text-[#38bdf8] hover:underline font-semibold shrink-0"
                          >
                            Download
                          </a>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Right Action Stack + Rules Box (5 cols) matching image_646f7210.png */}
            <div className="room-side space-y-2.5">
              {/* Green Primary Action */}
              {match.status === 'Waiting' && !myParticipant ? (
                <button
                  type="button"
                  onClick={() => handleJoin('B')}
                  disabled={joiningSolo}
                  className="w-full py-3 rounded-lg bg-[#10c469] hover:bg-[#0eb35f] text-white text-sm font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors"
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  {joiningSolo ? 'Joining…' : 'Join Match (' + (match.entry_lamports > 0 ? `${formatSol(match.entry_lamports, 2)} SOL` : 'Free') + ')'}
                </button>
              ) : null}

              {myParticipant && match.status === 'Ready' && (
                <button
                  type="button"
                  onClick={() => setDisputeModalOpen(true)}
                  className="w-full py-3 rounded-lg bg-[#ef4444] hover:bg-[#dc2626] text-white text-sm font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors"
                >
                  <X className="w-4 h-4 stroke-[3]" />
                  Open Dispute
                </button>
              )}

              {/* Match support */}
              <button
                type="button"
                onClick={() => navigate('/support')}
                className="room-support w-full py-3 rounded-lg bg-[#5865f2] hover:bg-[#4752c4] text-white text-sm font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                <MessageSquare className="w-4 h-4" />
                Match Support
              </button>

              {!isStaff && startedControls && <section className="participant-actions" aria-label="Started match controls">
                {canReport && <button className="participant-danger" type="button" disabled={resultBusy || voted} onClick={voteCancel}><Ban size={19}/>{voted ? 'Voted to Cancel' : 'Vote Match Cancel'} ({votes.length}/2)</button>}
                {inProgress && <button className="participant-primary" type="button" disabled={!canReport || resultBusy || !!myParticipant?.reported_winner_side} onClick={openResults}><Trophy size={19}/>{myParticipant?.reported_winner_side ? 'Results Submitted' : myParticipant?.is_captain !== 1 ? 'Captain submits score' : 'Submit Results'}</button>}
                {inProgress && <button type="button" className="participant-danger" onClick={() => setDisputeModalOpen(true)}><AlertTriangle size={18}/> Open Dispute</button>}
                {viewerPermissions.canUploadEvidence && <div className="participant-evidence"><button type="button" className="participant-primary" disabled={uploadingEvidence} onClick={() => fileInputRef.current?.click()}><ImagePlus size={18}/> {uploadingEvidence ? 'Uploading…' : 'Upload Evidence'}</button></div>}
              </section>}
              {isStaff && (
                <section className="room-staff">
                  <h2>Staff Controls</h2>
                  {canModerateMatch && <>
                    {!['Cancelled', 'Complete'].includes(match.status) &&
                      <button type="button" disabled={staffPending} onClick={() => runStaffAction('cancel', { reason: 'Staff cancelled the match from the match room.' }, 'Match cancelled.')}>Cancel Match</button>}
                    {match.status !== 'Cancelled' && teamA.length === Number(match.format[0]) && teamB.length === Number(match.format[0]) &&
                      (['A','B'] as const).map(side => (
                        <button type="button" key={side} disabled={staffPending} onClick={() => forceWin(side)}>
                          Force {(side === 'A' ? teamA[0] : teamB[0]).username_snapshot} Team Win
                        </button>
                      ))}
                    {user?.role === 'owner' && (['Cancelled', 'Complete'].includes(match.status) || (match.status === 'Disputed' && match.started_at)) &&
                      <button type="button" disabled={staffPending} onClick={() => runStaffAction('staff-reset', {
                        reason: match.status === 'Complete' ? 'Admin opened a free rematch.' : match.status === 'Cancelled' ? 'Staff reset the cancelled match.' : 'Staff reopened score submissions.',
                      }, match.status === 'Complete' ? 'Free rematch opened.' : match.status === 'Cancelled' ? 'Match reset.' : 'Score submissions reopened.')}>Reset Match</button>}
                  </>}
                  {viewerPermissions.canUploadEvidence && <button type="button" disabled={uploadingEvidence} onClick={() => fileInputRef.current?.click()}>{uploadingEvidence ? 'Uploading…' : 'Upload Evidence'}</button>}
                </section>
              )}
              {/* Rules & Map Code Card */}
              <div className="room-rules mt-2 rounded-lg bg-[#161c2b] border border-[#242c40] overflow-hidden">
                <div className="flex items-center gap-5 px-4 border-b border-[#242c40]">
                  {[
                    { id: 'mode', label: `${match.mode} Rules` },
                    { id: 'general', label: 'General Rules' },
                    ...(revisions.length > 0 ? [{ id: 'revisions', label: `History (${revisions.length})` }] : []),
                  ].map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setRulesTab(t.id as typeof rulesTab)}
                      className={`py-2.5 text-xs font-semibold border-b-2 transition-colors cursor-pointer ${
                        rulesTab === t.id
                          ? 'border-[#f59e0b] text-white'
                          : 'border-transparent text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>

                <div className="p-4 text-xs space-y-3">
                  {rulesTab === 'mode' && (
                    <>
                      <div className="flex items-center gap-2 font-bold">
                        <span className="text-white uppercase tracking-wide">MAP CODE:</span>
                        <button
                          type="button"
                          onClick={() => copyText(match.map_code, 'Map code')}
                          className="text-[#38bdf8] hover:underline font-mono inline-flex items-center gap-1 cursor-pointer tabular-nums"
                        >
                          {match.map_code}
                          <Copy className="w-3 h-3" />
                        </button>
                      </div>
                      {map?.code === match.map_code && <p className="text-slate-300">{map.name}</p>}
                      <ul className="space-y-1.5 text-slate-300 list-disc pl-4 leading-relaxed">
                        {(mapRules.length > 0
                          ? mapRules
                          : [
                              'Once loot has been distributed, the match must continue even if a player leaves. Do NOT leave the game.',
                              'If you respawn during an active round, you automatically forfeit that round.',
                              'Opening chests, ammo boxes, or collecting unapproved floor loot is prohibited.',
                              'Players are responsible for providing proof in the event of a dispute.',
                            ]
                        ).map((rule, i) => (
                          <li key={i}>{rule}</li>
                        ))}
                      </ul>
                    </>
                  )}

                  {rulesTab === 'general' && (
                    <ul className="space-y-1.5 text-slate-300 list-disc pl-4 leading-relaxed">
                      <li>Accounts must be 18+ verified where paid SOL competition is enabled.</li>
                      <li>Match snapshots freeze player usernames and Epic IGNs at the moment of lobby lock.</li>
                      <li>Conflicting score submissions freeze reserved escrow until SFT staff reviews private evidence.</li>
                      <li>Platform fee (5%) is withheld from total pot strictly on confirmed payouts.</li>
                    </ul>
                  )}

                  {rulesTab === 'revisions' && (
                    <div className="space-y-2">
                      {revisions.map((r) => (
                        <div key={r.id} className="p-2.5 rounded bg-[#111521] border border-[#242c42]">
                          <div className="flex items-center justify-between font-bold text-white">
                            <span>
                              v{r.version_num} → Team {r.new_winner_side} ({r.new_score_a}-{r.new_score_b})
                            </span>
                            <span className="text-[10px] text-slate-400 tabular-nums">
                              {formatUtcTimestamp(r.created_at)}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400 mt-0.5">
                            Actor: {r.actor_username || 'Auto-Match'} · {r.reason}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Desktop ~300px Right Match Chat Column */}
      <aside className="room-chat-aside hidden lg:block w-[300px] shrink-0 h-[calc(100vh-3.5rem)] sticky top-14">
        {ChatColumn}
      </aside>

      {/* Mobile Chat Drawer */}
      {mobileChatOpen && (
        <div className="fixed inset-0 z-[75] lg:hidden flex justify-end">
          <div className="fixed inset-0 bg-black/70" onClick={() => setMobileChatOpen(false)} />
          <div className="relative w-80 max-w-[90vw] h-full z-10 flex flex-col bg-[#111520]">
            <div className="flex-1 min-h-0">{ChatColumn}</div>
          </div>
        </div>
      )}

      {reportOpen && canReport && (
        <div className="responsive-modal-overlay fixed inset-0 z-[80] bg-black/75 flex items-center justify-center p-4" onClick={event=>{if(event.target===event.currentTarget && !resultBusy) setReportOpen(false);}}>
          <section role="dialog" aria-modal="true" aria-label={resultStep === 'defeat' ? 'Confirm Defeat' : 'Submit Results'} className="room-result-dialog">
            <button className="room-result-close" type="button" aria-label="Close" disabled={resultBusy} onClick={()=>setReportOpen(false)}><X size={21}/></button>
            <h2 className={resultStep==='defeat' ? 'text-red-400' : ''}>{resultStep === 'defeat' ? 'Confirm Defeat' : 'Submit Results'}</h2>
            <p>{resultStep === 'defeat' ? 'Are you sure you want to accept defeat? This gives your opponent the win.' : 'Select the outcome for your team. False claims may be reviewed by staff.'}</p>
            {resultStep === 'defeat' ? <>
              <div className="room-defeat-notice"><AlertTriangle size={27}/><p>By confirming, you acknowledge that your team lost this match and the opponent will receive the result.</p></div>
              <div className="room-result-choices"><button type="button" disabled={resultBusy} onClick={()=>setResultStep('outcome')}>Cancel</button><button className="room-cancel-vote" type="button" disabled={resultBusy} onClick={()=>void submitOutcome('defeat')}><Flag size={18}/> Confirm Defeat</button></div>
            </> : <>
              <p>Your Team: <strong className="text-white">{(myParticipant?.team_side === 'A' ? teamA : teamB)[0]?.username_snapshot}</strong></p>
              <div className="room-result-choices">
                <button className="room-defeat-choice" type="button" disabled={resultBusy} onClick={()=>setResultStep('defeat')}><X size={20}/> Defeat</button>
                <button className="room-victory-choice" type="button" disabled={resultBusy} aria-expanded={resultStep === 'victory' || resultStep === 'score'} onClick={()=>setResultStep(resultStep==='victory' ? 'outcome' : 'victory')}><Trophy size={20}/> Victory <ChevronDown size={17}/></button>
              </div>
              {(resultStep === 'victory' || resultStep === 'score') && <div className="room-win-conditions">
                <h3><Trophy size={19}/> Select win condition</h3>
                <p>Your selection will be posted in match chat.</p>
                <button type="button" disabled={timerSeconds > 0 || resultBusy} onClick={()=>void submitOutcome('timer')}><Lock size={20}/><span><strong>Won by Timer</strong><small>Unlocks 10 minutes after match start</small></span>{timerSeconds > 0 && <code>{timerLabel}</code>}</button>
                <button type="button" disabled={resultBusy} onClick={()=>setResultStep('score')}><BarChart3 size={20}/><span><strong>Won by Score</strong><small>Winning score reached</small></span></button>
                {resultStep === 'score' && <form className="arena-form-stack" onSubmit={e=>{e.preventDefault();void submitOutcome('score');}}>
                  <div className="arena-form-pair"><label>Team A score<input type="number" min="0" required value={repScoreA} onChange={e=>setRepScoreA(e.target.value)}/></label><label>Team B score<input type="number" min="0" required value={repScoreB} onChange={e=>setRepScoreB(e.target.value)}/></label></div>
                  <button className="arena-form-primary" disabled={resultBusy}>Confirm Score</button>
                </form>}
              </div>}
            </>}
          </section>
        </div>
      )}

      {/* Open Dispute Modal */}
      {disputeModalOpen && (
        <div className="responsive-modal-overlay fixed inset-0 z-[80] bg-black/75 flex items-center justify-center p-4">
          <form
            onSubmit={handleOpenDispute}
            className="w-full max-w-sm bg-[#181d2c] border border-[#2a3248] rounded-xl p-5 space-y-4"
          >
            <h3 className="text-base font-display font-bold text-white">Open Match Dispute</h3>
            <p className="text-xs text-slate-400">
              Escrow remains safely locked while SFT moderators inspect chat and private evidence.
            </p>
            <textarea
              required
              rows={3}
              value={disputeReason}
              onChange={(e) => setDisputeReason(e.target.value)}
              placeholder="Explain round violation, wrong map settings, or disconnect..."
              className="w-full px-3 py-2 rounded-lg bg-[#111521] border border-[#283148] text-xs text-white"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setDisputeModalOpen(false)}
                className="px-3.5 py-2 rounded-lg bg-[#232a3e] text-xs text-slate-200 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-red-600 text-white text-xs font-bold cursor-pointer"
              >
                Submit Dispute
              </button>
            </div>
          </form>
        </div>
      )}

      {joinSide && <JoinMatchDialog title={match.title} format={match.format} entryLamports={match.entry_lamports}
        onClose={()=>setJoinSide(null)} onJoin={teamId => joinMatch(joinSide, teamId || null)}/>}
    </div>
  );
}
