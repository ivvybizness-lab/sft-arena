import React, { useEffect, useState, useCallback } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import {
  BarChart3,
  ShieldAlert,
  Coins,
  Users,
  Search,
  CheckCircle2,
  RefreshCw,
  FileText,
  AlertTriangle,
  Activity,
  ExternalLink,
} from 'lucide-react';
import { apiFetch } from '../lib/api';
import { formatSol, formatSolExactDeposit, formatUtcTimestamp, formatDurationShort } from '../lib/format';
import { useAuth } from '../context/AuthContext';

interface AnalyticsPayload {
  currency: string;
  networkMode: string;
  financial: {
    totalMatchVolumeLamports: number;
    grossFeesLamports: number;
    netRevenueLamports: number;
    averageEntryLamports: number;
    arpuLamports: number;
    depositToWagerConversionPct: number;
    depositsLamports: number;
    withdrawalsLamports: number;
    outstandingLiabilitiesLamports: number;
    bonusAndReferralCostLamports: number;
    feeReversalsLamports: number;
  };
  activity: {
    totalUsers: number;
    newRegistrations: number;
    firstDepositCount: number;
    firstMatchCount: number;
    dau: number;
    wau: number;
    mau: number;
    avgSessionDurationSec: number;
    retention: {
      d1: { eligible: number; retained: number; ratePct: number };
      d7: { eligible: number; retained: number; ratePct: number };
      d30: { eligible: number; retained: number; ratePct: number };
    };
    funnel: Array<{ stage: string; count: number }>;
  };
  marketplaceHealth: {
    totalMatches: number;
    completedMatches: number;
    cancelledMatches: number;
    activeLobbies: number;
    completionRatePct: number;
    cancellationRatePct: number;
    avgTimeToMatchSec: number;
    unmatchedWaits: number;
    disputeRatePct: number;
    openDisputes: number;
    avgDisputeResolutionSec: number;
    unassistedCompletionPct: number;
  };
  breakdowns: {
    byRegion: Array<{ region: string; matches: number; volume_lamports: number; fees_lamports: number }>;
    byMode: Array<{ mode: string; matches: number; volume_lamports: number; fees_lamports: number }>;
    byStakeTier: Array<{ stake_tier: string; matches: number }>;
    byAcquisition: Array<{ acquisition_source: string; users: number }>;
    byCountry: Array<{ country: string; users: number }>;
    dailyRevenueSeries: Array<{ day: string; matches: number; volume_lamports: number; fees_lamports: number }>;
  };
}

export default function StaffConsolePage({ embedded = false }: { embedded?: boolean }) {
  const { user, notify, refreshUser } = useAuth();
  const navigate = useNavigate();
  const [params] = useSearchParams();

  const isOwner = user?.role === 'owner';
  const isFinance = user?.role === 'finance' || isOwner;
  const isStaff = user && ['moderator', 'finance', 'owner'].includes(user.role);

  const [activeTab, setActiveTab] = useState<'analytics' | 'disputes' | 'finance' | 'accounts' | 'audit'>(() =>
    params.get('tab') === 'accounts' ? 'accounts' : user?.role === 'owner' ? 'analytics' : user?.role === 'finance' ? 'finance' : 'disputes'
  );

  // Business Analytics filters & data
  const [days, setDays] = useState(30);
  const [anRegion, setAnRegion] = useState('ALL');
  const [anMode, setAnMode] = useState('ALL');
  const [includeDemo, setIncludeDemo] = useState(true);
  const [analytics, setAnalytics] = useState<AnalyticsPayload | null>(null);

  // Match lookup by ID
  const [matchJumpId, setMatchJumpId] = useState('');

  // Overview / Disputes / Risk / Security Events
  const [staffOverview, setStaffOverview] = useState<{
    disputes: Array<{ id: string; match_id: string; match_title: string; reason: string; status: string; opened_by_username: string; created_at: string }>;
    riskFlags: Array<{ id: string; user_id: string; username: string; flag_type: string; severity: string; status: string; risk_score: number; details_json: string }>;
    loginEvents: Array<{ id: string; username: string | null; username_or_email: string; event_type: string; country: string; device_id: string; browser: string; os: string; is_vpn_proxy: number; created_at: string }>;
  } | null>(null);

  // Finance Reconciliation
  const [recon, setRecon] = useState<{
    config: { network_mode: string; mainnet_enabled: number; paid_matches_enabled: number; fee_bps: number; treasury_address: string };
    liabilities: { total_available_lamports: number; total_reserved_lamports: number; total_frozen_lamports: number; totalLiabilityLamports: number };
    depositExceptions: Array<{ id: string; username: string; expected_lamports: number; received_lamports: number | null; status: string; review_note: string | null }>;
    unmatchedTransfers: Array<{ id: string; tx_signature: string; lamports: number; status: string; note: string }>;
    withdrawalQueue: Array<{ id: string; username: string; amount_lamports: number; destination_address: string; status: string; last_error: string | null }>;
    recentLedger: Array<{ id: string; username: string; entry_type: string; delta_lamports: number; description: string; created_at: string }>;
  } | null>(null);

  // Users directory & Audit log
  const [userSearch, setUserSearch] = useState('');
  const [staffUsers, setStaffUsers] = useState<Array<{ id: string; username: string; email: string; role: string; status: string; risk_score: number; competitive_region: string; available_lamports: number }>>([]);
  const [auditLogs, setAuditLogs] = useState<Array<{ id: string; actor_username: string | null; actor_role: string; action: string; entity_id: string; summary: string; created_at: string }>>([]);

  useEffect(() => {
    const view = params.get('tab');
    if (view === 'accounts' || view === 'disputes' || view === 'finance' || view === 'audit' || view === 'analytics') setActiveTab(view);
    else if (user?.role === 'owner') setActiveTab('analytics');
    else if (user?.role === 'finance') setActiveTab('finance');
    else if (user?.role === 'moderator') setActiveTab('disputes');
  }, [user?.role, params]);

  const loadAnalytics = useCallback(async () => {
    if (!isOwner) return;
    try {
      const qs = new URLSearchParams({
        days: String(days),
        region: anRegion,
        mode: anMode,
        includeDemo: String(includeDemo),
      });
      const d = await apiFetch<AnalyticsPayload>(`/api/owner/analytics?${qs.toString()}`);
      setAnalytics(d);
    } catch {
      // ignore
    }
  }, [isOwner, days, anRegion, anMode, includeDemo]);

  const loadStaffOps = useCallback(async () => {
    if (!isStaff) return;
    apiFetch<typeof staffOverview>('/api/staff/overview').then(setStaffOverview).catch(() => {});
    apiFetch<{ users: typeof staffUsers }>(`/api/staff/users?q=${encodeURIComponent(userSearch)}`)
      .then((d) => setStaffUsers(d.users))
      .catch(() => {});
    apiFetch<{ logs: typeof auditLogs }>('/api/staff/audit-logs')
      .then((d) => setAuditLogs(d.logs))
      .catch(() => {});
    if (isFinance) {
      apiFetch<typeof recon>('/api/finance/reconciliation').then(setRecon).catch(() => {});
    }
  }, [isStaff, isFinance, userSearch]);

  useEffect(() => {
    loadAnalytics();
    loadStaffOps();
  }, [loadAnalytics, loadStaffOps]);

  if (!isStaff) {
    return (
      <div className="p-8 max-w-xl mx-auto text-center">
        <div className="p-8 rounded-xl bg-[#161b29] border border-red-500/30">
          <ShieldAlert className="w-10 h-10 text-red-400 mx-auto mb-3" />
          <h1 className="text-xl font-display font-bold text-white">Staff Authorization Required</h1>
          <p className="text-sm text-slate-400 mt-1">
            This console is restricted to authenticated SFT Moderators, Finance Staff, and the Owner.
          </p>
        </div>
      </div>
    );
  }

  async function handleRiskDecision(flagId: string, status: 'Cleared' | 'Confirmed') {
    try {
      await apiFetch(`/api/staff/risk-flags/${flagId}/decision`, {
        method: 'POST',
        body: JSON.stringify({ status, decisionNote: `Reviewed via Staff Console by ${user?.username}` }),
      });
      await loadStaffOps();
      notify(`Risk flag marked ${status}.`, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Decision failed', 'error');
    }
  }

  async function handleUserStatusChange(userId: string, nextStatus: string) {
    try {
      await apiFetch(`/api/staff/users/${userId}`, {
        method: 'PATCH',
        body: JSON.stringify({ status: nextStatus, reason: `Staff Console action by ${user?.username}` }),
      });
      await loadStaffOps();
      notify(`Account updated to ${nextStatus}.`, 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Status update failed', 'error');
    }
  }

  async function handleApproveDeposit(invoiceId: string) {
    try {
      await apiFetch(`/api/finance/deposits/${invoiceId}/approve`, {
        method: 'POST',
        body: JSON.stringify({ note: 'Approved in Staff Finance Queue' }),
      });
      await loadStaffOps();
      await refreshUser();
      notify('Deposit exception credited to user ledger.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Approval failed', 'error');
    }
  }

  async function handleRetryWithdrawal(wdId: string) {
    try {
      const res = await apiFetch<{ result: { status: string } }>(`/api/finance/withdrawals/${wdId}/retry`, { method: 'POST' });
      await loadStaffOps();
      await refreshUser();
      notify(`Withdrawal reconciled: ${res.result.status}`, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Retry failed', 'error');
    }
  }

  async function handleToggleNetwork(networkMode: 'demo' | 'devnet') {
    try {
      await apiFetch('/api/finance/config', {
        method: 'PATCH',
        body: JSON.stringify({ networkMode }),
      });
      await loadStaffOps();
      await loadAnalytics();
      notify(`Switched active SOL network mode to ${networkMode.toUpperCase()}.`, 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Config update failed', 'error');
    }
  }

  return (
    <div className={embedded ? "space-y-6" : "px-4 sm:px-6 lg:px-8 py-6 max-w-[1400px] mx-auto space-y-6"}>
      {!embedded && <>
      {/* Staff Console Header + Direct Match ID Jump */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-display font-extrabold text-white">SFT Staff Console</h1>
            <span className="px-2.5 py-0.5 rounded bg-[#f5c542]/20 border border-[#f5c542]/40 text-[#f5c542] text-[10px] font-extrabold uppercase">
              {user.role}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Role-enforced operations, financial ledger reconciliation, fraud review, and owner analytics.
          </p>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (matchJumpId.trim()) navigate(`/matches/${matchJumpId.trim()}`);
          }}
          className="flex items-center gap-2"
        >
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={matchJumpId}
              onChange={(e) => setMatchJumpId(e.target.value)}
              placeholder="Jump to Match ID (e.g. m_demo_complete_1)"
              className="h-9 w-60 pl-8 pr-3 rounded-lg bg-[#171d2c] border border-[#262e45] text-xs font-mono text-white"
            />
          </div>
          <button
            type="submit"
            className="h-9 px-3.5 rounded-lg bg-[#6d4aff] hover:bg-[#7b5cff] text-white text-xs font-bold cursor-pointer"
          >
            Open Match
          </button>
        </form>
      </div>

      {/* Staff Console Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-[#232a3e] pb-3">
        {isOwner && (
          <button
            type="button"
            onClick={() => setActiveTab('analytics')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'analytics' ? 'bg-[#6d4aff] text-white' : 'bg-[#171d2c] text-slate-300 hover:text-white'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" /> Business Analytics (Owner)
          </button>
        )}
        <button
          type="button"
          onClick={() => setActiveTab('disputes')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'disputes' ? 'bg-[#6d4aff] text-white' : 'bg-[#171d2c] text-slate-300 hover:text-white'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5" /> Disputes & Match Ops
        </button>
        {isFinance && (
          <button
            type="button"
            onClick={() => setActiveTab('finance')}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'finance' ? 'bg-[#6d4aff] text-white' : 'bg-[#171d2c] text-slate-300 hover:text-white'
            }`}
          >
            <Coins className="w-3.5 h-3.5" /> Finance & Solana Reconciliation
          </button>
        )}
        <button
          type="button"
          onClick={() => setActiveTab('accounts')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'accounts' ? 'bg-[#6d4aff] text-white' : 'bg-[#171d2c] text-slate-300 hover:text-white'
          }`}
        >
          <Users className="w-3.5 h-3.5" /> Accounts & Fraud Risk
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('audit')}
          className={`px-3.5 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'audit' ? 'bg-[#6d4aff] text-white' : 'bg-[#171d2c] text-slate-300 hover:text-white'
          }`}
        >
          <FileText className="w-3.5 h-3.5" /> Audit Log
        </button>
      </div>

      </>}
      {/* TAB 1: OWNER BUSINESS ANALYTICS */}
      {activeTab === 'analytics' && isOwner && analytics && (
        <div className="space-y-6">
          {/* Analytics Filters */}
          <div className="p-4 rounded-xl bg-[#161b29] border border-[#252d44] flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2.5 text-xs">
              <select value={days} onChange={(e) => setDays(Number(e.target.value))} className="h-8 px-2.5 rounded-lg bg-[#111521] border border-[#283148] text-white">
                <option value={7}>Last 7 Days</option>
                <option value={30}>Last 30 Days</option>
                <option value={90}>Last 90 Days</option>
              </select>
              <select value={anRegion} onChange={(e) => setAnRegion(e.target.value)} className="h-8 px-2.5 rounded-lg bg-[#111521] border border-[#283148] text-white">
                <option value="ALL">All Regions</option>
                {['NAE', 'NAC', 'NAW', 'EU'].map((r) => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
              <select value={anMode} onChange={(e) => setAnMode(e.target.value)} className="h-8 px-2.5 rounded-lg bg-[#111521] border border-[#283148] text-white">
                <option value="ALL">All Modes</option>
                {['Zone Wars', 'Box Fights', 'Realistics', 'Build Fights', 'Piece Control', 'Zero Build'].map((m) => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
              <label className="flex items-center gap-1.5 text-slate-300 cursor-pointer ml-1">
                <input
                  type="checkbox"
                  checked={includeDemo}
                  onChange={(e) => setIncludeDemo(e.target.checked)}
                  className="rounded accent-[#6d4aff]"
                />
                Include Demo Records
              </label>
            </div>
            <div className="text-xs font-mono text-slate-400">
              Currency: <strong className="text-[#f5c542]">{analytics.currency}</strong> ({analytics.networkMode.toUpperCase()})
            </div>
          </div>

          {/* Financial KPIs */}
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Financial Metrics (Computed from Persisted Records)</h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 tabular-nums">
              {[
                { label: 'Match Volume (SOL)', val: `${formatSol(analytics.financial.totalMatchVolumeLamports, 4)} SOL`, accent: 'text-white' },
                { label: 'Gross Fee Revenue', val: `${formatSol(analytics.financial.grossFeesLamports, 4)} SOL`, accent: 'text-[#f5c542]' },
                { label: 'Net Revenue (After Bonuses)', val: `${formatSol(analytics.financial.netRevenueLamports, 4)} SOL`, accent: 'text-emerald-400' },
                { label: 'Outstanding User Liabilities', val: `${formatSol(analytics.financial.outstandingLiabilitiesLamports, 4)} SOL`, accent: 'text-[#9d85ff]' },
                { label: 'Avg Paid Entry', val: `${formatSol(analytics.financial.averageEntryLamports, 4)} SOL`, accent: 'text-white' },
                { label: 'ARPU (Fee / User)', val: `${formatSol(analytics.financial.arpuLamports, 4)} SOL`, accent: 'text-white' },
                { label: 'Deposits / Withdrawals', val: `${formatSol(analytics.financial.depositsLamports, 2)} / ${formatSol(analytics.financial.withdrawalsLamports, 2)}`, accent: 'text-slate-200' },
                { label: 'Bonus Cost / Reversals', val: `${formatSol(analytics.financial.bonusAndReferralCostLamports, 3)} / ${formatSol(analytics.financial.feeReversalsLamports, 3)}`, accent: 'text-amber-300' },
              ].map((kpi) => (
                <div key={kpi.label} className="p-4 rounded-xl bg-[#161b29] border border-[#252d44]">
                  <div className="text-[11px] text-slate-400">{kpi.label}</div>
                  <div className={`text-lg font-display font-extrabold mt-1 ${kpi.accent}`}>{kpi.val}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Activity + Retention + Marketplace Health */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            <div className="rounded-xl bg-[#161b29] border border-[#252d44] p-5 space-y-3">
              <h3 className="text-sm font-display font-bold text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-[#9d85ff]" /> Player Activity & Funnel
              </h3>
              <div className="grid grid-cols-3 gap-2 text-center tabular-nums">
                <div className="p-2.5 rounded-lg bg-[#111521]">
                  <div className="text-base font-bold text-white">{analytics.activity.dau}</div>
                  <div className="text-[10px] text-slate-400">DAU</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#111521]">
                  <div className="text-base font-bold text-white">{analytics.activity.wau}</div>
                  <div className="text-[10px] text-slate-400">WAU</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#111521]">
                  <div className="text-base font-bold text-white">{analytics.activity.mau}</div>
                  <div className="text-[10px] text-slate-400">MAU</div>
                </div>
              </div>
              <div className="space-y-2 pt-2 text-xs tabular-nums">
                {analytics.activity.funnel.map((f) => {
                  const pct = analytics.activity.totalUsers > 0 ? Math.round((f.count / analytics.activity.totalUsers) * 100) : 0;
                  return (
                    <div key={f.stage}>
                      <div className="flex justify-between text-slate-300 mb-1">
                        <span>{f.stage}</span>
                        <span>{f.count} ({pct}%)</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-[#111521] overflow-hidden">
                        <div className="h-full bg-[#6d4aff]" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="pt-2 text-[11px] text-slate-400 tabular-nums">
                Avg Session: <strong className="text-white">{formatDurationShort(analytics.activity.avgSessionDurationSec)}</strong> · Deposit→Wager:{' '}
                <strong className="text-white">{analytics.financial.depositToWagerConversionPct}%</strong>
              </div>
            </div>

            <div className="rounded-xl bg-[#161b29] border border-[#252d44] p-5 space-y-3">
              <h3 className="text-sm font-display font-bold text-white">Marketplace Health</h3>
              <div className="grid grid-cols-2 gap-2.5 text-xs tabular-nums">
                <div className="p-3 rounded-lg bg-[#111521]">
                  <div className="text-slate-400 text-[11px]">Completion Rate</div>
                  <div className="text-base font-bold text-emerald-400 mt-0.5">{analytics.marketplaceHealth.completionRatePct}%</div>
                </div>
                <div className="p-3 rounded-lg bg-[#111521]">
                  <div className="text-slate-400 text-[11px]">Cancellation Rate</div>
                  <div className="text-base font-bold text-amber-300 mt-0.5">{analytics.marketplaceHealth.cancellationRatePct}%</div>
                </div>
                <div className="p-3 rounded-lg bg-[#111521]">
                  <div className="text-slate-400 text-[11px]">Dispute Rate</div>
                  <div className="text-base font-bold text-red-300 mt-0.5">{analytics.marketplaceHealth.disputeRatePct}%</div>
                </div>
                <div className="p-3 rounded-lg bg-[#111521]">
                  <div className="text-slate-400 text-[11px]">Unassisted Wins</div>
                  <div className="text-base font-bold text-white mt-0.5">{analytics.marketplaceHealth.unassistedCompletionPct}%</div>
                </div>
              </div>
              <div className="text-xs text-slate-300 space-y-1 pt-1 tabular-nums">
                <div className="flex justify-between">
                  <span>Avg Time to Match:</span>
                  <strong>{formatDurationShort(analytics.marketplaceHealth.avgTimeToMatchSec)}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Avg Dispute Resolution:</span>
                  <strong>{formatDurationShort(analytics.marketplaceHealth.avgDisputeResolutionSec)}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Unmatched Waits / Open Disputes:</span>
                  <strong>{analytics.marketplaceHealth.unmatchedWaits} / {analytics.marketplaceHealth.openDisputes}</strong>
                </div>
              </div>
            </div>

            <div className="rounded-xl bg-[#161b29] border border-[#252d44] p-5 space-y-3">
              <h3 className="text-sm font-display font-bold text-white">Retention & Stake Tiers</h3>
              <div className="grid grid-cols-3 gap-2 text-center tabular-nums">
                {[
                  { label: 'D1 Ret.', obj: analytics.activity.retention.d1 },
                  { label: 'D7 Ret.', obj: analytics.activity.retention.d7 },
                  { label: 'D30 Ret.', obj: analytics.activity.retention.d30 },
                ].map((r) => (
                  <div key={r.label} className="p-2.5 rounded-lg bg-[#111521]">
                    <div className="text-sm font-bold text-[#f5c542]">{r.obj.ratePct}%</div>
                    <div className="text-[10px] text-slate-400">{r.label} ({r.obj.retained}/{r.obj.eligible})</div>
                  </div>
                ))}
              </div>
              <div className="space-y-1.5 text-xs pt-2 tabular-nums">
                <div className="text-[11px] font-semibold text-slate-400 uppercase">Common Stake Tiers</div>
                {analytics.breakdowns.byStakeTier.map((st) => (
                  <div key={st.stake_tier} className="flex justify-between text-slate-200">
                    <span>{st.stake_tier}</span>
                    <span className="font-mono">{st.matches} matches</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Breakdowns by Region, Mode, Acquisition Source & Country */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            <div className="rounded-xl bg-[#161b29] border border-[#252d44] p-4">
              <h4 className="font-display font-bold text-white mb-2.5">By Region (Matches / Fees)</h4>
              <div className="space-y-2 tabular-nums">
                {analytics.breakdowns.byRegion.map((r) => (
                  <div key={r.region} className="flex justify-between">
                    <span className="font-semibold text-slate-200">{r.region}</span>
                    <span className="text-slate-400">
                      {r.matches}m · <strong className="text-[#f5c542]">{formatSol(r.fees_lamports, 3)} SOL</strong>
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-xl bg-[#161b29] border border-[#252d44] p-4">
              <h4 className="font-display font-bold text-white mb-2.5">By Game Mode</h4>
              <div className="space-y-2 tabular-nums">
                {analytics.breakdowns.byMode.map((m) => (
                  <div key={m.mode} className="flex justify-between">
                    <span className="font-semibold text-slate-200">{m.mode}</span>
                    <span className="text-slate-400">
                      {m.matches}m · <strong className="text-emerald-400">{formatSol(m.volume_lamports, 2)} SOL</strong>
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-xl bg-[#161b29] border border-[#252d44] p-4">
              <h4 className="font-display font-bold text-white mb-2.5">By Acquisition Source</h4>
              <div className="space-y-2 tabular-nums">
                {analytics.breakdowns.byAcquisition.map((a) => (
                  <div key={a.acquisition_source} className="flex justify-between">
                    <span className="font-semibold text-slate-200 capitalize">{a.acquisition_source}</span>
                    <span className="font-mono text-slate-300">{a.users} users</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-xl bg-[#161b29] border border-[#252d44] p-4">
              <h4 className="font-display font-bold text-white mb-2.5">By Country</h4>
              <div className="space-y-2 tabular-nums">
                {analytics.breakdowns.byCountry.map((c) => (
                  <div key={c.country} className="flex justify-between">
                    <span className="font-semibold text-slate-200">{c.country}</span>
                    <span className="font-mono text-slate-300">{c.users} users</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: DISPUTES & MATCH OPS */}
      {activeTab === 'disputes' && staffOverview && (
        <div className="rounded-xl bg-[#161b29] border border-[#252d44] overflow-hidden">
          <div className="px-5 py-3.5 border-b border-[#232a3e] font-display font-bold text-sm text-white">
            Match Dispute Queue ({staffOverview.disputes.length})
          </div>
          <div className="divide-y divide-[#22293d]">
            {staffOverview.disputes.length === 0 ? (
              <div className="p-6 text-xs text-slate-500 text-center">No disputes currently logged.</div>
            ) : (
              staffOverview.disputes.map((d) => (
                <div key={d.id} className="p-4 flex flex-wrap items-center justify-between gap-4 text-xs">
                  <div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          d.status === 'Open' ? 'bg-red-500/20 text-red-300' : 'bg-emerald-500/20 text-emerald-300'
                        }`}
                      >
                        {d.status}
                      </span>
                      <span className="font-bold text-white">{d.match_title}</span>
                      <span className="font-mono text-slate-400">({d.match_id})</span>
                    </div>
                    <div className="text-slate-300 mt-1">{d.reason}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Opened by @{d.opened_by_username} · {formatUtcTimestamp(d.created_at)}
                    </div>
                  </div>
                  <Link
                    to={`/matches/${d.match_id}`}
                    className="px-3.5 py-2 rounded-lg bg-[#6d4aff] hover:bg-[#7b5cff] text-white font-semibold inline-flex items-center gap-1.5"
                  >
                    Inspect Room & Evidence <ExternalLink className="w-3.5 h-3.5" />
                  </Link>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB 3: FINANCE & SOLANA RECONCILIATION */}
      {activeTab === 'finance' && isFinance && recon && (
        <div className="space-y-6">
          <div className="p-5 rounded-xl bg-[#161b29] border border-[#252d44] flex flex-wrap items-center justify-between gap-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-5 tabular-nums text-xs">
              <div>
                <div className="text-slate-400">Available Liabilities</div>
                <div className="text-base font-bold text-[#f5c542]">{formatSol(recon.liabilities.total_available_lamports, 4)} SOL</div>
              </div>
              <div>
                <div className="text-slate-400">Reserved Escrow</div>
                <div className="text-base font-bold text-white">{formatSol(recon.liabilities.total_reserved_lamports, 4)} SOL</div>
              </div>
              <div>
                <div className="text-slate-400">Frozen SOL</div>
                <div className="text-base font-bold text-red-300">{formatSol(recon.liabilities.total_frozen_lamports, 4)} SOL</div>
              </div>
              <div>
                <div className="text-slate-400">Total Treasury Obligation</div>
                <div className="text-base font-bold text-emerald-400">{formatSol(recon.liabilities.totalLiabilityLamports, 4)} SOL</div>
              </div>
            </div>

            {isOwner && (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-400">Network:</span>
                <button
                  type="button"
                  onClick={() => handleToggleNetwork('demo')}
                  className={`px-3 py-1.5 rounded-lg font-bold cursor-pointer ${
                    recon.config.network_mode === 'demo' ? 'bg-[#6d4aff] text-white' : 'bg-[#111521] text-slate-300'
                  }`}
                >
                  DEMO
                </button>
                <button
                  type="button"
                  onClick={() => handleToggleNetwork('devnet')}
                  className={`px-3 py-1.5 rounded-lg font-bold cursor-pointer ${
                    recon.config.network_mode === 'devnet' ? 'bg-[#22c55e] text-[#0b1410]' : 'bg-[#111521] text-slate-300'
                  }`}
                >
                  DEVNET
                </button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Deposit Exceptions */}
            <div className="rounded-xl bg-[#161b29] border border-[#252d44] p-5 space-y-3">
              <h3 className="text-sm font-display font-bold text-white">Deposit Review Queue</h3>
              {recon.depositExceptions.length === 0 ? (
                <div className="text-xs text-slate-500">No pending or flagged deposit invoices.</div>
              ) : (
                recon.depositExceptions.map((d) => (
                  <div key={d.id} className="p-3 rounded-lg bg-[#111521] border border-[#242c42] text-xs flex items-center justify-between gap-2">
                    <div>
                      <div className="font-bold text-white">
                        @{d.username} · {formatSolExactDeposit(d.received_lamports || d.expected_lamports)} SOL
                      </div>
                      <div className="text-[11px] text-amber-300">{d.status}: {d.review_note || 'Waiting transfer'}</div>
                    </div>
                    {d.status === 'Needs Review' && (
                      <button
                        type="button"
                        onClick={() => handleApproveDeposit(d.id)}
                        className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-700 text-white font-bold cursor-pointer"
                      >
                        Approve & Credit
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>

            {/* Withdrawal Queue */}
            <div className="rounded-xl bg-[#161b29] border border-[#252d44] p-5 space-y-3">
              <h3 className="text-sm font-display font-bold text-white">Withdrawal Execution & Reconciliation Queue</h3>
              {recon.withdrawalQueue.length === 0 ? (
                <div className="text-xs text-slate-500">No withdrawals queued.</div>
              ) : (
                recon.withdrawalQueue.map((w) => (
                  <div key={w.id} className="p-3 rounded-lg bg-[#111521] border border-[#242c42] text-xs flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <div className="font-bold text-white tabular-nums">
                        @{w.username} · {formatSol(w.amount_lamports, 4)} SOL ({w.status})
                      </div>
                      <div className="text-[11px] font-mono text-slate-400 truncate">{w.destination_address}</div>
                      {w.last_error && <div className="text-[11px] text-amber-300">{w.last_error}</div>}
                    </div>
                    {['Needs Review', 'Queued', 'Processing'].includes(w.status) && (
                      <button
                        type="button"
                        onClick={() => handleRetryWithdrawal(w.id)}
                        className="px-3 py-1.5 rounded bg-[#6d4aff] hover:bg-[#7b5cff] text-white font-bold shrink-0 inline-flex items-center gap-1 cursor-pointer"
                      >
                        <RefreshCw className="w-3 h-3" /> Reconcile / Retry
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: ACCOUNTS & FRAUD RISK QUEUE */}
      {activeTab === 'accounts' && (
        <div className="space-y-6">
          {/* Risk Flags Queue */}
          {staffOverview && (
            <div className="rounded-xl bg-[#161b29] border border-[#252d44] overflow-hidden">
              <div className="px-5 py-3.5 border-b border-[#232a3e] font-display font-bold text-sm text-white">
                Automated Fraud & Multi-Account Review Queue ({staffOverview.riskFlags.length})
              </div>
              <div className="divide-y divide-[#22293d]">
                {staffOverview.riskFlags.map((rf) => (
                  <div key={rf.id} className="p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold uppercase text-[10px]">
                          {rf.severity} · {rf.flag_type.replaceAll("_", " ")}
                        </span>
                        <span className="font-bold text-white">@{rf.username}</span>
                        <span className="text-slate-400">Risk Score: {rf.risk_score}/100 · Status: {rf.status}</span>
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-1">{rf.details_json}</div>
                    </div>
                    {rf.status === 'Open' && (
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleRiskDecision(rf.id, 'Cleared')}
                          className="px-3 py-1.5 rounded bg-emerald-600 text-white font-semibold cursor-pointer flex items-center gap-1"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" /> Clear
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRiskDecision(rf.id, 'Confirmed')}
                          className="px-3 py-1.5 rounded bg-red-600 text-white font-semibold cursor-pointer"
                        >
                          Confirm Risk
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Restricted Staff Accounts Directory */}
          <div className="rounded-xl bg-[#161b29] border border-[#252d44] overflow-hidden">
            <div className="px-5 py-3.5 border-b border-[#232a3e] flex flex-wrap items-center justify-between gap-3">
              <span className="font-display font-bold text-sm text-white">Account Controls & Private Risk Directory</span>
              <input
                type="text"
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                placeholder="Search username, email, ID..."
                className="h-8 px-3 rounded-lg bg-[#111521] border border-[#283148] text-xs text-white"
              />
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#111521] text-slate-400 text-[10px] uppercase">
                  <tr>
                    <th className="px-4 py-2.5">User</th>
                    <th className="px-4 py-2.5">Role</th>
                    <th className="px-4 py-2.5">Status</th>
                    <th className="px-4 py-2.5">Risk</th>
                    <th className="px-4 py-2.5 text-right">Available SOL</th>
                    <th className="px-4 py-2.5 text-right">Moderation</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#22293d]">
                  {staffUsers.map((u) => (
                    <tr key={u.id} className="hover:bg-[#1a2033]">
                      <td className="px-4 py-2.5">
                        <Link className="font-bold text-white hover:underline" to={`/staff/players/${u.id}`}>{u.username}</Link>
                        <div className="text-[11px] text-slate-400">{u.email}</div>
                      </td>
                      <td className="px-4 py-2.5 uppercase font-semibold text-[#b4a0ff]">{u.role}</td>
                      <td className="px-4 py-2.5 uppercase font-bold">{u.status}</td>
                      <td className="px-4 py-2.5 font-mono tabular-nums">{u.risk_score}/100</td>
                      <td className="px-4 py-2.5 text-right font-mono tabular-nums">{formatSol(u.available_lamports, 4)}</td>
                      <td className="px-4 py-2.5 text-right">
                        <select
                          value={u.status}
                          onChange={(e) => handleUserStatusChange(u.id, e.target.value)}
                          className="h-7 px-2 rounded bg-[#111521] border border-[#283148] text-[11px] text-white"
                        >
                          <option value="active">Active</option>
                          <option value="restricted">Restricted</option>
                          <option value="suspended">Suspended</option>
                          <option value="banned">Banned</option>
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 5: AUDIT LOG */}
      {activeTab === 'audit' && (
        <div className="rounded-xl bg-[#161b29] border border-[#252d44] overflow-hidden">
          <div className="px-5 py-3.5 border-b border-[#232a3e] font-display font-bold text-sm text-white">
            Immutable Platform Audit Log
          </div>
          <div className="divide-y divide-[#22293d] text-xs">
            {auditLogs.map((l) => (
              <div key={l.id} className="px-5 py-3 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <span className="font-mono text-[#9d85ff] font-bold mr-2">{l.action}</span>
                  <span className="text-white">{l.summary}</span>
                </div>
                <div className="text-[11px] text-slate-400 tabular-nums">
                  {l.actor_username || l.actor_role} · {formatUtcTimestamp(l.created_at)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
