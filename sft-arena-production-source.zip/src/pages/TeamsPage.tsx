import React, { useEffect, useState, useCallback, useRef } from 'react';
import { Users, UserPlus, Check, X, Crown, Search } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { useAuth } from '../context/AuthContext';
import PlayerPortrait from '../components/PlayerPortrait';
import TeamIcon from '../components/TeamIcon';

interface TeamRow {
  id: string;
  name: string;
  tag: string;
  region: string;
  my_role: string;
  max_players: number;
  icon: string;
  icon_colour: string;
  members: Array<{ id: string; username: string; display_name: string; epic_display_name: string; role: string }>;
}

interface InviteRow {
  id: string;
  team_name: string;
  team_tag: string;
  region: string;
  invited_by_username: string;
}

export default function TeamsPage({ embedded = false }: { embedded?: boolean }) {
  const { user, openAuthModal, notify } = useAuth();
  const [teams, setTeams] = useState<TeamRow[]>([]);
  const [invites, setInvites] = useState<InviteRow[]>([]);
  const [createOpen, setCreateOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [loadError, setLoadError] = useState('');
  const [loading, setLoading] = useState(true);
  const [teamName, setTeamName] = useState('');
  const dialog = useRef<HTMLDialogElement>(null);
  const [size, setSize] = useState(2);
  const [search, setSearch] = useState('');
  const [results, setResults] = useState<{id:string; username:string}[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [createError, setCreateError] = useState('');

  const [inviteUsernames, setInviteUsernames] = useState<Record<string, string>>({});

  const loadTeams = useCallback(async () => {
    if (!user) return;
    setLoadError('');
    try {
      const data = await apiFetch<{ teams: TeamRow[]; invites: InviteRow[] }>('/api/teams');
      setTeams(data.teams);
      setInvites(data.invites);
    } catch (error) {
      setLoadError((error as Error).message);
    } finally { setLoading(false); }
  }, [user]);

  useEffect(() => {
    loadTeams();
  }, [loadTeams]);

  useEffect(() => {
    const node = dialog.current;
    if (createOpen) node?.showModal();
    return () => node?.close();
  }, [createOpen]);

  useEffect(() => {
    setResults([]);
    if (!createOpen || search.trim().length < 2) return;
    let active = true;
    const timer = setTimeout(() => {
      apiFetch<{users:{id:string;username:string}[]}>(`/api/users/search?q=${encodeURIComponent(search.trim())}`)
        .then(data=>{if(active) setResults(data.users);})
        .catch(()=>{if(active) setCreateError('Could not search players. Try again.');});
    }, 220);
    return () => {active=false; clearTimeout(timer);};
  }, [search, createOpen]);

  if (!user) {
    return (
      <div className="p-8 max-w-2xl mx-auto text-center">
        <div className="p-8 rounded-xl bg-[#161b29] border border-[#252d44]">
          <Users className="w-10 h-10 text-[#9d85ff] mx-auto mb-3" />
          <h1 className="text-xl font-display font-bold text-white">Competitive Teams & Rosters</h1>
          <p className="text-sm text-slate-400 mt-1">Sign in to manage 2v2, 3v3, and 4v4 competitive rosters.</p>
          <button
            type="button"
            onClick={() => openAuthModal('login')}
            className="mt-4 px-5 py-2.5 rounded-lg bg-[#6d4aff] text-white text-xs font-bold cursor-pointer"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  async function handleCreateTeam(e: React.FormEvent) {
    e.preventDefault();
    if (creating) return;
    setCreating(true);
    setCreateError('');
    try {
      await apiFetch('/api/teams', {
        method: 'POST',
        body: JSON.stringify({ name: teamName, maxPlayers: size, inviteUsernames: selected }),
      });
      setCreateOpen(false);
      await loadTeams();
      notify('Team roster created!', 'success');
    } catch (err) {
      setCreateError((err as Error).message);
    } finally { setCreating(false); }
  }

  async function handleSendInvite(teamId: string) {
    const uname = (inviteUsernames[teamId] || '').trim();
    if (!uname) return;
    try {
      await apiFetch(`/api/teams/${teamId}/invite`, {
        method: 'POST',
        body: JSON.stringify({ username: uname }),
      });
      setInviteUsernames((prev) => ({ ...prev, [teamId]: '' }));
      notify(`Invite sent to @${uname}`, 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Invite failed', 'error');
    }
  }

  async function handleRespondInvite(inviteId: string, accept: boolean) {
    try {
      await apiFetch(`/api/teams/invites/${inviteId}/respond`, {
        method: 'POST',
        body: JSON.stringify({ accept }),
      });
      await loadTeams();
      notify(accept ? 'Joined team roster!' : 'Invite declined.', 'info');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Action failed', 'error');
    }
  }

  function openCreateTeam() {
    setTeamName(''); setSize(2);
    setSearch(''); setSelected([]); setCreateError(''); setCreateOpen(true);
  }

  function closeCreateTeam() {
    if (!creating) setCreateOpen(false);
  }

  return (
    <div className={embedded ? 'profile-teams' : 'profile-teams profile-teams-page'}>
      <div className="profile-section-heading">
        {embedded ? <h2><Users size={20}/> Teams</h2> : <h1><Users size={20}/> Teams</h1>}
        <button className="profile-gold-button" onClick={openCreateTeam}>New Team</button>
      </div>
      {/* Pending Invites */}
      {invites.length > 0 && (
        <div className="rounded-xl bg-[#1a2236] border border-[#6d4aff]/40 p-4 space-y-2.5">
          <h2 className="text-xs font-bold uppercase tracking-wider text-[#c2b2ff]">Pending Roster Invites</h2>
          {invites.map((inv) => (
            <div key={inv.id} className="flex flex-wrap items-center justify-between gap-2 p-3 rounded-lg bg-[#111521] border border-[#252d44]">
              <div className="text-xs">
                <strong className="text-white">[{inv.team_tag}] {inv.team_name}</strong> ({inv.region}) — Invited by @{inv.invited_by_username}
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleRespondInvite(inv.id, true)}
                  className="px-3 py-1.5 rounded bg-emerald-600 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" /> Accept
                </button>
                <button
                  type="button"
                  onClick={() => handleRespondInvite(inv.id, false)}
                  className="px-3 py-1.5 rounded bg-[#232b42] text-slate-300 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" /> Decline
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="space-y-3">
        {createOpen && <dialog ref={dialog} className="arena-form-dialog arena-team-dialog" aria-labelledby="create-team-title"
          onCancel={event=>{event.preventDefault();closeCreateTeam();}} onClick={event=>{if(event.target===event.currentTarget) closeCreateTeam();}}>
          <div className="arena-form-panel">
            <header><div><h2 id="create-team-title"><Users size={21}/> Create a New Team</h2><p>Form your team and invite players to join you in matches.</p></div><button type="button" aria-label="Close" onClick={closeCreateTeam}><X size={20}/></button></header>
            <form onSubmit={handleCreateTeam} className="arena-form-stack">
              <label>Team Name<input autoFocus required minLength={2} maxLength={25} value={teamName} onChange={event=>setTeamName(event.target.value)} placeholder="Enter team name"/><small>{teamName.length}/25 characters</small></label>
              <fieldset className="arena-team-sizes"><legend>Team Size</legend><div>{[2,3,4].map(value=><button key={value} type="button" disabled={selected.length >= value} aria-pressed={size===value} onClick={()=>setSize(value)}>{value} players</button>)}</div></fieldset>
              <div className="arena-team-members">
                <div className="arena-team-label"><strong>Team Members</strong><small>{1+selected.length}/{size}</small></div>
                <div className="arena-team-roster">
                  <div><PlayerPortrait name={user.username} portrait={user.profilePortrait}/><span><strong>{user.username}</strong><small>Team Owner</small></span></div>
                  {selected.map(username=><div key={username}><span><strong>{username}</strong><small>Invite on creation</small></span><button type="button" aria-label={'Remove '+username} onClick={()=>setSelected(selected.filter(value=>value!==username))}><X size={17}/></button></div>)}
                  {selected.length < size-1 && <label className="arena-team-search"><Search size={17}/><input aria-label="Search players to invite" value={search} onChange={event=>setSearch(event.target.value)} placeholder="Search players to invite"/></label>}
                  {selected.length < size-1 && results.filter(player=>player.id!==user.id && !selected.includes(player.username)).slice(0,5).map(player=><button key={player.id} type="button" className="arena-team-result" onClick={()=>{setSelected([...selected,player.username]);setSearch('');setResults([]);}}><UserPlus size={16}/> {player.username}</button>)}
                </div>
              </div>
              {createError && <p role="alert" className="arena-form-error">{createError}</p>}
              <div className="arena-form-pair arena-team-footer"><button type="button" onClick={closeCreateTeam} disabled={creating}>Cancel</button><button className="arena-form-primary" disabled={creating}>{creating ? 'Creating…' : 'Create Team'}</button></div>
            </form>
          </div>
        </dialog>}

        <div className="space-y-3">
          {loading ? <p role="status">Loading teams…</p> : loadError ? <p role="alert">{loadError}</p> : teams.length === 0 ? (
            <div className="p-8 rounded-xl bg-[#161b29] border border-[#252d44] text-center text-xs text-slate-400">
              You haven’t joined a team yet.
            </div>
          ) : (
            teams.map((t) => (
              <details key={t.id} className="profile-team-rollup">
                <summary><strong className="flex items-center gap-2"><TeamIcon icon={t.icon} colour={t.icon_colour}/>{t.name}</strong><small>{t.members.length}/{t.max_players} players</small></summary>
                <div className="profile-team-detail">
                  <p className="text-xs text-slate-400">{t.tag} · {t.region} · {t.my_role}</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {t.members.map((m) => (
                    <div key={m.id} className="px-3 py-2 rounded-lg bg-[#111521] border border-[#242c42] flex items-center justify-between text-xs">
                      <div>
                        <div className="font-semibold text-white flex items-center gap-1">
                          {m.role === 'captain' && <Crown className="w-3 h-3 text-[#f5c542]" />}
                          {m.username}
                        </div>
                        <div className="text-[11px] text-slate-400">Epic: {m.epic_display_name || m.username}</div>
                      </div>
                      <span className="text-[10px] uppercase text-slate-400">{m.role}</span>
                    </div>
                  ))}
                </div>

                {t.my_role === 'captain' && t.members.length < t.max_players && (
                  <div className="flex items-center gap-2 pt-2 border-t border-[#22293d]">
                    <input
                      type="text"
                      value={inviteUsernames[t.id] || ''}
                      onChange={(e) => setInviteUsernames((p) => ({ ...p, [t.id]: e.target.value }))}
                      placeholder="Invite player by username..."
                      className="flex-1 h-8 px-3 rounded-lg bg-[#111521] border border-[#283148] text-xs text-white"
                    />
                    <button
                      type="button"
                      onClick={() => handleSendInvite(t.id)}
                      className="h-8 px-3 rounded-lg bg-[#242c41] hover:bg-[#313b56] text-xs font-semibold text-white flex items-center gap-1 cursor-pointer"
                    >
                      <UserPlus className="w-3.5 h-3.5" /> Invite
                    </button>
                  </div>
                )}
                </div>
              </details>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
