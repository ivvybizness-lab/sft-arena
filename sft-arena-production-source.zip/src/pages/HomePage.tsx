import sftLogo from '../assets/brand/sft-logo.png';
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Swords,
  Trophy,
  Coins,
  Radio,
  ArrowRight,
  Crown,
  Tv,
} from 'lucide-react';
import { apiFetch } from '../lib/api';
import { formatSol, getModeArt } from '../lib/format';
import { useAuth } from '../context/AuthContext';
import MatchCard, { MatchCardData } from '../components/MatchCard';
import TournamentCard, { type TournamentSummary } from '../components/TournamentCard';

interface PlatformStats {
  players: number;
  matchesPlayed: number;
  openLobbies: number;
  ongoingMatches: number;
  totalPaidLamports: number;
  activeTournaments: number;
}

type MatchCardItem = MatchCardData;

interface LeaderboardEntry {
  rank: number;
  username: string;
  competitiveRegion: string;
  wins: number;
  elo: number;
  earnedLamports: number;
  activeTitle: string;
  isDemo: boolean;
}

interface StreamItem {
  id: string;
  channel_name: string;
  stream_title: string;
  game_mode: string;
  viewer_count: number;
  thumbnail_accent: string;
  username: string;
}

export default function HomePage() {
  const { user, regionFilter, openAuthModal } = useAuth();
  const navigate = useNavigate();

  const [stats, setStats] = useState<PlatformStats | null>(null);
  const [openMatches, setOpenMatches] = useState<MatchCardItem[]>([]);
  const [tournaments, setTournaments] = useState<TournamentSummary[]>([]);
  const [serverTimeUtc, setServerTimeUtc] = useState<string>('');
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [streams, setStreams] = useState<StreamItem[]>([]);
  const [nowMs, setNowMs] = useState(() => Date.now());

  useEffect(() => {
    const id = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    apiFetch<PlatformStats>('/api/platform/stats').then(setStats).catch(() => {});
    apiFetch<{ matches: MatchCardItem[] }>(`/api/matches?tab=open&region=${regionFilter}`)
      .then((d) => setOpenMatches(d.matches.slice(0, 4)))
      .catch(() => {});
    apiFetch<{ tournaments: TournamentSummary[]; serverTimeUtc: string }>(`/api/tournaments?region=${regionFilter}`)
      .then((d) => {
        setTournaments(d.tournaments.slice(0, 2));
        setServerTimeUtc(d.serverTimeUtc);
      })
      .catch(() => {});
    apiFetch<{ leaderboard: LeaderboardEntry[] }>(`/api/leaderboard?region=${regionFilter}`)
      .then((d) => setLeaderboard(d.leaderboard.slice(0, 5)))
      .catch(() => {});
    apiFetch<{ streams: StreamItem[] }>('/api/streams')
      .then((d) => setStreams(d.streams))
      .catch(() => {});
  }, [regionFilter]);

  return (
    <div className="arena-home">
      <section className="arena-hero">
        <img className="arena-hero-logo" src={sftLogo} alt="SFT" width={82} height={82}/>
        <h1>The Fortnite Esports<br/> Wager Platform</h1>
        <p>Join <strong>{stats?.players.toLocaleString() ?? '…'}</strong> other players competing in wager matches<br className="hidden sm:block"/> on Solana Fortnite Tokens.</p>
        <div className="arena-hero-actions"><Link to="/matches"><Swords size={16}/>Find Matches</Link><Link to="/leaderboard"><Trophy size={16}/>Leaderboard</Link></div>
        <div className="arena-metrics"><span><Swords/>{stats?.matchesPlayed ?? '—'} Wagers Played</span><i>•</i><span><Coins/>{stats ? formatSol(stats.totalPaidLamports,2) : '—'} SOL Winnings Paid</span><i>•</i><span><Radio/>{stats?.ongoingMatches ?? '—'} Ongoing Wagers</span></div>
      </section>
      {/* Authorized Live Streams Row (Reference Image 3 bottom section) */}
      <section className="arena-live">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-display font-bold text-white inline-block pb-1 border-b-2 border-[#6d4aff]">
              Live Wagers
            </h2>
            <button
              type="button"
              onClick={() => (user ? navigate('/profile/'+encodeURIComponent(user.username)+'?tab=linked') : openAuthModal('login'))}
              className="px-3 py-1 rounded-md bg-[#232a3f] hover:bg-[#2d3650] border border-[#323c58] text-xs font-semibold text-slate-200 flex items-center gap-1.5 cursor-pointer"
            >
              <Tv className="w-3.5 h-3.5 text-[#a970ff]" />
              Link Twitch
            </button>
          </div>

        </div>

        {streams.length === 0 && <div className="arena-stream-empty"><Tv size={46}/><strong>No live streams</strong><span>Try linking your Twitch and streaming</span></div>}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {streams.map((s) => {
            const art = getModeArt(s.game_mode);
            return (
              <div
                key={s.id}
                className="relative rounded-xl overflow-hidden bg-[#121623] border border-[#262e45] aspect-video group"
              >
                <img
                  src={art.img}
                  alt={s.channel_name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover opacity-55 group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d111b] via-[#0d111b]/30 to-transparent" />
                <div className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded bg-red-600 text-white text-[10px] font-bold uppercase tracking-wider">
                  LIVE
                </div>
                <div className="absolute top-2.5 right-2.5 px-2.5 py-0.5 rounded bg-[#6d4aff] text-white text-[11px] font-semibold">
                  @{s.channel_name}
                </div>
                <div className="absolute bottom-0 inset-x-0 p-3">
                  <div className="text-xs font-bold text-white truncate">{s.stream_title}</div>
                  <div className="text-[11px] text-slate-300 flex items-center justify-between mt-0.5 tabular-nums">
                    <span>{s.game_mode}</span>
                    <span>{s.viewer_count} viewers</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>
      {/* Open Wagers Preview */}
      <section className="arena-open mt-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-display font-bold text-white inline-block pb-1 border-b-2 border-[#6d4aff]">
            Open Wagers
          </h2>
          <Link to="/matches" className="text-xs font-semibold text-[#9d85ff] hover:text-white flex items-center gap-1">
            View All Matches <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {openMatches.length === 0 ? (
          <div className="p-8 rounded-xl bg-[#161b29] border border-[#232a3e] text-center">
            <p className="text-sm text-slate-300">No open matches right now in this region.</p>
            <Link to="/matches" className="inline-block mt-3 px-4 py-2 rounded-lg bg-[#6d4aff] text-xs font-semibold text-white">
              Create a Match
            </Link>
          </div>
        ) : (
          <div className="sft-match-grid">
            {openMatches.map((m) => (
              <MatchCard key={m.id} match={m} nowMs={nowMs} />
            ))}
          </div>
        )}
      </section>

      {/* Featured Tournaments + Leaderboard Preview */}
      <div className="mt-8 grid grid-cols-1 gap-6">
        <section className="arena-home-tournaments">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-display font-bold text-white inline-block pb-1 border-b-2 border-[#f5c542]">
              Featured Tournaments
            </h2>
            <Link to="/tournaments" className="text-xs font-semibold text-[#9d85ff] hover:text-white flex items-center gap-1">
              All Tournaments <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {tournaments.map(tournament=><TournamentCard key={tournament.id} tournament={tournament}
              serverTimeUtc={serverTimeUtc} onOpen={id=>navigate('/tournaments?id='+encodeURIComponent(id))}/>)}
          </div>
        </section>

        <section className="arena-home-leaderboard">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-display font-bold text-white inline-block pb-1 border-b-2 border-emerald-400">
              Top Competitors
            </h2>
            <Link to="/leaderboard" className="text-xs font-semibold text-[#9d85ff] hover:text-white flex items-center gap-1">
              Full Rankings <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="bg-[#181e2d] border border-[#262e45] rounded-xl overflow-hidden divide-y divide-[#232a3e]">
            {leaderboard.map((row) => (
              <Link
                key={row.username}
                to={`/profile/${row.username}`}
                className="px-4 py-3 flex items-center justify-between hover:bg-[#1e2538] transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span
                    className={`w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center tabular-nums ${
                      row.rank === 1
                        ? 'bg-[#f5c542]/20 text-[#f5c542]'
                        : row.rank === 2
                        ? 'bg-slate-300/20 text-slate-200'
                        : row.rank === 3
                        ? 'bg-amber-600/25 text-amber-400'
                        : 'bg-[#232a3e] text-slate-400'
                    }`}
                  >
                    {row.rank === 1 ? <Crown className="w-3.5 h-3.5" /> : row.rank}
                  </span>
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-white truncate">{row.username}</div>
                    <div className="text-[11px] text-slate-400">
                      {row.competitiveRegion} · {row.wins} Wins
                    </div>
                  </div>
                </div>
                <div className="text-right tabular-nums shrink-0">
                  <div className="text-xs font-bold text-[#9d85ff]">{row.elo} ELO</div>
                  <div className="text-[11px] text-[#f5c542]">{formatSol(row.earnedLamports, 2)} SOL</div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </div>

    </div>
  );
}
