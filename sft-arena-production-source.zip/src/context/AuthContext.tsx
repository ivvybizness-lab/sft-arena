import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from 'react';
import { apiFetch } from '../lib/api';
import { readOnlyPreview, pollingTransport } from '../lib/preview';

export interface UserBalance {
  available_lamports: number;
  reserved_lamports: number;
  frozen_lamports: number;
}

export interface AuthUser {
  id: string;
  username: string;
  displayName: string;
  email: string;
  emailVerified: boolean;
  phone: string | null;
  phoneVerified: boolean;
  role: 'player' | 'moderator' | 'finance' | 'owner';
  country: string;
  competitiveRegion: 'NAE' | 'NAC' | 'NAW' | 'EU';
  ageVerified: boolean;
  ageAttested: boolean;
  epicDisplayName: string;
  epicAccountId: string;
  status: 'active' | 'restricted' | 'suspended' | 'banned';
  referralCode: string;
  acquisitionSource: string;
  twitchChannel: string | null;
  twitchAuthorized: boolean;
  avatarUrl: string;
  profileBanner?: string;
  profilePortrait?: number | null;
  googleConnected?: boolean;
  activeTitle: string;
  activeBorder: string;
  payoutAddress: string;
  wins: number;
  losses: number;
  elo: number;
  xp: number;
  isDemo: boolean;
  createdAt: string;
  balance: UserBalance;
}

export interface NotificationItem {
  id: string;
  category: string;
  title: string;
  body: string;
  link_url: string;
  is_read: number;
  created_at: string;
}

interface ToastItem {
  id: string;
  message: string;
  type: 'info' | 'success' | 'error';
}

interface AuthContextValue {
  user: AuthUser | null;
  loading: boolean;
  regionFilter: string;
  setRegionFilter: (r: string) => void;
  notifications: NotificationItem[];
  unreadCount: number;
  markNotificationsRead: () => Promise<void>;
  refreshUser: () => Promise<void>;
  logout: () => Promise<void>;
  authModalOpen: boolean;
  authModalMode: 'login' | 'register';
  openAuthModal: (mode?: 'login' | 'register') => void;
  closeAuthModal: () => void;
  notify: (message: string, type?: 'info' | 'success' | 'error') => void;
  wsConnected: boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [regionFilter, setRegionFilter] = useState('ALL');
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [wsConnected, setWsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);

  const notify = useCallback((message: string, type: 'info' | 'success' | 'error' = 'info') => {
    const id = Math.random().toString(36).slice(2);
    setToasts((prev) => [...prev.slice(-3), { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4200);
  }, []);

  const fetchNotifications = useCallback(async () => {
    try {
      const data = await apiFetch<{ notifications: NotificationItem[]; unreadCount: number }>('/api/notifications');
      setNotifications(data.notifications);
      setUnreadCount(data.unreadCount);
    } catch {
      // ignore if logged out
    }
  }, []);

  const refreshUser = useCallback(async () => {
    try {
      const data = await apiFetch<{ user: AuthUser | null }>('/api/auth/me');
      setUser(data.user);
      if (data.user) {
        fetchNotifications();
      } else {
        setNotifications([]);
        setUnreadCount(0);
      }
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, [fetchNotifications]);

  useEffect(() => {
    refreshUser();
  }, [refreshUser]);

  // Keep a lightweight global WS for balance/notification updates
  useEffect(() => {
    if (readOnlyPreview) return;
    if (pollingTransport) {
      if (!user) return;
      const timer = window.setInterval(() => { if (!document.hidden) refreshUser(); }, 30000);
      return () => window.clearInterval(timer);
    }
    const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${proto}//${window.location.host}/ws`);
    wsRef.current = ws;

    ws.onopen = () => setWsConnected(true);
    ws.onclose = () => setWsConnected(false);
    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data) as { type: string };
        if (msg.type === 'matches_updated' && user) {
          refreshUser();
        }
      } catch {
        // ignore
      }
    };

    return () => {
      ws.close();
    };
  }, [user?.id, refreshUser]);

  const markNotificationsRead = useCallback(async () => {
    if (!user) return;
    try {
      await apiFetch('/api/notifications/read', { method: 'POST' });
      setUnreadCount(0);
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: 1 })));
    } catch {
      // ignore
    }
  }, [user]);

  const logout = useCallback(async () => {
    await apiFetch('/api/auth/logout', { method: 'POST' });
    setUser(null);
    setNotifications([]);
    setUnreadCount(0);
    notify('Signed out cleanly.', 'info');
  }, [notify]);

  const openAuthModal = useCallback((mode: 'login' | 'register' = 'login') => {
    if (readOnlyPreview) {
      notify('Accounts and live actions require a connected SFT server.');
      return;
    }
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  }, [notify]);

  const closeAuthModal = useCallback(() => setAuthModalOpen(false), []);

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        regionFilter,
        setRegionFilter,
        notifications,
        unreadCount,
        markNotificationsRead,
        refreshUser,
        logout,
        authModalOpen,
        authModalMode,
        openAuthModal,
        closeAuthModal,
        notify,
        wsConnected,
      }}
    >
      {children}
      {/* Toast notification stack */}
      <div className="fixed bottom-4 right-4 z-[90] flex flex-col gap-2 max-w-sm pointer-events-none">
        {toasts.map((t) => (
          <div
            key={t.id}
            role="status"
            className={`pointer-events-auto px-4 py-3 rounded-lg border text-sm font-medium shadow-xl backdrop-blur-md transition-all ${
              t.type === 'error'
                ? 'bg-[#2a161b]/95 border-red-500/40 text-red-100'
                : t.type === 'success'
                ? 'bg-[#142720]/95 border-emerald-500/40 text-emerald-100'
                : 'bg-[#1a2032]/95 border-[#6d4aff]/40 text-slate-100'
            }`}
          >
            {t.message}
          </div>
        ))}
      </div>
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
