export const readOnlyPreview = import.meta.env.MODE === 'preview';
export const pollingTransport = import.meta.env.VITE_SFT_REALTIME === 'polling';

type Row = Record<string, unknown>;
type Resource = Record<string, unknown> & {
  matches?: Row[];
  tournaments?: Row[];
  leaderboard?: Row[];
};

let snapshot: Promise<Record<string, Resource>> | undefined;

export async function readPreview(url: string, method = 'GET'): Promise<unknown> {
  if (method.toUpperCase() !== 'GET') throw new Error('This preview uses read-only demo data.');
  const { pathname, searchParams } = new URL(url, window.location.origin);
  if (pathname === '/api/auth/me') return { user: null };
  snapshot ??= fetch('/preview-data.json').then(res => {
    if (!res.ok) throw new Error('Demo data is unavailable.');
    return res.json();
  }).catch(error => {
    snapshot = undefined;
    throw error;
  });
  const data = await snapshot;
  const search = (searchParams.get('search') || '').trim().toLowerCase();
  const includes = (...values: unknown[]) => values.some(value =>
    typeof value === 'string' && value.toLowerCase().includes(search));
  const accepts = (key: string, value: unknown) => {
    const requested = searchParams.get(key);
    return !requested || requested === 'ALL' || requested === 'None' || requested === String(value);
  };

  if (pathname === '/api/matches') {
    const tab = searchParams.get('tab') || 'open';
    const rows = data[pathname].matches ?? [];
    const matches = rows.filter(row => {
      if (tab === 'my' || (tab === 'open' && row.status !== 'Waiting')) return false;
      if (tab === 'ongoing' && !['Ready','In Progress','Disputed'].includes(String(row.status))) return false;
      if (tab === 'ranked' && (!row.is_ranked || row.status === 'Cancelled')) return false;
      const firstTo = Number(searchParams.get('firstTo'));
      const participants = Array.isArray(row.participants) ? row.participants as Row[] : [];
      return accepts('region', row.region) && accepts('mode', row.mode) &&
        accepts('format', row.format) && accepts('platform', row.platform) &&
        (!firstTo || firstTo === row.first_to) &&
        (!search || includes(row.id, row.title, ...participants.map(p => p.username_snapshot)));
    });
    return { ...data[pathname], matches };
  }
  if (pathname === '/api/tournaments') {
    const views: Record<string, string[]> = {
      upcoming: ['Upcoming','Registration Open','Check-In'], live: ['Live'], past: ['Completed','Cancelled'],
    };
    const statuses = views[searchParams.get('view') || 'all'];
    const tournaments = (data[pathname].tournaments ?? []).filter(row => accepts('region', row.region) &&
      (!statuses || statuses.includes(String(row.status))) && (!search || includes(row.title, row.mode)));
    return { ...data[pathname], tournaments };
  }
  if (pathname === '/api/leaderboard') {
    const leaderboard = (data[pathname].leaderboard ?? []).filter(row => accepts('region', row.competitiveRegion))
      .map((row, index) => ({ ...row, rank: index + 1 }));
    return { leaderboard };
  }
  if (pathname === '/api/users/search') {
    const query = (searchParams.get('q') || '').trim().toLowerCase();
    return { users: data['/api/leaderboard'].leaderboard?.filter(row =>
      [row.username, row.displayName, row.epicDisplayName].some(value =>
        typeof value === 'string' && value.toLowerCase().includes(query))) ?? [] };
  }
  if (Object.hasOwn(data, pathname)) return data[pathname];
  throw new Error('This feature requires a connected SFT server.');
}
