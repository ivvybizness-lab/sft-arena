import boxFightsImg from '../assets/images/mode_box_fights_1795329561038.jpg';
import zoneWarsImg from '../assets/images/mode_zone_wars_1795329560681.jpg';
import realisticsImg from '../assets/images/mode_realistics_1795329560928.jpg';
import buildFightsImg from '../assets/images/mode_build_fights_1795329561418.jpg';
import pieceControlImg from '../assets/images/mode_piece_control_1795329574782.jpg';
import zeroBuildImg from '../assets/images/mode_zero_build_1795329575448.jpg';
import tournamentBannerImg from '../assets/images/tournament_banner_sft_1795329561594.jpg';

export const LAMPORTS_PER_SOL = 1_000_000_000;

export function formatSol(lamports: number | null | undefined, decimals = 4): string {
  const val = Number(lamports ?? 0) / LAMPORTS_PER_SOL;
  return val.toFixed(decimals);
}

export function formatSolExactDeposit(lamports: number | null | undefined): string {
  const val = Number(lamports ?? 0) / LAMPORTS_PER_SOL;
  return val.toFixed(9);
}

export function formatTimeAgo(iso: string | null | undefined): string {
  if (!iso) return '—';
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.max(0, Math.floor(diffMs / 60000));
  if (mins < 1) return 'Just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  return `${days}d ago`;
}

export function formatCountdownUntil(targetIso: string, serverNowIso?: string): string {
  const now = serverNowIso ? new Date(serverNowIso).getTime() : Date.now();
  const diff = new Date(targetIso).getTime() - now;
  if (diff <= 0) return 'Started / Closed';
  const totalMins = Math.floor(diff / 60000);
  const days = Math.floor(totalMins / (60 * 24));
  const hrs = Math.floor((totalMins % (60 * 24)) / 60);
  const mins = totalMins % 60;
  if (days > 0) return `${days}d ${hrs}h`;
  if (hrs > 0) return `${hrs}h ${mins}m`;
  return `${mins}m`;
}

export function formatUtcTimestamp(iso: string | null | undefined): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toISOString().replace('T', ' ').slice(0, 16) + ' UTC';
}

export function formatDurationShort(seconds: number): string {
  if (!seconds || seconds <= 0) return '0s';
  const mins = Math.floor(seconds / 60);
  const secs = Math.round(seconds % 60);
  if (mins >= 60) {
    return `${Math.floor(mins / 60)}h ${mins % 60}m`;
  }
  return mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
}

export function formatRegionFull(region: string): string {
  switch (region) {
    case 'NAE':
      return 'NA East';
    case 'NAC':
      return 'NA Central';
    case 'NAW':
      return 'NA West';
    case 'EU':
      return 'Europe';
    default:
      return region;
  }
}

export function formatMatchTimerMMSS(iso: string | null | undefined, nowMs = Date.now()): string {
  if (!iso) return '00:00';
  const createdMs = new Date(iso).getTime();
  if (Number.isNaN(createdMs)) return '00:00';
  const elapsedSec = Math.max(0, Math.floor((nowMs - createdMs) / 1000));
  const mins = Math.min(99, Math.floor(elapsedSec / 60));
  const secs = elapsedSec % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export const MODE_ASSETS: Record<string, { img: string; gradient: string; accent: string }> = {
  'Box Fights': {
    img: boxFightsImg,
    gradient: 'from-[#a67e26]/55 via-[#584723]/35 to-[#1e2738]',
    accent: '#eab308',
  },
  'Zone Wars': {
    img: zoneWarsImg,
    gradient: 'from-[#287b8f]/55 via-[#1f4c5e]/35 to-[#1e2738]',
    accent: '#06b6d4',
  },
  Realistics: {
    img: realisticsImg,
    gradient: 'from-[#24912d]/55 via-[#1d532a]/35 to-[#1e2738]',
    accent: '#22c55e',
  },
  'Build Fights': {
    img: buildFightsImg,
    gradient: 'from-[#6348c7]/55 via-[#302863]/35 to-[#1e2738]',
    accent: '#7b5cff',
  },
  'Piece Control': {
    img: pieceControlImg,
    gradient: 'from-[#a12e4e]/55 via-[#4f2035]/35 to-[#1e2738]',
    accent: '#f43f5e',
  },
  'Zero Build': {
    img: zeroBuildImg,
    gradient: 'from-[#2473a3]/55 via-[#1c435f]/35 to-[#1e2738]',
    accent: '#38bdf8',
  },
};

export const TOURNAMENT_BANNER = tournamentBannerImg;

export function getModeArt(mode: string) {
  return MODE_ASSETS[mode] || MODE_ASSETS['Zone Wars'];
}
