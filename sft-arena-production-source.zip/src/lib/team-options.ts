export const teamIcons = ['shield', 'bolt', 'crown', 'target', 'trophy', 'star'] as const;
export const teamColours = {
  gold: '#f5c542',
  violet: '#a78bfa',
  cyan: '#22d3ee',
  rose: '#fb7185',
  emerald: '#34d399',
} as const;
