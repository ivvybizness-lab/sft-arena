import { readOnlyPreview, readPreview } from './preview';

export async function apiFetch<T = unknown>(url: string, options: RequestInit = {}): Promise<T> {
  if (readOnlyPreview) return await readPreview(url, options.method) as T;
  const isFormData = typeof FormData !== 'undefined' && options.body instanceof FormData;
  const headers: Record<string, string> = {
    ...(isFormData ? {} : { 'Content-Type': 'application/json' }),
    ...(options.headers as Record<string, string> | undefined),
  };

  const res = await fetch(url, {
    ...options,
    headers,
    credentials: 'include',
  });

  const text = await res.text();
  let data: unknown = {};
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = { error: text };
    }
  }

  if (!res.ok) {
    const errMsg = (data as { error?: string })?.error || `Request failed (${res.status})`;
    throw new Error(errMsg);
  }

  return data as T;
}
