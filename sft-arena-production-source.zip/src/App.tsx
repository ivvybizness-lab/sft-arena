import React from 'react';
import { BrowserRouter, HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import MatchesPage from './pages/MatchesPage';
import MatchRoomPage from './pages/MatchRoomPage';
import TournamentsPage from './pages/TournamentsPage';
import LeaderboardPage from './pages/LeaderboardPage';
import ShopPage from './pages/ShopPage';
import TeamsPage from './pages/TeamsPage';
import RewardsPage from './pages/RewardsPage';
import ProfilePage from './pages/ProfilePage';
import RulesPage from './pages/RulesPage';
import SupportPage from './pages/SupportPage';
import AdminPlayerPage from './pages/AdminPlayerPage';
import AdminDashboardPage from './pages/AdminDashboardPage';
import StaffConsolePage from './pages/StaffConsolePage';

import { readOnlyPreview } from './lib/preview';

export default function App() {
  const Router = readOnlyPreview ? HashRouter : BrowserRouter;
  return (
    <Router>
      <AuthProvider>
        <Layout>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/matches" element={<MatchesPage />} />
            <Route path="/matches/:id" element={<MatchRoomPage />} />
            <Route path="/tournaments" element={<TournamentsPage />} />
            <Route path="/leaderboard" element={<LeaderboardPage />} />
            <Route path="/shop" element={<ShopPage />} />
            <Route path="/teams" element={<TeamsPage />} />
            <Route path="/rewards" element={<RewardsPage />} />
            <Route path="/profile/:username" element={<ProfilePage />} />
            <Route path="/rules" element={<RulesPage />} />
            <Route path="/support" element={<SupportPage />} />
            <Route path="/staff" element={<AdminDashboardPage legacy={StaffConsolePage} />} />
            <Route path="/staff/players/:id" element={<AdminPlayerPage />} />
            <Route path="/admin" element={<Navigate to="/staff" replace />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Layout>
      </AuthProvider>
    </Router>
  );
}
